var ev = Object.defineProperty;
var tv = (t, e, n) => e in t ? ev(t, e, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: n
}) : t[e] = n;
var ke = (t, e, n) => (tv(t, typeof e != "symbol" ? e + "" : e, n), n);
import {
    L as nv,
    j as v,
    u as hr,
    a as kn,
    m as wr,
    s as to,
    e as Ur,
    B as rv,
    R as md,
    K as iv,
    b as er,
    E as Ah,
    c as ov,
    N as sv,
    V as av,
    T as lv,
    H as cv,
    d as uv,
    M as fv,
    f as dv,
    Q as pv,
    g as hv,
    S as mv,
    F as gv,
    h as vv,
    i as yv,
    C as xv,
    k as bv
} from "./fiber-NCUsL-sL.js";
import {
    r as u,
    _ as Xn,
    a as cf,
    b as Fh,
    R as j,
    d as wv,
    P as sn,
    g as cs,
    u as kh,
    c as uf,
    e as Xl,
    T as _v,
    f as Dv,
    h as Sv,
    i as Cv,
    m as Ev,
    j as xc,
    k as Tv
} from "./react-ZVDsBwBb.js";
import {
    u as Pv,
    l as Gt,
    c as Kt,
    S as gd,
    a as Rv,
    b as Mv,
    d as $v
} from "./utils-4sL86zKL.js";
import {
    c as us
} from "./store-cPCsoetY.js";
import {
    a$ as Av,
    m as Fv,
    s as ff,
    aO as kv,
    V as dt,
    E as Ov,
    Q as Yo,
    Y as He,
    az as Di,
    w as Ti,
    aw as df,
    aN as Oh,
    ax as pf,
    b0 as jv,
    b1 as Lv,
    b2 as Nv,
    r as xr,
    M as qc,
    ap as yl,
    y as Nn,
    e as jh,
    u as Kc,
    ag as zv,
    af as ql,
    Z as Iv,
    as as Zc,
    b3 as Bv,
    b4 as bc,
    a2 as Ui,
    f as ai,
    b5 as li,
    aH as al,
    b6 as Wv,
    X as Vv,
    aC as Uv,
    b7 as Hv,
    b8 as Gv,
    b9 as Kl,
    an as ha,
    ao as ns,
    P as hf,
    j as ma,
    D as Yv,
    aZ as Xv,
    S as Lh,
    G as mf,
    aM as Nh,
    aL as qv,
    a6 as Qc,
    at as vd,
    ar as Kv,
    am as Zv,
    a7 as Qv,
    ba as Jv
} from "./three-H0uqkCM-.js";
import {
    D as ey,
    G as ty,
    R as ny
} from "./three-stdlib-orAABGcX.js";
import {
    g as he
} from "./gsap-nk37oyWQ.js";
(function() {
    const e = document.createElement("link").relList;
    if (e && e.supports && e.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const o of i)
            if (o.type === "childList")
                for (const s of o.addedNodes) s.tagName === "LINK" && s.rel === "modulepreload" && r(s)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(i) {
        const o = {};
        return i.integrity && (o.integrity = i.integrity), i.referrerPolicy && (o.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? o.credentials = "include" : i.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const o = n(i);
        fetch(i.href, o)
    }
})();

function ry(t, e) {
    typeof t == "function" ? t(e) : t != null && (t.current = e)
}

function zh(...t) {
    return e => t.forEach(n => ry(n, e))
}

function fs(...t) {
    return u.useCallback(zh(...t), t)
}
const Ih = u.forwardRef((t, e) => {
    const {
        children: n,
        ...r
    } = t, i = u.Children.toArray(n), o = i.find(iy);
    if (o) {
        const s = o.props.children,
            a = i.map(l => l === o ? u.Children.count(s) > 1 ? u.Children.only(null) : u.isValidElement(s) ? s.props.children : null : l);
        return u.createElement(Jc, Xn({}, r, {
            ref: e
        }), u.isValidElement(s) ? u.cloneElement(s, void 0, a) : null)
    }
    return u.createElement(Jc, Xn({}, r, {
        ref: e
    }), n)
});
Ih.displayName = "Slot";
const Jc = u.forwardRef((t, e) => {
    const {
        children: n,
        ...r
    } = t;
    return u.isValidElement(n) ? u.cloneElement(n, { ...oy(r, n.props),
        ref: e ? zh(e, n.ref) : n.ref
    }) : u.Children.count(n) > 1 ? u.Children.only(null) : null
});
Jc.displayName = "SlotClone";
const Bh = ({
    children: t
}) => u.createElement(u.Fragment, null, t);

function iy(t) {
    return u.isValidElement(t) && t.type === Bh
}

function oy(t, e) {
    const n = { ...e
    };
    for (const r in e) {
        const i = t[r],
            o = e[r];
        /^on[A-Z]/.test(r) ? i && o ? n[r] = (...a) => {
            o(...a), i(...a)
        } : i && (n[r] = i) : r === "style" ? n[r] = { ...i,
            ...o
        } : r === "className" && (n[r] = [i, o].filter(Boolean).join(" "))
    }
    return { ...t,
        ...n
    }
}
const sy = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"],
    Ro = sy.reduce((t, e) => {
        const n = u.forwardRef((r, i) => {
            const {
                asChild: o,
                ...s
            } = r, a = o ? Ih : e;
            return u.useEffect(() => {
                window[Symbol.for("radix-ui")] = !0
            }, []), u.createElement(a, Xn({}, s, {
                ref: i
            }))
        });
        return n.displayName = `Primitive.${e}`, { ...t,
            [e]: n
        }
    }, {});

function ay(t, e) {
    t && cf.flushSync(() => t.dispatchEvent(e))
}
const ly = u.forwardRef((t, e) => {
        var n;
        const {
            container: r = globalThis == null || (n = globalThis.document) === null || n === void 0 ? void 0 : n.body,
            ...i
        } = t;
        return r ? Fh.createPortal(u.createElement(Ro.div, Xn({}, i, {
            ref: e
        })), r) : null
    }),
    cy = ly;
var yd = Object.prototype.hasOwnProperty;

function ea(t, e) {
    var n, r;
    if (t === e) return !0;
    if (t && e && (n = t.constructor) === e.constructor) {
        if (n === Date) return t.getTime() === e.getTime();
        if (n === RegExp) return t.toString() === e.toString();
        if (n === Array) {
            if ((r = t.length) === e.length)
                for (; r-- && ea(t[r], e[r]););
            return r === -1
        }
        if (!n || typeof t == "object") {
            r = 0;
            for (n in t)
                if (yd.call(t, n) && ++r && !yd.call(e, n) || !(n in e) || !ea(t[n], e[n])) return !1;
            return Object.keys(e).length === r
        }
    }
    return t !== t && e !== e
}

function ga(t, e) {
    if (Object.is(t, e)) return !0;
    if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
    const n = Object.keys(t);
    if (n.length !== Object.keys(e).length) return !1;
    for (let r = 0; r < n.length; r++)
        if (!Object.prototype.hasOwnProperty.call(e, n[r]) || !Object.is(t[n[r]], e[n[r]])) return !1;
    return !0
}
var Zl = function(e, n, r, i) {
    this.name = e, this.fn = n, this.args = r, this.modifiers = i
};
Zl.prototype._test = function(e) {
    var n = this.fn;
    try {
        Xo(this.modifiers.slice(), n, this)(e)
    } catch {
        n = function() {
            return !1
        }
    }
    try {
        return Xo(this.modifiers.slice(), n, this)(e)
    } catch {
        return !1
    }
};
Zl.prototype._check = function(e) {
    try {
        Xo(this.modifiers.slice(), this.fn, this)(e)
    } catch {
        if (Xo(this.modifiers.slice(), function(r) {
                return r
            }, this)(!1)) return
    }
    if (!Xo(this.modifiers.slice(), this.fn, this)(e)) throw null
};
Zl.prototype._testAsync = function(e) {
    var n = this;
    return new Promise(function(r, i) {
        Vh(n.modifiers.slice(), n.fn, n)(e).then(function(o) {
            o ? r(e) : i(null)
        }).catch(function(o) {
            return i(o)
        })
    })
};

function Wh(t, e) {
    return e === void 0 && (e = "simple"), typeof t == "object" ? t[e] : t
}

function Xo(t, e, n) {
    if (t.length) {
        var r = t.shift(),
            i = Xo(t, e, n);
        return r.perform(i, n)
    } else return Wh(e)
}

function Vh(t, e, n) {
    if (t.length) {
        var r = t.shift(),
            i = Vh(t, e, n);
        return r.performAsync(i, n)
    } else return function(o) {
        return Promise.resolve(Wh(e, "async")(o))
    }
}
var uy = function(e, n, r) {
        this.name = e, this.perform = n, this.performAsync = r
    },
    gf = function(t) {
        function e(n, r, i, o) {
            for (var s = [], a = arguments.length - 4; a-- > 0;) s[a] = arguments[a + 4];
            t.call(this, s), t.captureStackTrace && t.captureStackTrace(this, e), this.rule = n, this.value = r, this.cause = i, this.target = o
        }
        return t && (e.__proto__ = t), e.prototype = Object.create(t && t.prototype), e.prototype.constructor = e, e
    }(Error),
    pi = function(e, n) {
        e === void 0 && (e = []), n === void 0 && (n = []), this.chain = e, this.nextRuleModifiers = n
    };
pi.prototype._applyRule = function(e, n) {
    var r = this;
    return function() {
        for (var i = [], o = arguments.length; o--;) i[o] = arguments[o];
        return r.chain.push(new Zl(n, e.apply(r, i), i, r.nextRuleModifiers)), r.nextRuleModifiers = [], r
    }
};
pi.prototype._applyModifier = function(e, n) {
    return this.nextRuleModifiers.push(new uy(n, e.simple, e.async)), this
};
pi.prototype._clone = function() {
    return new pi(this.chain.slice(), this.nextRuleModifiers.slice())
};
pi.prototype.test = function(e) {
    return this.chain.every(function(n) {
        return n._test(e)
    })
};
pi.prototype.testAll = function(e) {
    var n = [];
    return this.chain.forEach(function(r) {
        try {
            r._check(e)
        } catch (i) {
            n.push(new gf(r, e, i))
        }
    }), n
};
pi.prototype.check = function(e) {
    this.chain.forEach(function(n) {
        try {
            n._check(e)
        } catch (r) {
            throw new gf(n, e, r)
        }
    })
};
pi.prototype.testAsync = function(e) {
    var n = this;
    return new Promise(function(r, i) {
        Uh(e, n.chain.slice(), r, i)
    })
};

function Uh(t, e, n, r) {
    if (e.length) {
        var i = e.shift();
        i._testAsync(t).then(function() {
            Uh(t, e, n, r)
        }, function(o) {
            r(new gf(i, t, o))
        })
    } else n(t)
}
var xd = function(t, e) {
    return e && typeof t == "string" && t.trim().length === 0 ? !0 : t == null
};

function fy(t, e) {
    return e === void 0 && (e = !1), {
        simple: function(n) {
            return xd(n, e) || t.check(n) === void 0
        },
        async: function(n) {
            return xd(n, e) || t.testAsync(n)
        }
    }
}

function br() {
    return typeof Proxy < "u" ? Hh(new pi) : eu(new pi)
}
var ta = {};
br.extend = function(t) {
    Object.assign(ta, t)
};
br.clearCustomRules = function() {
    ta = {}
};

function Hh(t) {
    return new Proxy(t, {
        get: function(n, r) {
            if (r in n) return n[r];
            var i = Hh(t._clone());
            if (r in xl) return i._applyModifier(xl[r], r);
            if (r in ta) return i._applyRule(ta[r], r);
            if (r in tu) return i._applyRule(tu[r], r)
        }
    })
}

function eu(t) {
    var e = function(i, o) {
            return Object.keys(i).forEach(function(s) {
                o[s] = function() {
                    for (var a = [], l = arguments.length; l--;) a[l] = arguments[l];
                    var c = eu(o._clone()),
                        d = c._applyRule(i[s], s).apply(void 0, a);
                    return d
                }
            }), o
        },
        n = e(tu, t),
        r = e(ta, n);
    return Object.keys(xl).forEach(function(i) {
        Object.defineProperty(r, i, {
            get: function() {
                var o = eu(r._clone());
                return o._applyModifier(xl[i], i)
            }
        })
    }), r
}
var xl = {
    not: {
        simple: function(t) {
            return function(e) {
                return !t(e)
            }
        },
        async: function(t) {
            return function(e) {
                return Promise.resolve(t(e)).then(function(n) {
                    return !n
                }).catch(function() {
                    return !0
                })
            }
        }
    },
    some: {
        simple: function(t) {
            return function(e) {
                return ka(e).some(function(n) {
                    try {
                        return t(n)
                    } catch {
                        return !1
                    }
                })
            }
        },
        async: function(t) {
            return function(e) {
                return Promise.all(ka(e).map(function(n) {
                    try {
                        return t(n).catch(function() {
                            return !1
                        })
                    } catch {
                        return !1
                    }
                })).then(function(n) {
                    return n.some(Boolean)
                })
            }
        }
    },
    every: {
        simple: function(t) {
            return function(e) {
                return e !== !1 && ka(e).every(t)
            }
        },
        async: function(t) {
            return function(e) {
                return Promise.all(ka(e).map(t)).then(function(n) {
                    return n.every(Boolean)
                })
            }
        }
    },
    strict: {
        simple: function(t, e) {
            return function(n) {
                return bd(e) && n && typeof n == "object" ? Object.keys(e.args[0]).length === Object.keys(n).length && t(n) : t(n)
            }
        },
        async: function(t, e) {
            return function(n) {
                return Promise.resolve(t(n)).then(function(r) {
                    return bd(e) && n && typeof n == "object" ? Object.keys(e.args[0]).length === Object.keys(n).length && r : r
                }).catch(function() {
                    return !1
                })
            }
        }
    }
};

function bd(t) {
    return t && t.name === "schema" && t.args.length > 0 && typeof t.args[0] == "object"
}

function ka(t) {
    return typeof t == "string" ? t.split("") : t
}
var tu = {
    equal: function(t) {
        return function(e) {
            return e == t
        }
    },
    exact: function(t) {
        return function(e) {
            return e === t
        }
    },
    number: function(t) {
        return t === void 0 && (t = !0),
            function(e) {
                return typeof e == "number" && (t || isFinite(e))
            }
    },
    integer: function() {
        return function(t) {
            var e = Number.isInteger || dy;
            return e(t)
        }
    },
    numeric: function() {
        return function(t) {
            return !isNaN(parseFloat(t)) && isFinite(t)
        }
    },
    string: function() {
        return Mo("string")
    },
    boolean: function() {
        return Mo("boolean")
    },
    undefined: function() {
        return Mo("undefined")
    },
    null: function() {
        return Mo("null")
    },
    array: function() {
        return Mo("array")
    },
    object: function() {
        return Mo("object")
    },
    instanceOf: function(t) {
        return function(e) {
            return e instanceof t
        }
    },
    pattern: function(t) {
        return function(e) {
            return t.test(e)
        }
    },
    lowercase: function() {
        return function(t) {
            return typeof t == "boolean" || t === t.toLowerCase() && t.trim() !== ""
        }
    },
    uppercase: function() {
        return function(t) {
            return t === t.toUpperCase() && t.trim() !== ""
        }
    },
    vowel: function() {
        return function(t) {
            return /^[aeiou]+$/i.test(t)
        }
    },
    consonant: function() {
        return function(t) {
            return /^(?=[^aeiou])([a-z]+)$/i.test(t)
        }
    },
    first: function(t) {
        return function(e) {
            return e[0] == t
        }
    },
    last: function(t) {
        return function(e) {
            return e[e.length - 1] == t
        }
    },
    empty: function() {
        return function(t) {
            return t.length === 0
        }
    },
    length: function(t, e) {
        return function(n) {
            return n.length >= t && n.length <= (e || t)
        }
    },
    minLength: function(t) {
        return function(e) {
            return e.length >= t
        }
    },
    maxLength: function(t) {
        return function(e) {
            return e.length <= t
        }
    },
    negative: function() {
        return function(t) {
            return t < 0
        }
    },
    positive: function() {
        return function(t) {
            return t >= 0
        }
    },
    between: function(t, e) {
        return function(n) {
            return n >= t && n <= e
        }
    },
    range: function(t, e) {
        return function(n) {
            return n >= t && n <= e
        }
    },
    lessThan: function(t) {
        return function(e) {
            return e < t
        }
    },
    lessThanOrEqual: function(t) {
        return function(e) {
            return e <= t
        }
    },
    greaterThan: function(t) {
        return function(e) {
            return e > t
        }
    },
    greaterThanOrEqual: function(t) {
        return function(e) {
            return e >= t
        }
    },
    even: function() {
        return function(t) {
            return t % 2 === 0
        }
    },
    odd: function() {
        return function(t) {
            return t % 2 !== 0
        }
    },
    includes: function(t) {
        return function(e) {
            return ~e.indexOf(t)
        }
    },
    schema: function(t) {
        return py(t)
    },
    passesAnyOf: function() {
        for (var t = [], e = arguments.length; e--;) t[e] = arguments[e];
        return function(n) {
            return t.some(function(r) {
                return r.test(n)
            })
        }
    },
    optional: fy
};

function Mo(t) {
    return function(e) {
        return Array.isArray(e) && t === "array" || e === null && t === "null" || typeof e === t
    }
}

function dy(t) {
    return typeof t == "number" && isFinite(t) && Math.floor(t) === t
}

function py(t) {
    return {
        simple: function(e) {
            var n = [];
            if (Object.keys(t).forEach(function(r) {
                    var i = t[r];
                    try {
                        i.check((e || {})[r])
                    } catch (o) {
                        o.target = r, n.push(o)
                    }
                }), n.length > 0) throw n;
            return !0
        },
        async: function(e) {
            var n = [],
                r = Object.keys(t).map(function(i) {
                    var o = t[i];
                    return o.testAsync((e || {})[i]).catch(function(s) {
                        s.target = i, n.push(s)
                    })
                });
            return Promise.all(r).then(function() {
                if (n.length > 0) throw n;
                return !0
            })
        }
    }
}
var en = "colors",
    rr = "sizes",
    Ie = "space",
    hy = {
        gap: Ie,
        gridGap: Ie,
        columnGap: Ie,
        gridColumnGap: Ie,
        rowGap: Ie,
        gridRowGap: Ie,
        inset: Ie,
        insetBlock: Ie,
        insetBlockEnd: Ie,
        insetBlockStart: Ie,
        insetInline: Ie,
        insetInlineEnd: Ie,
        insetInlineStart: Ie,
        margin: Ie,
        marginTop: Ie,
        marginRight: Ie,
        marginBottom: Ie,
        marginLeft: Ie,
        marginBlock: Ie,
        marginBlockEnd: Ie,
        marginBlockStart: Ie,
        marginInline: Ie,
        marginInlineEnd: Ie,
        marginInlineStart: Ie,
        padding: Ie,
        paddingTop: Ie,
        paddingRight: Ie,
        paddingBottom: Ie,
        paddingLeft: Ie,
        paddingBlock: Ie,
        paddingBlockEnd: Ie,
        paddingBlockStart: Ie,
        paddingInline: Ie,
        paddingInlineEnd: Ie,
        paddingInlineStart: Ie,
        top: Ie,
        right: Ie,
        bottom: Ie,
        left: Ie,
        scrollMargin: Ie,
        scrollMarginTop: Ie,
        scrollMarginRight: Ie,
        scrollMarginBottom: Ie,
        scrollMarginLeft: Ie,
        scrollMarginX: Ie,
        scrollMarginY: Ie,
        scrollMarginBlock: Ie,
        scrollMarginBlockEnd: Ie,
        scrollMarginBlockStart: Ie,
        scrollMarginInline: Ie,
        scrollMarginInlineEnd: Ie,
        scrollMarginInlineStart: Ie,
        scrollPadding: Ie,
        scrollPaddingTop: Ie,
        scrollPaddingRight: Ie,
        scrollPaddingBottom: Ie,
        scrollPaddingLeft: Ie,
        scrollPaddingX: Ie,
        scrollPaddingY: Ie,
        scrollPaddingBlock: Ie,
        scrollPaddingBlockEnd: Ie,
        scrollPaddingBlockStart: Ie,
        scrollPaddingInline: Ie,
        scrollPaddingInlineEnd: Ie,
        scrollPaddingInlineStart: Ie,
        fontSize: "fontSizes",
        background: en,
        backgroundColor: en,
        backgroundImage: en,
        borderImage: en,
        border: en,
        borderBlock: en,
        borderBlockEnd: en,
        borderBlockStart: en,
        borderBottom: en,
        borderBottomColor: en,
        borderColor: en,
        borderInline: en,
        borderInlineEnd: en,
        borderInlineStart: en,
        borderLeft: en,
        borderLeftColor: en,
        borderRight: en,
        borderRightColor: en,
        borderTop: en,
        borderTopColor: en,
        caretColor: en,
        color: en,
        columnRuleColor: en,
        fill: en,
        outline: en,
        outlineColor: en,
        stroke: en,
        textDecorationColor: en,
        fontFamily: "fonts",
        fontWeight: "fontWeights",
        lineHeight: "lineHeights",
        letterSpacing: "letterSpacings",
        blockSize: rr,
        minBlockSize: rr,
        maxBlockSize: rr,
        inlineSize: rr,
        minInlineSize: rr,
        maxInlineSize: rr,
        width: rr,
        minWidth: rr,
        maxWidth: rr,
        height: rr,
        minHeight: rr,
        maxHeight: rr,
        flexBasis: rr,
        gridTemplateColumns: rr,
        gridTemplateRows: rr,
        borderWidth: "borderWidths",
        borderTopWidth: "borderWidths",
        borderRightWidth: "borderWidths",
        borderBottomWidth: "borderWidths",
        borderLeftWidth: "borderWidths",
        borderStyle: "borderStyles",
        borderTopStyle: "borderStyles",
        borderRightStyle: "borderStyles",
        borderBottomStyle: "borderStyles",
        borderLeftStyle: "borderStyles",
        borderRadius: "radii",
        borderTopLeftRadius: "radii",
        borderTopRightRadius: "radii",
        borderBottomRightRadius: "radii",
        borderBottomLeftRadius: "radii",
        boxShadow: "shadows",
        textShadow: "shadows",
        transition: "transitions",
        zIndex: "zIndices"
    },
    my = (t, e) => typeof e == "function" ? {
        "()": Function.prototype.toString.call(e)
    } : e,
    ds = () => {
        const t = Object.create(null);
        return (e, n, ...r) => {
            const i = (o => JSON.stringify(o, my))(e);
            return i in t ? t[i] : t[i] = n(e, ...r)
        }
    },
    ho = Symbol.for("sxs.internal"),
    vf = (t, e) => Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)),
    wd = t => {
        for (const e in t) return !0;
        return !1
    },
    {
        hasOwnProperty: gy
    } = Object.prototype,
    nu = t => t.includes("-") ? t : t.replace(/[A-Z]/g, e => "-" + e.toLowerCase()),
    vy = /\s+(?![^()]*\))/,
    $o = t => e => t(...typeof e == "string" ? String(e).split(vy) : [e]),
    _d = {
        appearance: t => ({
            WebkitAppearance: t,
            appearance: t
        }),
        backfaceVisibility: t => ({
            WebkitBackfaceVisibility: t,
            backfaceVisibility: t
        }),
        backdropFilter: t => ({
            WebkitBackdropFilter: t,
            backdropFilter: t
        }),
        backgroundClip: t => ({
            WebkitBackgroundClip: t,
            backgroundClip: t
        }),
        boxDecorationBreak: t => ({
            WebkitBoxDecorationBreak: t,
            boxDecorationBreak: t
        }),
        clipPath: t => ({
            WebkitClipPath: t,
            clipPath: t
        }),
        content: t => ({
            content: t.includes('"') || t.includes("'") || /^([A-Za-z]+\([^]*|[^]*-quote|inherit|initial|none|normal|revert|unset)$/.test(t) ? t : `"${t}"`
        }),
        hyphens: t => ({
            WebkitHyphens: t,
            hyphens: t
        }),
        maskImage: t => ({
            WebkitMaskImage: t,
            maskImage: t
        }),
        maskSize: t => ({
            WebkitMaskSize: t,
            maskSize: t
        }),
        tabSize: t => ({
            MozTabSize: t,
            tabSize: t
        }),
        textSizeAdjust: t => ({
            WebkitTextSizeAdjust: t,
            textSizeAdjust: t
        }),
        userSelect: t => ({
            WebkitUserSelect: t,
            userSelect: t
        }),
        marginBlock: $o((t, e) => ({
            marginBlockStart: t,
            marginBlockEnd: e || t
        })),
        marginInline: $o((t, e) => ({
            marginInlineStart: t,
            marginInlineEnd: e || t
        })),
        maxSize: $o((t, e) => ({
            maxBlockSize: t,
            maxInlineSize: e || t
        })),
        minSize: $o((t, e) => ({
            minBlockSize: t,
            minInlineSize: e || t
        })),
        paddingBlock: $o((t, e) => ({
            paddingBlockStart: t,
            paddingBlockEnd: e || t
        })),
        paddingInline: $o((t, e) => ({
            paddingInlineStart: t,
            paddingInlineEnd: e || t
        }))
    },
    wc = /([\d.]+)([^]*)/,
    yy = (t, e) => t.length ? t.reduce((n, r) => (n.push(...e.map(i => i.includes("&") ? i.replace(/&/g, /[ +>|~]/.test(r) && /&.*&/.test(i) ? `:is(${r})` : r) : r + " " + i)), n), []) : e,
    xy = (t, e) => t in by && typeof e == "string" ? e.replace(/^((?:[^]*[^\w-])?)(fit-content|stretch)((?:[^\w-][^]*)?)$/, (n, r, i, o) => r + (i === "stretch" ? `-moz-available${o};${nu(t)}:${r}-webkit-fill-available` : `-moz-fit-content${o};${nu(t)}:${r}fit-content`) + o) : String(e),
    by = {
        blockSize: 1,
        height: 1,
        inlineSize: 1,
        maxBlockSize: 1,
        maxHeight: 1,
        maxInlineSize: 1,
        maxWidth: 1,
        minBlockSize: 1,
        minHeight: 1,
        minInlineSize: 1,
        minWidth: 1,
        width: 1
    },
    Mi = t => t ? t + "-" : "",
    Gh = (t, e, n) => t.replace(/([+-])?((?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?)?(\$|--)([$\w-]+)/g, (r, i, o, s, a) => s == "$" == !!o ? r : (i || s == "--" ? "calc(" : "") + "var(--" + (s === "$" ? Mi(e) + (a.includes("$") ? "" : Mi(n)) + a.replace(/\$/g, "-") : a) + ")" + (i || s == "--" ? "*" + (i || "") + (o || "1") + ")" : "")),
    wy = /\s*,\s*(?![^()]*\))/,
    _y = Object.prototype.toString,
    Bo = (t, e, n, r, i) => {
        let o, s, a;
        const l = (c, d, f) => {
            let h, p;
            const m = g => {
                for (h in g) {
                    const w = h.charCodeAt(0) === 64,
                        M = w && Array.isArray(g[h]) ? g[h] : [g[h]];
                    for (p of M) {
                        const T = /[A-Z]/.test(x = h) ? x : x.replace(/-[^]/g, R => R[1].toUpperCase()),
                            O = typeof p == "object" && p && p.toString === _y && (!r.utils[T] || !d.length);
                        if (T in r.utils && !O) {
                            const R = r.utils[T];
                            if (R !== s) {
                                s = R, m(R(p)), s = null;
                                continue
                            }
                        } else if (T in _d) {
                            const R = _d[T];
                            if (R !== a) {
                                a = R, m(R(p)), a = null;
                                continue
                            }
                        }
                        if (w && (y = h.slice(1) in r.media ? "@media " + r.media[h.slice(1)] : h, h = y.replace(/\(\s*([\w-]+)\s*(=|<|<=|>|>=)\s*([\w-]+)\s*(?:(<|<=|>|>=)\s*([\w-]+)\s*)?\)/g, (R, P, B, te, W, ee) => {
                                const V = wc.test(P),
                                    I = .0625 * (V ? -1 : 1),
                                    [X, q] = V ? [te, P] : [P, te];
                                return "(" + (B[0] === "=" ? "" : B[0] === ">" === V ? "max-" : "min-") + X + ":" + (B[0] !== "=" && B.length === 1 ? q.replace(wc, (Z, le, Se) => Number(le) + I * (B === ">" ? 1 : -1) + Se) : q) + (W ? ") and (" + (W[0] === ">" ? "min-" : "max-") + X + ":" + (W.length === 1 ? ee.replace(wc, (Z, le, Se) => Number(le) + I * (W === ">" ? -1 : 1) + Se) : ee) : "") + ")"
                            })), O) {
                            const R = w ? f.concat(h) : [...f],
                                P = w ? [...d] : yy(d, h.split(wy));
                            o !== void 0 && i(Dd(...o)), o = void 0, l(p, P, R)
                        } else o === void 0 && (o = [
                            [], d, f
                        ]), h = w || h.charCodeAt(0) !== 36 ? h : `--${Mi(r.prefix)}${h.slice(1).replace(/\$/g,"-")}`, p = O ? p : typeof p == "number" ? p && T in Dy ? String(p) + "px" : String(p) : Gh(xy(T, p ? ? ""), r.prefix, r.themeMap[T]), o[0].push(`${w?`${h} `:`${nu(h)}:`}${p}`)
                    }
                }
                var y, x
            };
            m(c), o !== void 0 && i(Dd(...o)), o = void 0
        };
        l(t, e, n)
    },
    Dd = (t, e, n) => `${n.map(r=>`${r}{`).join("")}${e.length?`${e.join(",")}{`:""}${t.join(";")}${e.length?"}":""}${Array(n.length?n.length+1:0).join("}")}`,
    Dy = {
        animationDelay: 1,
        animationDuration: 1,
        backgroundSize: 1,
        blockSize: 1,
        border: 1,
        borderBlock: 1,
        borderBlockEnd: 1,
        borderBlockEndWidth: 1,
        borderBlockStart: 1,
        borderBlockStartWidth: 1,
        borderBlockWidth: 1,
        borderBottom: 1,
        borderBottomLeftRadius: 1,
        borderBottomRightRadius: 1,
        borderBottomWidth: 1,
        borderEndEndRadius: 1,
        borderEndStartRadius: 1,
        borderInlineEnd: 1,
        borderInlineEndWidth: 1,
        borderInlineStart: 1,
        borderInlineStartWidth: 1,
        borderInlineWidth: 1,
        borderLeft: 1,
        borderLeftWidth: 1,
        borderRadius: 1,
        borderRight: 1,
        borderRightWidth: 1,
        borderSpacing: 1,
        borderStartEndRadius: 1,
        borderStartStartRadius: 1,
        borderTop: 1,
        borderTopLeftRadius: 1,
        borderTopRightRadius: 1,
        borderTopWidth: 1,
        borderWidth: 1,
        bottom: 1,
        columnGap: 1,
        columnRule: 1,
        columnRuleWidth: 1,
        columnWidth: 1,
        containIntrinsicSize: 1,
        flexBasis: 1,
        fontSize: 1,
        gap: 1,
        gridAutoColumns: 1,
        gridAutoRows: 1,
        gridTemplateColumns: 1,
        gridTemplateRows: 1,
        height: 1,
        inlineSize: 1,
        inset: 1,
        insetBlock: 1,
        insetBlockEnd: 1,
        insetBlockStart: 1,
        insetInline: 1,
        insetInlineEnd: 1,
        insetInlineStart: 1,
        left: 1,
        letterSpacing: 1,
        margin: 1,
        marginBlock: 1,
        marginBlockEnd: 1,
        marginBlockStart: 1,
        marginBottom: 1,
        marginInline: 1,
        marginInlineEnd: 1,
        marginInlineStart: 1,
        marginLeft: 1,
        marginRight: 1,
        marginTop: 1,
        maxBlockSize: 1,
        maxHeight: 1,
        maxInlineSize: 1,
        maxWidth: 1,
        minBlockSize: 1,
        minHeight: 1,
        minInlineSize: 1,
        minWidth: 1,
        offsetDistance: 1,
        offsetRotate: 1,
        outline: 1,
        outlineOffset: 1,
        outlineWidth: 1,
        overflowClipMargin: 1,
        padding: 1,
        paddingBlock: 1,
        paddingBlockEnd: 1,
        paddingBlockStart: 1,
        paddingBottom: 1,
        paddingInline: 1,
        paddingInlineEnd: 1,
        paddingInlineStart: 1,
        paddingLeft: 1,
        paddingRight: 1,
        paddingTop: 1,
        perspective: 1,
        right: 1,
        rowGap: 1,
        scrollMargin: 1,
        scrollMarginBlock: 1,
        scrollMarginBlockEnd: 1,
        scrollMarginBlockStart: 1,
        scrollMarginBottom: 1,
        scrollMarginInline: 1,
        scrollMarginInlineEnd: 1,
        scrollMarginInlineStart: 1,
        scrollMarginLeft: 1,
        scrollMarginRight: 1,
        scrollMarginTop: 1,
        scrollPadding: 1,
        scrollPaddingBlock: 1,
        scrollPaddingBlockEnd: 1,
        scrollPaddingBlockStart: 1,
        scrollPaddingBottom: 1,
        scrollPaddingInline: 1,
        scrollPaddingInlineEnd: 1,
        scrollPaddingInlineStart: 1,
        scrollPaddingLeft: 1,
        scrollPaddingRight: 1,
        scrollPaddingTop: 1,
        shapeMargin: 1,
        textDecoration: 1,
        textDecorationThickness: 1,
        textIndent: 1,
        textUnderlineOffset: 1,
        top: 1,
        transitionDelay: 1,
        transitionDuration: 1,
        verticalAlign: 1,
        width: 1,
        wordSpacing: 1
    },
    Sd = t => String.fromCharCode(t + (t > 25 ? 39 : 97)),
    mo = t => (e => {
        let n, r = "";
        for (n = Math.abs(e); n > 52; n = n / 52 | 0) r = Sd(n % 52) + r;
        return Sd(n % 52) + r
    })(((e, n) => {
        let r = n.length;
        for (; r;) e = 33 * e ^ n.charCodeAt(--r);
        return e
    })(5381, JSON.stringify(t)) >>> 0),
    Fs = ["themed", "global", "styled", "onevar", "resonevar", "allvar", "inline"],
    Sy = t => {
        if (t.href && !t.href.startsWith(location.origin)) return !1;
        try {
            return !!t.cssRules
        } catch {
            return !1
        }
    },
    Cy = t => {
        let e;
        const n = () => {
                const {
                    cssRules: i
                } = e.sheet;
                return [].map.call(i, (o, s) => {
                    const {
                        cssText: a
                    } = o;
                    let l = "";
                    if (a.startsWith("--sxs")) return "";
                    if (i[s - 1] && (l = i[s - 1].cssText).startsWith("--sxs")) {
                        if (!o.cssRules.length) return "";
                        for (const c in e.rules)
                            if (e.rules[c].group === o) return `--sxs{--sxs:${[...e.rules[c].cache].join(" ")}}${a}`;
                        return o.cssRules.length ? `${l}${a}` : ""
                    }
                    return a
                }).join("")
            },
            r = () => {
                if (e) {
                    const {
                        rules: a,
                        sheet: l
                    } = e;
                    if (!l.deleteRule) {
                        for (; Object(Object(l.cssRules)[0]).type === 3;) l.cssRules.splice(0, 1);
                        l.cssRules = []
                    }
                    for (const c in a) delete a[c]
                }
                const i = Object(t).styleSheets || [];
                for (const a of i)
                    if (Sy(a)) {
                        for (let l = 0, c = a.cssRules; c[l]; ++l) {
                            const d = Object(c[l]);
                            if (d.type !== 1) continue;
                            const f = Object(c[l + 1]);
                            if (f.type !== 4) continue;
                            ++l;
                            const {
                                cssText: h
                            } = d;
                            if (!h.startsWith("--sxs")) continue;
                            const p = h.slice(14, -3).trim().split(/\s+/),
                                m = Fs[p[0]];
                            m && (e || (e = {
                                sheet: a,
                                reset: r,
                                rules: {},
                                toString: n
                            }), e.rules[m] = {
                                group: f,
                                index: l,
                                cache: new Set(p)
                            })
                        }
                        if (e) break
                    }
                if (!e) {
                    const a = (l, c) => ({
                        type: c,
                        cssRules: [],
                        insertRule(d, f) {
                            this.cssRules.splice(f, 0, a(d, {
                                import: 3,
                                undefined: 1
                            }[(d.toLowerCase().match(/^@([a-z]+)/) || [])[1]] || 4))
                        },
                        get cssText() {
                            return l === "@media{}" ? `@media{${[].map.call(this.cssRules,d=>d.cssText).join("")}}` : l
                        }
                    });
                    e = {
                        sheet: t ? (t.head || t).appendChild(document.createElement("style")).sheet : a("", "text/css"),
                        rules: {},
                        reset: r,
                        toString: n
                    }
                }
                const {
                    sheet: o,
                    rules: s
                } = e;
                for (let a = Fs.length - 1; a >= 0; --a) {
                    const l = Fs[a];
                    if (!s[l]) {
                        const c = Fs[a + 1],
                            d = s[c] ? s[c].index : o.cssRules.length;
                        o.insertRule("@media{}", d), o.insertRule(`--sxs{--sxs:${a}}`, d), s[l] = {
                            group: o.cssRules[d + 1],
                            index: d,
                            cache: new Set([a])
                        }
                    }
                    Ey(s[l])
                }
            };
        return r(), e
    },
    Ey = t => {
        const e = t.group;
        let n = e.cssRules.length;
        t.apply = r => {
            try {
                e.insertRule(r, n), ++n
            } catch {}
        }
    },
    Es = Symbol(),
    Ty = ds(),
    Cd = (t, e) => Ty(t, () => (...n) => {
        let r = {
            type: null,
            composers: new Set
        };
        for (const i of n)
            if (i != null)
                if (i[ho]) {
                    r.type == null && (r.type = i[ho].type);
                    for (const o of i[ho].composers) r.composers.add(o)
                } else i.constructor !== Object || i.$$typeof ? r.type == null && (r.type = i) : r.composers.add(Py(i, t));
        return r.type == null && (r.type = "span"), r.composers.size || r.composers.add(["PJLV", {},
            [],
            [], {},
            []
        ]), Ry(t, r, e)
    }),
    Py = ({
        variants: t,
        compoundVariants: e,
        defaultVariants: n,
        ...r
    }, i) => {
        const o = `${Mi(i.prefix)}c-${mo(r)}`,
            s = [],
            a = [],
            l = Object.create(null),
            c = [];
        for (const h in n) l[h] = String(n[h]);
        if (typeof t == "object" && t)
            for (const h in t) {
                d = l, f = h, gy.call(d, f) || (l[h] = "undefined");
                const p = t[h];
                for (const m in p) {
                    const g = {
                        [h]: String(m)
                    };
                    String(m) === "undefined" && c.push(h);
                    const y = p[m],
                        x = [g, y, !wd(y)];
                    s.push(x)
                }
            }
        var d, f;
        if (typeof e == "object" && e)
            for (const h of e) {
                let {
                    css: p,
                    ...m
                } = h;
                p = typeof p == "object" && p || {};
                for (const y in m) m[y] = String(m[y]);
                const g = [m, p, !wd(p)];
                a.push(g)
            }
        return [o, r, s, a, l, c]
    },
    Ry = (t, e, n) => {
        const [r, i, o, s] = My(e.composers), a = typeof e.type == "function" || e.type.$$typeof ? (f => {
            function h() {
                for (let p = 0; p < h[Es].length; p++) {
                    const [m, g] = h[Es][p];
                    f.rules[m].apply(g)
                }
                return h[Es] = [], null
            }
            return h[Es] = [], h.rules = {}, Fs.forEach(p => h.rules[p] = {
                apply: m => h[Es].push([p, m])
            }), h
        })(n) : null, l = (a || n).rules, c = `.${r}${i.length>1?`:where(.${i.slice(1).join(".")})`:""}`, d = f => {
            f = typeof f == "object" && f || $y;
            const {
                css: h,
                ...p
            } = f, m = {};
            for (const x in o)
                if (delete p[x], x in f) {
                    let w = f[x];
                    typeof w == "object" && w ? m[x] = {
                        "@initial": o[x],
                        ...w
                    } : (w = String(w), m[x] = w !== "undefined" || s.has(x) ? w : o[x])
                } else m[x] = o[x];
            const g = new Set([...i]);
            for (const [x, w, M, T] of e.composers) {
                n.rules.styled.cache.has(x) || (n.rules.styled.cache.add(x), Bo(w, [`.${x}`], [], t, P => {
                    l.styled.apply(P)
                }));
                const O = Ed(M, m, t.media),
                    R = Ed(T, m, t.media, !0);
                for (const P of O)
                    if (P !== void 0)
                        for (const [B, te, W] of P) {
                            const ee = `${x}-${mo(te)}-${B}`;
                            g.add(ee);
                            const V = (W ? n.rules.resonevar : n.rules.onevar).cache,
                                I = W ? l.resonevar : l.onevar;
                            V.has(ee) || (V.add(ee), Bo(te, [`.${ee}`], [], t, X => {
                                I.apply(X)
                            }))
                        }
                for (const P of R)
                    if (P !== void 0)
                        for (const [B, te] of P) {
                            const W = `${x}-${mo(te)}-${B}`;
                            g.add(W), n.rules.allvar.cache.has(W) || (n.rules.allvar.cache.add(W), Bo(te, [`.${W}`], [], t, ee => {
                                l.allvar.apply(ee)
                            }))
                        }
            }
            if (typeof h == "object" && h) {
                const x = `${r}-i${mo(h)}-css`;
                g.add(x), n.rules.inline.cache.has(x) || (n.rules.inline.cache.add(x), Bo(h, [`.${x}`], [], t, w => {
                    l.inline.apply(w)
                }))
            }
            for (const x of String(f.className || "").trim().split(/\s+/)) x && g.add(x);
            const y = p.className = [...g].join(" ");
            return {
                type: e.type,
                className: y,
                selector: c,
                props: p,
                toString: () => y,
                deferredInjector: a
            }
        };
        return vf(d, {
            className: r,
            selector: c,
            [ho]: e,
            toString: () => (n.rules.styled.cache.has(r) || d(), r)
        })
    },
    My = t => {
        let e = "";
        const n = [],
            r = {},
            i = [];
        for (const [o, , , , s, a] of t) {
            e === "" && (e = o), n.push(o), i.push(...a);
            for (const l in s) {
                const c = s[l];
                (r[l] === void 0 || c !== "undefined" || a.includes(c)) && (r[l] = c)
            }
        }
        return [e, n, r, new Set(i)]
    },
    Ed = (t, e, n, r) => {
        const i = [];
        e: for (let [o, s, a] of t) {
            if (a) continue;
            let l, c = 0,
                d = !1;
            for (l in o) {
                const f = o[l];
                let h = e[l];
                if (h !== f) {
                    if (typeof h != "object" || !h) continue e; {
                        let p, m, g = 0;
                        for (const y in h) {
                            if (f === String(h[y])) {
                                if (y !== "@initial") {
                                    const x = y.slice(1);
                                    (m = m || []).push(x in n ? n[x] : y.replace(/^@media ?/, "")), d = !0
                                }
                                c += g, p = !0
                            }++g
                        }
                        if (m && m.length && (s = {
                                ["@media " + m.join(", ")]: s
                            }), !p) continue e
                    }
                }
            }(i[c] = i[c] || []).push([r ? "cv" : `${l}-${o[l]}`, s, d])
        }
        return i
    },
    $y = {},
    Ay = ds(),
    Fy = (t, e) => Ay(t, () => (...n) => {
        const r = () => {
            for (let i of n) {
                i = typeof i == "object" && i || {};
                let o = mo(i);
                if (!e.rules.global.cache.has(o)) {
                    if (e.rules.global.cache.add(o), "@import" in i) {
                        let s = [].indexOf.call(e.sheet.cssRules, e.rules.themed.group) - 1;
                        for (let a of [].concat(i["@import"])) a = a.includes('"') || a.includes("'") ? a : `"${a}"`, e.sheet.insertRule(`@import ${a};`, s++);
                        delete i["@import"]
                    }
                    Bo(i, [], [], t, s => {
                        e.rules.global.apply(s)
                    })
                }
            }
            return ""
        };
        return vf(r, {
            toString: r
        })
    }),
    ky = ds(),
    Oy = (t, e) => ky(t, () => n => {
        const r = `${Mi(t.prefix)}k-${mo(n)}`,
            i = () => {
                if (!e.rules.global.cache.has(r)) {
                    e.rules.global.cache.add(r);
                    const o = [];
                    Bo(n, [], [], t, a => o.push(a));
                    const s = `@keyframes ${r}{${o.join("")}}`;
                    e.rules.global.apply(s)
                }
                return r
            };
        return vf(i, {
            get name() {
                return i()
            },
            toString: i
        })
    }),
    jy = class {
        constructor(t, e, n, r) {
            this.token = t == null ? "" : String(t), this.value = e == null ? "" : String(e), this.scale = n == null ? "" : String(n), this.prefix = r == null ? "" : String(r)
        }
        get computedValue() {
            return "var(" + this.variable + ")"
        }
        get variable() {
            return "--" + Mi(this.prefix) + Mi(this.scale) + this.token
        }
        toString() {
            return this.computedValue
        }
    },
    Ly = ds(),
    Ny = (t, e) => Ly(t, () => (n, r) => {
        r = typeof n == "object" && n || Object(r);
        const i = `.${n=(n=typeof n=="string"?n:"")||`${Mi(t.prefix)}t-${mo(r)}`}`,
            o = {},
            s = [];
        for (const l in r) {
            o[l] = {};
            for (const c in r[l]) {
                const d = `--${Mi(t.prefix)}${l}-${c}`,
                    f = Gh(String(r[l][c]), t.prefix, l);
                o[l][c] = new jy(c, f, l, t.prefix), s.push(`${d}:${f}`)
            }
        }
        const a = () => {
            if (s.length && !e.rules.themed.cache.has(n)) {
                e.rules.themed.cache.add(n);
                const l = `${r===t.theme?":root,":""}.${n}{${s.join(";")}}`;
                e.rules.themed.apply(l)
            }
            return n
        };
        return { ...o,
            get className() {
                return a()
            },
            selector: i,
            toString: a
        }
    }),
    zy = ds(),
    Iy = ds(),
    By = t => {
        const e = (n => {
            let r = !1;
            const i = zy(n, o => {
                r = !0;
                const s = "prefix" in (o = typeof o == "object" && o || {}) ? String(o.prefix) : "",
                    a = typeof o.media == "object" && o.media || {},
                    l = typeof o.root == "object" ? o.root || null : globalThis.document || null,
                    c = typeof o.theme == "object" && o.theme || {},
                    d = {
                        prefix: s,
                        media: a,
                        theme: c,
                        themeMap: typeof o.themeMap == "object" && o.themeMap || { ...hy
                        },
                        utils: typeof o.utils == "object" && o.utils || {}
                    },
                    f = Cy(l),
                    h = {
                        css: Cd(d, f),
                        globalCss: Fy(d, f),
                        keyframes: Oy(d, f),
                        createTheme: Ny(d, f),
                        reset() {
                            f.reset(), h.theme.toString()
                        },
                        theme: {},
                        sheet: f,
                        config: d,
                        prefix: s,
                        getCssText: f.toString,
                        toString: f.toString
                    };
                return String(h.theme = h.createTheme(c)), h
            });
            return r || i.reset(), i
        })(t);
        return e.styled = (({
            config: n,
            sheet: r
        }) => Iy(n, () => {
            const i = Cd(n, r);
            return (...o) => {
                const s = i(...o),
                    a = s[ho].type,
                    l = j.forwardRef((c, d) => {
                        const f = c && c.as || a,
                            {
                                props: h,
                                deferredInjector: p
                            } = s(c);
                        return delete h.as, h.ref = d, p ? j.createElement(j.Fragment, null, j.createElement(f, h), j.createElement(p, null)) : j.createElement(f, h)
                    });
                return l.className = s.className, l.displayName = `Styled.${a.displayName||a.name||a}`, l.selector = s.selector, l.toString = () => s.selector, l[ho] = s[ho], l
            }
        }))(e), e
    };

function xi(t, e, {
    checkForDefaultPrevented: n = !0
} = {}) {
    return function(i) {
        if (t == null || t(i), n === !1 || !i.defaultPrevented) return e == null ? void 0 : e(i)
    }
}

function Yh(t, e = []) {
    let n = [];

    function r(o, s) {
        const a = u.createContext(s),
            l = n.length;
        n = [...n, s];

        function c(f) {
            const {
                scope: h,
                children: p,
                ...m
            } = f, g = (h == null ? void 0 : h[t][l]) || a, y = u.useMemo(() => m, Object.values(m));
            return u.createElement(g.Provider, {
                value: y
            }, p)
        }

        function d(f, h) {
            const p = (h == null ? void 0 : h[t][l]) || a,
                m = u.useContext(p);
            if (m) return m;
            if (s !== void 0) return s;
            throw new Error(`\`${f}\` must be used within \`${o}\``)
        }
        return c.displayName = o + "Provider", [c, d]
    }
    const i = () => {
        const o = n.map(s => u.createContext(s));
        return function(a) {
            const l = (a == null ? void 0 : a[t]) || o;
            return u.useMemo(() => ({
                [`__scope${t}`]: { ...a,
                    [t]: l
                }
            }), [a, l])
        }
    };
    return i.scopeName = t, [r, Wy(i, ...e)]
}

function Wy(...t) {
    const e = t[0];
    if (t.length === 1) return e;
    const n = () => {
        const r = t.map(i => ({
            useScope: i(),
            scopeName: i.scopeName
        }));
        return function(o) {
            const s = r.reduce((a, {
                useScope: l,
                scopeName: c
            }) => {
                const f = l(o)[`__scope${c}`];
                return { ...a,
                    ...f
                }
            }, {});
            return u.useMemo(() => ({
                [`__scope${e.scopeName}`]: s
            }), [s])
        }
    };
    return n.scopeName = e.scopeName, n
}

function ps(t) {
    const e = u.useRef(t);
    return u.useEffect(() => {
        e.current = t
    }), u.useMemo(() => (...n) => {
        var r;
        return (r = e.current) === null || r === void 0 ? void 0 : r.call(e, ...n)
    }, [])
}

function Vy(t, e = globalThis == null ? void 0 : globalThis.document) {
    const n = ps(t);
    u.useEffect(() => {
        const r = i => {
            i.key === "Escape" && n(i)
        };
        return e.addEventListener("keydown", r), () => e.removeEventListener("keydown", r)
    }, [n, e])
}
const ru = "dismissableLayer.update",
    Uy = "dismissableLayer.pointerDownOutside",
    Hy = "dismissableLayer.focusOutside";
let Td;
const Gy = u.createContext({
        layers: new Set,
        layersWithOutsidePointerEventsDisabled: new Set,
        branches: new Set
    }),
    Yy = u.forwardRef((t, e) => {
        var n;
        const {
            disableOutsidePointerEvents: r = !1,
            onEscapeKeyDown: i,
            onPointerDownOutside: o,
            onFocusOutside: s,
            onInteractOutside: a,
            onDismiss: l,
            ...c
        } = t, d = u.useContext(Gy), [f, h] = u.useState(null), p = (n = f == null ? void 0 : f.ownerDocument) !== null && n !== void 0 ? n : globalThis == null ? void 0 : globalThis.document, [, m] = u.useState({}), g = fs(e, B => h(B)), y = Array.from(d.layers), [x] = [...d.layersWithOutsidePointerEventsDisabled].slice(-1), w = y.indexOf(x), M = f ? y.indexOf(f) : -1, T = d.layersWithOutsidePointerEventsDisabled.size > 0, O = M >= w, R = Xy(B => {
            const te = B.target,
                W = [...d.branches].some(ee => ee.contains(te));
            !O || W || (o == null || o(B), a == null || a(B), B.defaultPrevented || l == null || l())
        }, p), P = qy(B => {
            const te = B.target;
            [...d.branches].some(ee => ee.contains(te)) || (s == null || s(B), a == null || a(B), B.defaultPrevented || l == null || l())
        }, p);
        return Vy(B => {
            M === d.layers.size - 1 && (i == null || i(B), !B.defaultPrevented && l && (B.preventDefault(), l()))
        }, p), u.useEffect(() => {
            if (f) return r && (d.layersWithOutsidePointerEventsDisabled.size === 0 && (Td = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), d.layersWithOutsidePointerEventsDisabled.add(f)), d.layers.add(f), Pd(), () => {
                r && d.layersWithOutsidePointerEventsDisabled.size === 1 && (p.body.style.pointerEvents = Td)
            }
        }, [f, p, r, d]), u.useEffect(() => () => {
            f && (d.layers.delete(f), d.layersWithOutsidePointerEventsDisabled.delete(f), Pd())
        }, [f, d]), u.useEffect(() => {
            const B = () => m({});
            return document.addEventListener(ru, B), () => document.removeEventListener(ru, B)
        }, []), u.createElement(Ro.div, Xn({}, c, {
            ref: g,
            style: {
                pointerEvents: T ? O ? "auto" : "none" : void 0,
                ...t.style
            },
            onFocusCapture: xi(t.onFocusCapture, P.onFocusCapture),
            onBlurCapture: xi(t.onBlurCapture, P.onBlurCapture),
            onPointerDownCapture: xi(t.onPointerDownCapture, R.onPointerDownCapture)
        }))
    });

function Xy(t, e = globalThis == null ? void 0 : globalThis.document) {
    const n = ps(t),
        r = u.useRef(!1),
        i = u.useRef(() => {});
    return u.useEffect(() => {
        const o = a => {
                if (a.target && !r.current) {
                    let c = function() {
                        Xh(Uy, n, l, {
                            discrete: !0
                        })
                    };
                    const l = {
                        originalEvent: a
                    };
                    a.pointerType === "touch" ? (e.removeEventListener("click", i.current), i.current = c, e.addEventListener("click", i.current, {
                        once: !0
                    })) : c()
                } else e.removeEventListener("click", i.current);
                r.current = !1
            },
            s = window.setTimeout(() => {
                e.addEventListener("pointerdown", o)
            }, 0);
        return () => {
            window.clearTimeout(s), e.removeEventListener("pointerdown", o), e.removeEventListener("click", i.current)
        }
    }, [e, n]), {
        onPointerDownCapture: () => r.current = !0
    }
}

function qy(t, e = globalThis == null ? void 0 : globalThis.document) {
    const n = ps(t),
        r = u.useRef(!1);
    return u.useEffect(() => {
        const i = o => {
            o.target && !r.current && Xh(Hy, n, {
                originalEvent: o
            }, {
                discrete: !1
            })
        };
        return e.addEventListener("focusin", i), () => e.removeEventListener("focusin", i)
    }, [e, n]), {
        onFocusCapture: () => r.current = !0,
        onBlurCapture: () => r.current = !1
    }
}

function Pd() {
    const t = new CustomEvent(ru);
    document.dispatchEvent(t)
}

function Xh(t, e, n, {
    discrete: r
}) {
    const i = n.originalEvent.target,
        o = new CustomEvent(t, {
            bubbles: !1,
            cancelable: !0,
            detail: n
        });
    e && i.addEventListener(t, e, {
        once: !0
    }), r ? ay(i, o) : i.dispatchEvent(o)
}
const rs = globalThis != null && globalThis.document ? u.useLayoutEffect : () => {},
    Ky = wv["useId".toString()] || (() => {});
let Zy = 0;

function Qy(t) {
    const [e, n] = u.useState(Ky());
    return rs(() => {
        t || n(r => r ? ? String(Zy++))
    }, [t]), t || (e ? `radix-${e}` : "")
}
const Jy = ["top", "right", "bottom", "left"],
    Ki = Math.min,
    Er = Math.max,
    bl = Math.round,
    Oa = Math.floor,
    Zi = t => ({
        x: t,
        y: t
    }),
    e1 = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    },
    t1 = {
        start: "end",
        end: "start"
    };

function iu(t, e, n) {
    return Er(t, Ki(e, n))
}

function $i(t, e) {
    return typeof t == "function" ? t(e) : t
}

function Ai(t) {
    return t.split("-")[0]
}

function hs(t) {
    return t.split("-")[1]
}

function yf(t) {
    return t === "x" ? "y" : "x"
}

function xf(t) {
    return t === "y" ? "height" : "width"
}

function ms(t) {
    return ["top", "bottom"].includes(Ai(t)) ? "y" : "x"
}

function bf(t) {
    return yf(ms(t))
}

function n1(t, e, n) {
    n === void 0 && (n = !1);
    const r = hs(t),
        i = bf(t),
        o = xf(i);
    let s = i === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
    return e.reference[o] > e.floating[o] && (s = wl(s)), [s, wl(s)]
}

function r1(t) {
    const e = wl(t);
    return [ou(t), e, ou(e)]
}

function ou(t) {
    return t.replace(/start|end/g, e => t1[e])
}

function i1(t, e, n) {
    const r = ["left", "right"],
        i = ["right", "left"],
        o = ["top", "bottom"],
        s = ["bottom", "top"];
    switch (t) {
        case "top":
        case "bottom":
            return n ? e ? i : r : e ? r : i;
        case "left":
        case "right":
            return e ? o : s;
        default:
            return []
    }
}

function o1(t, e, n, r) {
    const i = hs(t);
    let o = i1(Ai(t), n === "start", r);
    return i && (o = o.map(s => s + "-" + i), e && (o = o.concat(o.map(ou)))), o
}

function wl(t) {
    return t.replace(/left|right|bottom|top/g, e => e1[e])
}

function s1(t) {
    return {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        ...t
    }
}

function qh(t) {
    return typeof t != "number" ? s1(t) : {
        top: t,
        right: t,
        bottom: t,
        left: t
    }
}

function _l(t) {
    return { ...t,
        top: t.y,
        left: t.x,
        right: t.x + t.width,
        bottom: t.y + t.height
    }
}

function Rd(t, e, n) {
    let {
        reference: r,
        floating: i
    } = t;
    const o = ms(e),
        s = bf(e),
        a = xf(s),
        l = Ai(e),
        c = o === "y",
        d = r.x + r.width / 2 - i.width / 2,
        f = r.y + r.height / 2 - i.height / 2,
        h = r[a] / 2 - i[a] / 2;
    let p;
    switch (l) {
        case "top":
            p = {
                x: d,
                y: r.y - i.height
            };
            break;
        case "bottom":
            p = {
                x: d,
                y: r.y + r.height
            };
            break;
        case "right":
            p = {
                x: r.x + r.width,
                y: f
            };
            break;
        case "left":
            p = {
                x: r.x - i.width,
                y: f
            };
            break;
        default:
            p = {
                x: r.x,
                y: r.y
            }
    }
    switch (hs(e)) {
        case "start":
            p[s] -= h * (n && c ? -1 : 1);
            break;
        case "end":
            p[s] += h * (n && c ? -1 : 1);
            break
    }
    return p
}
const a1 = async (t, e, n) => {
    const {
        placement: r = "bottom",
        strategy: i = "absolute",
        middleware: o = [],
        platform: s
    } = n, a = o.filter(Boolean), l = await (s.isRTL == null ? void 0 : s.isRTL(e));
    let c = await s.getElementRects({
            reference: t,
            floating: e,
            strategy: i
        }),
        {
            x: d,
            y: f
        } = Rd(c, r, l),
        h = r,
        p = {},
        m = 0;
    for (let g = 0; g < a.length; g++) {
        const {
            name: y,
            fn: x
        } = a[g], {
            x: w,
            y: M,
            data: T,
            reset: O
        } = await x({
            x: d,
            y: f,
            initialPlacement: r,
            placement: h,
            strategy: i,
            middlewareData: p,
            rects: c,
            platform: s,
            elements: {
                reference: t,
                floating: e
            }
        });
        if (d = w ? ? d, f = M ? ? f, p = { ...p,
                [y]: { ...p[y],
                    ...T
                }
            }, O && m <= 50) {
            m++, typeof O == "object" && (O.placement && (h = O.placement), O.rects && (c = O.rects === !0 ? await s.getElementRects({
                reference: t,
                floating: e,
                strategy: i
            }) : O.rects), {
                x: d,
                y: f
            } = Rd(c, h, l)), g = -1;
            continue
        }
    }
    return {
        x: d,
        y: f,
        placement: h,
        strategy: i,
        middlewareData: p
    }
};
async function na(t, e) {
    var n;
    e === void 0 && (e = {});
    const {
        x: r,
        y: i,
        platform: o,
        rects: s,
        elements: a,
        strategy: l
    } = t, {
        boundary: c = "clippingAncestors",
        rootBoundary: d = "viewport",
        elementContext: f = "floating",
        altBoundary: h = !1,
        padding: p = 0
    } = $i(e, t), m = qh(p), y = a[h ? f === "floating" ? "reference" : "floating" : f], x = _l(await o.getClippingRect({
        element: (n = await (o.isElement == null ? void 0 : o.isElement(y))) == null || n ? y : y.contextElement || await (o.getDocumentElement == null ? void 0 : o.getDocumentElement(a.floating)),
        boundary: c,
        rootBoundary: d,
        strategy: l
    })), w = f === "floating" ? { ...s.floating,
        x: r,
        y: i
    } : s.reference, M = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(a.floating)), T = await (o.isElement == null ? void 0 : o.isElement(M)) ? await (o.getScale == null ? void 0 : o.getScale(M)) || {
        x: 1,
        y: 1
    } : {
        x: 1,
        y: 1
    }, O = _l(o.convertOffsetParentRelativeRectToViewportRelativeRect ? await o.convertOffsetParentRelativeRectToViewportRelativeRect({
        rect: w,
        offsetParent: M,
        strategy: l
    }) : w);
    return {
        top: (x.top - O.top + m.top) / T.y,
        bottom: (O.bottom - x.bottom + m.bottom) / T.y,
        left: (x.left - O.left + m.left) / T.x,
        right: (O.right - x.right + m.right) / T.x
    }
}
const Md = t => ({
        name: "arrow",
        options: t,
        async fn(e) {
            const {
                x: n,
                y: r,
                placement: i,
                rects: o,
                platform: s,
                elements: a,
                middlewareData: l
            } = e, {
                element: c,
                padding: d = 0
            } = $i(t, e) || {};
            if (c == null) return {};
            const f = qh(d),
                h = {
                    x: n,
                    y: r
                },
                p = bf(i),
                m = xf(p),
                g = await s.getDimensions(c),
                y = p === "y",
                x = y ? "top" : "left",
                w = y ? "bottom" : "right",
                M = y ? "clientHeight" : "clientWidth",
                T = o.reference[m] + o.reference[p] - h[p] - o.floating[m],
                O = h[p] - o.reference[p],
                R = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(c));
            let P = R ? R[M] : 0;
            (!P || !await (s.isElement == null ? void 0 : s.isElement(R))) && (P = a.floating[M] || o.floating[m]);
            const B = T / 2 - O / 2,
                te = P / 2 - g[m] / 2 - 1,
                W = Ki(f[x], te),
                ee = Ki(f[w], te),
                V = W,
                I = P - g[m] - ee,
                X = P / 2 - g[m] / 2 + B,
                q = iu(V, X, I),
                Z = !l.arrow && hs(i) != null && X != q && o.reference[m] / 2 - (X < V ? W : ee) - g[m] / 2 < 0,
                le = Z ? X < V ? X - V : X - I : 0;
            return {
                [p]: h[p] + le,
                data: {
                    [p]: q,
                    centerOffset: X - q - le,
                    ...Z && {
                        alignmentOffset: le
                    }
                },
                reset: Z
            }
        }
    }),
    l1 = function(t) {
        return t === void 0 && (t = {}), {
            name: "flip",
            options: t,
            async fn(e) {
                var n, r;
                const {
                    placement: i,
                    middlewareData: o,
                    rects: s,
                    initialPlacement: a,
                    platform: l,
                    elements: c
                } = e, {
                    mainAxis: d = !0,
                    crossAxis: f = !0,
                    fallbackPlacements: h,
                    fallbackStrategy: p = "bestFit",
                    fallbackAxisSideDirection: m = "none",
                    flipAlignment: g = !0,
                    ...y
                } = $i(t, e);
                if ((n = o.arrow) != null && n.alignmentOffset) return {};
                const x = Ai(i),
                    w = Ai(a) === a,
                    M = await (l.isRTL == null ? void 0 : l.isRTL(c.floating)),
                    T = h || (w || !g ? [wl(a)] : r1(a));
                !h && m !== "none" && T.push(...o1(a, g, m, M));
                const O = [a, ...T],
                    R = await na(e, y),
                    P = [];
                let B = ((r = o.flip) == null ? void 0 : r.overflows) || [];
                if (d && P.push(R[x]), f) {
                    const V = n1(i, s, M);
                    P.push(R[V[0]], R[V[1]])
                }
                if (B = [...B, {
                        placement: i,
                        overflows: P
                    }], !P.every(V => V <= 0)) {
                    var te, W;
                    const V = (((te = o.flip) == null ? void 0 : te.index) || 0) + 1,
                        I = O[V];
                    if (I) return {
                        data: {
                            index: V,
                            overflows: B
                        },
                        reset: {
                            placement: I
                        }
                    };
                    let X = (W = B.filter(q => q.overflows[0] <= 0).sort((q, Z) => q.overflows[1] - Z.overflows[1])[0]) == null ? void 0 : W.placement;
                    if (!X) switch (p) {
                        case "bestFit":
                            {
                                var ee;
                                const q = (ee = B.map(Z => [Z.placement, Z.overflows.filter(le => le > 0).reduce((le, Se) => le + Se, 0)]).sort((Z, le) => Z[1] - le[1])[0]) == null ? void 0 : ee[0];q && (X = q);
                                break
                            }
                        case "initialPlacement":
                            X = a;
                            break
                    }
                    if (i !== X) return {
                        reset: {
                            placement: X
                        }
                    }
                }
                return {}
            }
        }
    };

function $d(t, e) {
    return {
        top: t.top - e.height,
        right: t.right - e.width,
        bottom: t.bottom - e.height,
        left: t.left - e.width
    }
}

function Ad(t) {
    return Jy.some(e => t[e] >= 0)
}
const c1 = function(t) {
    return t === void 0 && (t = {}), {
        name: "hide",
        options: t,
        async fn(e) {
            const {
                rects: n
            } = e, {
                strategy: r = "referenceHidden",
                ...i
            } = $i(t, e);
            switch (r) {
                case "referenceHidden":
                    {
                        const o = await na(e, { ...i,
                                elementContext: "reference"
                            }),
                            s = $d(o, n.reference);
                        return {
                            data: {
                                referenceHiddenOffsets: s,
                                referenceHidden: Ad(s)
                            }
                        }
                    }
                case "escaped":
                    {
                        const o = await na(e, { ...i,
                                altBoundary: !0
                            }),
                            s = $d(o, n.floating);
                        return {
                            data: {
                                escapedOffsets: s,
                                escaped: Ad(s)
                            }
                        }
                    }
                default:
                    return {}
            }
        }
    }
};
async function u1(t, e) {
    const {
        placement: n,
        platform: r,
        elements: i
    } = t, o = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), s = Ai(n), a = hs(n), l = ms(n) === "y", c = ["left", "top"].includes(s) ? -1 : 1, d = o && l ? -1 : 1, f = $i(e, t);
    let {
        mainAxis: h,
        crossAxis: p,
        alignmentAxis: m
    } = typeof f == "number" ? {
        mainAxis: f,
        crossAxis: 0,
        alignmentAxis: null
    } : {
        mainAxis: 0,
        crossAxis: 0,
        alignmentAxis: null,
        ...f
    };
    return a && typeof m == "number" && (p = a === "end" ? m * -1 : m), l ? {
        x: p * d,
        y: h * c
    } : {
        x: h * c,
        y: p * d
    }
}
const f1 = function(t) {
        return t === void 0 && (t = 0), {
            name: "offset",
            options: t,
            async fn(e) {
                const {
                    x: n,
                    y: r
                } = e, i = await u1(e, t);
                return {
                    x: n + i.x,
                    y: r + i.y,
                    data: i
                }
            }
        }
    },
    d1 = function(t) {
        return t === void 0 && (t = {}), {
            name: "shift",
            options: t,
            async fn(e) {
                const {
                    x: n,
                    y: r,
                    placement: i
                } = e, {
                    mainAxis: o = !0,
                    crossAxis: s = !1,
                    limiter: a = {
                        fn: y => {
                            let {
                                x,
                                y: w
                            } = y;
                            return {
                                x,
                                y: w
                            }
                        }
                    },
                    ...l
                } = $i(t, e), c = {
                    x: n,
                    y: r
                }, d = await na(e, l), f = ms(Ai(i)), h = yf(f);
                let p = c[h],
                    m = c[f];
                if (o) {
                    const y = h === "y" ? "top" : "left",
                        x = h === "y" ? "bottom" : "right",
                        w = p + d[y],
                        M = p - d[x];
                    p = iu(w, p, M)
                }
                if (s) {
                    const y = f === "y" ? "top" : "left",
                        x = f === "y" ? "bottom" : "right",
                        w = m + d[y],
                        M = m - d[x];
                    m = iu(w, m, M)
                }
                const g = a.fn({ ...e,
                    [h]: p,
                    [f]: m
                });
                return { ...g,
                    data: {
                        x: g.x - n,
                        y: g.y - r
                    }
                }
            }
        }
    },
    p1 = function(t) {
        return t === void 0 && (t = {}), {
            options: t,
            fn(e) {
                const {
                    x: n,
                    y: r,
                    placement: i,
                    rects: o,
                    middlewareData: s
                } = e, {
                    offset: a = 0,
                    mainAxis: l = !0,
                    crossAxis: c = !0
                } = $i(t, e), d = {
                    x: n,
                    y: r
                }, f = ms(i), h = yf(f);
                let p = d[h],
                    m = d[f];
                const g = $i(a, e),
                    y = typeof g == "number" ? {
                        mainAxis: g,
                        crossAxis: 0
                    } : {
                        mainAxis: 0,
                        crossAxis: 0,
                        ...g
                    };
                if (l) {
                    const M = h === "y" ? "height" : "width",
                        T = o.reference[h] - o.floating[M] + y.mainAxis,
                        O = o.reference[h] + o.reference[M] - y.mainAxis;
                    p < T ? p = T : p > O && (p = O)
                }
                if (c) {
                    var x, w;
                    const M = h === "y" ? "width" : "height",
                        T = ["top", "left"].includes(Ai(i)),
                        O = o.reference[f] - o.floating[M] + (T && ((x = s.offset) == null ? void 0 : x[f]) || 0) + (T ? 0 : y.crossAxis),
                        R = o.reference[f] + o.reference[M] + (T ? 0 : ((w = s.offset) == null ? void 0 : w[f]) || 0) - (T ? y.crossAxis : 0);
                    m < O ? m = O : m > R && (m = R)
                }
                return {
                    [h]: p,
                    [f]: m
                }
            }
        }
    },
    h1 = function(t) {
        return t === void 0 && (t = {}), {
            name: "size",
            options: t,
            async fn(e) {
                const {
                    placement: n,
                    rects: r,
                    platform: i,
                    elements: o
                } = e, {
                    apply: s = () => {},
                    ...a
                } = $i(t, e), l = await na(e, a), c = Ai(n), d = hs(n), f = ms(n) === "y", {
                    width: h,
                    height: p
                } = r.floating;
                let m, g;
                c === "top" || c === "bottom" ? (m = c, g = d === (await (i.isRTL == null ? void 0 : i.isRTL(o.floating)) ? "start" : "end") ? "left" : "right") : (g = c, m = d === "end" ? "top" : "bottom");
                const y = p - l[m],
                    x = h - l[g],
                    w = !e.middlewareData.shift;
                let M = y,
                    T = x;
                if (f) {
                    const R = h - l.left - l.right;
                    T = d || w ? Ki(x, R) : R
                } else {
                    const R = p - l.top - l.bottom;
                    M = d || w ? Ki(y, R) : R
                }
                if (w && !d) {
                    const R = Er(l.left, 0),
                        P = Er(l.right, 0),
                        B = Er(l.top, 0),
                        te = Er(l.bottom, 0);
                    f ? T = h - 2 * (R !== 0 || P !== 0 ? R + P : Er(l.left, l.right)) : M = p - 2 * (B !== 0 || te !== 0 ? B + te : Er(l.top, l.bottom))
                }
                await s({ ...e,
                    availableWidth: T,
                    availableHeight: M
                });
                const O = await i.getDimensions(o.floating);
                return h !== O.width || p !== O.height ? {
                    reset: {
                        rects: !0
                    }
                } : {}
            }
        }
    };

function Qi(t) {
    return Kh(t) ? (t.nodeName || "").toLowerCase() : "#document"
}

function Pr(t) {
    var e;
    return (t == null || (e = t.ownerDocument) == null ? void 0 : e.defaultView) || window
}

function Oi(t) {
    var e;
    return (e = (Kh(t) ? t.ownerDocument : t.document) || window.document) == null ? void 0 : e.documentElement
}

function Kh(t) {
    return t instanceof Node || t instanceof Pr(t).Node
}

function Fi(t) {
    return t instanceof Element || t instanceof Pr(t).Element
}

function hi(t) {
    return t instanceof HTMLElement || t instanceof Pr(t).HTMLElement
}

function Fd(t) {
    return typeof ShadowRoot > "u" ? !1 : t instanceof ShadowRoot || t instanceof Pr(t).ShadowRoot
}

function va(t) {
    const {
        overflow: e,
        overflowX: n,
        overflowY: r,
        display: i
    } = Vr(t);
    return /auto|scroll|overlay|hidden|clip/.test(e + r + n) && !["inline", "contents"].includes(i)
}

function m1(t) {
    return ["table", "td", "th"].includes(Qi(t))
}

function wf(t) {
    const e = _f(),
        n = Vr(t);
    return n.transform !== "none" || n.perspective !== "none" || (n.containerType ? n.containerType !== "normal" : !1) || !e && (n.backdropFilter ? n.backdropFilter !== "none" : !1) || !e && (n.filter ? n.filter !== "none" : !1) || ["transform", "perspective", "filter"].some(r => (n.willChange || "").includes(r)) || ["paint", "layout", "strict", "content"].some(r => (n.contain || "").includes(r))
}

function g1(t) {
    let e = is(t);
    for (; hi(e) && !Ql(e);) {
        if (wf(e)) return e;
        e = is(e)
    }
    return null
}

function _f() {
    return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none")
}

function Ql(t) {
    return ["html", "body", "#document"].includes(Qi(t))
}

function Vr(t) {
    return Pr(t).getComputedStyle(t)
}

function Jl(t) {
    return Fi(t) ? {
        scrollLeft: t.scrollLeft,
        scrollTop: t.scrollTop
    } : {
        scrollLeft: t.pageXOffset,
        scrollTop: t.pageYOffset
    }
}

function is(t) {
    if (Qi(t) === "html") return t;
    const e = t.assignedSlot || t.parentNode || Fd(t) && t.host || Oi(t);
    return Fd(e) ? e.host : e
}

function Zh(t) {
    const e = is(t);
    return Ql(e) ? t.ownerDocument ? t.ownerDocument.body : t.body : hi(e) && va(e) ? e : Zh(e)
}

function ra(t, e, n) {
    var r;
    e === void 0 && (e = []), n === void 0 && (n = !0);
    const i = Zh(t),
        o = i === ((r = t.ownerDocument) == null ? void 0 : r.body),
        s = Pr(i);
    return o ? e.concat(s, s.visualViewport || [], va(i) ? i : [], s.frameElement && n ? ra(s.frameElement) : []) : e.concat(i, ra(i, [], n))
}

function Qh(t) {
    const e = Vr(t);
    let n = parseFloat(e.width) || 0,
        r = parseFloat(e.height) || 0;
    const i = hi(t),
        o = i ? t.offsetWidth : n,
        s = i ? t.offsetHeight : r,
        a = bl(n) !== o || bl(r) !== s;
    return a && (n = o, r = s), {
        width: n,
        height: r,
        $: a
    }
}

function Df(t) {
    return Fi(t) ? t : t.contextElement
}

function qo(t) {
    const e = Df(t);
    if (!hi(e)) return Zi(1);
    const n = e.getBoundingClientRect(),
        {
            width: r,
            height: i,
            $: o
        } = Qh(e);
    let s = (o ? bl(n.width) : n.width) / r,
        a = (o ? bl(n.height) : n.height) / i;
    return (!s || !Number.isFinite(s)) && (s = 1), (!a || !Number.isFinite(a)) && (a = 1), {
        x: s,
        y: a
    }
}
const v1 = Zi(0);

function Jh(t) {
    const e = Pr(t);
    return !_f() || !e.visualViewport ? v1 : {
        x: e.visualViewport.offsetLeft,
        y: e.visualViewport.offsetTop
    }
}

function y1(t, e, n) {
    return e === void 0 && (e = !1), !n || e && n !== Pr(t) ? !1 : e
}

function _o(t, e, n, r) {
    e === void 0 && (e = !1), n === void 0 && (n = !1);
    const i = t.getBoundingClientRect(),
        o = Df(t);
    let s = Zi(1);
    e && (r ? Fi(r) && (s = qo(r)) : s = qo(t));
    const a = y1(o, n, r) ? Jh(o) : Zi(0);
    let l = (i.left + a.x) / s.x,
        c = (i.top + a.y) / s.y,
        d = i.width / s.x,
        f = i.height / s.y;
    if (o) {
        const h = Pr(o),
            p = r && Fi(r) ? Pr(r) : r;
        let m = h.frameElement;
        for (; m && r && p !== h;) {
            const g = qo(m),
                y = m.getBoundingClientRect(),
                x = Vr(m),
                w = y.left + (m.clientLeft + parseFloat(x.paddingLeft)) * g.x,
                M = y.top + (m.clientTop + parseFloat(x.paddingTop)) * g.y;
            l *= g.x, c *= g.y, d *= g.x, f *= g.y, l += w, c += M, m = Pr(m).frameElement
        }
    }
    return _l({
        width: d,
        height: f,
        x: l,
        y: c
    })
}

function x1(t) {
    let {
        rect: e,
        offsetParent: n,
        strategy: r
    } = t;
    const i = hi(n),
        o = Oi(n);
    if (n === o) return e;
    let s = {
            scrollLeft: 0,
            scrollTop: 0
        },
        a = Zi(1);
    const l = Zi(0);
    if ((i || !i && r !== "fixed") && ((Qi(n) !== "body" || va(o)) && (s = Jl(n)), hi(n))) {
        const c = _o(n);
        a = qo(n), l.x = c.x + n.clientLeft, l.y = c.y + n.clientTop
    }
    return {
        width: e.width * a.x,
        height: e.height * a.y,
        x: e.x * a.x - s.scrollLeft * a.x + l.x,
        y: e.y * a.y - s.scrollTop * a.y + l.y
    }
}

function b1(t) {
    return Array.from(t.getClientRects())
}

function e0(t) {
    return _o(Oi(t)).left + Jl(t).scrollLeft
}

function w1(t) {
    const e = Oi(t),
        n = Jl(t),
        r = t.ownerDocument.body,
        i = Er(e.scrollWidth, e.clientWidth, r.scrollWidth, r.clientWidth),
        o = Er(e.scrollHeight, e.clientHeight, r.scrollHeight, r.clientHeight);
    let s = -n.scrollLeft + e0(t);
    const a = -n.scrollTop;
    return Vr(r).direction === "rtl" && (s += Er(e.clientWidth, r.clientWidth) - i), {
        width: i,
        height: o,
        x: s,
        y: a
    }
}

function _1(t, e) {
    const n = Pr(t),
        r = Oi(t),
        i = n.visualViewport;
    let o = r.clientWidth,
        s = r.clientHeight,
        a = 0,
        l = 0;
    if (i) {
        o = i.width, s = i.height;
        const c = _f();
        (!c || c && e === "fixed") && (a = i.offsetLeft, l = i.offsetTop)
    }
    return {
        width: o,
        height: s,
        x: a,
        y: l
    }
}

function D1(t, e) {
    const n = _o(t, !0, e === "fixed"),
        r = n.top + t.clientTop,
        i = n.left + t.clientLeft,
        o = hi(t) ? qo(t) : Zi(1),
        s = t.clientWidth * o.x,
        a = t.clientHeight * o.y,
        l = i * o.x,
        c = r * o.y;
    return {
        width: s,
        height: a,
        x: l,
        y: c
    }
}

function kd(t, e, n) {
    let r;
    if (e === "viewport") r = _1(t, n);
    else if (e === "document") r = w1(Oi(t));
    else if (Fi(e)) r = D1(e, n);
    else {
        const i = Jh(t);
        r = { ...e,
            x: e.x - i.x,
            y: e.y - i.y
        }
    }
    return _l(r)
}

function t0(t, e) {
    const n = is(t);
    return n === e || !Fi(n) || Ql(n) ? !1 : Vr(n).position === "fixed" || t0(n, e)
}

function S1(t, e) {
    const n = e.get(t);
    if (n) return n;
    let r = ra(t, [], !1).filter(a => Fi(a) && Qi(a) !== "body"),
        i = null;
    const o = Vr(t).position === "fixed";
    let s = o ? is(t) : t;
    for (; Fi(s) && !Ql(s);) {
        const a = Vr(s),
            l = wf(s);
        !l && a.position === "fixed" && (i = null), (o ? !l && !i : !l && a.position === "static" && !!i && ["absolute", "fixed"].includes(i.position) || va(s) && !l && t0(t, s)) ? r = r.filter(d => d !== s) : i = a, s = is(s)
    }
    return e.set(t, r), r
}

function C1(t) {
    let {
        element: e,
        boundary: n,
        rootBoundary: r,
        strategy: i
    } = t;
    const s = [...n === "clippingAncestors" ? S1(e, this._c) : [].concat(n), r],
        a = s[0],
        l = s.reduce((c, d) => {
            const f = kd(e, d, i);
            return c.top = Er(f.top, c.top), c.right = Ki(f.right, c.right), c.bottom = Ki(f.bottom, c.bottom), c.left = Er(f.left, c.left), c
        }, kd(e, a, i));
    return {
        width: l.right - l.left,
        height: l.bottom - l.top,
        x: l.left,
        y: l.top
    }
}

function E1(t) {
    return Qh(t)
}

function T1(t, e, n) {
    const r = hi(e),
        i = Oi(e),
        o = n === "fixed",
        s = _o(t, !0, o, e);
    let a = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const l = Zi(0);
    if (r || !r && !o)
        if ((Qi(e) !== "body" || va(i)) && (a = Jl(e)), r) {
            const c = _o(e, !0, o, e);
            l.x = c.x + e.clientLeft, l.y = c.y + e.clientTop
        } else i && (l.x = e0(i));
    return {
        x: s.left + a.scrollLeft - l.x,
        y: s.top + a.scrollTop - l.y,
        width: s.width,
        height: s.height
    }
}

function Od(t, e) {
    return !hi(t) || Vr(t).position === "fixed" ? null : e ? e(t) : t.offsetParent
}

function n0(t, e) {
    const n = Pr(t);
    if (!hi(t)) return n;
    let r = Od(t, e);
    for (; r && m1(r) && Vr(r).position === "static";) r = Od(r, e);
    return r && (Qi(r) === "html" || Qi(r) === "body" && Vr(r).position === "static" && !wf(r)) ? n : r || g1(t) || n
}
const P1 = async function(t) {
    let {
        reference: e,
        floating: n,
        strategy: r
    } = t;
    const i = this.getOffsetParent || n0,
        o = this.getDimensions;
    return {
        reference: T1(e, await i(n), r),
        floating: {
            x: 0,
            y: 0,
            ...await o(n)
        }
    }
};

function R1(t) {
    return Vr(t).direction === "rtl"
}
const M1 = {
    convertOffsetParentRelativeRectToViewportRelativeRect: x1,
    getDocumentElement: Oi,
    getClippingRect: C1,
    getOffsetParent: n0,
    getElementRects: P1,
    getClientRects: b1,
    getDimensions: E1,
    getScale: qo,
    isElement: Fi,
    isRTL: R1
};

function $1(t, e) {
    let n = null,
        r;
    const i = Oi(t);

    function o() {
        clearTimeout(r), n && n.disconnect(), n = null
    }

    function s(a, l) {
        a === void 0 && (a = !1), l === void 0 && (l = 1), o();
        const {
            left: c,
            top: d,
            width: f,
            height: h
        } = t.getBoundingClientRect();
        if (a || e(), !f || !h) return;
        const p = Oa(d),
            m = Oa(i.clientWidth - (c + f)),
            g = Oa(i.clientHeight - (d + h)),
            y = Oa(c),
            w = {
                rootMargin: -p + "px " + -m + "px " + -g + "px " + -y + "px",
                threshold: Er(0, Ki(1, l)) || 1
            };
        let M = !0;

        function T(O) {
            const R = O[0].intersectionRatio;
            if (R !== l) {
                if (!M) return s();
                R ? s(!1, R) : r = setTimeout(() => {
                    s(!1, 1e-7)
                }, 100)
            }
            M = !1
        }
        try {
            n = new IntersectionObserver(T, { ...w,
                root: i.ownerDocument
            })
        } catch {
            n = new IntersectionObserver(T, w)
        }
        n.observe(t)
    }
    return s(!0), o
}

function A1(t, e, n, r) {
    r === void 0 && (r = {});
    const {
        ancestorScroll: i = !0,
        ancestorResize: o = !0,
        elementResize: s = typeof ResizeObserver == "function",
        layoutShift: a = typeof IntersectionObserver == "function",
        animationFrame: l = !1
    } = r, c = Df(t), d = i || o ? [...c ? ra(c) : [], ...ra(e)] : [];
    d.forEach(x => {
        i && x.addEventListener("scroll", n, {
            passive: !0
        }), o && x.addEventListener("resize", n)
    });
    const f = c && a ? $1(c, n) : null;
    let h = -1,
        p = null;
    s && (p = new ResizeObserver(x => {
        let [w] = x;
        w && w.target === c && p && (p.unobserve(e), cancelAnimationFrame(h), h = requestAnimationFrame(() => {
            p && p.observe(e)
        })), n()
    }), c && !l && p.observe(c), p.observe(e));
    let m, g = l ? _o(t) : null;
    l && y();

    function y() {
        const x = _o(t);
        g && (x.x !== g.x || x.y !== g.y || x.width !== g.width || x.height !== g.height) && n(), g = x, m = requestAnimationFrame(y)
    }
    return n(), () => {
        d.forEach(x => {
            i && x.removeEventListener("scroll", n), o && x.removeEventListener("resize", n)
        }), f && f(), p && p.disconnect(), p = null, l && cancelAnimationFrame(m)
    }
}
const F1 = (t, e, n) => {
        const r = new Map,
            i = {
                platform: M1,
                ...n
            },
            o = { ...i.platform,
                _c: r
            };
        return a1(t, e, { ...i,
            platform: o
        })
    },
    k1 = t => {
        function e(n) {
            return {}.hasOwnProperty.call(n, "current")
        }
        return {
            name: "arrow",
            options: t,
            fn(n) {
                const {
                    element: r,
                    padding: i
                } = typeof t == "function" ? t(n) : t;
                return r && e(r) ? r.current != null ? Md({
                    element: r.current,
                    padding: i
                }).fn(n) : {} : r ? Md({
                    element: r,
                    padding: i
                }).fn(n) : {}
            }
        }
    };
var ll = typeof document < "u" ? u.useLayoutEffect : u.useEffect;

function Dl(t, e) {
    if (t === e) return !0;
    if (typeof t != typeof e) return !1;
    if (typeof t == "function" && t.toString() === e.toString()) return !0;
    let n, r, i;
    if (t && e && typeof t == "object") {
        if (Array.isArray(t)) {
            if (n = t.length, n != e.length) return !1;
            for (r = n; r-- !== 0;)
                if (!Dl(t[r], e[r])) return !1;
            return !0
        }
        if (i = Object.keys(t), n = i.length, n !== Object.keys(e).length) return !1;
        for (r = n; r-- !== 0;)
            if (!{}.hasOwnProperty.call(e, i[r])) return !1;
        for (r = n; r-- !== 0;) {
            const o = i[r];
            if (!(o === "_owner" && t.$$typeof) && !Dl(t[o], e[o])) return !1
        }
        return !0
    }
    return t !== t && e !== e
}

function r0(t) {
    return typeof window > "u" ? 1 : (t.ownerDocument.defaultView || window).devicePixelRatio || 1
}

function jd(t, e) {
    const n = r0(t);
    return Math.round(e * n) / n
}

function Ld(t) {
    const e = u.useRef(t);
    return ll(() => {
        e.current = t
    }), e
}

function O1(t) {
    t === void 0 && (t = {});
    const {
        placement: e = "bottom",
        strategy: n = "absolute",
        middleware: r = [],
        platform: i,
        elements: {
            reference: o,
            floating: s
        } = {},
        transform: a = !0,
        whileElementsMounted: l,
        open: c
    } = t, [d, f] = u.useState({
        x: 0,
        y: 0,
        strategy: n,
        placement: e,
        middlewareData: {},
        isPositioned: !1
    }), [h, p] = u.useState(r);
    Dl(h, r) || p(r);
    const [m, g] = u.useState(null), [y, x] = u.useState(null), w = u.useCallback(Z => {
        Z != R.current && (R.current = Z, g(Z))
    }, [g]), M = u.useCallback(Z => {
        Z !== P.current && (P.current = Z, x(Z))
    }, [x]), T = o || m, O = s || y, R = u.useRef(null), P = u.useRef(null), B = u.useRef(d), te = Ld(l), W = Ld(i), ee = u.useCallback(() => {
        if (!R.current || !P.current) return;
        const Z = {
            placement: e,
            strategy: n,
            middleware: h
        };
        W.current && (Z.platform = W.current), F1(R.current, P.current, Z).then(le => {
            const Se = { ...le,
                isPositioned: !0
            };
            V.current && !Dl(B.current, Se) && (B.current = Se, cf.flushSync(() => {
                f(Se)
            }))
        })
    }, [h, e, n, W]);
    ll(() => {
        c === !1 && B.current.isPositioned && (B.current.isPositioned = !1, f(Z => ({ ...Z,
            isPositioned: !1
        })))
    }, [c]);
    const V = u.useRef(!1);
    ll(() => (V.current = !0, () => {
        V.current = !1
    }), []), ll(() => {
        if (T && (R.current = T), O && (P.current = O), T && O) {
            if (te.current) return te.current(T, O, ee);
            ee()
        }
    }, [T, O, ee, te]);
    const I = u.useMemo(() => ({
            reference: R,
            floating: P,
            setReference: w,
            setFloating: M
        }), [w, M]),
        X = u.useMemo(() => ({
            reference: T,
            floating: O
        }), [T, O]),
        q = u.useMemo(() => {
            const Z = {
                position: n,
                left: 0,
                top: 0
            };
            if (!X.floating) return Z;
            const le = jd(X.floating, d.x),
                Se = jd(X.floating, d.y);
            return a ? { ...Z,
                transform: "translate(" + le + "px, " + Se + "px)",
                ...r0(X.floating) >= 1.5 && {
                    willChange: "transform"
                }
            } : {
                position: n,
                left: le,
                top: Se
            }
        }, [n, a, X.floating, d.x, d.y]);
    return u.useMemo(() => ({ ...d,
        update: ee,
        refs: I,
        elements: X,
        floatingStyles: q
    }), [d, ee, I, X, q])
}
const j1 = u.forwardRef((t, e) => {
        const {
            children: n,
            width: r = 10,
            height: i = 5,
            ...o
        } = t;
        return u.createElement(Ro.svg, Xn({}, o, {
            ref: e,
            width: r,
            height: i,
            viewBox: "0 0 30 10",
            preserveAspectRatio: "none"
        }), t.asChild ? n : u.createElement("polygon", {
            points: "0,0 30,0 15,10"
        }))
    }),
    L1 = j1;

function N1(t) {
    const [e, n] = u.useState(void 0);
    return rs(() => {
        if (t) {
            n({
                width: t.offsetWidth,
                height: t.offsetHeight
            });
            const r = new ResizeObserver(i => {
                if (!Array.isArray(i) || !i.length) return;
                const o = i[0];
                let s, a;
                if ("borderBoxSize" in o) {
                    const l = o.borderBoxSize,
                        c = Array.isArray(l) ? l[0] : l;
                    s = c.inlineSize, a = c.blockSize
                } else s = t.offsetWidth, a = t.offsetHeight;
                n({
                    width: s,
                    height: a
                })
            });
            return r.observe(t, {
                box: "border-box"
            }), () => r.unobserve(t)
        } else n(void 0)
    }, [t]), e
}
const i0 = "Popper",
    [o0, s0] = Yh(i0),
    [z1, a0] = o0(i0),
    I1 = t => {
        const {
            __scopePopper: e,
            children: n
        } = t, [r, i] = u.useState(null);
        return u.createElement(z1, {
            scope: e,
            anchor: r,
            onAnchorChange: i
        }, n)
    },
    B1 = "PopperAnchor",
    W1 = u.forwardRef((t, e) => {
        const {
            __scopePopper: n,
            virtualRef: r,
            ...i
        } = t, o = a0(B1, n), s = u.useRef(null), a = fs(e, s);
        return u.useEffect(() => {
            o.onAnchorChange((r == null ? void 0 : r.current) || s.current)
        }), r ? null : u.createElement(Ro.div, Xn({}, i, {
            ref: a
        }))
    }),
    l0 = "PopperContent",
    [V1, U1] = o0(l0),
    H1 = u.forwardRef((t, e) => {
        var n, r, i, o, s, a, l, c;
        const {
            __scopePopper: d,
            side: f = "bottom",
            sideOffset: h = 0,
            align: p = "center",
            alignOffset: m = 0,
            arrowPadding: g = 0,
            avoidCollisions: y = !0,
            collisionBoundary: x = [],
            collisionPadding: w = 0,
            sticky: M = "partial",
            hideWhenDetached: T = !1,
            updatePositionStrategy: O = "optimized",
            onPlaced: R,
            ...P
        } = t, B = a0(l0, d), [te, W] = u.useState(null), ee = fs(e, ot => W(ot)), [V, I] = u.useState(null), X = N1(V), q = (n = X == null ? void 0 : X.width) !== null && n !== void 0 ? n : 0, Z = (r = X == null ? void 0 : X.height) !== null && r !== void 0 ? r : 0, le = f + (p !== "center" ? "-" + p : ""), Se = typeof w == "number" ? w : {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            ...w
        }, Me = Array.isArray(x) ? x : [x], z = Me.length > 0, ge = {
            padding: Se,
            boundary: Me.filter(q1),
            altBoundary: z
        }, {
            refs: $e,
            floatingStyles: Xe,
            placement: tt,
            isPositioned: wt,
            middlewareData: Ue
        } = O1({
            strategy: "fixed",
            placement: le,
            whileElementsMounted: (...ot) => A1(...ot, {
                animationFrame: O === "always"
            }),
            elements: {
                reference: B.anchor
            },
            middleware: [f1({
                mainAxis: h + Z,
                alignmentAxis: m
            }), y && d1({
                mainAxis: !0,
                crossAxis: !1,
                limiter: M === "partial" ? p1() : void 0,
                ...ge
            }), y && l1({ ...ge
            }), h1({ ...ge,
                apply: ({
                    elements: ot,
                    rects: gt,
                    availableWidth: re,
                    availableHeight: pt
                }) => {
                    const {
                        width: It,
                        height: At
                    } = gt.reference, Je = ot.floating.style;
                    Je.setProperty("--radix-popper-available-width", `${re}px`), Je.setProperty("--radix-popper-available-height", `${pt}px`), Je.setProperty("--radix-popper-anchor-width", `${It}px`), Je.setProperty("--radix-popper-anchor-height", `${At}px`)
                }
            }), V && k1({
                element: V,
                padding: g
            }), K1({
                arrowWidth: q,
                arrowHeight: Z
            }), T && c1({
                strategy: "referenceHidden",
                ...ge
            })]
        }), [Ye, Ge] = c0(tt), rt = ps(R);
        rs(() => {
            wt && (rt == null || rt())
        }, [wt, rt]);
        const it = (i = Ue.arrow) === null || i === void 0 ? void 0 : i.x,
            lt = (o = Ue.arrow) === null || o === void 0 ? void 0 : o.y,
            Lt = ((s = Ue.arrow) === null || s === void 0 ? void 0 : s.centerOffset) !== 0,
            [Ne, ct] = u.useState();
        return rs(() => {
            te && ct(window.getComputedStyle(te).zIndex)
        }, [te]), u.createElement("div", {
            ref: $e.setFloating,
            "data-radix-popper-content-wrapper": "",
            style: { ...Xe,
                transform: wt ? Xe.transform : "translate(0, -200%)",
                minWidth: "max-content",
                zIndex: Ne,
                "--radix-popper-transform-origin": [(a = Ue.transformOrigin) === null || a === void 0 ? void 0 : a.x, (l = Ue.transformOrigin) === null || l === void 0 ? void 0 : l.y].join(" ")
            },
            dir: t.dir
        }, u.createElement(V1, {
            scope: d,
            placedSide: Ye,
            onArrowChange: I,
            arrowX: it,
            arrowY: lt,
            shouldHideArrow: Lt
        }, u.createElement(Ro.div, Xn({
            "data-side": Ye,
            "data-align": Ge
        }, P, {
            ref: ee,
            style: { ...P.style,
                animation: wt ? void 0 : "none",
                opacity: (c = Ue.hide) !== null && c !== void 0 && c.referenceHidden ? 0 : void 0
            }
        }))))
    }),
    G1 = "PopperArrow",
    Y1 = {
        top: "bottom",
        right: "left",
        bottom: "top",
        left: "right"
    },
    X1 = u.forwardRef(function(e, n) {
        const {
            __scopePopper: r,
            ...i
        } = e, o = U1(G1, r), s = Y1[o.placedSide];
        return u.createElement("span", {
            ref: o.onArrowChange,
            style: {
                position: "absolute",
                left: o.arrowX,
                top: o.arrowY,
                [s]: 0,
                transformOrigin: {
                    top: "",
                    right: "0 0",
                    bottom: "center 0",
                    left: "100% 0"
                }[o.placedSide],
                transform: {
                    top: "translateY(100%)",
                    right: "translateY(50%) rotate(90deg) translateX(-50%)",
                    bottom: "rotate(180deg)",
                    left: "translateY(50%) rotate(-90deg) translateX(50%)"
                }[o.placedSide],
                visibility: o.shouldHideArrow ? "hidden" : void 0
            }
        }, u.createElement(L1, Xn({}, i, {
            ref: n,
            style: { ...i.style,
                display: "block"
            }
        })))
    });

function q1(t) {
    return t !== null
}
const K1 = t => ({
    name: "transformOrigin",
    options: t,
    fn(e) {
        var n, r, i, o, s;
        const {
            placement: a,
            rects: l,
            middlewareData: c
        } = e, f = ((n = c.arrow) === null || n === void 0 ? void 0 : n.centerOffset) !== 0, h = f ? 0 : t.arrowWidth, p = f ? 0 : t.arrowHeight, [m, g] = c0(a), y = {
            start: "0%",
            center: "50%",
            end: "100%"
        }[g], x = ((r = (i = c.arrow) === null || i === void 0 ? void 0 : i.x) !== null && r !== void 0 ? r : 0) + h / 2, w = ((o = (s = c.arrow) === null || s === void 0 ? void 0 : s.y) !== null && o !== void 0 ? o : 0) + p / 2;
        let M = "",
            T = "";
        return m === "bottom" ? (M = f ? y : `${x}px`, T = `${-p}px`) : m === "top" ? (M = f ? y : `${x}px`, T = `${l.floating.height+p}px`) : m === "right" ? (M = `${-p}px`, T = f ? y : `${w}px`) : m === "left" && (M = `${l.floating.width+p}px`, T = f ? y : `${w}px`), {
            data: {
                x: M,
                y: T
            }
        }
    }
});

function c0(t) {
    const [e, n = "center"] = t.split("-");
    return [e, n]
}
const Z1 = I1,
    Q1 = W1,
    J1 = H1,
    ex = X1;

function tx(t, e) {
    return u.useReducer((n, r) => {
        const i = e[n][r];
        return i ? ? n
    }, t)
}
const u0 = t => {
    const {
        present: e,
        children: n
    } = t, r = nx(e), i = typeof n == "function" ? n({
        present: r.isPresent
    }) : u.Children.only(n), o = fs(r.ref, i.ref);
    return typeof n == "function" || r.isPresent ? u.cloneElement(i, {
        ref: o
    }) : null
};
u0.displayName = "Presence";

function nx(t) {
    const [e, n] = u.useState(), r = u.useRef({}), i = u.useRef(t), o = u.useRef("none"), s = t ? "mounted" : "unmounted", [a, l] = tx(s, {
        mounted: {
            UNMOUNT: "unmounted",
            ANIMATION_OUT: "unmountSuspended"
        },
        unmountSuspended: {
            MOUNT: "mounted",
            ANIMATION_END: "unmounted"
        },
        unmounted: {
            MOUNT: "mounted"
        }
    });
    return u.useEffect(() => {
        const c = ja(r.current);
        o.current = a === "mounted" ? c : "none"
    }, [a]), rs(() => {
        const c = r.current,
            d = i.current;
        if (d !== t) {
            const h = o.current,
                p = ja(c);
            t ? l("MOUNT") : p === "none" || (c == null ? void 0 : c.display) === "none" ? l("UNMOUNT") : l(d && h !== p ? "ANIMATION_OUT" : "UNMOUNT"), i.current = t
        }
    }, [t, l]), rs(() => {
        if (e) {
            const c = f => {
                    const p = ja(r.current).includes(f.animationName);
                    f.target === e && p && cf.flushSync(() => l("ANIMATION_END"))
                },
                d = f => {
                    f.target === e && (o.current = ja(r.current))
                };
            return e.addEventListener("animationstart", d), e.addEventListener("animationcancel", c), e.addEventListener("animationend", c), () => {
                e.removeEventListener("animationstart", d), e.removeEventListener("animationcancel", c), e.removeEventListener("animationend", c)
            }
        } else l("ANIMATION_END")
    }, [e, l]), {
        isPresent: ["mounted", "unmountSuspended"].includes(a),
        ref: u.useCallback(c => {
            c && (r.current = getComputedStyle(c)), n(c)
        }, [])
    }
}

function ja(t) {
    return (t == null ? void 0 : t.animationName) || "none"
}

function rx({
    prop: t,
    defaultProp: e,
    onChange: n = () => {}
}) {
    const [r, i] = ix({
        defaultProp: e,
        onChange: n
    }), o = t !== void 0, s = o ? t : r, a = ps(n), l = u.useCallback(c => {
        if (o) {
            const f = typeof c == "function" ? c(t) : c;
            f !== t && a(f)
        } else i(c)
    }, [o, t, i, a]);
    return [s, l]
}

function ix({
    defaultProp: t,
    onChange: e
}) {
    const n = u.useState(t),
        [r] = n,
        i = u.useRef(r),
        o = ps(e);
    return u.useEffect(() => {
        i.current !== r && (o(r), i.current = r)
    }, [r, i, o]), n
}
const ox = u.forwardRef((t, e) => u.createElement(Ro.span, Xn({}, t, {
        ref: e,
        style: {
            position: "absolute",
            border: 0,
            width: 1,
            height: 1,
            padding: 0,
            margin: -1,
            overflow: "hidden",
            clip: "rect(0, 0, 0, 0)",
            whiteSpace: "nowrap",
            wordWrap: "normal",
            ...t.style
        }
    }))),
    sx = ox,
    [ec, RP] = Yh("Tooltip", [s0]),
    tc = s0(),
    ax = "TooltipProvider",
    su = "tooltip.open",
    [MP, Sf] = ec(ax),
    Cf = "Tooltip",
    [lx, nc] = ec(Cf),
    cx = t => {
        const {
            __scopeTooltip: e,
            children: n,
            open: r,
            defaultOpen: i = !1,
            onOpenChange: o,
            disableHoverableContent: s,
            delayDuration: a
        } = t, l = Sf(Cf, t.__scopeTooltip), c = tc(e), [d, f] = u.useState(null), h = Qy(), p = u.useRef(0), m = s ? ? l.disableHoverableContent, g = a ? ? l.delayDuration, y = u.useRef(!1), [x = !1, w] = rx({
            prop: r,
            defaultProp: i,
            onChange: P => {
                P ? (l.onOpen(), document.dispatchEvent(new CustomEvent(su))) : l.onClose(), o == null || o(P)
            }
        }), M = u.useMemo(() => x ? y.current ? "delayed-open" : "instant-open" : "closed", [x]), T = u.useCallback(() => {
            window.clearTimeout(p.current), y.current = !1, w(!0)
        }, [w]), O = u.useCallback(() => {
            window.clearTimeout(p.current), w(!1)
        }, [w]), R = u.useCallback(() => {
            window.clearTimeout(p.current), p.current = window.setTimeout(() => {
                y.current = !0, w(!0)
            }, g)
        }, [g, w]);
        return u.useEffect(() => () => window.clearTimeout(p.current), []), u.createElement(Z1, c, u.createElement(lx, {
            scope: e,
            contentId: h,
            open: x,
            stateAttribute: M,
            trigger: d,
            onTriggerChange: f,
            onTriggerEnter: u.useCallback(() => {
                l.isOpenDelayed ? R() : T()
            }, [l.isOpenDelayed, R, T]),
            onTriggerLeave: u.useCallback(() => {
                m ? O() : window.clearTimeout(p.current)
            }, [O, m]),
            onOpen: T,
            onClose: O,
            disableHoverableContent: m
        }, n))
    },
    Nd = "TooltipTrigger",
    ux = u.forwardRef((t, e) => {
        const {
            __scopeTooltip: n,
            ...r
        } = t, i = nc(Nd, n), o = Sf(Nd, n), s = tc(n), a = u.useRef(null), l = fs(e, a, i.onTriggerChange), c = u.useRef(!1), d = u.useRef(!1), f = u.useCallback(() => c.current = !1, []);
        return u.useEffect(() => () => document.removeEventListener("pointerup", f), [f]), u.createElement(Q1, Xn({
            asChild: !0
        }, s), u.createElement(Ro.button, Xn({
            "aria-describedby": i.open ? i.contentId : void 0,
            "data-state": i.stateAttribute
        }, r, {
            ref: l,
            onPointerMove: xi(t.onPointerMove, h => {
                h.pointerType !== "touch" && !d.current && !o.isPointerInTransitRef.current && (i.onTriggerEnter(), d.current = !0)
            }),
            onPointerLeave: xi(t.onPointerLeave, () => {
                i.onTriggerLeave(), d.current = !1
            }),
            onPointerDown: xi(t.onPointerDown, () => {
                c.current = !0, document.addEventListener("pointerup", f, {
                    once: !0
                })
            }),
            onFocus: xi(t.onFocus, () => {
                c.current || i.onOpen()
            }),
            onBlur: xi(t.onBlur, i.onClose),
            onClick: xi(t.onClick, i.onClose)
        })))
    }),
    fx = "TooltipPortal",
    [$P, dx] = ec(fx, {
        forceMount: void 0
    }),
    ia = "TooltipContent",
    px = u.forwardRef((t, e) => {
        const n = dx(ia, t.__scopeTooltip),
            {
                forceMount: r = n.forceMount,
                side: i = "top",
                ...o
            } = t,
            s = nc(ia, t.__scopeTooltip);
        return u.createElement(u0, {
            present: r || s.open
        }, s.disableHoverableContent ? u.createElement(f0, Xn({
            side: i
        }, o, {
            ref: e
        })) : u.createElement(hx, Xn({
            side: i
        }, o, {
            ref: e
        })))
    }),
    hx = u.forwardRef((t, e) => {
        const n = nc(ia, t.__scopeTooltip),
            r = Sf(ia, t.__scopeTooltip),
            i = u.useRef(null),
            o = fs(e, i),
            [s, a] = u.useState(null),
            {
                trigger: l,
                onClose: c
            } = n,
            d = i.current,
            {
                onPointerInTransitChange: f
            } = r,
            h = u.useCallback(() => {
                a(null), f(!1)
            }, [f]),
            p = u.useCallback((m, g) => {
                const y = m.currentTarget,
                    x = {
                        x: m.clientX,
                        y: m.clientY
                    },
                    w = xx(x, y.getBoundingClientRect()),
                    M = bx(x, w),
                    T = wx(g.getBoundingClientRect()),
                    O = Dx([...M, ...T]);
                a(O), f(!0)
            }, [f]);
        return u.useEffect(() => () => h(), [h]), u.useEffect(() => {
            if (l && d) {
                const m = y => p(y, d),
                    g = y => p(y, l);
                return l.addEventListener("pointerleave", m), d.addEventListener("pointerleave", g), () => {
                    l.removeEventListener("pointerleave", m), d.removeEventListener("pointerleave", g)
                }
            }
        }, [l, d, p, h]), u.useEffect(() => {
            if (s) {
                const m = g => {
                    const y = g.target,
                        x = {
                            x: g.clientX,
                            y: g.clientY
                        },
                        w = (l == null ? void 0 : l.contains(y)) || (d == null ? void 0 : d.contains(y)),
                        M = !_x(x, s);
                    w ? h() : M && (h(), c())
                };
                return document.addEventListener("pointermove", m), () => document.removeEventListener("pointermove", m)
            }
        }, [l, d, s, c, h]), u.createElement(f0, Xn({}, t, {
            ref: o
        }))
    }),
    [mx, gx] = ec(Cf, {
        isInside: !1
    }),
    f0 = u.forwardRef((t, e) => {
        const {
            __scopeTooltip: n,
            children: r,
            "aria-label": i,
            onEscapeKeyDown: o,
            onPointerDownOutside: s,
            ...a
        } = t, l = nc(ia, n), c = tc(n), {
            onClose: d
        } = l;
        return u.useEffect(() => (document.addEventListener(su, d), () => document.removeEventListener(su, d)), [d]), u.useEffect(() => {
            if (l.trigger) {
                const f = h => {
                    const p = h.target;
                    p != null && p.contains(l.trigger) && d()
                };
                return window.addEventListener("scroll", f, {
                    capture: !0
                }), () => window.removeEventListener("scroll", f, {
                    capture: !0
                })
            }
        }, [l.trigger, d]), u.createElement(Yy, {
            asChild: !0,
            disableOutsidePointerEvents: !1,
            onEscapeKeyDown: o,
            onPointerDownOutside: s,
            onFocusOutside: f => f.preventDefault(),
            onDismiss: d
        }, u.createElement(J1, Xn({
            "data-state": l.stateAttribute
        }, c, a, {
            ref: e,
            style: { ...a.style,
                "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
                "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
                "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
                "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
                "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
            }
        }), u.createElement(Bh, null, r), u.createElement(mx, {
            scope: n,
            isInside: !0
        }, u.createElement(sx, {
            id: l.contentId,
            role: "tooltip"
        }, i || r))))
    }),
    vx = "TooltipArrow",
    yx = u.forwardRef((t, e) => {
        const {
            __scopeTooltip: n,
            ...r
        } = t, i = tc(n);
        return gx(vx, n).isInside ? null : u.createElement(ex, Xn({}, i, r, {
            ref: e
        }))
    });

function xx(t, e) {
    const n = Math.abs(e.top - t.y),
        r = Math.abs(e.bottom - t.y),
        i = Math.abs(e.right - t.x),
        o = Math.abs(e.left - t.x);
    switch (Math.min(n, r, i, o)) {
        case o:
            return "left";
        case i:
            return "right";
        case n:
            return "top";
        case r:
            return "bottom";
        default:
            throw new Error("unreachable")
    }
}

function bx(t, e, n = 5) {
    const r = [];
    switch (e) {
        case "top":
            r.push({
                x: t.x - n,
                y: t.y + n
            }, {
                x: t.x + n,
                y: t.y + n
            });
            break;
        case "bottom":
            r.push({
                x: t.x - n,
                y: t.y - n
            }, {
                x: t.x + n,
                y: t.y - n
            });
            break;
        case "left":
            r.push({
                x: t.x + n,
                y: t.y - n
            }, {
                x: t.x + n,
                y: t.y + n
            });
            break;
        case "right":
            r.push({
                x: t.x - n,
                y: t.y - n
            }, {
                x: t.x - n,
                y: t.y + n
            });
            break
    }
    return r
}

function wx(t) {
    const {
        top: e,
        right: n,
        bottom: r,
        left: i
    } = t;
    return [{
        x: i,
        y: e
    }, {
        x: n,
        y: e
    }, {
        x: n,
        y: r
    }, {
        x: i,
        y: r
    }]
}

function _x(t, e) {
    const {
        x: n,
        y: r
    } = t;
    let i = !1;
    for (let o = 0, s = e.length - 1; o < e.length; s = o++) {
        const a = e[o].x,
            l = e[o].y,
            c = e[s].x,
            d = e[s].y;
        l > r != d > r && n < (c - a) * (r - l) / (d - l) + a && (i = !i)
    }
    return i
}

function Dx(t) {
    const e = t.slice();
    return e.sort((n, r) => n.x < r.x ? -1 : n.x > r.x ? 1 : n.y < r.y ? -1 : n.y > r.y ? 1 : 0), Sx(e)
}

function Sx(t) {
    if (t.length <= 1) return t.slice();
    const e = [];
    for (let r = 0; r < t.length; r++) {
        const i = t[r];
        for (; e.length >= 2;) {
            const o = e[e.length - 1],
                s = e[e.length - 2];
            if ((o.x - s.x) * (i.y - s.y) >= (o.y - s.y) * (i.x - s.x)) e.pop();
            else break
        }
        e.push(i)
    }
    e.pop();
    const n = [];
    for (let r = t.length - 1; r >= 0; r--) {
        const i = t[r];
        for (; n.length >= 2;) {
            const o = n[n.length - 1],
                s = n[n.length - 2];
            if ((o.x - s.x) * (i.y - s.y) >= (o.y - s.y) * (i.x - s.x)) n.pop();
            else break
        }
        n.push(i)
    }
    return n.pop(), e.length === 1 && n.length === 1 && e[0].x === n[0].x && e[0].y === n[0].y ? e : e.concat(n)
}
const Cx = cx,
    Ex = ux,
    Tx = px,
    Px = yx;

function Rx(t, e) {
    if (t == null) return {};
    var n = {},
        r = Object.keys(t),
        i, o;
    for (o = 0; o < r.length; o++) i = r[o], !(e.indexOf(i) >= 0) && (n[i] = t[i]);
    return n
}

function tn(t, e) {
    if (t == null) return {};
    var n = Rx(t, e),
        r, i;
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(t);
        for (i = 0; i < o.length; i++) r = o[i], !(e.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(t, r) && (n[r] = t[r])
    }
    return n
}
let xn;
(function(t) {
    t[t.UNSUPPORTED_INPUT = 0] = "UNSUPPORTED_INPUT", t[t.NO_COMPONENT_FOR_TYPE = 1] = "NO_COMPONENT_FOR_TYPE", t[t.UNKNOWN_INPUT = 2] = "UNKNOWN_INPUT", t[t.DUPLICATE_KEYS = 3] = "DUPLICATE_KEYS", t[t.ALREADY_REGISTERED_TYPE = 4] = "ALREADY_REGISTERED_TYPE", t[t.CLIPBOARD_ERROR = 5] = "CLIPBOARD_ERROR", t[t.THEME_ERROR = 6] = "THEME_ERROR", t[t.PATH_DOESNT_EXIST = 7] = "PATH_DOESNT_EXIST", t[t.INPUT_TYPE_OVERRIDE = 8] = "INPUT_TYPE_OVERRIDE", t[t.EMPTY_KEY = 9] = "EMPTY_KEY"
})(xn || (xn = {}));
const Mx = {
    [xn.UNSUPPORTED_INPUT]: (t, e) => [`An input with type \`${t}\` input was found at path \`${e}\` but it's not supported yet.`],
    [xn.NO_COMPONENT_FOR_TYPE]: (t, e) => [`Type \`${t}\` found at path \`${e}\` can't be displayed in panel because no component supports it yet.`],
    [xn.UNKNOWN_INPUT]: (t, e) => [`input at path \`${t}\` is not recognized.`, e],
    [xn.DUPLICATE_KEYS]: (t, e, n) => [`Key \`${t}\` of path \`${e}\` already exists at path \`${n}\`. Even nested keys need to be unique. Rename one of the keys.`],
    [xn.ALREADY_REGISTERED_TYPE]: t => [`Type ${t} has already been registered. You can't register a component with the same type.`],
    [xn.CLIPBOARD_ERROR]: t => ["Error copying the value", t],
    [xn.THEME_ERROR]: (t, e) => [`Error accessing the theme \`${t}.${e}\` value.`],
    [xn.PATH_DOESNT_EXIST]: t => [`Error getting the value at path \`${t}\`. There is probably an error in your \`render\` function.`],
    [xn.PATH_DOESNT_EXIST]: t => [`Error accessing the value at path \`${t}\``],
    [xn.INPUT_TYPE_OVERRIDE]: (t, e, n) => [`Input at path \`${t}\` already exists with type: \`${e}\`. Its type cannot be overridden with type \`${n}\`.`],
    [xn.EMPTY_KEY]: () => ["Keys can not be empty, if you want to hide a label use whitespace."]
};

function d0(t, e, ...n) {
    const [r, ...i] = Mx[e](...n);
    console[t]("LEVA: " + r, ...i)
}
const bi = d0.bind(null, "warn"),
    $x = d0.bind(null, "log"),
    Ax = ["value"],
    Fx = ["schema"],
    kx = ["value"],
    p0 = [],
    Do = {};

function zd(t) {
    let {
        value: e
    } = t, n = tn(t, Ax);
    for (let r of p0) {
        const i = r(e, n);
        if (i) return i
    }
}

function ji(t, e) {
    let {
        schema: n
    } = e, r = tn(e, Fx);
    if (t in Do) {
        bi(xn.ALREADY_REGISTERED_TYPE, t);
        return
    }
    p0.push((i, o) => n(i, o) && t), Do[t] = r
}

function _c(t, e, n, r) {
    const {
        normalize: i
    } = Do[t];
    if (i) return i(e, n, r);
    if (typeof e != "object" || !("value" in e)) return {
        value: e
    };
    const {
        value: o
    } = e, s = tn(e, kx);
    return {
        value: o,
        settings: s
    }
}

function Ox(t, e, n, r, i, o) {
    const {
        sanitize: s
    } = Do[t];
    return s ? s(e, n, r, i, o) : e
}

function Id(t, e, n) {
    const {
        format: r
    } = Do[t];
    return r ? r(e, n) : e
}

function jx(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t
}

function Bd(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(t, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function ft(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? Bd(Object(n), !0).forEach(function(r) {
            jx(t, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Bd(Object(n)).forEach(function(r) {
            Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return t
}
const Ji = (t, e, n) => t > n ? n : t < e ? e : t,
    Lx = t => {
        if (t === "" || typeof t == "number") return t;
        try {
            const e = Wi(t);
            if (!isNaN(e)) return e
        } catch {}
        return parseFloat(t)
    },
    Nx = Math.log(10);

function Wd(t) {
    let e = Math.abs(+String(t).replace(".", ""));
    if (e === 0) return .01;
    for (; e !== 0 && e % 10 === 0;) e /= 10;
    const n = Math.floor(Math.log(e) / Nx) + 1,
        r = Math.floor(Math.log10(Math.abs(t))),
        i = Math.pow(10, r - n);
    return Math.max(i, .001)
}
const Sl = (t, e, n) => n === e ? 0 : (Ji(t, e, n) - e) / (n - e),
    Cl = (t, e, n) => t * (n - e) + e,
    zx = () => "_" + Math.random().toString(36).substr(2, 9),
    Vd = /\(([0-9+\-*/^ .]+)\)/,
    Ud = /(\d+(?:\.\d+)?) ?\^ ?(\d+(?:\.\d+)?)/,
    Hd = /(\d+(?:\.\d+)?) ?\* ?(\d+(?:\.\d+)?)/,
    Gd = /(\d+(?:\.\d+)?) ?\/ ?(\d+(?:\.\d+)?)/,
    Yd = /(\d+(?:\.\d+)?) ?\+ ?(\d+(?:\.\d+)?)/,
    Xd = /(\d+(?:\.\d+)?) ?- ?(\d+(?:\.\d+)?)/;

function Wi(t) {
    if (isNaN(Number(t)))
        if (Vd.test(t)) {
            const e = t.replace(Vd, (n, r) => String(Wi(r)));
            return Wi(e)
        } else if (Ud.test(t)) {
        const e = t.replace(Ud, (n, r, i) => String(Math.pow(Number(r), Number(i))));
        return Wi(e)
    } else if (Hd.test(t)) {
        const e = t.replace(Hd, (n, r, i) => String(Number(r) * Number(i)));
        return Wi(e)
    } else if (Gd.test(t)) {
        const e = t.replace(Gd, (n, r, i) => {
            if (i != 0) return String(Number(r) / Number(i));
            throw new Error("Division by zero")
        });
        return Wi(e)
    } else if (Yd.test(t)) {
        const e = t.replace(Yd, (n, r, i) => String(Number(r) + Number(i)));
        return Wi(e)
    } else if (Xd.test(t)) {
        const e = t.replace(Xd, (n, r, i) => String(Number(r) - Number(i)));
        return Wi(e)
    } else return Number(t);
    return Number(t)
}

function Ix(t, e) {
    return e.reduce((n, r) => (t && t.hasOwnProperty(r) && (n[r] = t[r]), n), {})
}

function Bx(t, e) {
    const n = ft({}, t);
    return e.forEach(r => r in t && delete n[r]), n
}

function Wx(t, e) {
    return t.reduce((n, r, i) => Object.assign(n, {
        [e[i]]: r
    }), {})
}

function h0(t) {
    return Object.prototype.toString.call(t) === "[object Object]"
}
const Vx = t => h0(t) && Object.keys(t).length === 0;
let ei;
(function(t) {
    t.BUTTON = "BUTTON", t.BUTTON_GROUP = "BUTTON_GROUP", t.MONITOR = "MONITOR", t.FOLDER = "FOLDER"
})(ei || (ei = {}));
let ti;
(function(t) {
    t.SELECT = "SELECT", t.IMAGE = "IMAGE", t.NUMBER = "NUMBER", t.COLOR = "COLOR", t.STRING = "STRING", t.BOOLEAN = "BOOLEAN", t.INTERVAL = "INTERVAL", t.VECTOR3D = "VECTOR3D", t.VECTOR2D = "VECTOR2D"
})(ti || (ti = {}));
const Ux = ["type", "__customInput"],
    Hx = ["render", "label", "optional", "order", "disabled", "hint", "onChange", "onEditStart", "onEditEnd", "transient"],
    Gx = ["type"];

function m0(t, e, n = {}, r) {
    var i, o;
    if (typeof t != "object" || Array.isArray(t)) return {
        type: r,
        input: t,
        options: ft({
            key: e,
            label: e,
            optional: !1,
            disabled: !1,
            order: 0
        }, n)
    };
    if ("__customInput" in t) {
        const {
            type: O,
            __customInput: R
        } = t, P = tn(t, Ux);
        return m0(R, e, P, O)
    }
    const {
        render: s,
        label: a,
        optional: l,
        order: c = 0,
        disabled: d,
        hint: f,
        onChange: h,
        onEditStart: p,
        onEditEnd: m,
        transient: g
    } = t, y = tn(t, Hx), x = ft({
        render: s,
        key: e,
        label: a ? ? e,
        hint: f,
        transient: g ? ? !!h,
        onEditStart: p,
        onEditEnd: m,
        disabled: d,
        optional: l,
        order: c
    }, n);
    let {
        type: w
    } = y, M = tn(y, Gx);
    if (w = r ? ? w, w in ei) return {
        type: w,
        input: M,
        options: x
    };
    let T;
    return r && h0(M) && "value" in M ? T = M.value : T = Vx(M) ? void 0 : M, {
        type: w,
        input: T,
        options: ft(ft({}, x), {}, {
            onChange: h,
            optional: (i = x.optional) !== null && i !== void 0 ? i : !1,
            disabled: (o = x.disabled) !== null && o !== void 0 ? o : !1
        })
    }
}

function Yx(t, e, n, r) {
    const i = m0(t, e),
        {
            type: o,
            input: s,
            options: a
        } = i;
    if (o) return o in ei ? i : {
        type: o,
        input: _c(o, s, n, r),
        options: a
    };
    let l = zd(s);
    return l ? {
        type: l,
        input: _c(l, s, n, r),
        options: a
    } : (l = zd({
        value: s
    }), l ? {
        type: l,
        input: _c(l, {
            value: s
        }, n, r),
        options: a
    } : !1)
}

function qd(t, e, n, r, i) {
    const {
        value: o,
        type: s,
        settings: a
    } = t;
    t.value = g0({
        type: s,
        value: o,
        settings: a
    }, e, n, r), t.fromPanel = i
}
const Xx = function(e, n, r) {
    this.type = "LEVA_ERROR", this.message = "LEVA: " + e, this.previousValue = n, this.error = r
};

function g0({
    type: t,
    value: e,
    settings: n
}, r, i, o) {
    const s = t !== "SELECT" && typeof r == "function" ? r(e) : r;
    let a;
    try {
        a = Ox(t, s, n, e, i, o)
    } catch (l) {
        throw new Xx(`The value \`${r}\` did not result in a correct value.`, e, l)
    }
    return ea(a, e) ? e : a
}
const v0 = (t, e, n = !1) => {
        let r = 0;
        return function() {
            const i = arguments,
                o = n && !r,
                s = () => t.apply(this, i);
            window.clearTimeout(r), r = window.setTimeout(s, e), o && s()
        }
    },
    y0 = t => t.shiftKey ? 5 : t.altKey ? 1 / 5 : 1;

function qx(t, e) {
    const n = console.error;
    console.error = () => {}, Fh.render(t, e), console.error = n
}
const Kx = ["value"],
    Zx = ["min", "max"],
    Qx = t => {
        if (typeof t == "number") return !0;
        if (typeof t == "string") {
            const e = parseFloat(t);
            return isNaN(e) ? !1 : t.substring(("" + e).length).trim().length < 4
        }
        return !1
    },
    x0 = (t, {
        min: e = -1 / 0,
        max: n = 1 / 0,
        suffix: r
    }) => {
        const i = parseFloat(t);
        if (t === "" || isNaN(i)) throw Error("Invalid number");
        const o = Ji(i, e, n);
        return r ? o + r : o
    },
    Jx = (t, {
        pad: e = 0,
        suffix: n
    }) => {
        const r = parseFloat(t).toFixed(e);
        return n ? r + n : r
    },
    b0 = t => {
        let {
            value: e
        } = t, n = tn(t, Kx);
        const {
            min: r = -1 / 0,
            max: i = 1 / 0
        } = n, o = tn(n, Zx);
        let s = parseFloat(e);
        const a = typeof e == "string" ? e.substring(("" + s).length) : void 0;
        s = Ji(s, r, i);
        let l = n.step;
        l || (Number.isFinite(r) ? Number.isFinite(i) ? l = +(Math.abs(i - r) / 100).toPrecision(1) : l = +(Math.abs(s - r) / 100).toPrecision(1) : Number.isFinite(i) && (l = +(Math.abs(i - s) / 100).toPrecision(1)));
        const c = l ? Wd(l) * 10 : Wd(s);
        l = l || c / 10;
        const d = Math.round(Ji(Math.log10(1 / c), 0, 2));
        return {
            value: a ? s + a : s,
            settings: ft({
                initialValue: s,
                step: l,
                pad: d,
                min: r,
                max: i,
                suffix: a
            }, o)
        }
    },
    w0 = (t, {
        step: e,
        initialValue: n
    }) => {
        const r = Math.round((t - n) / e);
        return n + r * e
    };
var _0 = Object.freeze({
    __proto__: null,
    schema: Qx,
    sanitize: x0,
    format: Jx,
    normalize: b0,
    sanitizeStep: w0
});

function wn() {
    return wn = Object.assign ? Object.assign.bind() : function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
        }
        return t
    }, wn.apply(this, arguments)
}
const D0 = u.createContext({});

function tr() {
    return u.useContext(D0)
}
const Ef = u.createContext(null),
    S0 = u.createContext(null),
    C0 = u.createContext(null);

function ya() {
    return u.useContext(S0)
}

function eb() {
    return u.useContext(C0)
}
const E0 = () => ({
    colors: {
        elevation1: "#292d39",
        elevation2: "#181c20",
        elevation3: "#373c4b",
        accent1: "#0066dc",
        accent2: "#007bff",
        accent3: "#3c93ff",
        highlight1: "#535760",
        highlight2: "#8c92a4",
        highlight3: "#fefefe",
        vivid1: "#ffcc00",
        folderWidgetColor: "$highlight2",
        folderTextColor: "$highlight3",
        toolTipBackground: "$highlight3",
        toolTipText: "$elevation2"
    },
    radii: {
        xs: "2px",
        sm: "3px",
        lg: "10px"
    },
    space: {
        xs: "3px",
        sm: "6px",
        md: "10px",
        rowGap: "7px",
        colGap: "7px"
    },
    fonts: {
        mono: "ui-monospace, SFMono-Regular, Menlo, 'Roboto Mono', monospace",
        sans: "system-ui, sans-serif"
    },
    fontSizes: {
        root: "11px",
        toolTip: "$root"
    },
    sizes: {
        rootWidth: "280px",
        controlWidth: "160px",
        numberInputMinWidth: "38px",
        scrubberWidth: "8px",
        scrubberHeight: "16px",
        rowHeight: "24px",
        folderTitleHeight: "20px",
        checkboxSize: "16px",
        joystickWidth: "100px",
        joystickHeight: "100px",
        colorPickerWidth: "$controlWidth",
        colorPickerHeight: "100px",
        imagePreviewWidth: "$controlWidth",
        imagePreviewHeight: "100px",
        monitorHeight: "60px",
        titleBarHeight: "39px"
    },
    shadows: {
        level1: "0 0 9px 0 #00000088",
        level2: "0 4px 14px #00000033"
    },
    borderWidths: {
        root: "0px",
        input: "1px",
        focus: "1px",
        hover: "1px",
        active: "1px",
        folder: "1px"
    },
    fontWeights: {
        label: "normal",
        folder: "normal",
        button: "normal"
    }
});

function La(t, e) {
    const [n, r] = t.split(" "), i = {};
    return n !== "none" && (i.boxShadow = `${e.inset?"inset ":""}0 0 0 $borderWidths${[e.key]} $colors${n!=="default"&&n||e.borderColor}`), r && (i.backgroundColor = r), i
}
const Ts = {
        $inputStyle: () => t => La(t, {
            key: "$input",
            borderColor: "$highlight1",
            inset: !0
        }),
        $focusStyle: () => t => La(t, {
            key: "$focus",
            borderColor: "$accent2"
        }),
        $hoverStyle: () => t => La(t, {
            key: "$hover",
            borderColor: "$accent1",
            inset: !0
        }),
        $activeStyle: () => t => La(t, {
            key: "$active",
            borderColor: "$accent1",
            inset: !0
        })
    },
    {
        styled: nt,
        css: AP,
        createTheme: tb,
        globalCss: nb,
        keyframes: FP
    } = By({
        prefix: "leva",
        theme: E0(),
        utils: ft(ft({}, Ts), {}, {
            $flex: () => ({
                display: "flex",
                alignItems: "center"
            }),
            $flexCenter: () => ({
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }),
            $reset: () => ({
                outline: "none",
                fontSize: "inherit",
                fontWeight: "inherit",
                color: "inherit",
                fontFamily: "inherit",
                border: "none",
                backgroundColor: "transparent",
                appearance: "none"
            }),
            $draggable: () => ({
                touchAction: "none",
                WebkitUserDrag: "none",
                userSelect: "none"
            }),
            $focus: t => ({
                "&:focus": Ts.$focusStyle()(t)
            }),
            $focusWithin: t => ({
                "&:focus-within": Ts.$focusStyle()(t)
            }),
            $hover: t => ({
                "&:hover": Ts.$hoverStyle()(t)
            }),
            $active: t => ({
                "&:active": Ts.$activeStyle()(t)
            })
        })
    }),
    rb = nb({
        ".leva__panel__dragged": {
            WebkitUserDrag: "none",
            userSelect: "none",
            input: {
                userSelect: "none"
            },
            "*": {
                cursor: "ew-resize !important"
            }
        }
    });

function ib(t) {
    const e = E0();
    if (!t) return {
        theme: e,
        className: ""
    };
    Object.keys(t).forEach(r => {
        Object.assign(e[r], t[r])
    });
    const n = tb(e);
    return {
        theme: e,
        className: n.className
    }
}

function Pi(t, e) {
    const {
        theme: n
    } = u.useContext(Ef);
    if (!(t in n) || !(e in n[t])) return bi(xn.THEME_ERROR, t, e), "";
    let r = e;
    for (;;) {
        let i = n[t][r];
        if (typeof i == "string" && i.charAt(0) === "$") r = i.substr(1);
        else return i
    }
}
const T0 = nt("input", {
        $reset: "",
        padding: "0 $sm",
        width: 0,
        minWidth: 0,
        flex: 1,
        height: "100%",
        variants: {
            levaType: {
                number: {
                    textAlign: "right"
                }
            },
            as: {
                textarea: {
                    padding: "$sm"
                }
            }
        }
    }),
    P0 = nt("div", {
        $draggable: "",
        height: "100%",
        $flexCenter: "",
        position: "relative",
        padding: "0 $xs",
        fontSize: "0.8em",
        opacity: .8,
        cursor: "default",
        touchAction: "none",
        [`& + ${T0}`]: {
            paddingLeft: 0
        }
    }),
    ob = nt(P0, {
        cursor: "ew-resize",
        marginRight: "-$xs",
        textTransform: "uppercase",
        opacity: .3,
        "&:hover": {
            opacity: 1
        },
        variants: {
            dragging: {
                true: {
                    backgroundColor: "$accent2",
                    opacity: 1
                }
            }
        }
    }),
    sb = nt("div", {
        $flex: "",
        position: "relative",
        borderRadius: "$sm",
        overflow: "hidden",
        color: "inherit",
        height: "$rowHeight",
        backgroundColor: "$elevation3",
        $inputStyle: "$elevation1",
        $hover: "",
        $focusWithin: "",
        variants: {
            textArea: {
                true: {
                    height: "auto"
                }
            }
        }
    }),
    ab = ["innerLabel", "value", "onUpdate", "onChange", "onKeyDown", "type", "id", "inputType", "rows"],
    lb = ["onUpdate"];

function Tf(t) {
    let {
        innerLabel: e,
        value: n,
        onUpdate: r,
        onChange: i,
        onKeyDown: o,
        type: s,
        id: a,
        inputType: l = "text",
        rows: c = 0
    } = t, d = tn(t, ab);
    const {
        id: f,
        emitOnEditStart: h,
        emitOnEditEnd: p,
        disabled: m
    } = tr(), g = a || f, y = u.useRef(null), x = c > 0, w = x ? "textarea" : "input", M = u.useCallback(R => P => {
        const B = P.currentTarget.value;
        R(B)
    }, []);
    j.useEffect(() => {
        const R = y.current,
            P = M(B => {
                r(B), p()
            });
        return R == null || R.addEventListener("blur", P), () => R == null ? void 0 : R.removeEventListener("blur", P)
    }, [M, r, p]);
    const T = u.useCallback(R => {
            R.key === "Enter" && M(r)(R)
        }, [M, r]),
        O = Object.assign({
            as: w
        }, x ? {
            rows: c
        } : {}, d);
    return j.createElement(sb, {
        textArea: x
    }, e && typeof e == "string" ? j.createElement(P0, null, e) : e, j.createElement(T0, wn({
        levaType: s,
        ref: y,
        id: g,
        type: l,
        autoComplete: "off",
        spellCheck: "false",
        value: n,
        onChange: M(i),
        onFocus: () => h(),
        onKeyPress: T,
        onKeyDown: o,
        disabled: m
    }, O)))
}

function cb(t) {
    let {
        onUpdate: e
    } = t, n = tn(t, lb);
    const r = u.useCallback(o => e(Lx(o)), [e]),
        i = u.useCallback(o => {
            const s = o.key === "ArrowUp" ? 1 : o.key === "ArrowDown" ? -1 : 0;
            if (s) {
                o.preventDefault();
                const a = o.altKey ? .1 : o.shiftKey ? 10 : 1;
                e(l => parseFloat(l) + s * a)
            }
        }, [e]);
    return j.createElement(Tf, wn({}, n, {
        onUpdate: r,
        onKeyDown: i,
        type: "number"
    }))
}
const El = nt("div", {}),
    au = nt("div", {
        position: "relative",
        background: "$elevation2",
        transition: "height 300ms ease",
        variants: {
            fill: {
                true: {},
                false: {}
            },
            flat: {
                false: {},
                true: {}
            },
            isRoot: {
                true: {},
                false: {
                    paddingLeft: "$md",
                    "&::after": {
                        content: '""',
                        position: "absolute",
                        left: 0,
                        top: 0,
                        width: "$borderWidths$folder",
                        height: "100%",
                        backgroundColor: "$folderWidgetColor",
                        opacity: .4,
                        transform: "translateX(-50%)"
                    }
                }
            }
        },
        compoundVariants: [{
            isRoot: !0,
            fill: !1,
            css: {
                overflowY: "auto",
                maxHeight: "calc(100vh - 20px - $$titleBarHeight)"
            }
        }, {
            isRoot: !0,
            flat: !1,
            css: {
                borderRadius: "$lg"
            }
        }]
    }),
    ub = nt("div", {
        $flex: "",
        color: "$folderTextColor",
        userSelect: "none",
        cursor: "pointer",
        height: "$folderTitleHeight",
        fontWeight: "$folder",
        "> svg": {
            marginLeft: -4,
            marginRight: 4,
            cursor: "pointer",
            fill: "$folderWidgetColor",
            opacity: .6
        },
        "&:hover > svg": {
            fill: "$folderWidgetColor"
        },
        [`&:hover + ${au}::after`]: {
            opacity: .6
        },
        [`${El}:hover > & + ${au}::after`]: {
            opacity: .6
        },
        [`${El}:hover > & > svg`]: {
            opacity: 1
        }
    }),
    R0 = nt("div", {
        position: "relative",
        display: "grid",
        gridTemplateColumns: "100%",
        rowGap: "$rowGap",
        transition: "opacity 250ms ease",
        variants: {
            toggled: {
                true: {
                    opacity: 1,
                    transitionDelay: "250ms"
                },
                false: {
                    opacity: 0,
                    transitionDelay: "0ms",
                    pointerEvents: "none"
                }
            },
            isRoot: {
                true: {
                    "& > div": {
                        paddingLeft: "$md",
                        paddingRight: "$md"
                    },
                    "& > div:first-of-type": {
                        paddingTop: "$sm"
                    },
                    "& > div:last-of-type": {
                        paddingBottom: "$sm"
                    },
                    [`> ${El}:not(:first-of-type)`]: {
                        paddingTop: "$sm",
                        marginTop: "$md",
                        borderTop: "$borderWidths$folder solid $colors$elevation1"
                    }
                }
            }
        }
    }),
    M0 = nt("div", {
        position: "relative",
        zIndex: 100,
        display: "grid",
        rowGap: "$rowGap",
        gridTemplateRows: "minmax($sizes$rowHeight, max-content)",
        alignItems: "center",
        color: "$highlight2",
        [`${R0} > &`]: {
            "&:first-of-type": {
                marginTop: "$rowGap"
            },
            "&:last-of-type": {
                marginBottom: "$rowGap"
            }
        },
        variants: {
            disabled: {
                true: {
                    pointerEvents: "none"
                },
                false: {
                    "&:hover,&:focus-within": {
                        color: "$highlight3"
                    }
                }
            }
        }
    }),
    $0 = nt(M0, {
        gridTemplateColumns: "auto $sizes$controlWidth",
        columnGap: "$colGap"
    }),
    fb = nt("div", {
        $flex: "",
        height: "100%",
        position: "relative",
        overflow: "hidden",
        "& > div": {
            marginLeft: "$colGap",
            padding: "0 $xs",
            opacity: .4
        },
        "& > div:hover": {
            opacity: .8
        },
        "& > div > svg": {
            display: "none",
            cursor: "pointer",
            width: 13,
            minWidth: 13,
            height: 13,
            backgroundColor: "$elevation2"
        },
        "&:hover > div > svg": {
            display: "block"
        },
        variants: {
            align: {
                top: {
                    height: "100%",
                    alignItems: "flex-start",
                    paddingTop: "$sm"
                }
            }
        }
    }),
    db = nt("input", {
        $reset: "",
        height: 0,
        width: 0,
        opacity: 0,
        margin: 0,
        "& + label": {
            position: "relative",
            $flexCenter: "",
            height: "100%",
            userSelect: "none",
            cursor: "pointer",
            paddingLeft: 2,
            paddingRight: "$sm",
            pointerEvents: "auto"
        },
        "& + label:after": {
            content: '""',
            width: 6,
            height: 6,
            backgroundColor: "$elevation3",
            borderRadius: "50%",
            $activeStyle: ""
        },
        "&:focus + label:after": {
            $focusStyle: ""
        },
        "& + label:active:after": {
            backgroundColor: "$accent1",
            $focusStyle: ""
        },
        "&:checked + label:after": {
            backgroundColor: "$accent1"
        }
    }),
    lu = nt("label", {
        fontWeight: "$label",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        "& > svg": {
            display: "block"
        }
    }),
    pb = nt("div", {
        opacity: 1,
        variants: {
            disabled: {
                true: {
                    opacity: .6,
                    pointerEvents: "none",
                    [`& ${lu}`]: {
                        pointerEvents: "auto"
                    }
                }
            }
        }
    }),
    A0 = nt("div", {
        position: "fixed",
        top: 0,
        bottom: 0,
        right: 0,
        left: 0,
        zIndex: 1e3,
        userSelect: "none"
    }),
    hb = nt("div", {
        background: "$toolTipBackground",
        fontFamily: "$sans",
        fontSize: "$toolTip",
        padding: "$xs $sm",
        color: "$toolTipText",
        borderRadius: "$xs",
        boxShadow: "$level2",
        maxWidth: 260
    }),
    mb = nt(Px, {
        fill: "$toolTipBackground"
    });

function Pf({
    children: t
}) {
    const {
        className: e
    } = u.useContext(Ef);
    return j.createElement(cy, {
        className: e
    }, t)
}
const gb = ["align"];

function vb() {
    const {
        id: t,
        disable: e,
        disabled: n
    } = tr();
    return j.createElement(j.Fragment, null, j.createElement(db, {
        id: t + "__disable",
        type: "checkbox",
        checked: !n,
        onChange: () => e(!n)
    }), j.createElement("label", {
        htmlFor: t + "__disable"
    }))
}

function yb(t) {
    const {
        id: e,
        optional: n,
        hint: r
    } = tr(), i = t.htmlFor || (e ? {
        htmlFor: e
    } : null), o = !r && typeof t.children == "string" ? {
        title: t.children
    } : null;
    return j.createElement(j.Fragment, null, n && j.createElement(vb, null), r !== void 0 ? j.createElement(Cx, null, j.createElement(Ex, {
        asChild: !0
    }, j.createElement(lu, wn({}, i, t))), j.createElement(Tx, {
        side: "top",
        sideOffset: 2
    }, j.createElement(hb, null, r, j.createElement(mb, null)))) : j.createElement(lu, wn({}, i, o, t)))
}

function ni(t) {
    let {
        align: e
    } = t, n = tn(t, gb);
    const {
        value: r,
        label: i,
        key: o,
        disabled: s
    } = tr(), {
        hideCopyButton: a
    } = eb(), l = !a && o !== void 0, [c, d] = u.useState(!1), f = async () => {
        try {
            await navigator.clipboard.writeText(JSON.stringify({
                [o]: r ? ? ""
            })), d(!0)
        } catch {
            bi(xn.CLIPBOARD_ERROR, {
                [o]: r
            })
        }
    };
    return j.createElement(fb, {
        align: e,
        onPointerLeave: () => d(!1)
    }, j.createElement(yb, n), l && !s && j.createElement("div", {
        title: `Click to copy ${typeof i=="string"?i:o} value`
    }, c ? j.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        fill: "currentColor"
    }, j.createElement("path", {
        d: "M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"
    }), j.createElement("path", {
        fillRule: "evenodd",
        d: "M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
        clipRule: "evenodd"
    })) : j.createElement("svg", {
        onClick: f,
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        fill: "currentColor"
    }, j.createElement("path", {
        d: "M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"
    }), j.createElement("path", {
        d: "M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"
    }))))
}
const xb = ["toggled"],
    bb = nt("svg", {
        fill: "currentColor",
        transition: "transform 350ms ease, fill 250ms ease"
    });

function Rf(t) {
    let {
        toggled: e
    } = t, n = tn(t, xb);
    return j.createElement(bb, wn({
        width: "9",
        height: "5",
        viewBox: "0 0 9 5",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
            transform: `rotate(${e?0:-90}deg)`
        }
    }, n), j.createElement("path", {
        d: "M3.8 4.4c.4.3 1 .3 1.4 0L8 1.7A1 1 0 007.4 0H1.6a1 1 0 00-.7 1.7l3 2.7z"
    }))
}
const wb = ["input"];

function Hr(t) {
    let {
        input: e
    } = t, n = tn(t, wb);
    return e ? j.createElement($0, n) : j.createElement(M0, n)
}

function F0({
    value: t,
    type: e,
    settings: n,
    setValue: r
}) {
    const [i, o] = u.useState(Id(e, t, n)), s = u.useRef(t), a = u.useRef(n);
    a.current = n;
    const l = u.useCallback(d => o(Id(e, d, a.current)), [e]),
        c = u.useCallback(d => {
            try {
                r(d)
            } catch (f) {
                const {
                    type: h,
                    previousValue: p
                } = f;
                if (h !== "LEVA_ERROR") throw f;
                l(p)
            }
        }, [l, r]);
    return u.useEffect(() => {
        ea(t, s.current) || l(t), s.current = t
    }, [t, l]), {
        displayValue: i,
        onChange: o,
        onUpdate: c
    }
}

function xa(t, e) {
    const {
        emitOnEditStart: n,
        emitOnEditEnd: r
    } = tr();
    return Pv(i => {
        i.first && (document.body.classList.add("leva__panel__dragged"), n == null || n());
        const o = t(i);
        return i.last && (document.body.classList.remove("leva__panel__dragged"), r == null || r()), o
    }, e)
}

function _b(t) {
    const e = u.useRef(null),
        n = u.useRef(null),
        r = u.useRef(!1);
    return u.useEffect(() => {
        const i = v0(() => {
            e.current.width = e.current.offsetWidth * window.devicePixelRatio, e.current.height = e.current.offsetHeight * window.devicePixelRatio, t(e.current, n.current)
        }, 250);
        return window.addEventListener("resize", i), r.current || (i(), r.current = !0), () => window.removeEventListener("resize", i)
    }, [t]), u.useEffect(() => {
        n.current = e.current.getContext("2d")
    }, []), [e, n]
}

function k0() {
    const t = u.useRef(null),
        e = u.useRef({
            x: 0,
            y: 0
        }),
        n = u.useCallback(r => {
            Object.assign(e.current, r), t.current && (t.current.style.transform = `translate3d(${e.current.x}px, ${e.current.y}px, 0)`)
        }, []);
    return [t, n]
}
const Db = ["__refCount"],
    Dc = (t, e) => {
        if (!t[e]) return null;
        const n = t[e];
        return tn(n, Db)
    };

function Sb(t) {
    const e = ya(),
        [n, r] = u.useState(Dc(e.getData(), t)),
        i = u.useCallback(c => e.setValueAtPath(t, c, !0), [t, e]),
        o = u.useCallback(c => e.setSettingsAtPath(t, c), [t, e]),
        s = u.useCallback(c => e.disableInputAtPath(t, c), [t, e]),
        a = u.useCallback(() => e.emitOnEditStart(t), [t, e]),
        l = u.useCallback(() => e.emitOnEditEnd(t), [t, e]);
    return u.useEffect(() => {
        r(Dc(e.getData(), t));
        const c = e.useStore.subscribe(d => Dc(d.data, t), r, {
            equalityFn: ga
        });
        return () => c()
    }, [e, t]), [n, {
        set: i,
        setSettings: o,
        disable: s,
        storeId: e.storeId,
        emitOnEditStart: a,
        emitOnEditEnd: l
    }]
}
const Cb = nt("div", {
        variants: {
            hasRange: {
                true: {
                    position: "relative",
                    display: "grid",
                    gridTemplateColumns: "auto $sizes$numberInputMinWidth",
                    columnGap: "$colGap",
                    alignItems: "center"
                }
            }
        }
    }),
    O0 = nt("div", {
        position: "relative",
        width: "100%",
        height: 2,
        borderRadius: "$xs",
        backgroundColor: "$elevation1"
    }),
    cu = nt("div", {
        position: "absolute",
        width: "$scrubberWidth",
        height: "$scrubberHeight",
        borderRadius: "$xs",
        boxShadow: "0 0 0 2px $colors$elevation2",
        backgroundColor: "$accent2",
        cursor: "pointer",
        $active: "none $accent1",
        $hover: "none $accent3",
        variants: {
            position: {
                left: {
                    borderTopRightRadius: 0,
                    borderBottomRightRadius: 0,
                    transform: "translateX(calc(-0.5 * ($sizes$scrubberWidth + 4px)))"
                },
                right: {
                    borderTopLeftRadius: 0,
                    borderBottomLeftRadius: 0,
                    transform: "translateX(calc(0.5 * ($sizes$scrubberWidth + 4px)))"
                }
            }
        }
    }),
    j0 = nt("div", {
        position: "relative",
        $flex: "",
        height: "100%",
        cursor: "pointer",
        touchAction: "none"
    }),
    L0 = nt("div", {
        position: "absolute",
        height: "100%",
        backgroundColor: "$accent2"
    });

function Eb({
    value: t,
    min: e,
    max: n,
    onDrag: r,
    step: i,
    initialValue: o
}) {
    const s = u.useRef(null),
        a = u.useRef(null),
        l = u.useRef(0),
        c = Pi("sizes", "scrubberWidth"),
        d = xa(({
            event: h,
            first: p,
            xy: [m],
            movement: [g],
            memo: y
        }) => {
            if (p) {
                const {
                    width: w,
                    left: M
                } = s.current.getBoundingClientRect();
                l.current = w - parseFloat(c), y = (h == null ? void 0 : h.target) === a.current ? t : Cl((m - M) / w, e, n)
            }
            const x = y + Cl(g / l.current, 0, n - e);
            return r(w0(x, {
                step: i,
                initialValue: o
            })), y
        }),
        f = Sl(t, e, n);
    return j.createElement(j0, wn({
        ref: s
    }, d()), j.createElement(O0, null, j.createElement(L0, {
        style: {
            left: 0,
            right: `${(1-f)*100}%`
        }
    })), j.createElement(cu, {
        ref: a,
        style: {
            left: `calc(${f} * (100% - ${c}))`
        }
    }))
}
const Tb = j.memo(({
    label: t,
    onUpdate: e,
    step: n,
    innerLabelTrim: r
}) => {
    const [i, o] = u.useState(!1), s = xa(({
        active: a,
        delta: [l],
        event: c,
        memo: d = 0
    }) => (o(a), d += l / 2, Math.abs(d) >= 1 && (e(f => parseFloat(f) + Math.floor(d) * n * y0(c)), d = 0), d));
    return j.createElement(ob, wn({
        dragging: i,
        title: t.length > 1 ? t : ""
    }, s()), t.slice(0, r))
});

function N0({
    label: t,
    id: e,
    displayValue: n,
    onUpdate: r,
    onChange: i,
    settings: o,
    innerLabelTrim: s = 1
}) {
    const a = s > 0 && j.createElement(Tb, {
        label: t,
        step: o.step,
        onUpdate: r,
        innerLabelTrim: s
    });
    return j.createElement(cb, {
        id: e,
        value: String(n),
        onUpdate: r,
        onChange: i,
        innerLabel: a
    })
}

function Pb() {
    const t = tr(),
        {
            label: e,
            value: n,
            onUpdate: r,
            settings: i,
            id: o
        } = t,
        {
            min: s,
            max: a
        } = i,
        l = a !== 1 / 0 && s !== -1 / 0;
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, e), j.createElement(Cb, {
        hasRange: l
    }, l && j.createElement(Eb, wn({
        value: parseFloat(n),
        onDrag: r
    }, i)), j.createElement(N0, wn({}, t, {
        id: o,
        label: "value",
        innerLabelTrim: l ? 0 : 1
    }))))
}
const {
    sanitizeStep: Rb
} = _0, Mb = tn(_0, ["sanitizeStep"]);
var $b = ft({
    component: Pb
}, Mb);
const Ab = (t, e) => br().schema({
        options: br().passesAnyOf(br().object(), br().array())
    }).test(e),
    Fb = (t, {
        values: e
    }) => {
        if (e.indexOf(t) < 0) throw Error("Selected value doesn't match Select options");
        return t
    },
    kb = (t, {
        values: e
    }) => e.indexOf(t),
    Ob = t => {
        let {
            value: e,
            options: n
        } = t, r, i;
        return Array.isArray(n) ? (i = n, r = n.map(o => String(o))) : (i = Object.values(n), r = Object.keys(n)), "value" in t ? i.includes(e) || (r.unshift(String(e)), i.unshift(e)) : e = i[0], Object.values(n).includes(e) || (n[String(e)] = e), {
            value: e,
            settings: {
                keys: r,
                values: i
            }
        }
    };
var jb = Object.freeze({
    __proto__: null,
    schema: Ab,
    sanitize: Fb,
    format: kb,
    normalize: Ob
});
const Lb = nt("div", {
        $flexCenter: "",
        position: "relative",
        "> svg": {
            pointerEvents: "none",
            position: "absolute",
            right: "$md"
        }
    }),
    uu = nt("select", {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        opacity: 0
    }),
    Nb = nt("div", {
        display: "flex",
        alignItems: "center",
        width: "100%",
        height: "$rowHeight",
        backgroundColor: "$elevation3",
        borderRadius: "$sm",
        padding: "0 $sm",
        cursor: "pointer",
        [`${uu}:focus + &`]: {
            $focusStyle: ""
        },
        [`${uu}:hover + &`]: {
            $hoverStyle: ""
        }
    });

function zb({
    displayValue: t,
    value: e,
    onUpdate: n,
    id: r,
    settings: i,
    disabled: o
}) {
    const {
        keys: s,
        values: a
    } = i, l = u.useRef();
    return e === a[t] && (l.current = s[t]), j.createElement(Lb, null, j.createElement(uu, {
        id: r,
        value: t,
        onChange: c => n(a[Number(c.currentTarget.value)]),
        disabled: o
    }, s.map((c, d) => j.createElement("option", {
        key: c,
        value: d
    }, c))), j.createElement(Nb, null, l.current), j.createElement(Rf, {
        toggled: !0
    }))
}

function Ib() {
    const {
        label: t,
        value: e,
        displayValue: n,
        onUpdate: r,
        id: i,
        disabled: o,
        settings: s
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(zb, {
        id: i,
        value: e,
        displayValue: n,
        onUpdate: r,
        settings: s,
        disabled: o
    }))
}
var Bb = ft({
    component: Ib
}, jb);
const Wb = t => br().string().test(t),
    Vb = t => {
        if (typeof t != "string") throw Error("Invalid string");
        return t
    },
    Ub = ({
        value: t,
        editable: e = !0,
        rows: n = !1
    }) => ({
        value: t,
        settings: {
            editable: e,
            rows: typeof n == "number" ? n : n ? 5 : 0
        }
    });
var Hb = Object.freeze({
    __proto__: null,
    schema: Wb,
    sanitize: Vb,
    normalize: Ub
});
const Gb = ["displayValue", "onUpdate", "onChange", "editable"],
    Yb = nt("div", {
        whiteSpace: "pre-wrap"
    });

function Xb(t) {
    let {
        displayValue: e,
        onUpdate: n,
        onChange: r,
        editable: i = !0
    } = t, o = tn(t, Gb);
    return i ? j.createElement(Tf, wn({
        value: e,
        onUpdate: n,
        onChange: r
    }, o)) : j.createElement(Yb, null, e)
}

function qb() {
    const {
        label: t,
        settings: e,
        displayValue: n,
        onUpdate: r,
        onChange: i
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(Xb, wn({
        displayValue: n,
        onUpdate: r,
        onChange: i
    }, e)))
}
var Kb = ft({
    component: qb
}, Hb);
const Zb = t => br().boolean().test(t),
    Qb = t => {
        if (typeof t != "boolean") throw Error("Invalid boolean");
        return t
    };
var Jb = Object.freeze({
    __proto__: null,
    schema: Zb,
    sanitize: Qb
});
const ew = nt("div", {
    position: "relative",
    $flex: "",
    height: "$rowHeight",
    input: {
        $reset: "",
        height: 0,
        width: 0,
        opacity: 0,
        margin: 0
    },
    label: {
        position: "relative",
        $flexCenter: "",
        userSelect: "none",
        cursor: "pointer",
        height: "$checkboxSize",
        width: "$checkboxSize",
        backgroundColor: "$elevation3",
        borderRadius: "$sm",
        $hover: ""
    },
    "input:focus + label": {
        $focusStyle: ""
    },
    "input:focus:checked + label, input:checked + label:hover": {
        $hoverStyle: "$accent3"
    },
    "input + label:active": {
        backgroundColor: "$accent1"
    },
    "input:checked + label:active": {
        backgroundColor: "$accent1"
    },
    "label > svg": {
        display: "none",
        width: "90%",
        height: "90%",
        stroke: "$highlight3"
    },
    "input:checked + label": {
        backgroundColor: "$accent2"
    },
    "input:checked + label > svg": {
        display: "block"
    }
});

function tw({
    value: t,
    onUpdate: e,
    id: n,
    disabled: r
}) {
    return j.createElement(ew, null, j.createElement("input", {
        id: n,
        type: "checkbox",
        checked: t,
        onChange: i => e(i.currentTarget.checked),
        disabled: r
    }), j.createElement("label", {
        htmlFor: n
    }, j.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24"
    }, j.createElement("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M5 13l4 4L19 7"
    }))))
}

function nw() {
    const {
        label: t,
        value: e,
        onUpdate: n,
        disabled: r,
        id: i
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(tw, {
        value: e,
        onUpdate: n,
        id: i,
        disabled: r
    }))
}
var rw = ft({
    component: nw
}, Jb);
const iw = ["locked"];

function ow({
    value: t,
    id: e,
    valueKey: n,
    settings: r,
    onUpdate: i,
    innerLabelTrim: o
}) {
    const s = u.useRef(t[n]);
    s.current = t[n];
    const a = u.useCallback(c => i({
            [n]: g0({
                type: "NUMBER",
                value: s.current,
                settings: r
            }, c)
        }), [i, r, n]),
        l = F0({
            type: "NUMBER",
            value: t[n],
            settings: r,
            setValue: a
        });
    return j.createElement(N0, {
        id: e,
        label: n,
        value: t[n],
        displayValue: l.displayValue,
        onUpdate: l.onUpdate,
        onChange: l.onChange,
        settings: r,
        innerLabelTrim: o
    })
}
const sw = nt("div", {
    display: "grid",
    columnGap: "$colGap",
    gridAutoFlow: "column dense",
    alignItems: "center",
    variants: {
        withLock: {
            true: {
                gridTemplateColumns: "10px auto",
                "> svg": {
                    cursor: "pointer"
                }
            }
        }
    }
});

function aw(t) {
    let {
        locked: e
    } = t, n = tn(t, iw);
    return j.createElement("svg", wn({
        width: "10",
        height: "10",
        viewBox: "0 0 15 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
    }, n), e ? j.createElement("path", {
        d: "M5 4.63601C5 3.76031 5.24219 3.1054 5.64323 2.67357C6.03934 2.24705 6.64582 1.9783 7.5014 1.9783C8.35745 1.9783 8.96306 2.24652 9.35823 2.67208C9.75838 3.10299 10 3.75708 10 4.63325V5.99999H5V4.63601ZM4 5.99999V4.63601C4 3.58148 4.29339 2.65754 4.91049 1.99307C5.53252 1.32329 6.42675 0.978302 7.5014 0.978302C8.57583 0.978302 9.46952 1.32233 10.091 1.99162C10.7076 2.65557 11 3.57896 11 4.63325V5.99999H12C12.5523 5.99999 13 6.44771 13 6.99999V13C13 13.5523 12.5523 14 12 14H3C2.44772 14 2 13.5523 2 13V6.99999C2 6.44771 2.44772 5.99999 3 5.99999H4ZM3 6.99999H12V13H3V6.99999Z",
        fill: "currentColor",
        fillRule: "evenodd",
        clipRule: "evenodd"
    }) : j.createElement("path", {
        d: "M9 3.63601C9 2.76044 9.24207 2.11211 9.64154 1.68623C10.0366 1.26502 10.6432 1 11.5014 1C12.4485 1 13.0839 1.30552 13.4722 1.80636C13.8031 2.23312 14 2.84313 14 3.63325H15C15 2.68242 14.7626 1.83856 14.2625 1.19361C13.6389 0.38943 12.6743 0 11.5014 0C10.4294 0 9.53523 0.337871 8.91218 1.0021C8.29351 1.66167 8 2.58135 8 3.63601V6H1C0.447715 6 0 6.44772 0 7V13C0 13.5523 0.447715 14 1 14H10C10.5523 14 11 13.5523 11 13V7C11 6.44772 10.5523 6 10 6H9V3.63601ZM1 7H10V13H1V7Z",
        fill: "currentColor",
        fillRule: "evenodd",
        clipRule: "evenodd"
    }))
}

function Mf({
    value: t,
    onUpdate: e,
    settings: n,
    innerLabelTrim: r
}) {
    const {
        id: i,
        setSettings: o
    } = tr(), {
        lock: s,
        locked: a
    } = n;
    return j.createElement(sw, {
        withLock: s
    }, s && j.createElement(aw, {
        locked: a,
        onClick: () => o({
            locked: !a
        })
    }), Object.keys(t).map((l, c) => j.createElement(ow, {
        id: c === 0 ? i : `${i}.${l}`,
        key: l,
        valueKey: l,
        value: t,
        settings: n[l],
        onUpdate: e,
        innerLabelTrim: r
    })))
}
const z0 = (t, e) => {
        const n = {};
        let r = 0,
            i = 1 / 0;
        Object.entries(t).forEach(([o, s]) => {
            n[o] = b0(ft({
                value: s
            }, e[o])).settings, r = Math.max(r, n[o].step), i = Math.min(i, n[o].pad)
        });
        for (let o in n) {
            const {
                step: s,
                min: a,
                max: l
            } = e[o] || {};
            !isFinite(s) && (!isFinite(a) || !isFinite(l)) && (n[o].step = r, n[o].pad = i)
        }
        return n
    },
    lw = ["lock"],
    cw = ["value"];

function uw(t) {
    const e = br().array().length(t).every.number(),
        n = r => {
            if (!r || typeof r != "object") return !1;
            const i = Object.values(r);
            return i.length === t && i.every(o => isFinite(o))
        };
    return r => e.test(r) || n(r)
}

function fw(t) {
    return Array.isArray(t) ? "array" : "object"
}

function zs(t, e, n) {
    return fw(t) === e ? t : e === "array" ? Object.values(t) : Wx(t, n)
}
const dw = (t, e, n) => {
        const r = zs(t, "object", e.keys);
        for (let s in r) r[s] = x0(r[s], e[s]);
        const i = Object.keys(r);
        let o = {};
        if (i.length === e.keys.length) o = r;
        else {
            const s = zs(n, "object", e.keys);
            if (i.length === 1 && e.locked) {
                const a = i[0],
                    l = r[a],
                    c = s[a],
                    d = c !== 0 ? l / c : 1;
                for (let f in s) f === a ? o[a] = l : o[f] = s[f] * d
            } else o = ft(ft({}, s), r)
        }
        return zs(o, e.format, e.keys)
    },
    pw = (t, e) => zs(t, "object", e.keys),
    hw = t => !!t && ("step" in t || "min" in t || "max" in t);

function mw(t, e, n = []) {
    const {
        lock: r = !1
    } = e, i = tn(e, lw), o = Array.isArray(t) ? "array" : "object", s = o === "object" ? Object.keys(t) : n, a = zs(t, "object", s), l = hw(i) ? s.reduce((d, f) => Object.assign(d, {
        [f]: i
    }), {}) : i, c = z0(a, l);
    return {
        value: o === "array" ? t : a,
        settings: ft(ft({}, c), {}, {
            format: o,
            keys: s,
            lock: r,
            locked: !1
        })
    }
}

function I0(t) {
    return {
        schema: uw(t.length),
        normalize: e => {
            let {
                value: n
            } = e, r = tn(e, cw);
            return mw(n, r, t)
        },
        format: (e, n) => pw(e, n),
        sanitize: (e, n, r) => dw(e, n, r)
    }
}
var gw = {
        grad: .9,
        turn: 360,
        rad: 360 / (2 * Math.PI)
    },
    vi = function(t) {
        return typeof t == "string" ? t.length > 0 : typeof t == "number"
    },
    zn = function(t, e, n) {
        return e === void 0 && (e = 0), n === void 0 && (n = Math.pow(10, e)), Math.round(n * t) / n + 0
    },
    zr = function(t, e, n) {
        return e === void 0 && (e = 0), n === void 0 && (n = 1), t > n ? n : t > e ? t : e
    },
    B0 = function(t) {
        return (t = isFinite(t) ? t % 360 : 0) > 0 ? t : t + 360
    },
    Kd = function(t) {
        return {
            r: zr(t.r, 0, 255),
            g: zr(t.g, 0, 255),
            b: zr(t.b, 0, 255),
            a: zr(t.a)
        }
    },
    Sc = function(t) {
        return {
            r: zn(t.r),
            g: zn(t.g),
            b: zn(t.b),
            a: zn(t.a, 3)
        }
    },
    vw = /^#([0-9a-f]{3,8})$/i,
    Na = function(t) {
        var e = t.toString(16);
        return e.length < 2 ? "0" + e : e
    },
    W0 = function(t) {
        var e = t.r,
            n = t.g,
            r = t.b,
            i = t.a,
            o = Math.max(e, n, r),
            s = o - Math.min(e, n, r),
            a = s ? o === e ? (n - r) / s : o === n ? 2 + (r - e) / s : 4 + (e - n) / s : 0;
        return {
            h: 60 * (a < 0 ? a + 6 : a),
            s: o ? s / o * 100 : 0,
            v: o / 255 * 100,
            a: i
        }
    },
    V0 = function(t) {
        var e = t.h,
            n = t.s,
            r = t.v,
            i = t.a;
        e = e / 360 * 6, n /= 100, r /= 100;
        var o = Math.floor(e),
            s = r * (1 - n),
            a = r * (1 - (e - o) * n),
            l = r * (1 - (1 - e + o) * n),
            c = o % 6;
        return {
            r: 255 * [r, a, s, s, l, r][c],
            g: 255 * [l, r, r, a, s, s][c],
            b: 255 * [s, s, l, r, r, a][c],
            a: i
        }
    },
    Zd = function(t) {
        return {
            h: B0(t.h),
            s: zr(t.s, 0, 100),
            l: zr(t.l, 0, 100),
            a: zr(t.a)
        }
    },
    Qd = function(t) {
        return {
            h: zn(t.h),
            s: zn(t.s),
            l: zn(t.l),
            a: zn(t.a, 3)
        }
    },
    Jd = function(t) {
        return V0((n = (e = t).s, {
            h: e.h,
            s: (n *= ((r = e.l) < 50 ? r : 100 - r) / 100) > 0 ? 2 * n / (r + n) * 100 : 0,
            v: r + n,
            a: e.a
        }));
        var e, n, r
    },
    Is = function(t) {
        return {
            h: (e = W0(t)).h,
            s: (i = (200 - (n = e.s)) * (r = e.v) / 100) > 0 && i < 200 ? n * r / 100 / (i <= 100 ? i : 200 - i) * 100 : 0,
            l: i / 2,
            a: e.a
        };
        var e, n, r, i
    },
    yw = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s*,\s*([+-]?\d*\.?\d+)%\s*,\s*([+-]?\d*\.?\d+)%\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,
    xw = /^hsla?\(\s*([+-]?\d*\.?\d+)(deg|rad|grad|turn)?\s+([+-]?\d*\.?\d+)%\s+([+-]?\d*\.?\d+)%\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,
    bw = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*,\s*([+-]?\d*\.?\d+)(%)?\s*(?:,\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,
    ww = /^rgba?\(\s*([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s+([+-]?\d*\.?\d+)(%)?\s*(?:\/\s*([+-]?\d*\.?\d+)(%)?\s*)?\)$/i,
    fu = {
        string: [
            [function(t) {
                var e = vw.exec(t);
                return e ? (t = e[1]).length <= 4 ? {
                    r: parseInt(t[0] + t[0], 16),
                    g: parseInt(t[1] + t[1], 16),
                    b: parseInt(t[2] + t[2], 16),
                    a: t.length === 4 ? zn(parseInt(t[3] + t[3], 16) / 255, 2) : 1
                } : t.length === 6 || t.length === 8 ? {
                    r: parseInt(t.substr(0, 2), 16),
                    g: parseInt(t.substr(2, 2), 16),
                    b: parseInt(t.substr(4, 2), 16),
                    a: t.length === 8 ? zn(parseInt(t.substr(6, 2), 16) / 255, 2) : 1
                } : null : null
            }, "hex"],
            [function(t) {
                var e = bw.exec(t) || ww.exec(t);
                return e ? e[2] !== e[4] || e[4] !== e[6] ? null : Kd({
                    r: Number(e[1]) / (e[2] ? 100 / 255 : 1),
                    g: Number(e[3]) / (e[4] ? 100 / 255 : 1),
                    b: Number(e[5]) / (e[6] ? 100 / 255 : 1),
                    a: e[7] === void 0 ? 1 : Number(e[7]) / (e[8] ? 100 : 1)
                }) : null
            }, "rgb"],
            [function(t) {
                var e = yw.exec(t) || xw.exec(t);
                if (!e) return null;
                var n, r, i = Zd({
                    h: (n = e[1], r = e[2], r === void 0 && (r = "deg"), Number(n) * (gw[r] || 1)),
                    s: Number(e[3]),
                    l: Number(e[4]),
                    a: e[5] === void 0 ? 1 : Number(e[5]) / (e[6] ? 100 : 1)
                });
                return Jd(i)
            }, "hsl"]
        ],
        object: [
            [function(t) {
                var e = t.r,
                    n = t.g,
                    r = t.b,
                    i = t.a,
                    o = i === void 0 ? 1 : i;
                return vi(e) && vi(n) && vi(r) ? Kd({
                    r: Number(e),
                    g: Number(n),
                    b: Number(r),
                    a: Number(o)
                }) : null
            }, "rgb"],
            [function(t) {
                var e = t.h,
                    n = t.s,
                    r = t.l,
                    i = t.a,
                    o = i === void 0 ? 1 : i;
                if (!vi(e) || !vi(n) || !vi(r)) return null;
                var s = Zd({
                    h: Number(e),
                    s: Number(n),
                    l: Number(r),
                    a: Number(o)
                });
                return Jd(s)
            }, "hsl"],
            [function(t) {
                var e = t.h,
                    n = t.s,
                    r = t.v,
                    i = t.a,
                    o = i === void 0 ? 1 : i;
                if (!vi(e) || !vi(n) || !vi(r)) return null;
                var s = function(a) {
                    return {
                        h: B0(a.h),
                        s: zr(a.s, 0, 100),
                        v: zr(a.v, 0, 100),
                        a: zr(a.a)
                    }
                }({
                    h: Number(e),
                    s: Number(n),
                    v: Number(r),
                    a: Number(o)
                });
                return V0(s)
            }, "hsv"]
        ]
    },
    ep = function(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n][0](t);
            if (r) return [r, e[n][1]]
        }
        return [null, void 0]
    },
    U0 = function(t) {
        return typeof t == "string" ? ep(t.trim(), fu.string) : typeof t == "object" && t !== null ? ep(t, fu.object) : [null, void 0]
    },
    _w = function(t) {
        return U0(t)[1]
    },
    Cc = function(t, e) {
        var n = Is(t);
        return {
            h: n.h,
            s: zr(n.s + 100 * e, 0, 100),
            l: n.l,
            a: n.a
        }
    },
    Ec = function(t) {
        return (299 * t.r + 587 * t.g + 114 * t.b) / 1e3 / 255
    },
    tp = function(t, e) {
        var n = Is(t);
        return {
            h: n.h,
            s: n.s,
            l: zr(n.l + 100 * e, 0, 100),
            a: n.a
        }
    },
    du = function() {
        function t(e) {
            this.parsed = U0(e)[0], this.rgba = this.parsed || {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            }
        }
        return t.prototype.isValid = function() {
            return this.parsed !== null
        }, t.prototype.brightness = function() {
            return zn(Ec(this.rgba), 2)
        }, t.prototype.isDark = function() {
            return Ec(this.rgba) < .5
        }, t.prototype.isLight = function() {
            return Ec(this.rgba) >= .5
        }, t.prototype.toHex = function() {
            return e = Sc(this.rgba), n = e.r, r = e.g, i = e.b, s = (o = e.a) < 1 ? Na(zn(255 * o)) : "", "#" + Na(n) + Na(r) + Na(i) + s;
            var e, n, r, i, o, s
        }, t.prototype.toRgb = function() {
            return Sc(this.rgba)
        }, t.prototype.toRgbString = function() {
            return e = Sc(this.rgba), n = e.r, r = e.g, i = e.b, (o = e.a) < 1 ? "rgba(" + n + ", " + r + ", " + i + ", " + o + ")" : "rgb(" + n + ", " + r + ", " + i + ")";
            var e, n, r, i, o
        }, t.prototype.toHsl = function() {
            return Qd(Is(this.rgba))
        }, t.prototype.toHslString = function() {
            return e = Qd(Is(this.rgba)), n = e.h, r = e.s, i = e.l, (o = e.a) < 1 ? "hsla(" + n + ", " + r + "%, " + i + "%, " + o + ")" : "hsl(" + n + ", " + r + "%, " + i + "%)";
            var e, n, r, i, o
        }, t.prototype.toHsv = function() {
            return e = W0(this.rgba), {
                h: zn(e.h),
                s: zn(e.s),
                v: zn(e.v),
                a: zn(e.a, 3)
            };
            var e
        }, t.prototype.invert = function() {
            return ar({
                r: 255 - (e = this.rgba).r,
                g: 255 - e.g,
                b: 255 - e.b,
                a: e.a
            });
            var e
        }, t.prototype.saturate = function(e) {
            return e === void 0 && (e = .1), ar(Cc(this.rgba, e))
        }, t.prototype.desaturate = function(e) {
            return e === void 0 && (e = .1), ar(Cc(this.rgba, -e))
        }, t.prototype.grayscale = function() {
            return ar(Cc(this.rgba, -1))
        }, t.prototype.lighten = function(e) {
            return e === void 0 && (e = .1), ar(tp(this.rgba, e))
        }, t.prototype.darken = function(e) {
            return e === void 0 && (e = .1), ar(tp(this.rgba, -e))
        }, t.prototype.rotate = function(e) {
            return e === void 0 && (e = 15), this.hue(this.hue() + e)
        }, t.prototype.alpha = function(e) {
            return typeof e == "number" ? ar({
                r: (n = this.rgba).r,
                g: n.g,
                b: n.b,
                a: e
            }) : zn(this.rgba.a, 3);
            var n
        }, t.prototype.hue = function(e) {
            var n = Is(this.rgba);
            return typeof e == "number" ? ar({
                h: e,
                s: n.s,
                l: n.l,
                a: n.a
            }) : zn(n.h)
        }, t.prototype.isEqual = function(e) {
            return this.toHex() === ar(e).toHex()
        }, t
    }(),
    ar = function(t) {
        return t instanceof du ? t : new du(t)
    },
    np = [],
    Dw = function(t) {
        t.forEach(function(e) {
            np.indexOf(e) < 0 && (e(du, fu), np.push(e))
        })
    };

function Sw(t, e) {
    var n = {
            white: "#ffffff",
            bisque: "#ffe4c4",
            blue: "#0000ff",
            cadetblue: "#5f9ea0",
            chartreuse: "#7fff00",
            chocolate: "#d2691e",
            coral: "#ff7f50",
            antiquewhite: "#faebd7",
            aqua: "#00ffff",
            azure: "#f0ffff",
            whitesmoke: "#f5f5f5",
            papayawhip: "#ffefd5",
            plum: "#dda0dd",
            blanchedalmond: "#ffebcd",
            black: "#000000",
            gold: "#ffd700",
            goldenrod: "#daa520",
            gainsboro: "#dcdcdc",
            cornsilk: "#fff8dc",
            cornflowerblue: "#6495ed",
            burlywood: "#deb887",
            aquamarine: "#7fffd4",
            beige: "#f5f5dc",
            crimson: "#dc143c",
            cyan: "#00ffff",
            darkblue: "#00008b",
            darkcyan: "#008b8b",
            darkgoldenrod: "#b8860b",
            darkkhaki: "#bdb76b",
            darkgray: "#a9a9a9",
            darkgreen: "#006400",
            darkgrey: "#a9a9a9",
            peachpuff: "#ffdab9",
            darkmagenta: "#8b008b",
            darkred: "#8b0000",
            darkorchid: "#9932cc",
            darkorange: "#ff8c00",
            darkslateblue: "#483d8b",
            gray: "#808080",
            darkslategray: "#2f4f4f",
            darkslategrey: "#2f4f4f",
            deeppink: "#ff1493",
            deepskyblue: "#00bfff",
            wheat: "#f5deb3",
            firebrick: "#b22222",
            floralwhite: "#fffaf0",
            ghostwhite: "#f8f8ff",
            darkviolet: "#9400d3",
            magenta: "#ff00ff",
            green: "#008000",
            dodgerblue: "#1e90ff",
            grey: "#808080",
            honeydew: "#f0fff0",
            hotpink: "#ff69b4",
            blueviolet: "#8a2be2",
            forestgreen: "#228b22",
            lawngreen: "#7cfc00",
            indianred: "#cd5c5c",
            indigo: "#4b0082",
            fuchsia: "#ff00ff",
            brown: "#a52a2a",
            maroon: "#800000",
            mediumblue: "#0000cd",
            lightcoral: "#f08080",
            darkturquoise: "#00ced1",
            lightcyan: "#e0ffff",
            ivory: "#fffff0",
            lightyellow: "#ffffe0",
            lightsalmon: "#ffa07a",
            lightseagreen: "#20b2aa",
            linen: "#faf0e6",
            mediumaquamarine: "#66cdaa",
            lemonchiffon: "#fffacd",
            lime: "#00ff00",
            khaki: "#f0e68c",
            mediumseagreen: "#3cb371",
            limegreen: "#32cd32",
            mediumspringgreen: "#00fa9a",
            lightskyblue: "#87cefa",
            lightblue: "#add8e6",
            midnightblue: "#191970",
            lightpink: "#ffb6c1",
            mistyrose: "#ffe4e1",
            moccasin: "#ffe4b5",
            mintcream: "#f5fffa",
            lightslategray: "#778899",
            lightslategrey: "#778899",
            navajowhite: "#ffdead",
            navy: "#000080",
            mediumvioletred: "#c71585",
            powderblue: "#b0e0e6",
            palegoldenrod: "#eee8aa",
            oldlace: "#fdf5e6",
            paleturquoise: "#afeeee",
            mediumturquoise: "#48d1cc",
            mediumorchid: "#ba55d3",
            rebeccapurple: "#663399",
            lightsteelblue: "#b0c4de",
            mediumslateblue: "#7b68ee",
            thistle: "#d8bfd8",
            tan: "#d2b48c",
            orchid: "#da70d6",
            mediumpurple: "#9370db",
            purple: "#800080",
            pink: "#ffc0cb",
            skyblue: "#87ceeb",
            springgreen: "#00ff7f",
            palegreen: "#98fb98",
            red: "#ff0000",
            yellow: "#ffff00",
            slateblue: "#6a5acd",
            lavenderblush: "#fff0f5",
            peru: "#cd853f",
            palevioletred: "#db7093",
            violet: "#ee82ee",
            teal: "#008080",
            slategray: "#708090",
            slategrey: "#708090",
            aliceblue: "#f0f8ff",
            darkseagreen: "#8fbc8f",
            darkolivegreen: "#556b2f",
            greenyellow: "#adff2f",
            seagreen: "#2e8b57",
            seashell: "#fff5ee",
            tomato: "#ff6347",
            silver: "#c0c0c0",
            sienna: "#a0522d",
            lavender: "#e6e6fa",
            lightgreen: "#90ee90",
            orange: "#ffa500",
            orangered: "#ff4500",
            steelblue: "#4682b4",
            royalblue: "#4169e1",
            turquoise: "#40e0d0",
            yellowgreen: "#9acd32",
            salmon: "#fa8072",
            saddlebrown: "#8b4513",
            sandybrown: "#f4a460",
            rosybrown: "#bc8f8f",
            darksalmon: "#e9967a",
            lightgoldenrodyellow: "#fafad2",
            snow: "#fffafa",
            lightgrey: "#d3d3d3",
            lightgray: "#d3d3d3",
            dimgray: "#696969",
            dimgrey: "#696969",
            olivedrab: "#6b8e23",
            olive: "#808000"
        },
        r = {};
    for (var i in n) r[n[i]] = i;
    var o = {};
    t.prototype.toName = function(s) {
        if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b)) return "transparent";
        var a, l, c = r[this.toHex()];
        if (c) return c;
        if (s != null && s.closest) {
            var d = this.toRgb(),
                f = 1 / 0,
                h = "black";
            if (!o.length)
                for (var p in n) o[p] = new t(n[p]).toRgb();
            for (var m in n) {
                var g = (a = d, l = o[m], Math.pow(a.r - l.r, 2) + Math.pow(a.g - l.g, 2) + Math.pow(a.b - l.b, 2));
                g < f && (f = g, h = m)
            }
            return h
        }
    }, e.string.push([function(s) {
        var a = s.toLowerCase(),
            l = a === "transparent" ? "#0000" : n[a];
        return l ? new t(l).toRgb() : null
    }, "name"])
}

function gs() {
    return (gs = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
        }
        return t
    }).apply(this, arguments)
}

function $f(t, e) {
    if (t == null) return {};
    var n, r, i = {},
        o = Object.keys(t);
    for (r = 0; r < o.length; r++) e.indexOf(n = o[r]) >= 0 || (i[n] = t[n]);
    return i
}

function pu(t) {
    var e = u.useRef(t),
        n = u.useRef(function(r) {
            e.current && e.current(r)
        });
    return e.current = t, n.current
}
var os = function(t, e, n) {
        return e === void 0 && (e = 0), n === void 0 && (n = 1), t > n ? n : t < e ? e : t
    },
    Bs = function(t) {
        return "touches" in t
    },
    hu = function(t) {
        return t && t.ownerDocument.defaultView || self
    },
    rp = function(t, e, n) {
        var r = t.getBoundingClientRect(),
            i = Bs(e) ? function(o, s) {
                for (var a = 0; a < o.length; a++)
                    if (o[a].identifier === s) return o[a];
                return o[0]
            }(e.touches, n) : e;
        return {
            left: os((i.pageX - (r.left + hu(t).pageXOffset)) / r.width),
            top: os((i.pageY - (r.top + hu(t).pageYOffset)) / r.height)
        }
    },
    ip = function(t) {
        !Bs(t) && t.preventDefault()
    },
    Af = j.memo(function(t) {
        var e = t.onMove,
            n = t.onKey,
            r = $f(t, ["onMove", "onKey"]),
            i = u.useRef(null),
            o = pu(e),
            s = pu(n),
            a = u.useRef(null),
            l = u.useRef(!1),
            c = u.useMemo(function() {
                var p = function(y) {
                        ip(y), (Bs(y) ? y.touches.length > 0 : y.buttons > 0) && i.current ? o(rp(i.current, y, a.current)) : g(!1)
                    },
                    m = function() {
                        return g(!1)
                    };

                function g(y) {
                    var x = l.current,
                        w = hu(i.current),
                        M = y ? w.addEventListener : w.removeEventListener;
                    M(x ? "touchmove" : "mousemove", p), M(x ? "touchend" : "mouseup", m)
                }
                return [function(y) {
                    var x = y.nativeEvent,
                        w = i.current;
                    if (w && (ip(x), ! function(T, O) {
                            return O && !Bs(T)
                        }(x, l.current) && w)) {
                        if (Bs(x)) {
                            l.current = !0;
                            var M = x.changedTouches || [];
                            M.length && (a.current = M[0].identifier)
                        }
                        w.focus(), o(rp(w, x, a.current)), g(!0)
                    }
                }, function(y) {
                    var x = y.which || y.keyCode;
                    x < 37 || x > 40 || (y.preventDefault(), s({
                        left: x === 39 ? .05 : x === 37 ? -.05 : 0,
                        top: x === 40 ? .05 : x === 38 ? -.05 : 0
                    }))
                }, g]
            }, [s, o]),
            d = c[0],
            f = c[1],
            h = c[2];
        return u.useEffect(function() {
            return h
        }, [h]), j.createElement("div", gs({}, r, {
            onTouchStart: d,
            onMouseDown: d,
            className: "react-colorful__interactive",
            ref: i,
            onKeyDown: f,
            tabIndex: 0,
            role: "slider"
        }))
    }),
    ba = function(t) {
        return t.filter(Boolean).join(" ")
    },
    Ff = function(t) {
        var e = t.color,
            n = t.left,
            r = t.top,
            i = r === void 0 ? .5 : r,
            o = ba(["react-colorful__pointer", t.className]);
        return j.createElement("div", {
            className: o,
            style: {
                top: 100 * i + "%",
                left: 100 * n + "%"
            }
        }, j.createElement("div", {
            className: "react-colorful__pointer-fill",
            style: {
                backgroundColor: e
            }
        }))
    },
    pr = function(t, e, n) {
        return e === void 0 && (e = 0), n === void 0 && (n = Math.pow(10, e)), Math.round(n * t) / n
    },
    H0 = function(t) {
        var e = t.s,
            n = t.v,
            r = t.a,
            i = (200 - e) * n / 100;
        return {
            h: pr(t.h),
            s: pr(i > 0 && i < 200 ? e * n / 100 / (i <= 100 ? i : 200 - i) * 100 : 0),
            l: pr(i / 2),
            a: pr(r, 2)
        }
    },
    mu = function(t) {
        var e = H0(t);
        return "hsl(" + e.h + ", " + e.s + "%, " + e.l + "%)"
    },
    Tc = function(t) {
        var e = H0(t);
        return "hsla(" + e.h + ", " + e.s + "%, " + e.l + "%, " + e.a + ")"
    },
    G0 = function(t) {
        var e = t.h,
            n = t.s,
            r = t.v,
            i = t.a;
        e = e / 360 * 6, n /= 100, r /= 100;
        var o = Math.floor(e),
            s = r * (1 - n),
            a = r * (1 - (e - o) * n),
            l = r * (1 - (1 - e + o) * n),
            c = o % 6;
        return {
            r: pr(255 * [r, a, s, s, l, r][c]),
            g: pr(255 * [l, r, r, a, s, s][c]),
            b: pr(255 * [s, s, l, r, r, a][c]),
            a: pr(i, 2)
        }
    },
    Y0 = function(t) {
        var e = t.r,
            n = t.g,
            r = t.b,
            i = t.a,
            o = Math.max(e, n, r),
            s = o - Math.min(e, n, r),
            a = s ? o === e ? (n - r) / s : o === n ? 2 + (r - e) / s : 4 + (e - n) / s : 0;
        return {
            h: pr(60 * (a < 0 ? a + 6 : a)),
            s: pr(o ? s / o * 100 : 0),
            v: pr(o / 255 * 100),
            a: i
        }
    },
    X0 = j.memo(function(t) {
        var e = t.hue,
            n = t.onChange,
            r = ba(["react-colorful__hue", t.className]);
        return j.createElement("div", {
            className: r
        }, j.createElement(Af, {
            onMove: function(i) {
                n({
                    h: 360 * i.left
                })
            },
            onKey: function(i) {
                n({
                    h: os(e + 360 * i.left, 0, 360)
                })
            },
            "aria-label": "Hue",
            "aria-valuenow": pr(e),
            "aria-valuemax": "360",
            "aria-valuemin": "0"
        }, j.createElement(Ff, {
            className: "react-colorful__hue-pointer",
            left: e / 360,
            color: mu({
                h: e,
                s: 100,
                v: 100,
                a: 1
            })
        })))
    }),
    q0 = j.memo(function(t) {
        var e = t.hsva,
            n = t.onChange,
            r = {
                backgroundColor: mu({
                    h: e.h,
                    s: 100,
                    v: 100,
                    a: 1
                })
            };
        return j.createElement("div", {
            className: "react-colorful__saturation",
            style: r
        }, j.createElement(Af, {
            onMove: function(i) {
                n({
                    s: 100 * i.left,
                    v: 100 - 100 * i.top
                })
            },
            onKey: function(i) {
                n({
                    s: os(e.s + 100 * i.left, 0, 100),
                    v: os(e.v - 100 * i.top, 0, 100)
                })
            },
            "aria-label": "Color",
            "aria-valuetext": "Saturation " + pr(e.s) + "%, Brightness " + pr(e.v) + "%"
        }, j.createElement(Ff, {
            className: "react-colorful__saturation-pointer",
            top: 1 - e.v / 100,
            left: e.s / 100,
            color: mu(e)
        })))
    }),
    kf = function(t, e) {
        if (t === e) return !0;
        for (var n in t)
            if (t[n] !== e[n]) return !1;
        return !0
    };

function K0(t, e, n) {
    var r = pu(n),
        i = u.useState(function() {
            return t.toHsva(e)
        }),
        o = i[0],
        s = i[1],
        a = u.useRef({
            color: e,
            hsva: o
        });
    u.useEffect(function() {
        if (!t.equal(e, a.current.color)) {
            var c = t.toHsva(e);
            a.current = {
                hsva: c,
                color: e
            }, s(c)
        }
    }, [e, t]), u.useEffect(function() {
        var c;
        kf(o, a.current.hsva) || t.equal(c = t.fromHsva(o), a.current.color) || (a.current = {
            hsva: o,
            color: c
        }, r(c))
    }, [o, t, r]);
    var l = u.useCallback(function(c) {
        s(function(d) {
            return Object.assign({}, d, c)
        })
    }, []);
    return [o, l]
}
var Cw = typeof window < "u" ? u.useLayoutEffect : u.useEffect,
    Ew = function() {
        return typeof __webpack_nonce__ < "u" ? __webpack_nonce__ : void 0
    },
    op = new Map,
    Z0 = function(t) {
        Cw(function() {
            var e = t.current ? t.current.ownerDocument : document;
            if (e !== void 0 && !op.has(e)) {
                var n = e.createElement("style");
                n.innerHTML = `.react-colorful{position:relative;display:flex;flex-direction:column;width:200px;height:200px;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:default}.react-colorful__saturation{position:relative;flex-grow:1;border-color:transparent;border-bottom:12px solid #000;border-radius:8px 8px 0 0;background-image:linear-gradient(0deg,#000,transparent),linear-gradient(90deg,#fff,hsla(0,0%,100%,0))}.react-colorful__alpha-gradient,.react-colorful__pointer-fill{content:"";position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;border-radius:inherit}.react-colorful__alpha-gradient,.react-colorful__saturation{box-shadow:inset 0 0 0 1px rgba(0,0,0,.05)}.react-colorful__alpha,.react-colorful__hue{position:relative;height:24px}.react-colorful__hue{background:linear-gradient(90deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.react-colorful__last-control{border-radius:0 0 8px 8px}.react-colorful__interactive{position:absolute;left:0;top:0;right:0;bottom:0;border-radius:inherit;outline:none;touch-action:none}.react-colorful__pointer{position:absolute;z-index:1;box-sizing:border-box;width:28px;height:28px;transform:translate(-50%,-50%);background-color:#fff;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 4px rgba(0,0,0,.2)}.react-colorful__interactive:focus .react-colorful__pointer{transform:translate(-50%,-50%) scale(1.1)}.react-colorful__alpha,.react-colorful__alpha-pointer{background-color:#fff;background-image:url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill-opacity=".05"><path d="M8 0h8v8H8zM0 8h8v8H0z"/></svg>')}.react-colorful__saturation-pointer{z-index:3}.react-colorful__hue-pointer{z-index:2}`, op.set(e, n);
                var r = Ew();
                r && n.setAttribute("nonce", r), e.head.appendChild(n)
            }
        }, [])
    },
    Tw = function(t) {
        var e = t.className,
            n = t.colorModel,
            r = t.color,
            i = r === void 0 ? n.defaultColor : r,
            o = t.onChange,
            s = $f(t, ["className", "colorModel", "color", "onChange"]),
            a = u.useRef(null);
        Z0(a);
        var l = K0(n, i, o),
            c = l[0],
            d = l[1],
            f = ba(["react-colorful", e]);
        return j.createElement("div", gs({}, s, {
            ref: a,
            className: f
        }), j.createElement(q0, {
            hsva: c,
            onChange: d
        }), j.createElement(X0, {
            hue: c.h,
            onChange: d,
            className: "react-colorful__last-control"
        }))
    },
    Pw = function(t) {
        var e = t.className,
            n = t.hsva,
            r = t.onChange,
            i = {
                backgroundImage: "linear-gradient(90deg, " + Tc(Object.assign({}, n, {
                    a: 0
                })) + ", " + Tc(Object.assign({}, n, {
                    a: 1
                })) + ")"
            },
            o = ba(["react-colorful__alpha", e]),
            s = pr(100 * n.a);
        return j.createElement("div", {
            className: o
        }, j.createElement("div", {
            className: "react-colorful__alpha-gradient",
            style: i
        }), j.createElement(Af, {
            onMove: function(a) {
                r({
                    a: a.left
                })
            },
            onKey: function(a) {
                r({
                    a: os(n.a + a.left)
                })
            },
            "aria-label": "Alpha",
            "aria-valuetext": s + "%",
            "aria-valuenow": s,
            "aria-valuemin": "0",
            "aria-valuemax": "100"
        }, j.createElement(Ff, {
            className: "react-colorful__alpha-pointer",
            left: n.a,
            color: Tc(n)
        })))
    },
    Rw = function(t) {
        var e = t.className,
            n = t.colorModel,
            r = t.color,
            i = r === void 0 ? n.defaultColor : r,
            o = t.onChange,
            s = $f(t, ["className", "colorModel", "color", "onChange"]),
            a = u.useRef(null);
        Z0(a);
        var l = K0(n, i, o),
            c = l[0],
            d = l[1],
            f = ba(["react-colorful", e]);
        return j.createElement("div", gs({}, s, {
            ref: a,
            className: f
        }), j.createElement(q0, {
            hsva: c,
            onChange: d
        }), j.createElement(X0, {
            hue: c.h,
            onChange: d
        }), j.createElement(Pw, {
            hsva: c,
            onChange: d,
            className: "react-colorful__last-control"
        }))
    },
    Mw = {
        defaultColor: {
            r: 0,
            g: 0,
            b: 0,
            a: 1
        },
        toHsva: Y0,
        fromHsva: G0,
        equal: kf
    },
    $w = function(t) {
        return j.createElement(Rw, gs({}, t, {
            colorModel: Mw
        }))
    },
    Aw = {
        defaultColor: {
            r: 0,
            g: 0,
            b: 0
        },
        toHsva: function(t) {
            return Y0({
                r: t.r,
                g: t.g,
                b: t.b,
                a: 1
            })
        },
        fromHsva: function(t) {
            return {
                r: (e = G0(t)).r,
                g: e.g,
                b: e.b
            };
            var e
        },
        equal: kf
    },
    Fw = function(t) {
        return j.createElement(Tw, gs({}, t, {
            colorModel: Aw
        }))
    };

function vs(t, e, n, r) {
    function i(o) {
        return o instanceof n ? o : new n(function(s) {
            s(o)
        })
    }
    return new(n || (n = Promise))(function(o, s) {
        function a(d) {
            try {
                c(r.next(d))
            } catch (f) {
                s(f)
            }
        }

        function l(d) {
            try {
                c(r.throw(d))
            } catch (f) {
                s(f)
            }
        }

        function c(d) {
            d.done ? o(d.value) : i(d.value).then(a, l)
        }
        c((r = r.apply(t, e || [])).next())
    })
}

function ys(t, e) {
    var n = {
            label: 0,
            sent: function() {
                if (o[0] & 1) throw o[1];
                return o[1]
            },
            trys: [],
            ops: []
        },
        r, i, o, s;
    return s = {
        next: a(0),
        throw: a(1),
        return: a(2)
    }, typeof Symbol == "function" && (s[Symbol.iterator] = function() {
        return this
    }), s;

    function a(c) {
        return function(d) {
            return l([c, d])
        }
    }

    function l(c) {
        if (r) throw new TypeError("Generator is already executing.");
        for (; s && (s = 0, c[0] && (n = 0)), n;) try {
            if (r = 1, i && (o = c[0] & 2 ? i.return : c[0] ? i.throw || ((o = i.return) && o.call(i), 0) : i.next) && !(o = o.call(i, c[1])).done) return o;
            switch (i = 0, o && (c = [c[0] & 2, o.value]), c[0]) {
                case 0:
                case 1:
                    o = c;
                    break;
                case 4:
                    return n.label++, {
                        value: c[1],
                        done: !1
                    };
                case 5:
                    n.label++, i = c[1], c = [0];
                    continue;
                case 7:
                    c = n.ops.pop(), n.trys.pop();
                    continue;
                default:
                    if (o = n.trys, !(o = o.length > 0 && o[o.length - 1]) && (c[0] === 6 || c[0] === 2)) {
                        n = 0;
                        continue
                    }
                    if (c[0] === 3 && (!o || c[1] > o[0] && c[1] < o[3])) {
                        n.label = c[1];
                        break
                    }
                    if (c[0] === 6 && n.label < o[1]) {
                        n.label = o[1], o = c;
                        break
                    }
                    if (o && n.label < o[2]) {
                        n.label = o[2], n.ops.push(c);
                        break
                    }
                    o[2] && n.ops.pop(), n.trys.pop();
                    continue
            }
            c = e.call(t, n)
        } catch (d) {
            c = [6, d], i = 0
        } finally {
            r = o = 0
        }
        if (c[0] & 5) throw c[1];
        return {
            value: c[0] ? c[1] : void 0,
            done: !0
        }
    }
}

function kw(t, e) {
    var n = typeof Symbol == "function" && t[Symbol.iterator];
    if (!n) return t;
    var r = n.call(t),
        i, o = [],
        s;
    try {
        for (;
            (e === void 0 || e-- > 0) && !(i = r.next()).done;) o.push(i.value)
    } catch (a) {
        s = {
            error: a
        }
    } finally {
        try {
            i && !i.done && (n = r.return) && n.call(r)
        } finally {
            if (s) throw s.error
        }
    }
    return o
}

function Ow() {
    for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(kw(arguments[e]));
    return t
}
var jw = new Map([
    ["aac", "audio/aac"],
    ["abw", "application/x-abiword"],
    ["arc", "application/x-freearc"],
    ["avif", "image/avif"],
    ["avi", "video/x-msvideo"],
    ["azw", "application/vnd.amazon.ebook"],
    ["bin", "application/octet-stream"],
    ["bmp", "image/bmp"],
    ["bz", "application/x-bzip"],
    ["bz2", "application/x-bzip2"],
    ["cda", "application/x-cdf"],
    ["csh", "application/x-csh"],
    ["css", "text/css"],
    ["csv", "text/csv"],
    ["doc", "application/msword"],
    ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
    ["eot", "application/vnd.ms-fontobject"],
    ["epub", "application/epub+zip"],
    ["gz", "application/gzip"],
    ["gif", "image/gif"],
    ["heic", "image/heic"],
    ["heif", "image/heif"],
    ["htm", "text/html"],
    ["html", "text/html"],
    ["ico", "image/vnd.microsoft.icon"],
    ["ics", "text/calendar"],
    ["jar", "application/java-archive"],
    ["jpeg", "image/jpeg"],
    ["jpg", "image/jpeg"],
    ["js", "text/javascript"],
    ["json", "application/json"],
    ["jsonld", "application/ld+json"],
    ["mid", "audio/midi"],
    ["midi", "audio/midi"],
    ["mjs", "text/javascript"],
    ["mp3", "audio/mpeg"],
    ["mp4", "video/mp4"],
    ["mpeg", "video/mpeg"],
    ["mpkg", "application/vnd.apple.installer+xml"],
    ["odp", "application/vnd.oasis.opendocument.presentation"],
    ["ods", "application/vnd.oasis.opendocument.spreadsheet"],
    ["odt", "application/vnd.oasis.opendocument.text"],
    ["oga", "audio/ogg"],
    ["ogv", "video/ogg"],
    ["ogx", "application/ogg"],
    ["opus", "audio/opus"],
    ["otf", "font/otf"],
    ["png", "image/png"],
    ["pdf", "application/pdf"],
    ["php", "application/x-httpd-php"],
    ["ppt", "application/vnd.ms-powerpoint"],
    ["pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
    ["rar", "application/vnd.rar"],
    ["rtf", "application/rtf"],
    ["sh", "application/x-sh"],
    ["svg", "image/svg+xml"],
    ["swf", "application/x-shockwave-flash"],
    ["tar", "application/x-tar"],
    ["tif", "image/tiff"],
    ["tiff", "image/tiff"],
    ["ts", "video/mp2t"],
    ["ttf", "font/ttf"],
    ["txt", "text/plain"],
    ["vsd", "application/vnd.visio"],
    ["wav", "audio/wav"],
    ["weba", "audio/webm"],
    ["webm", "video/webm"],
    ["webp", "image/webp"],
    ["woff", "font/woff"],
    ["woff2", "font/woff2"],
    ["xhtml", "application/xhtml+xml"],
    ["xls", "application/vnd.ms-excel"],
    ["xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
    ["xml", "application/xml"],
    ["xul", "application/vnd.mozilla.xul+xml"],
    ["zip", "application/zip"],
    ["7z", "application/x-7z-compressed"],
    ["mkv", "video/x-matroska"],
    ["mov", "video/quicktime"],
    ["msg", "application/vnd.ms-outlook"]
]);

function wa(t, e) {
    var n = Lw(t);
    if (typeof n.path != "string") {
        var r = t.webkitRelativePath;
        Object.defineProperty(n, "path", {
            value: typeof e == "string" ? e : typeof r == "string" && r.length > 0 ? r : t.name,
            writable: !1,
            configurable: !1,
            enumerable: !0
        })
    }
    return n
}

function Lw(t) {
    var e = t.name,
        n = e && e.lastIndexOf(".") !== -1;
    if (n && !t.type) {
        var r = e.split(".").pop().toLowerCase(),
            i = jw.get(r);
        i && Object.defineProperty(t, "type", {
            value: i,
            writable: !1,
            configurable: !1,
            enumerable: !0
        })
    }
    return t
}
var Nw = [".DS_Store", "Thumbs.db"];

function zw(t) {
    return vs(this, void 0, void 0, function() {
        return ys(this, function(e) {
            return Tl(t) && Iw(t) ? [2, Uw(t.dataTransfer, t.type)] : Bw(t) ? [2, Ww(t)] : Array.isArray(t) && t.every(function(n) {
                return "getFile" in n && typeof n.getFile == "function"
            }) ? [2, Vw(t)] : [2, []]
        })
    })
}

function Iw(t) {
    return Tl(t.dataTransfer)
}

function Bw(t) {
    return Tl(t) && Tl(t.target)
}

function Tl(t) {
    return typeof t == "object" && t !== null
}

function Ww(t) {
    return gu(t.target.files).map(function(e) {
        return wa(e)
    })
}

function Vw(t) {
    return vs(this, void 0, void 0, function() {
        var e;
        return ys(this, function(n) {
            switch (n.label) {
                case 0:
                    return [4, Promise.all(t.map(function(r) {
                        return r.getFile()
                    }))];
                case 1:
                    return e = n.sent(), [2, e.map(function(r) {
                        return wa(r)
                    })]
            }
        })
    })
}

function Uw(t, e) {
    return vs(this, void 0, void 0, function() {
        var n, r;
        return ys(this, function(i) {
            switch (i.label) {
                case 0:
                    return t === null ? [2, []] : t.items ? (n = gu(t.items).filter(function(o) {
                        return o.kind === "file"
                    }), e !== "drop" ? [2, n] : [4, Promise.all(n.map(Hw))]) : [3, 2];
                case 1:
                    return r = i.sent(), [2, sp(Q0(r))];
                case 2:
                    return [2, sp(gu(t.files).map(function(o) {
                        return wa(o)
                    }))]
            }
        })
    })
}

function sp(t) {
    return t.filter(function(e) {
        return Nw.indexOf(e.name) === -1
    })
}

function gu(t) {
    if (t === null) return [];
    for (var e = [], n = 0; n < t.length; n++) {
        var r = t[n];
        e.push(r)
    }
    return e
}

function Hw(t) {
    if (typeof t.webkitGetAsEntry != "function") return ap(t);
    var e = t.webkitGetAsEntry();
    return e && e.isDirectory ? J0(e) : ap(t)
}

function Q0(t) {
    return t.reduce(function(e, n) {
        return Ow(e, Array.isArray(n) ? Q0(n) : [n])
    }, [])
}

function ap(t) {
    var e = t.getAsFile();
    if (!e) return Promise.reject(t + " is not a File");
    var n = wa(e);
    return Promise.resolve(n)
}

function Gw(t) {
    return vs(this, void 0, void 0, function() {
        return ys(this, function(e) {
            return [2, t.isDirectory ? J0(t) : Yw(t)]
        })
    })
}

function J0(t) {
    var e = t.createReader();
    return new Promise(function(n, r) {
        var i = [];

        function o() {
            var s = this;
            e.readEntries(function(a) {
                return vs(s, void 0, void 0, function() {
                    var l, c, d;
                    return ys(this, function(f) {
                        switch (f.label) {
                            case 0:
                                if (a.length) return [3, 5];
                                f.label = 1;
                            case 1:
                                return f.trys.push([1, 3, , 4]), [4, Promise.all(i)];
                            case 2:
                                return l = f.sent(), n(l), [3, 4];
                            case 3:
                                return c = f.sent(), r(c), [3, 4];
                            case 4:
                                return [3, 6];
                            case 5:
                                d = Promise.all(a.map(Gw)), i.push(d), o(), f.label = 6;
                            case 6:
                                return [2]
                        }
                    })
                })
            }, function(a) {
                r(a)
            })
        }
        o()
    })
}

function Yw(t) {
    return vs(this, void 0, void 0, function() {
        return ys(this, function(e) {
            return [2, new Promise(function(n, r) {
                t.file(function(i) {
                    var o = wa(i, t.fullPath);
                    n(o)
                }, function(i) {
                    r(i)
                })
            })]
        })
    })
}
var Xw = function(t, e) {
    if (t && e) {
        var n = Array.isArray(e) ? e : e.split(","),
            r = t.name || "",
            i = (t.type || "").toLowerCase(),
            o = i.replace(/\/.*$/, "");
        return n.some(function(s) {
            var a = s.trim().toLowerCase();
            return a.charAt(0) === "." ? r.toLowerCase().endsWith(a) : a.endsWith("/*") ? o === a.replace(/\/.*$/, "") : i === a
        })
    }
    return !0
};

function lp(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(t, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function cp(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? lp(Object(n), !0).forEach(function(r) {
            em(t, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : lp(Object(n)).forEach(function(r) {
            Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return t
}

function em(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t
}

function up(t, e) {
    return Qw(t) || Zw(t, e) || Kw(t, e) || qw()
}

function qw() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function Kw(t, e) {
    if (t) {
        if (typeof t == "string") return fp(t, e);
        var n = Object.prototype.toString.call(t).slice(8, -1);
        if (n === "Object" && t.constructor && (n = t.constructor.name), n === "Map" || n === "Set") return Array.from(t);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return fp(t, e)
    }
}

function fp(t, e) {
    (e == null || e > t.length) && (e = t.length);
    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
    return r
}

function Zw(t, e) {
    var n = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
    if (n != null) {
        var r = [],
            i = !0,
            o = !1,
            s, a;
        try {
            for (n = n.call(t); !(i = (s = n.next()).done) && (r.push(s.value), !(e && r.length === e)); i = !0);
        } catch (l) {
            o = !0, a = l
        } finally {
            try {
                !i && n.return != null && n.return()
            } finally {
                if (o) throw a
            }
        }
        return r
    }
}

function Qw(t) {
    if (Array.isArray(t)) return t
}
var Jw = "file-invalid-type",
    e2 = "file-too-large",
    t2 = "file-too-small",
    n2 = "too-many-files",
    r2 = function(e) {
        e = Array.isArray(e) && e.length === 1 ? e[0] : e;
        var n = Array.isArray(e) ? "one of ".concat(e.join(", ")) : e;
        return {
            code: Jw,
            message: "File type must be ".concat(n)
        }
    },
    dp = function(e) {
        return {
            code: e2,
            message: "File is larger than ".concat(e, " ").concat(e === 1 ? "byte" : "bytes")
        }
    },
    pp = function(e) {
        return {
            code: t2,
            message: "File is smaller than ".concat(e, " ").concat(e === 1 ? "byte" : "bytes")
        }
    },
    i2 = {
        code: n2,
        message: "Too many files"
    };

function tm(t, e) {
    var n = t.type === "application/x-moz-file" || Xw(t, e);
    return [n, n ? null : r2(e)]
}

function nm(t, e, n) {
    if (Ps(t.size))
        if (Ps(e) && Ps(n)) {
            if (t.size > n) return [!1, dp(n)];
            if (t.size < e) return [!1, pp(e)]
        } else {
            if (Ps(e) && t.size < e) return [!1, pp(e)];
            if (Ps(n) && t.size > n) return [!1, dp(n)]
        }
    return [!0, null]
}

function Ps(t) {
    return t != null
}

function o2(t) {
    var e = t.files,
        n = t.accept,
        r = t.minSize,
        i = t.maxSize,
        o = t.multiple,
        s = t.maxFiles;
    return !o && e.length > 1 || o && s >= 1 && e.length > s ? !1 : e.every(function(a) {
        var l = tm(a, n),
            c = up(l, 1),
            d = c[0],
            f = nm(a, r, i),
            h = up(f, 1),
            p = h[0];
        return d && p
    })
}

function Pl(t) {
    return typeof t.isPropagationStopped == "function" ? t.isPropagationStopped() : typeof t.cancelBubble < "u" ? t.cancelBubble : !1
}

function za(t) {
    return t.dataTransfer ? Array.prototype.some.call(t.dataTransfer.types, function(e) {
        return e === "Files" || e === "application/x-moz-file"
    }) : !!t.target && !!t.target.files
}

function hp(t) {
    t.preventDefault()
}

function s2(t) {
    return t.indexOf("MSIE") !== -1 || t.indexOf("Trident/") !== -1
}

function a2(t) {
    return t.indexOf("Edge/") !== -1
}

function l2() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : window.navigator.userAgent;
    return s2(t) || a2(t)
}

function si() {
    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
    return function(r) {
        for (var i = arguments.length, o = new Array(i > 1 ? i - 1 : 0), s = 1; s < i; s++) o[s - 1] = arguments[s];
        return e.some(function(a) {
            return !Pl(r) && a && a.apply(void 0, [r].concat(o)), Pl(r)
        })
    }
}

function c2() {
    return "showOpenFilePicker" in window
}

function u2(t) {
    return t = typeof t == "string" ? t.split(",") : t, [{
        description: "everything",
        accept: Array.isArray(t) ? t.filter(function(e) {
            return e === "audio/*" || e === "video/*" || e === "image/*" || e === "text/*" || /\w+\/[-+.\w]+/g.test(e)
        }).reduce(function(e, n) {
            return cp(cp({}, e), {}, em({}, n, []))
        }, {}) : {}
    }]
}

function f2(t) {
    return t instanceof DOMException && (t.name === "AbortError" || t.code === t.ABORT_ERR)
}

function d2(t) {
    return t instanceof DOMException && (t.name === "SecurityError" || t.code === t.SECURITY_ERR)
}
var p2 = ["children"],
    h2 = ["open"],
    m2 = ["refKey", "role", "onKeyDown", "onFocus", "onBlur", "onClick", "onDragEnter", "onDragOver", "onDragLeave", "onDrop"],
    g2 = ["refKey", "onChange", "onClick"];

function v2(t) {
    return b2(t) || x2(t) || rm(t) || y2()
}

function y2() {
    throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function x2(t) {
    if (typeof Symbol < "u" && t[Symbol.iterator] != null || t["@@iterator"] != null) return Array.from(t)
}

function b2(t) {
    if (Array.isArray(t)) return vu(t)
}

function Pc(t, e) {
    return D2(t) || _2(t, e) || rm(t, e) || w2()
}

function w2() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function rm(t, e) {
    if (t) {
        if (typeof t == "string") return vu(t, e);
        var n = Object.prototype.toString.call(t).slice(8, -1);
        if (n === "Object" && t.constructor && (n = t.constructor.name), n === "Map" || n === "Set") return Array.from(t);
        if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return vu(t, e)
    }
}

function vu(t, e) {
    (e == null || e > t.length) && (e = t.length);
    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
    return r
}

function _2(t, e) {
    var n = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
    if (n != null) {
        var r = [],
            i = !0,
            o = !1,
            s, a;
        try {
            for (n = n.call(t); !(i = (s = n.next()).done) && (r.push(s.value), !(e && r.length === e)); i = !0);
        } catch (l) {
            o = !0, a = l
        } finally {
            try {
                !i && n.return != null && n.return()
            } finally {
                if (o) throw a
            }
        }
        return r
    }
}

function D2(t) {
    if (Array.isArray(t)) return t
}

function mp(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(t, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function yn(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? mp(Object(n), !0).forEach(function(r) {
            yu(t, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : mp(Object(n)).forEach(function(r) {
            Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return t
}

function yu(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t
}

function Rl(t, e) {
    if (t == null) return {};
    var n = S2(t, e),
        r, i;
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(t);
        for (i = 0; i < o.length; i++) r = o[i], !(e.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(t, r) && (n[r] = t[r])
    }
    return n
}

function S2(t, e) {
    if (t == null) return {};
    var n = {},
        r = Object.keys(t),
        i, o;
    for (o = 0; o < r.length; o++) i = r[o], !(e.indexOf(i) >= 0) && (n[i] = t[i]);
    return n
}
var Of = u.forwardRef(function(t, e) {
    var n = t.children,
        r = Rl(t, p2),
        i = om(r),
        o = i.open,
        s = Rl(i, h2);
    return u.useImperativeHandle(e, function() {
        return {
            open: o
        }
    }, [o]), j.createElement(u.Fragment, null, n(yn(yn({}, s), {}, {
        open: o
    })))
});
Of.displayName = "Dropzone";
var im = {
    disabled: !1,
    getFilesFromEvent: zw,
    maxSize: 1 / 0,
    minSize: 0,
    multiple: !0,
    maxFiles: 0,
    preventDropOnDocument: !0,
    noClick: !1,
    noKeyboard: !1,
    noDrag: !1,
    noDragEventsBubbling: !1,
    validator: null,
    useFsAccessApi: !0
};
Of.defaultProps = im;
Of.propTypes = {
    children: sn.func,
    accept: sn.oneOfType([sn.string, sn.arrayOf(sn.string)]),
    multiple: sn.bool,
    preventDropOnDocument: sn.bool,
    noClick: sn.bool,
    noKeyboard: sn.bool,
    noDrag: sn.bool,
    noDragEventsBubbling: sn.bool,
    minSize: sn.number,
    maxSize: sn.number,
    maxFiles: sn.number,
    disabled: sn.bool,
    getFilesFromEvent: sn.func,
    onFileDialogCancel: sn.func,
    onFileDialogOpen: sn.func,
    useFsAccessApi: sn.bool,
    onDragEnter: sn.func,
    onDragLeave: sn.func,
    onDragOver: sn.func,
    onDrop: sn.func,
    onDropAccepted: sn.func,
    onDropRejected: sn.func,
    validator: sn.func
};
var xu = {
    isFocused: !1,
    isFileDialogActive: !1,
    isDragActive: !1,
    isDragAccept: !1,
    isDragReject: !1,
    draggedFiles: [],
    acceptedFiles: [],
    fileRejections: []
};

function om() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
        e = yn(yn({}, im), t),
        n = e.accept,
        r = e.disabled,
        i = e.getFilesFromEvent,
        o = e.maxSize,
        s = e.minSize,
        a = e.multiple,
        l = e.maxFiles,
        c = e.onDragEnter,
        d = e.onDragLeave,
        f = e.onDragOver,
        h = e.onDrop,
        p = e.onDropAccepted,
        m = e.onDropRejected,
        g = e.onFileDialogCancel,
        y = e.onFileDialogOpen,
        x = e.useFsAccessApi,
        w = e.preventDropOnDocument,
        M = e.noClick,
        T = e.noKeyboard,
        O = e.noDrag,
        R = e.noDragEventsBubbling,
        P = e.validator,
        B = u.useMemo(function() {
            return typeof y == "function" ? y : gp
        }, [y]),
        te = u.useMemo(function() {
            return typeof g == "function" ? g : gp
        }, [g]),
        W = u.useRef(null),
        ee = u.useRef(null),
        V = u.useReducer(C2, xu),
        I = Pc(V, 2),
        X = I[0],
        q = I[1],
        Z = X.isFocused,
        le = X.isFileDialogActive,
        Se = X.draggedFiles,
        Me = u.useRef(typeof window < "u" && window.isSecureContext && x && c2()),
        z = function() {
            !Me.current && le && setTimeout(function() {
                if (ee.current) {
                    var _e = ee.current.files;
                    _e.length || (q({
                        type: "closeDialog"
                    }), te())
                }
            }, 300)
        };
    u.useEffect(function() {
        return window.addEventListener("focus", z, !1),
            function() {
                window.removeEventListener("focus", z, !1)
            }
    }, [ee, le, te, Me]);
    var ge = u.useRef([]),
        $e = function(_e) {
            W.current && W.current.contains(_e.target) || (_e.preventDefault(), ge.current = [])
        };
    u.useEffect(function() {
        return w && (document.addEventListener("dragover", hp, !1), document.addEventListener("drop", $e, !1)),
            function() {
                w && (document.removeEventListener("dragover", hp), document.removeEventListener("drop", $e))
            }
    }, [W, w]);
    var Xe = u.useCallback(function(Ce) {
            Ce.preventDefault(), Ce.persist(), gt(Ce), ge.current = [].concat(v2(ge.current), [Ce.target]), za(Ce) && Promise.resolve(i(Ce)).then(function(_e) {
                Pl(Ce) && !R || (q({
                    draggedFiles: _e,
                    isDragActive: !0,
                    type: "setDraggedFiles"
                }), c && c(Ce))
            })
        }, [i, c, R]),
        tt = u.useCallback(function(Ce) {
            Ce.preventDefault(), Ce.persist(), gt(Ce);
            var _e = za(Ce);
            if (_e && Ce.dataTransfer) try {
                Ce.dataTransfer.dropEffect = "copy"
            } catch {}
            return _e && f && f(Ce), !1
        }, [f, R]),
        wt = u.useCallback(function(Ce) {
            Ce.preventDefault(), Ce.persist(), gt(Ce);
            var _e = ge.current.filter(function(qe) {
                    return W.current && W.current.contains(qe)
                }),
                Ve = _e.indexOf(Ce.target);
            Ve !== -1 && _e.splice(Ve, 1), ge.current = _e, !(_e.length > 0) && (q({
                isDragActive: !1,
                type: "setDraggedFiles",
                draggedFiles: []
            }), za(Ce) && d && d(Ce))
        }, [W, d, R]),
        Ue = u.useCallback(function(Ce, _e) {
            var Ve = [],
                qe = [];
            Ce.forEach(function(pe) {
                var Mt = tm(pe, n),
                    Bt = Pc(Mt, 2),
                    vt = Bt[0],
                    Yt = Bt[1],
                    C = nm(pe, s, o),
                    L = Pc(C, 2),
                    ce = L[0],
                    oe = L[1],
                    ve = P ? P(pe) : null;
                if (vt && ce && !ve) Ve.push(pe);
                else {
                    var Ee = [Yt, oe];
                    ve && (Ee = Ee.concat(ve)), qe.push({
                        file: pe,
                        errors: Ee.filter(function(Ae) {
                            return Ae
                        })
                    })
                }
            }), (!a && Ve.length > 1 || a && l >= 1 && Ve.length > l) && (Ve.forEach(function(pe) {
                qe.push({
                    file: pe,
                    errors: [i2]
                })
            }), Ve.splice(0)), q({
                acceptedFiles: Ve,
                fileRejections: qe,
                type: "setFiles"
            }), h && h(Ve, qe, _e), qe.length > 0 && m && m(qe, _e), Ve.length > 0 && p && p(Ve, _e)
        }, [q, a, n, s, o, l, h, p, m, P]),
        Ye = u.useCallback(function(Ce) {
            Ce.preventDefault(), Ce.persist(), gt(Ce), ge.current = [], za(Ce) && Promise.resolve(i(Ce)).then(function(_e) {
                Pl(Ce) && !R || Ue(_e, Ce)
            }), q({
                type: "reset"
            })
        }, [i, Ue, R]),
        Ge = u.useCallback(function() {
            if (Me.current) {
                q({
                    type: "openDialog"
                }), B();
                var Ce = {
                    multiple: a,
                    types: u2(n)
                };
                window.showOpenFilePicker(Ce).then(function(_e) {
                    return i(_e)
                }).then(function(_e) {
                    Ue(_e, null), q({
                        type: "closeDialog"
                    })
                }).catch(function(_e) {
                    f2(_e) ? (te(_e), q({
                        type: "closeDialog"
                    })) : d2(_e) && (Me.current = !1, ee.current && (ee.current.value = null, ee.current.click()))
                });
                return
            }
            ee.current && (q({
                type: "openDialog"
            }), B(), ee.current.value = null, ee.current.click())
        }, [q, B, te, x, Ue, n, a]),
        rt = u.useCallback(function(Ce) {
            !W.current || !W.current.isEqualNode(Ce.target) || (Ce.key === " " || Ce.key === "Enter" || Ce.keyCode === 32 || Ce.keyCode === 13) && (Ce.preventDefault(), Ge())
        }, [W, Ge]),
        it = u.useCallback(function() {
            q({
                type: "focus"
            })
        }, []),
        lt = u.useCallback(function() {
            q({
                type: "blur"
            })
        }, []),
        Lt = u.useCallback(function() {
            M || (l2() ? setTimeout(Ge, 0) : Ge())
        }, [M, Ge]),
        Ne = function(_e) {
            return r ? null : _e
        },
        ct = function(_e) {
            return T ? null : Ne(_e)
        },
        ot = function(_e) {
            return O ? null : Ne(_e)
        },
        gt = function(_e) {
            R && _e.stopPropagation()
        },
        re = u.useMemo(function() {
            return function() {
                var Ce = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
                    _e = Ce.refKey,
                    Ve = _e === void 0 ? "ref" : _e,
                    qe = Ce.role,
                    pe = Ce.onKeyDown,
                    Mt = Ce.onFocus,
                    Bt = Ce.onBlur,
                    vt = Ce.onClick,
                    Yt = Ce.onDragEnter,
                    C = Ce.onDragOver,
                    L = Ce.onDragLeave,
                    ce = Ce.onDrop,
                    oe = Rl(Ce, m2);
                return yn(yn(yu({
                    onKeyDown: ct(si(pe, rt)),
                    onFocus: ct(si(Mt, it)),
                    onBlur: ct(si(Bt, lt)),
                    onClick: Ne(si(vt, Lt)),
                    onDragEnter: ot(si(Yt, Xe)),
                    onDragOver: ot(si(C, tt)),
                    onDragLeave: ot(si(L, wt)),
                    onDrop: ot(si(ce, Ye)),
                    role: typeof qe == "string" && qe !== "" ? qe : "button"
                }, Ve, W), !r && !T ? {
                    tabIndex: 0
                } : {}), oe)
            }
        }, [W, rt, it, lt, Lt, Xe, tt, wt, Ye, T, O, r]),
        pt = u.useCallback(function(Ce) {
            Ce.stopPropagation()
        }, []),
        It = u.useMemo(function() {
            return function() {
                var Ce = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
                    _e = Ce.refKey,
                    Ve = _e === void 0 ? "ref" : _e,
                    qe = Ce.onChange,
                    pe = Ce.onClick,
                    Mt = Rl(Ce, g2),
                    Bt = yu({
                        accept: n,
                        multiple: a,
                        type: "file",
                        style: {
                            display: "none"
                        },
                        onChange: Ne(si(qe, Ye)),
                        onClick: Ne(si(pe, pt)),
                        tabIndex: -1
                    }, Ve, ee);
                return yn(yn({}, Bt), Mt)
            }
        }, [ee, n, a, Ye, r]),
        At = Se.length,
        Je = At > 0 && o2({
            files: Se,
            accept: n,
            minSize: s,
            maxSize: o,
            multiple: a,
            maxFiles: l
        }),
        fn = At > 0 && !Je;
    return yn(yn({}, X), {}, {
        isDragAccept: Je,
        isDragReject: fn,
        isFocused: Z && !r,
        getRootProps: re,
        getInputProps: It,
        rootRef: W,
        inputRef: ee,
        open: Ne(Ge)
    })
}

function C2(t, e) {
    switch (e.type) {
        case "focus":
            return yn(yn({}, t), {}, {
                isFocused: !0
            });
        case "blur":
            return yn(yn({}, t), {}, {
                isFocused: !1
            });
        case "openDialog":
            return yn(yn({}, xu), {}, {
                isFileDialogActive: !0
            });
        case "closeDialog":
            return yn(yn({}, t), {}, {
                isFileDialogActive: !1
            });
        case "setDraggedFiles":
            var n = e.isDragActive,
                r = e.draggedFiles;
            return yn(yn({}, t), {}, {
                draggedFiles: r,
                isDragActive: n
            });
        case "setFiles":
            return yn(yn({}, t), {}, {
                acceptedFiles: e.acceptedFiles,
                fileRejections: e.fileRejections
            });
        case "reset":
            return yn({}, xu);
        default:
            return t
    }
}

function gp() {}

function E2(t) {
    let e;
    const n = new Set,
        r = (c, d) => {
            const f = typeof c == "function" ? c(e) : c;
            if (f !== e) {
                const h = e;
                e = d ? f : Object.assign({}, e, f), n.forEach(p => p(e, h))
            }
        },
        i = () => e,
        o = (c, d = i, f = Object.is) => {
            console.warn("[DEPRECATED] Please use `subscribeWithSelector` middleware");
            let h = d(e);

            function p() {
                const m = d(e);
                if (!f(h, m)) {
                    const g = h;
                    c(h = m, g)
                }
            }
            return n.add(p), () => n.delete(p)
        },
        l = {
            setState: r,
            getState: i,
            subscribe: (c, d, f) => d || f ? o(c, d, f) : (n.add(c), () => n.delete(c)),
            destroy: () => n.clear()
        };
    return e = t(r, i, l), l
}
const T2 = typeof window > "u" || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent),
    vp = T2 ? u.useEffect : u.useLayoutEffect;

function P2(t) {
    const e = typeof t == "function" ? E2(t) : t,
        n = (r = e.getState, i = Object.is) => {
            const [, o] = u.useReducer(y => y + 1, 0), s = e.getState(), a = u.useRef(s), l = u.useRef(r), c = u.useRef(i), d = u.useRef(!1), f = u.useRef();
            f.current === void 0 && (f.current = r(s));
            let h, p = !1;
            (a.current !== s || l.current !== r || c.current !== i || d.current) && (h = r(s), p = !i(f.current, h)), vp(() => {
                p && (f.current = h), a.current = s, l.current = r, c.current = i, d.current = !1
            });
            const m = u.useRef(s);
            vp(() => {
                const y = () => {
                        try {
                            const w = e.getState(),
                                M = l.current(w);
                            c.current(f.current, M) || (a.current = w, f.current = M, o())
                        } catch {
                            d.current = !0, o()
                        }
                    },
                    x = e.subscribe(y);
                return e.getState() !== m.current && y(), x
            }, []);
            const g = p ? h : f.current;
            return u.useDebugValue(g), g
        };
    return Object.assign(n, e), n[Symbol.iterator] = function() {
        console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
        const r = [n, e];
        return {
            next() {
                const i = r.length <= 0;
                return {
                    value: r.shift(),
                    done: i
                }
            }
        }
    }, n
}
const R2 = t => (e, n, r) => {
    const i = r.subscribe;
    return r.subscribe = (s, a, l) => {
        let c = s;
        if (a) {
            const d = (l == null ? void 0 : l.equalityFn) || Object.is;
            let f = s(r.getState());
            c = h => {
                const p = s(h);
                if (!d(f, p)) {
                    const m = f;
                    a(f = p, m)
                }
            }, l != null && l.fireImmediately && a(f, f)
        }
        return i(c)
    }, t(e, n, r)
};
/*!
 * isobject <https://github.com/jonschlinkert/isobject>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var M2 = function(e) {
    return e != null && typeof e == "object" && Array.isArray(e) === !1
};
/*!
 * is-plain-object <https://github.com/jonschlinkert/is-plain-object>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var $2 = M2;

function yp(t) {
    return $2(t) === !0 && Object.prototype.toString.call(t) === "[object Object]"
}
var sm = function(e) {
    var n, r;
    return !(yp(e) === !1 || (n = e.constructor, typeof n != "function") || (r = n.prototype, yp(r) === !1) || r.hasOwnProperty("isPrototypeOf") === !1)
};
/*!
 * is-extendable <https://github.com/jonschlinkert/is-extendable>
 *
 * Copyright (c) 2015-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var A2 = sm,
    jf = function(e) {
        return A2(e) || typeof e == "function" || Array.isArray(e)
    };
/*!
 * for-in <https://github.com/jonschlinkert/for-in>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var F2 = function(e, n, r) {
        for (var i in e)
            if (n.call(r, e[i], i, e) === !1) break
    },
    k2 = jf,
    O2 = F2;

function am(t, e) {
    for (var n = arguments.length, r = 0; ++r < n;) {
        var i = arguments[r];
        bu(i) && O2(i, j2, t)
    }
    return t
}

function j2(t, e) {
    if (L2(e)) {
        var n = this[e];
        bu(t) && bu(n) ? am(n, t) : this[e] = t
    }
}

function bu(t) {
    return k2(t) && !Array.isArray(t)
}

function L2(t) {
    return t !== "__proto__" && t !== "constructor" && t !== "prototype"
}
var N2 = am;
/*!
 * get-value <https://github.com/jonschlinkert/get-value>
 *
 * Copyright (c) 2014-2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */
var z2 = function(t, e, n, r, i) {
    if (!I2(t) || !e) return t;
    if (e = Ia(e), n && (e += "." + Ia(n)), r && (e += "." + Ia(r)), i && (e += "." + Ia(i)), e in t) return t[e];
    for (var o = e.split("."), s = o.length, a = -1; t && ++a < s;) {
        for (var l = o[a]; l[l.length - 1] === "\\";) l = l.slice(0, -1) + "." + o[++a];
        t = t[l]
    }
    return t
};

function I2(t) {
    return t !== null && (typeof t == "object" || typeof t == "function")
}

function Ia(t) {
    return t ? Array.isArray(t) ? t.join(".") : t : ""
}
/*!
 * assign-symbols <https://github.com/jonschlinkert/assign-symbols>
 *
 * Copyright (c) 2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */
var B2 = function(t, e) {
        if (t === null || typeof t > "u") throw new TypeError("expected first argument to be an object.");
        if (typeof e > "u" || typeof Symbol > "u" || typeof Object.getOwnPropertySymbols != "function") return t;
        for (var n = Object.prototype.propertyIsEnumerable, r = Object(t), i = arguments.length, o = 0; ++o < i;)
            for (var s = Object(arguments[o]), a = Object.getOwnPropertySymbols(s), l = 0; l < a.length; l++) {
                var c = a[l];
                n.call(s, c) && (r[c] = s[c])
            }
        return r
    },
    W2 = jf,
    V2 = B2,
    U2 = Object.assign || function(t) {
        if (t === null || typeof t > "u") throw new TypeError("Cannot convert undefined or null to object");
        xp(t) || (t = {});
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            G2(n) && (n = Y2(n)), xp(n) && (H2(t, n), V2(t, n))
        }
        return t
    };

function H2(t, e) {
    for (var n in e) X2(e, n) && (t[n] = e[n])
}

function G2(t) {
    return t && typeof t == "string"
}

function Y2(t) {
    var e = {};
    for (var n in t) e[n] = t[n];
    return e
}

function xp(t) {
    return t && typeof t == "object" || W2(t)
}

function X2(t, e) {
    return Object.prototype.hasOwnProperty.call(t, e)
}
/*!
 * split-string <https://github.com/jonschlinkert/split-string>
 *
 * Copyright (c) 2015-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var q2 = U2,
    K2 = function(t, e, n) {
        if (typeof t != "string") throw new TypeError("expected a string");
        typeof e == "function" && (n = e, e = null), typeof e == "string" && (e = {
            sep: e
        });
        var r = q2({
                sep: "."
            }, e),
            i = r.quotes || ['"', "'", "`"],
            o;
        r.brackets === !0 ? o = {
            "<": ">",
            "(": ")",
            "[": "]",
            "{": "}"
        } : r.brackets && (o = r.brackets);
        var s = [],
            a = [],
            l = [""],
            c = r.sep,
            d = t.length,
            f = -1,
            h;

        function p() {
            if (o && a.length) return o[a[a.length - 1]]
        }
        for (; ++f < d;) {
            var m = t[f],
                g = t[f + 1],
                y = {
                    val: m,
                    idx: f,
                    arr: l,
                    str: t
                };
            if (s.push(y), m === "\\") {
                y.val = Q2(r, t, f) === !0 ? m + g : g, y.escaped = !0, typeof n == "function" && n(y), l[l.length - 1] += y.val, f++;
                continue
            }
            if (o && o[m]) {
                a.push(m);
                var x = p(),
                    w = f + 1;
                if (t.indexOf(x, w + 1) !== -1)
                    for (; a.length && w < d;) {
                        var M = t[++w];
                        if (M === "\\") {
                            M++;
                            continue
                        }
                        if (i.indexOf(M) !== -1) {
                            w = wu(t, M, w + 1);
                            continue
                        }
                        if (x = p(), a.length && t.indexOf(x, w + 1) === -1) break;
                        if (o[M]) {
                            a.push(M);
                            continue
                        }
                        x === M && a.pop()
                    }
                if (h = w, h === -1) {
                    l[l.length - 1] += m;
                    continue
                }
                m = t.slice(f, h + 1), y.val = m, y.idx = f = h
            }
            if (i.indexOf(m) !== -1) {
                if (h = wu(t, m, f + 1), h === -1) {
                    l[l.length - 1] += m;
                    continue
                }
                Z2(m, r) === !0 ? m = t.slice(f, h + 1) : m = t.slice(f + 1, h), y.val = m, y.idx = f = h
            }
            if (typeof n == "function" && (n(y, s), m = y.val, f = y.idx), y.val === c && y.split !== !1) {
                l.push("");
                continue
            }
            l[l.length - 1] += y.val
        }
        return l
    };

function wu(t, e, n, r) {
    var i = t.indexOf(e, n);
    return t.charAt(i - 1) === "\\" ? wu(t, e, i + 1) : i
}

function Z2(t, e) {
    return e.keepDoubleQuotes === !0 && t === '"' || e.keepSingleQuotes === !0 && t === "'" ? !0 : e.keepQuotes
}

function Q2(t, e, n) {
    return typeof t.keepEscaping == "function" ? t.keepEscaping(e, n) : t.keepEscaping === !0 || e[n + 1] === "\\"
}
/*!
 * is-extendable <https://github.com/jonschlinkert/is-extendable>
 *
 * Copyright (c) 2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */
var J2 = function(e) {
        return typeof e < "u" && e !== null && (typeof e == "object" || typeof e == "function")
    },
    bp = J2,
    e_ = function(e) {
        bp(e) || (e = {});
        for (var n = arguments.length, r = 1; r < n; r++) {
            var i = arguments[r];
            bp(i) && t_(e, i)
        }
        return e
    };

function t_(t, e) {
    for (var n in e) n_(e, n) && (t[n] = e[n])
}

function n_(t, e) {
    return Object.prototype.hasOwnProperty.call(t, e)
}
/*!
 * is-extendable <https://github.com/jonschlinkert/is-extendable>
 *
 * Copyright (c) 2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */
var r_ = function(e) {
    return typeof e < "u" && e !== null && (typeof e == "object" || typeof e == "function")
};
/*!
 * set-value <https://github.com/jonschlinkert/set-value>
 *
 * Copyright (c) 2014-2015, 2017, Jon Schlinkert.
 * Released under the MIT License.
 */
var i_ = K2,
    o_ = e_,
    wp = sm,
    _p = r_,
    s_ = function(t, e, n) {
        if (!_p(t) || (Array.isArray(e) && (e = [].concat.apply([], e).join(".")), typeof e != "string")) return t;
        for (var r = i_(e, {
                sep: ".",
                brackets: !0
            }).filter(a_), i = r.length, o = -1, s = t; ++o < i;) {
            var a = r[o];
            if (o !== i - 1) {
                _p(s[a]) || (s[a] = {}), s = s[a];
                continue
            }
            wp(s[a]) && wp(n) ? s[a] = o_({}, s[a], n) : s[a] = n
        }
        return t
    };

function a_(t) {
    return t !== "__proto__" && t !== "constructor" && t !== "prototype"
}
var Rc = jf,
    Dp = N2,
    l_ = z2,
    Sp = s_,
    c_ = function(e, n, r) {
        if (!Rc(e)) throw new TypeError("expected an object");
        if (typeof n != "string" || r == null) return Dp.apply(null, arguments);
        if (typeof r == "string") return Sp(e, n, r), e;
        var i = l_(e, n);
        return Rc(r) && Rc(i) && (r = Dp({}, i, r)), Sp(e, n, r), e
    };
const u_ = cs(c_),
    Lf = (...t) => t.filter(Boolean).join(".");

function f_(t) {
    const e = t.split(".");
    return [e.pop(), e.join(".") || void 0]
}

function d_(t, e) {
    return Object.entries(Ix(t, e)).reduce((n, [, {
        value: r,
        disabled: i,
        key: o
    }]) => (n[o] = i ? void 0 : r, n), {})
}

function p_(t, e) {
    const n = u.useRef();
    return (e ? ea : ga)(t, n.current) || (n.current = t), n.current
}

function lm(t, e) {
    return u.useMemo(t, p_(e, !0))
}

function h_(t) {
    const e = u.useRef(null),
        n = u.useRef(null),
        r = u.useRef(!0);
    return u.useLayoutEffect(() => {
        t || (e.current.style.height = "0px", e.current.style.overflow = "hidden")
    }, []), u.useEffect(() => {
        if (r.current) {
            r.current = !1;
            return
        }
        let i;
        const o = e.current,
            s = () => {
                t && (o.style.removeProperty("height"), o.style.removeProperty("overflow"), n.current.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                }))
            };
        o.addEventListener("transitionend", s, {
            once: !0
        });
        const {
            height: a
        } = n.current.getBoundingClientRect();
        return o.style.height = a + "px", t || (o.style.overflow = "hidden", i = window.setTimeout(() => o.style.height = "0px", 50)), () => {
            o.removeEventListener("transitionend", s), clearTimeout(i)
        }
    }, [t]), {
        wrapperRef: e,
        contentRef: n
    }
}
const m_ = t => {
    const [e, n] = u.useState(t.getVisiblePaths());
    return u.useEffect(() => {
        n(t.getVisiblePaths());
        const r = t.useStore.subscribe(t.getVisiblePaths, n, {
            equalityFn: ga
        });
        return () => r()
    }, [t]), e
};

function g_(t, e, n) {
    return t.useStore(i => {
        const o = ft(ft({}, n), i.data);
        return d_(o, e)
    }, ga)
}

function cm(t = 3) {
    const e = u.useRef(null),
        n = u.useRef(null),
        [r, i] = u.useState(!1),
        o = u.useCallback(() => i(!0), []),
        s = u.useCallback(() => i(!1), []);
    return u.useLayoutEffect(() => {
        if (r) {
            const {
                bottom: a,
                top: l,
                left: c
            } = e.current.getBoundingClientRect(), {
                height: d
            } = n.current.getBoundingClientRect(), f = a + d > window.innerHeight - 40 ? "up" : "down";
            n.current.style.position = "fixed", n.current.style.zIndex = "10000", n.current.style.left = c + "px", f === "down" ? n.current.style.top = a + t + "px" : n.current.style.bottom = window.innerHeight - l + t + "px"
        }
    }, [t, r]), {
        popinRef: e,
        wrapperRef: n,
        shown: r,
        show: o,
        hide: s
    }
}
Dw([Sw]);
const v_ = {
    rgb: "toRgb",
    hsl: "toHsl",
    hsv: "toHsv",
    hex: "toHex"
};
br.extend({
    color: () => t => ar(t).isValid()
});
const y_ = t => br().color().test(t);

function um(t, {
    format: e,
    hasAlpha: n,
    isString: r
}) {
    const i = v_[e] + (r && e !== "hex" ? "String" : ""),
        o = t[i]();
    return typeof o == "object" && !n ? Bx(o, ["a"]) : o
}
const fm = (t, e) => {
        const n = ar(t);
        if (!n.isValid()) throw Error("Invalid color");
        return um(n, e)
    },
    x_ = (t, e) => um(ar(t), ft(ft({}, e), {}, {
        isString: !0,
        format: "hex"
    })),
    b_ = ({
        value: t
    }) => {
        const e = _w(t),
            n = e === "name" ? "hex" : e,
            r = typeof t == "object" ? "a" in t : e === "hex" && t.length === 8 || /^(rgba)|(hsla)|(hsva)/.test(t),
            i = {
                format: n,
                hasAlpha: r,
                isString: typeof t == "string"
            };
        return {
            value: fm(t, i),
            settings: i
        }
    };
var w_ = Object.freeze({
    __proto__: null,
    schema: y_,
    sanitize: fm,
    format: x_,
    normalize: b_
});
const __ = nt("div", {
        position: "relative",
        boxSizing: "border-box",
        borderRadius: "$sm",
        overflow: "hidden",
        cursor: "pointer",
        height: "$rowHeight",
        width: "$rowHeight",
        backgroundColor: "#fff",
        backgroundImage: `url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill-opacity=".05"><path d="M8 0h8v8H8zM0 8h8v8H0z"/></svg>')`,
        $inputStyle: "",
        $hover: "",
        zIndex: 1,
        variants: {
            active: {
                true: {
                    $inputStyle: "$accent1"
                }
            }
        },
        "&::before": {
            content: '""',
            position: "absolute",
            top: 0,
            bottom: 0,
            right: 0,
            left: 0,
            backgroundColor: "currentColor",
            zIndex: 1
        }
    }),
    D_ = nt("div", {
        position: "relative",
        display: "grid",
        gridTemplateColumns: "$sizes$rowHeight auto",
        columnGap: "$colGap",
        alignItems: "center"
    }),
    S_ = nt("div", {
        width: "$colorPickerWidth",
        height: "$colorPickerHeight",
        ".react-colorful": {
            width: "100%",
            height: "100%",
            boxShadow: "$level2",
            cursor: "crosshair"
        },
        ".react-colorful__saturation": {
            borderRadius: "$sm $sm 0 0"
        },
        ".react-colorful__alpha, .react-colorful__hue": {
            height: 10
        },
        ".react-colorful__last-control": {
            borderRadius: "0 0 $sm $sm"
        },
        ".react-colorful__pointer": {
            height: 12,
            width: 12
        }
    });

function Cp(t, e) {
    return e !== "rgb" ? ar(t).toRgb() : t
}

function C_({
    value: t,
    displayValue: e,
    settings: n,
    onUpdate: r
}) {
    const {
        emitOnEditStart: i,
        emitOnEditEnd: o
    } = tr(), {
        format: s,
        hasAlpha: a
    } = n, {
        popinRef: l,
        wrapperRef: c,
        shown: d,
        show: f,
        hide: h
    } = cm(), p = u.useRef(0), [m, g] = u.useState(() => Cp(t, s)), y = a ? $w : Fw, x = () => {
        g(Cp(t, s)), f(), i()
    }, w = () => {
        h(), o(), window.clearTimeout(p.current)
    }, M = () => {
        p.current = window.setTimeout(w, 500)
    };
    return u.useEffect(() => () => window.clearTimeout(p.current), []), j.createElement(j.Fragment, null, j.createElement(__, {
        ref: l,
        active: d,
        onClick: () => x(),
        style: {
            color: e
        }
    }), d && j.createElement(Pf, null, j.createElement(A0, {
        onPointerUp: w
    }), j.createElement(S_, {
        ref: c,
        onMouseEnter: () => window.clearTimeout(p.current),
        onMouseLeave: T => T.buttons === 0 && M()
    }, j.createElement(y, {
        color: m,
        onChange: r
    }))))
}

function E_() {
    const {
        value: t,
        displayValue: e,
        label: n,
        onChange: r,
        onUpdate: i,
        settings: o
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, n), j.createElement(D_, null, j.createElement(C_, {
        value: t,
        displayValue: e,
        onChange: r,
        onUpdate: i,
        settings: o
    }), j.createElement(Tf, {
        value: e,
        onChange: r,
        onUpdate: i
    })))
}
var T_ = ft({
    component: E_
}, w_);

function P_() {
    const {
        label: t,
        displayValue: e,
        onUpdate: n,
        settings: r
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(Mf, {
        value: e,
        settings: r,
        onUpdate: n
    }))
}
var R_ = ft({
    component: P_
}, I0(["x", "y", "z"]));
const M_ = nt("div", {
        $flexCenter: "",
        position: "relative",
        backgroundColor: "$elevation3",
        borderRadius: "$sm",
        cursor: "pointer",
        height: "$rowHeight",
        width: "$rowHeight",
        touchAction: "none",
        $draggable: "",
        $hover: "",
        "&:active": {
            cursor: "none"
        },
        "&::after": {
            content: '""',
            backgroundColor: "$accent2",
            height: 4,
            width: 4,
            borderRadius: 2
        }
    }),
    $_ = nt("div", {
        $flexCenter: "",
        width: "$joystickWidth",
        height: "$joystickHeight",
        borderRadius: "$sm",
        boxShadow: "$level2",
        position: "fixed",
        zIndex: 1e4,
        overflow: "hidden",
        $draggable: "",
        transform: "translate(-50%, -50%)",
        variants: {
            isOutOfBounds: {
                true: {
                    backgroundColor: "$elevation1"
                },
                false: {
                    backgroundColor: "$elevation3"
                }
            }
        },
        "> div": {
            position: "absolute",
            $flexCenter: "",
            borderStyle: "solid",
            borderWidth: 1,
            borderColor: "$highlight1",
            backgroundColor: "$elevation3",
            width: "80%",
            height: "80%",
            "&::after,&::before": {
                content: '""',
                position: "absolute",
                zindex: 10,
                backgroundColor: "$highlight1"
            },
            "&::before": {
                width: "100%",
                height: 1
            },
            "&::after": {
                height: "100%",
                width: 1
            }
        },
        "> span": {
            position: "relative",
            zindex: 100,
            width: 10,
            height: 10,
            backgroundColor: "$accent2",
            borderRadius: "50%"
        }
    });

function A_({
    value: t,
    settings: e,
    onUpdate: n
}) {
    const r = u.useRef(),
        i = u.useRef(0),
        o = u.useRef(0),
        s = u.useRef(1),
        [a, l] = u.useState(!1),
        [c, d] = u.useState(!1),
        [f, h] = k0(),
        p = u.useRef(null),
        m = u.useRef(null);
    u.useLayoutEffect(() => {
        if (a) {
            const {
                top: V,
                left: I,
                width: X,
                height: q
            } = p.current.getBoundingClientRect();
            m.current.style.left = I + X / 2 + "px", m.current.style.top = V + q / 2 + "px"
        }
    }, [a]);
    const {
        keys: [g, y],
        joystick: x
    } = e, w = x === "invertY" ? 1 : -1, {
        [g]: {
            step: M
        },
        [y]: {
            step: T
        }
    } = e, O = Pi("sizes", "joystickWidth"), R = Pi("sizes", "joystickHeight"), P = parseFloat(O) * .8 / 2, B = parseFloat(R) * .8 / 2, te = u.useCallback(() => {
        r.current || (d(!0), i.current && h({
            x: i.current * P
        }), o.current && h({
            y: o.current * -B
        }), r.current = window.setInterval(() => {
            n(V => {
                const I = M * i.current * s.current,
                    X = w * T * o.current * s.current;
                return Array.isArray(V) ? {
                    [g]: V[0] + I,
                    [y]: V[1] + X
                } : {
                    [g]: V[g] + I,
                    [y]: V[y] + X
                }
            })
        }, 16))
    }, [P, B, n, h, M, T, g, y, w]), W = u.useCallback(() => {
        window.clearTimeout(r.current), r.current = void 0, d(!1)
    }, []);
    u.useEffect(() => {
        function V(I) {
            s.current = y0(I)
        }
        return window.addEventListener("keydown", V), window.addEventListener("keyup", V), () => {
            window.clearTimeout(r.current), window.removeEventListener("keydown", V), window.removeEventListener("keyup", V)
        }
    }, []);
    const ee = xa(({
        first: V,
        active: I,
        delta: [X, q],
        movement: [Z, le]
    }) => {
        V && l(!0);
        const Se = Ji(Z, -P, P),
            Me = Ji(le, -B, B);
        i.current = Math.abs(Z) > Math.abs(Se) ? Math.sign(Z - Se) : 0, o.current = Math.abs(le) > Math.abs(Me) ? Math.sign(Me - le) : 0;
        let z = t[g],
            ge = t[y];
        I ? (i.current || (z += X * M * s.current, h({
            x: Se
        })), o.current || (ge -= w * q * T * s.current, h({
            y: Me
        })), i.current || o.current ? te() : W(), n({
            [g]: z,
            [y]: ge
        })) : (l(!1), i.current = 0, o.current = 0, h({
            x: 0,
            y: 0
        }), W())
    });
    return j.createElement(M_, wn({
        ref: p
    }, ee()), a && j.createElement(Pf, null, j.createElement($_, {
        ref: m,
        isOutOfBounds: c
    }, j.createElement("div", null), j.createElement("span", {
        ref: f
    }))))
}
const F_ = nt("div", {
    display: "grid",
    columnGap: "$colGap",
    variants: {
        withJoystick: {
            true: {
                gridTemplateColumns: "$sizes$rowHeight auto"
            },
            false: {
                gridTemplateColumns: "auto"
            }
        }
    }
});

function k_() {
    const {
        label: t,
        displayValue: e,
        onUpdate: n,
        settings: r
    } = tr();
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(F_, {
        withJoystick: !!r.joystick
    }, r.joystick && j.createElement(A_, {
        value: e,
        settings: r,
        onUpdate: n
    }), j.createElement(Mf, {
        value: e,
        settings: r,
        onUpdate: n
    })))
}
const O_ = ["joystick"],
    dm = I0(["x", "y"]),
    j_ = t => {
        let {
            joystick: e = !0
        } = t, n = tn(t, O_);
        const {
            value: r,
            settings: i
        } = dm.normalize(n);
        return {
            value: r,
            settings: ft(ft({}, i), {}, {
                joystick: e
            })
        }
    };
var L_ = ft(ft({
    component: k_
}, dm), {}, {
    normalize: j_
});
const N_ = t => {
        if (t !== void 0) {
            if (t instanceof File) try {
                return URL.createObjectURL(t)
            } catch {
                return
            }
            if (typeof t == "string" && t.indexOf("blob:") === 0) return t;
            throw Error("Invalid image format [undefined | blob | File].")
        }
    },
    z_ = (t, e) => typeof e == "object" && "image" in e,
    I_ = ({
        image: t
    }) => ({
        value: t
    });
var B_ = Object.freeze({
    __proto__: null,
    sanitize: N_,
    schema: z_,
    normalize: I_
});
const W_ = nt("div", {
        position: "relative",
        display: "grid",
        gridTemplateColumns: "$sizes$rowHeight auto 20px",
        columnGap: "$colGap",
        alignItems: "center"
    }),
    V_ = nt("div", {
        $flexCenter: "",
        overflow: "hidden",
        height: "$rowHeight",
        background: "$elevation3",
        textAlign: "center",
        color: "inherit",
        borderRadius: "$sm",
        outline: "none",
        userSelect: "none",
        cursor: "pointer",
        $inputStyle: "",
        $hover: "",
        $focusWithin: "",
        $active: "$accent1 $elevation1",
        variants: {
            isDragAccept: {
                true: {
                    $inputStyle: "$accent1",
                    backgroundColor: "$elevation1"
                }
            }
        }
    }),
    U_ = nt("div", {
        boxSizing: "border-box",
        borderRadius: "$sm",
        height: "$rowHeight",
        width: "$rowHeight",
        $inputStyle: "",
        backgroundSize: "cover",
        backgroundPosition: "center",
        variants: {
            hasImage: {
                true: {
                    cursor: "pointer",
                    $hover: "",
                    $active: ""
                }
            }
        }
    }),
    H_ = nt("div", {
        $flexCenter: "",
        width: "$imagePreviewWidth",
        height: "$imagePreviewHeight",
        borderRadius: "$sm",
        boxShadow: "$level2",
        pointerEvents: "none",
        $inputStyle: "",
        backgroundSize: "cover",
        backgroundPosition: "center"
    }),
    G_ = nt("div", {
        fontSize: "0.8em",
        height: "100%",
        padding: "$rowGap $md"
    }),
    Y_ = nt("div", {
        $flexCenter: "",
        top: "0",
        right: "0",
        marginRight: "$sm",
        height: "100%",
        cursor: "pointer",
        variants: {
            disabled: {
                true: {
                    color: "$elevation3",
                    cursor: "default"
                }
            }
        },
        "&::after,&::before": {
            content: '""',
            position: "absolute",
            height: 2,
            width: 10,
            borderRadius: 1,
            backgroundColor: "currentColor"
        },
        "&::after": {
            transform: "rotate(45deg)"
        },
        "&::before": {
            transform: "rotate(-45deg)"
        }
    });

function X_() {
    const {
        label: t,
        value: e,
        onUpdate: n,
        disabled: r
    } = tr(), {
        popinRef: i,
        wrapperRef: o,
        shown: s,
        show: a,
        hide: l
    } = cm(), c = u.useCallback(m => {
        m.length && n(m[0])
    }, [n]), d = u.useCallback(m => {
        m.stopPropagation(), n(void 0)
    }, [n]), {
        getRootProps: f,
        getInputProps: h,
        isDragAccept: p
    } = om({
        maxFiles: 1,
        accept: "image/*",
        onDrop: c,
        disabled: r
    });
    return j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(W_, null, j.createElement(U_, {
        ref: i,
        hasImage: !!e,
        onPointerDown: () => !!e && a(),
        onPointerUp: l,
        style: {
            backgroundImage: e ? `url(${e})` : "none"
        }
    }), s && !!e && j.createElement(Pf, null, j.createElement(A0, {
        onPointerUp: l,
        style: {
            cursor: "pointer"
        }
    }), j.createElement(H_, {
        ref: o,
        style: {
            backgroundImage: `url(${e})`
        }
    })), j.createElement(V_, f({
        isDragAccept: p
    }), j.createElement("input", h()), j.createElement(G_, null, p ? "drop image" : "click or drop")), j.createElement(Y_, {
        onClick: d,
        disabled: !e
    })))
}
var q_ = ft({
    component: X_
}, B_);
const Ep = br().number(),
    K_ = (t, e) => br().array().length(2).every.number().test(t) && br().schema({
        min: Ep,
        max: Ep
    }).test(e),
    Ml = t => ({
        min: t[0],
        max: t[1]
    }),
    pm = (t, {
        bounds: [e, n]
    }, r) => {
        const i = Array.isArray(t) ? Ml(t) : t,
            o = {
                min: r[0],
                max: r[1]
            },
            {
                min: s,
                max: a
            } = ft(ft({}, o), i);
        return [Ji(Number(s), e, Math.max(e, a)), Ji(Number(a), Math.min(n, s), n)]
    },
    Z_ = ({
        value: t,
        min: e,
        max: n
    }) => {
        const r = {
                min: e,
                max: n
            },
            i = z0(Ml(t), {
                min: r,
                max: r
            }),
            o = [e, n],
            s = ft(ft({}, i), {}, {
                bounds: o
            });
        return {
            value: pm(Ml(t), s, t),
            settings: s
        }
    };
var Q_ = Object.freeze({
    __proto__: null,
    schema: K_,
    format: Ml,
    sanitize: pm,
    normalize: Z_
});
const J_ = ["value", "bounds", "onDrag"],
    eD = ["bounds"],
    tD = nt("div", {
        display: "grid",
        columnGap: "$colGap",
        gridTemplateColumns: "auto calc($sizes$numberInputMinWidth * 2 + $space$rowGap)"
    });

function nD(t) {
    let {
        value: e,
        bounds: [n, r],
        onDrag: i
    } = t, o = tn(t, J_);
    const s = u.useRef(null),
        a = u.useRef(null),
        l = u.useRef(null),
        c = u.useRef(0),
        d = Pi("sizes", "scrubberWidth"),
        f = xa(({
            event: m,
            first: g,
            xy: [y],
            movement: [x],
            memo: w = {}
        }) => {
            if (g) {
                const {
                    width: T,
                    left: O
                } = s.current.getBoundingClientRect();
                c.current = T - parseFloat(d);
                const R = (m == null ? void 0 : m.target) === a.current || (m == null ? void 0 : m.target) === l.current;
                w.pos = Cl((y - O) / T, n, r);
                const P = Math.abs(w.pos - e.min) - Math.abs(w.pos - e.max);
                w.key = P < 0 || P === 0 && w.pos <= e.min ? "min" : "max", R && (w.pos = e[w.key])
            }
            const M = w.pos + Cl(x / c.current, 0, r - n);
            return i({
                [w.key]: Rb(M, o[w.key])
            }), w
        }),
        h = `calc(${Sl(e.min,n,r)} * (100% - ${d} - 8px) + 4px)`,
        p = `calc(${1-Sl(e.max,n,r)} * (100% - ${d} - 8px) + 4px)`;
    return j.createElement(j0, wn({
        ref: s
    }, f()), j.createElement(O0, null, j.createElement(L0, {
        style: {
            left: h,
            right: p
        }
    })), j.createElement(cu, {
        position: "left",
        ref: a,
        style: {
            left: h
        }
    }), j.createElement(cu, {
        position: "right",
        ref: l,
        style: {
            right: p
        }
    }))
}

function rD() {
    const {
        label: t,
        displayValue: e,
        onUpdate: n,
        settings: r
    } = tr(), i = tn(r, eD);
    return j.createElement(j.Fragment, null, j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, null, t), j.createElement(tD, null, j.createElement(nD, wn({
        value: e
    }, r, {
        onDrag: n
    })), j.createElement(Mf, {
        value: e,
        settings: i,
        onUpdate: n,
        innerLabelTrim: 0
    }))))
}
var iD = ft({
    component: rD
}, Q_);
const oD = () => {
        const t = new Map;
        return {
            on: (e, n) => {
                let r = t.get(e);
                r === void 0 && (r = new Set, t.set(e, r)), r.add(n)
            },
            off: (e, n) => {
                const r = t.get(e);
                r !== void 0 && (r.delete(n), r.size === 0 && t.delete(e))
            },
            emit: (e, ...n) => {
                const r = t.get(e);
                if (r !== void 0)
                    for (const i of r) i(...n)
            }
        }
    },
    sD = ["type", "value"],
    aD = ["onChange", "transient", "onEditStart", "onEditEnd"],
    lD = function() {
        const e = P2(R2(() => ({
                data: {}
            }))),
            n = oD();
        this.storeId = zx(), this.useStore = e;
        const r = {},
            i = new Set;
        this.getVisiblePaths = () => {
            const s = this.getData(),
                a = Object.keys(s),
                l = [];
            Object.entries(r).forEach(([d, f]) => {
                f.render && a.some(h => h.indexOf(d) === 0) && !f.render(this.get) && l.push(d + ".")
            });
            const c = [];
            return i.forEach(d => {
                d in s && s[d].__refCount > 0 && l.every(f => d.indexOf(f) === -1) && (!s[d].render || s[d].render(this.get)) && c.push(d)
            }), c
        }, this.setOrderedPaths = s => {
            s.forEach(a => i.add(a))
        }, this.orderPaths = s => (this.setOrderedPaths(s), s), this.disposePaths = s => {
            e.setState(a => {
                const l = a.data;
                return s.forEach(c => {
                    if (c in l) {
                        const d = l[c];
                        d.__refCount--, d.__refCount === 0 && d.type in ei && delete l[c]
                    }
                }), {
                    data: l
                }
            })
        }, this.dispose = () => {
            e.setState(() => ({
                data: {}
            }))
        }, this.getFolderSettings = s => r[s] || {}, this.getData = () => e.getState().data, this.addData = (s, a) => {
            e.setState(l => {
                const c = l.data;
                return Object.entries(s).forEach(([d, f]) => {
                    let h = c[d];
                    if (h) {
                        const {
                            type: p,
                            value: m
                        } = f, g = tn(f, sD);
                        p !== h.type ? bi(xn.INPUT_TYPE_OVERRIDE, p) : ((h.__refCount === 0 || a) && Object.assign(h, g), h.__refCount++)
                    } else c[d] = ft(ft({}, f), {}, {
                        __refCount: 1
                    })
                }), {
                    data: c
                }
            })
        }, this.setValueAtPath = (s, a, l) => {
            e.setState(c => {
                const d = c.data;
                return qd(d[s], a, s, this, l), {
                    data: d
                }
            })
        }, this.setSettingsAtPath = (s, a) => {
            e.setState(l => {
                const c = l.data;
                return c[s].settings = ft(ft({}, c[s].settings), a), {
                    data: c
                }
            })
        }, this.disableInputAtPath = (s, a) => {
            e.setState(l => {
                const c = l.data;
                return c[s].disabled = a, {
                    data: c
                }
            })
        }, this.set = (s, a) => {
            e.setState(l => {
                const c = l.data;
                return Object.entries(s).forEach(([d, f]) => {
                    try {
                        qd(c[d], f, void 0, void 0, a)
                    } catch {}
                }), {
                    data: c
                }
            })
        }, this.getInput = s => {
            try {
                return this.getData()[s]
            } catch {
                bi(xn.PATH_DOESNT_EXIST, s)
            }
        }, this.get = s => {
            var a;
            return (a = this.getInput(s)) === null || a === void 0 ? void 0 : a.value
        }, this.emitOnEditStart = s => {
            n.emit(`onEditStart:${s}`, this.get(s), s, ft(ft({}, this.getInput(s)), {}, {
                get: this.get
            }))
        }, this.emitOnEditEnd = s => {
            n.emit(`onEditEnd:${s}`, this.get(s), s, ft(ft({}, this.getInput(s)), {}, {
                get: this.get
            }))
        }, this.subscribeToEditStart = (s, a) => {
            const l = `onEditStart:${s}`;
            return n.on(l, a), () => n.off(l, a)
        }, this.subscribeToEditEnd = (s, a) => {
            const l = `onEditEnd:${s}`;
            return n.on(l, a), () => n.off(l, a)
        };
        const o = (s, a, l) => {
            const c = {};
            return Object.entries(s).forEach(([d, f]) => {
                if (d === "") return bi(xn.EMPTY_KEY);
                let h = Lf(a, d);
                if (f.type === ei.FOLDER) {
                    const p = o(f.schema, h, l);
                    Object.assign(c, p), h in r || (r[h] = f.settings)
                } else if (d in l) bi(xn.DUPLICATE_KEYS, d, h, l[d].path);
                else {
                    const p = Yx(f, d, h, c);
                    if (p) {
                        const {
                            type: m,
                            options: g,
                            input: y
                        } = p, {
                            onChange: x,
                            transient: w,
                            onEditStart: M,
                            onEditEnd: T
                        } = g, O = tn(g, aD);
                        c[h] = ft(ft(ft({
                            type: m
                        }, O), y), {}, {
                            fromPanel: !0
                        }), l[d] = {
                            path: h,
                            onChange: x,
                            transient: w,
                            onEditStart: M,
                            onEditEnd: T
                        }
                    } else bi(xn.UNKNOWN_INPUT, h, f)
                }
            }), c
        };
        this.getDataFromSchema = s => {
            const a = {};
            return [o(s, "", a), a]
        }
    },
    hm = new lD,
    cD = {
        collapsed: !1
    };

function at(t, e) {
    return {
        type: ei.FOLDER,
        schema: t,
        settings: ft(ft({}, cD), e)
    }
}
const Tp = t => "__levaInput" in t,
    uD = (t, e) => {
        const n = {},
            r = e ? e.toLowerCase() : null;
        return t.forEach(i => {
            const [o, s] = f_(i);
            (!r || o.toLowerCase().indexOf(r) > -1) && u_(n, s, {
                [o]: {
                    __levaInput: !0,
                    path: i
                }
            })
        }), n
    },
    fD = ["type", "label", "path", "valueKey", "value", "settings", "setValue", "disabled"];

function dD(t) {
    let {
        type: e,
        label: n,
        path: r,
        valueKey: i,
        value: o,
        settings: s,
        setValue: a,
        disabled: l
    } = t, c = tn(t, fD);
    const {
        displayValue: d,
        onChange: f,
        onUpdate: h
    } = F0({
        type: e,
        value: o,
        settings: s,
        setValue: a
    }), p = Do[e].component;
    return p ? j.createElement(D0.Provider, {
        value: ft({
            key: i,
            path: r,
            id: "" + r,
            label: n,
            displayValue: d,
            value: o,
            onChange: f,
            onUpdate: h,
            settings: s,
            setValue: a,
            disabled: l
        }, c)
    }, j.createElement(pb, {
        disabled: l
    }, j.createElement(p, null))) : (bi(xn.NO_COMPONENT_FOR_TYPE, e, r), null)
}
const pD = nt("button", {
    display: "block",
    $reset: "",
    fontWeight: "$button",
    height: "$rowHeight",
    borderStyle: "none",
    borderRadius: "$sm",
    backgroundColor: "$elevation1",
    color: "$highlight1",
    "&:not(:disabled)": {
        color: "$highlight3",
        backgroundColor: "$accent2",
        cursor: "pointer",
        $hover: "$accent3",
        $active: "$accent3 $accent1",
        $focus: ""
    }
});

function hD({
    onClick: t,
    settings: e,
    label: n
}) {
    const r = ya();
    return j.createElement(Hr, null, j.createElement(pD, {
        disabled: e.disabled,
        onClick: () => t(r.get)
    }, n))
}
const mD = nt("div", {
        $flex: "",
        justifyContent: "flex-end",
        gap: "$colGap"
    }),
    gD = nt("button", {
        $reset: "",
        cursor: "pointer",
        borderRadius: "$xs",
        "&:hover": {
            backgroundColor: "$elevation3"
        }
    }),
    vD = ({
        label: t,
        opts: e
    }) => {
        let n = typeof t == "string" && t.trim() === "" ? null : t,
            r = e;
        return typeof e.opts == "object" && (r.label !== void 0 && (n = e.label), r = e.opts), {
            label: n,
            opts: r
        }
    };

function yD(t) {
    const {
        label: e,
        opts: n
    } = vD(t), r = ya();
    return j.createElement(Hr, {
        input: !!e
    }, e && j.createElement(ni, null, e), j.createElement(mD, null, Object.entries(n).map(([i, o]) => j.createElement(gD, {
        key: i,
        onClick: () => o(r.get)
    }, i))))
}
const xD = nt("canvas", {
        height: "$monitorHeight",
        width: "100%",
        display: "block",
        borderRadius: "$sm"
    }),
    mm = 100;

function bD(t, e) {
    t.push(e), t.length > mm && t.shift()
}
const wD = u.forwardRef(function({
        initialValue: t
    }, e) {
        const n = Pi("colors", "highlight3"),
            r = Pi("colors", "elevation2"),
            i = Pi("colors", "highlight1"),
            [o, s] = u.useMemo(() => [ar(i).alpha(.4).toRgbString(), ar(i).alpha(.1).toRgbString()], [i]),
            a = u.useRef([t]),
            l = u.useRef(t),
            c = u.useRef(t),
            d = u.useRef(),
            f = u.useCallback((m, g) => {
                if (!m) return;
                const {
                    width: y,
                    height: x
                } = m, w = new Path2D, M = y / mm, T = x * .05;
                for (let P = 0; P < a.current.length; P++) {
                    const B = Sl(a.current[P], l.current, c.current),
                        te = M * P,
                        W = x - B * (x - T * 2) - T;
                    w.lineTo(te, W)
                }
                g.clearRect(0, 0, y, x);
                const O = new Path2D(w);
                O.lineTo(M * (a.current.length + 1), x), O.lineTo(0, x), O.lineTo(0, 0);
                const R = g.createLinearGradient(0, 0, 0, x);
                R.addColorStop(0, o), R.addColorStop(1, s), g.fillStyle = R, g.fill(O), g.strokeStyle = r, g.lineJoin = "round", g.lineWidth = 14, g.stroke(w), g.strokeStyle = n, g.lineWidth = 2, g.stroke(w)
            }, [n, r, o, s]),
            [h, p] = _b(f);
        return u.useImperativeHandle(e, () => ({
            frame: m => {
                (l.current === void 0 || m < l.current) && (l.current = m), (c.current === void 0 || m > c.current) && (c.current = m), bD(a.current, m), d.current = requestAnimationFrame(() => f(h.current, p.current))
            }
        }), [h, p, f]), u.useEffect(() => () => cancelAnimationFrame(d.current), []), j.createElement(xD, {
            ref: h
        })
    }),
    Pp = t => Number.isFinite(t) ? t.toPrecision(2) : t.toString(),
    _D = u.forwardRef(function({
        initialValue: t
    }, e) {
        const [n, r] = u.useState(Pp(t));
        return u.useImperativeHandle(e, () => ({
            frame: i => r(Pp(i))
        }), []), j.createElement("div", null, n)
    });

function Rp(t) {
    return typeof t == "function" ? t() : t.current
}

function DD({
    label: t,
    objectOrFn: e,
    settings: n
}) {
    const r = u.useRef(),
        i = u.useRef(Rp(e));
    return u.useEffect(() => {
        const o = window.setInterval(() => {
            var s;
            document.hidden || (s = r.current) === null || s === void 0 || s.frame(Rp(e))
        }, n.interval);
        return () => window.clearInterval(o)
    }, [e, n.interval]), j.createElement(Hr, {
        input: !0
    }, j.createElement(ni, {
        align: "top"
    }, t), n.graph ? j.createElement(wD, {
        ref: r,
        initialValue: i.current
    }) : j.createElement(_D, {
        ref: r,
        initialValue: i.current
    }))
}
const SD = ["type", "label", "key"],
    CD = {
        [ei.BUTTON]: hD,
        [ei.BUTTON_GROUP]: yD,
        [ei.MONITOR]: DD
    },
    ED = j.memo(({
        path: t
    }) => {
        const [e, {
            set: n,
            setSettings: r,
            disable: i,
            storeId: o,
            emitOnEditStart: s,
            emitOnEditEnd: a
        }] = Sb(t);
        if (!e) return null;
        const {
            type: l,
            label: c,
            key: d
        } = e, f = tn(e, SD);
        if (l in ei) {
            const h = CD[l];
            return j.createElement(h, wn({
                label: c,
                path: t
            }, f))
        }
        return l in Do ? j.createElement(dD, wn({
            key: o + t,
            type: l,
            label: c,
            storeId: o,
            path: t,
            valueKey: d,
            setValue: n,
            setSettings: r,
            disable: i,
            emitOnEditStart: s,
            emitOnEditEnd: a
        }, f)) : ($x(xn.UNSUPPORTED_INPUT, l, t), null)
    });

function TD({
    toggle: t,
    toggled: e,
    name: n
}) {
    return j.createElement(ub, {
        onClick: () => t()
    }, j.createElement(Rf, {
        toggled: e
    }), j.createElement("div", null, n))
}
const PD = ({
        name: t,
        path: e,
        tree: n
    }) => {
        const r = ya(),
            i = Lf(e, t),
            {
                collapsed: o,
                color: s
            } = r.getFolderSettings(i),
            [a, l] = u.useState(!o),
            c = u.useRef(null),
            d = Pi("colors", "folderWidgetColor"),
            f = Pi("colors", "folderTextColor");
        return u.useLayoutEffect(() => {
            c.current.style.setProperty("--leva-colors-folderWidgetColor", s || d), c.current.style.setProperty("--leva-colors-folderTextColor", s || f)
        }, [s, d, f]), j.createElement(El, {
            ref: c
        }, j.createElement(TD, {
            name: t,
            toggled: a,
            toggle: () => l(h => !h)
        }), j.createElement(gm, {
            parent: i,
            tree: n,
            toggled: a
        }))
    },
    gm = j.memo(({
        isRoot: t = !1,
        fill: e = !1,
        flat: n = !1,
        parent: r,
        tree: i,
        toggled: o
    }) => {
        const {
            wrapperRef: s,
            contentRef: a
        } = h_(o), l = ya(), c = ([f, h]) => {
            var p;
            return (Tp(h) ? (p = l.getInput(h.path)) === null || p === void 0 ? void 0 : p.order : l.getFolderSettings(Lf(r, f)).order) || 0
        }, d = Object.entries(i).sort((f, h) => c(f) - c(h));
        return j.createElement(au, {
            ref: s,
            isRoot: t,
            fill: e,
            flat: n
        }, j.createElement(R0, {
            ref: a,
            isRoot: t,
            toggled: o
        }, d.map(([f, h]) => Tp(h) ? j.createElement(ED, {
            key: h.path,
            valueKey: h.valueKey,
            path: h.path
        }) : j.createElement(PD, {
            key: f,
            name: f,
            path: r,
            tree: h
        }))))
    }),
    RD = nt("div", {
        position: "relative",
        fontFamily: "$mono",
        fontSize: "$root",
        color: "$rootText",
        backgroundColor: "$elevation1",
        variants: {
            fill: {
                false: {
                    position: "fixed",
                    top: "10px",
                    right: "10px",
                    zIndex: 1e3,
                    width: "$rootWidth"
                },
                true: {
                    position: "relative",
                    width: "100%"
                }
            },
            flat: {
                false: {
                    borderRadius: "$lg",
                    boxShadow: "$level1"
                }
            },
            oneLineLabels: {
                true: {
                    [`${$0}`]: {
                        gridTemplateColumns: "auto",
                        gridAutoColumns: "minmax(max-content, 1fr)",
                        gridAutoRows: "minmax($sizes$rowHeight), auto)",
                        rowGap: 0,
                        columnGap: 0,
                        marginTop: "$rowGap"
                    }
                }
            },
            hideTitleBar: {
                true: {
                    $$titleBarHeight: "0px"
                },
                false: {
                    $$titleBarHeight: "$sizes$titleBarHeight"
                }
            }
        },
        "&,*,*:after,*:before": {
            boxSizing: "border-box"
        },
        "*::selection": {
            backgroundColor: "$accent2"
        }
    }),
    vm = 40,
    $l = nt("i", {
        $flexCenter: "",
        width: vm,
        userSelect: "none",
        cursor: "pointer",
        "> svg": {
            fill: "$highlight1",
            transition: "transform 350ms ease, fill 250ms ease"
        },
        "&:hover > svg": {
            fill: "$highlight3"
        },
        variants: {
            active: {
                true: {
                    "> svg": {
                        fill: "$highlight2"
                    }
                }
            }
        }
    }),
    MD = nt("div", {
        display: "flex",
        alignItems: "stretch",
        justifyContent: "space-between",
        height: "$titleBarHeight",
        variants: {
            mode: {
                drag: {
                    cursor: "grab"
                }
            }
        }
    }),
    $D = nt("div", {
        $flex: "",
        position: "relative",
        width: "100%",
        overflow: "hidden",
        transition: "height 250ms ease",
        color: "$highlight3",
        paddingLeft: "$md",
        [`> ${$l}`]: {
            height: 30
        },
        variants: {
            toggled: {
                true: {
                    height: 30
                },
                false: {
                    height: 0
                }
            }
        }
    }),
    AD = nt("input", {
        $reset: "",
        flex: 1,
        position: "relative",
        height: 30,
        width: "100%",
        backgroundColor: "transparent",
        fontSize: "10px",
        borderRadius: "$root",
        "&:focus": {},
        "&::placeholder": {
            color: "$highlight2"
        }
    }),
    FD = nt("div", {
        touchAction: "none",
        $flexCenter: "",
        flex: 1,
        "> svg": {
            fill: "$highlight1"
        },
        color: "$highlight1",
        variants: {
            drag: {
                true: {
                    $draggable: "",
                    "> svg": {
                        transition: "fill 250ms ease"
                    },
                    "&:hover": {
                        color: "$highlight3"
                    },
                    "&:hover > svg": {
                        fill: "$highlight3"
                    }
                }
            },
            filterEnabled: {
                false: {
                    paddingRight: vm
                }
            }
        }
    }),
    kD = j.forwardRef(({
        setFilter: t,
        toggle: e
    }, n) => {
        const [r, i] = u.useState(""), o = u.useMemo(() => v0(t, 250), [t]), s = () => {
            t(""), i("")
        }, a = l => {
            const c = l.currentTarget.value;
            e(!0), i(c)
        };
        return u.useEffect(() => {
            o(r)
        }, [r, o]), j.createElement(j.Fragment, null, j.createElement(AD, {
            ref: n,
            value: r,
            placeholder: "[Open filter with CMD+SHIFT+L]",
            onPointerDown: l => l.stopPropagation(),
            onChange: a
        }), j.createElement($l, {
            onClick: () => s(),
            style: {
                visibility: r ? "visible" : "hidden"
            }
        }, j.createElement("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            height: "14",
            width: "14",
            viewBox: "0 0 20 20",
            fill: "currentColor"
        }, j.createElement("path", {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
            clipRule: "evenodd"
        }))))
    });

function OD({
    setFilter: t,
    onDrag: e,
    onDragStart: n,
    onDragEnd: r,
    toggle: i,
    toggled: o,
    title: s,
    drag: a,
    filterEnabled: l,
    from: c
}) {
    const [d, f] = u.useState(!1), h = u.useRef(null);
    u.useEffect(() => {
        var m, g;
        d ? (m = h.current) === null || m === void 0 || m.focus() : (g = h.current) === null || g === void 0 || g.blur()
    }, [d]);
    const p = xa(({
        offset: [m, g],
        first: y,
        last: x
    }) => {
        e({
            x: m,
            y: g
        }), y && n({
            x: m,
            y: g
        }), x && r({
            x: m,
            y: g
        })
    }, {
        filterTaps: !0,
        from: ({
            offset: [m, g]
        }) => [(c == null ? void 0 : c.x) || m, (c == null ? void 0 : c.y) || g]
    });
    return u.useEffect(() => {
        const m = g => {
            g.key === "L" && g.shiftKey && g.metaKey && f(y => !y)
        };
        return window.addEventListener("keydown", m), () => window.removeEventListener("keydown", m)
    }, []), j.createElement(j.Fragment, null, j.createElement(MD, {
        mode: a ? "drag" : void 0
    }, j.createElement($l, {
        active: !o,
        onClick: () => i()
    }, j.createElement(Rf, {
        toggled: o,
        width: 12,
        height: 8
    })), j.createElement(FD, wn({}, a ? p() : {}, {
        drag: a,
        filterEnabled: l
    }), s === void 0 && a ? j.createElement("svg", {
        width: "20",
        height: "10",
        viewBox: "0 0 28 14",
        xmlns: "http://www.w3.org/2000/svg"
    }, j.createElement("circle", {
        cx: "2",
        cy: "2",
        r: "2"
    }), j.createElement("circle", {
        cx: "14",
        cy: "2",
        r: "2"
    }), j.createElement("circle", {
        cx: "26",
        cy: "2",
        r: "2"
    }), j.createElement("circle", {
        cx: "2",
        cy: "12",
        r: "2"
    }), j.createElement("circle", {
        cx: "14",
        cy: "12",
        r: "2"
    }), j.createElement("circle", {
        cx: "26",
        cy: "12",
        r: "2"
    })) : s), l && j.createElement($l, {
        active: d,
        onClick: () => f(m => !m)
    }, j.createElement("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        height: "20",
        viewBox: "0 0 20 20"
    }, j.createElement("path", {
        d: "M9 9a2 2 0 114 0 2 2 0 01-4 0z"
    }), j.createElement("path", {
        fillRule: "evenodd",
        d: "M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a4 4 0 00-3.446 6.032l-2.261 2.26a1 1 0 101.414 1.415l2.261-2.261A4 4 0 1011 5z",
        clipRule: "evenodd"
    })))), j.createElement($D, {
        toggled: d
    }, j.createElement(kD, {
        ref: h,
        setFilter: t,
        toggle: i
    })))
}
const jD = ["store", "hidden", "theme", "collapsed"];

function LD(t) {
    let {
        store: e,
        hidden: n = !1,
        theme: r,
        collapsed: i = !1
    } = t, o = tn(t, jD);
    const s = lm(() => ib(r), [r]),
        [a, l] = u.useState(!i),
        c = typeof i == "object" ? !i.collapsed : a,
        d = u.useMemo(() => typeof i == "object" ? f => {
            typeof f == "function" ? i.onChange(!f(!i.collapsed)) : i.onChange(!f)
        } : l, [i]);
    return !e || n ? null : j.createElement(Ef.Provider, {
        value: s
    }, j.createElement(ND, wn({
        store: e
    }, o, {
        toggled: c,
        setToggle: d,
        rootClass: s.className
    })))
}
const ND = j.memo(({
        store: t,
        rootClass: e,
        fill: n = !1,
        flat: r = !1,
        neverHide: i = !1,
        oneLineLabels: o = !1,
        titleBar: s = {
            title: void 0,
            drag: !0,
            filter: !0,
            position: void 0,
            onDrag: void 0,
            onDragStart: void 0,
            onDragEnd: void 0
        },
        hideCopyButton: a = !1,
        toggled: l,
        setToggle: c
    }) => {
        var d, f;
        const h = m_(t),
            [p, m] = u.useState(""),
            g = u.useMemo(() => uD(h, p), [h, p]),
            [y, x] = k0(),
            w = i || h.length > 0,
            M = typeof s == "object" && s.title || void 0,
            T = typeof s == "object" && (d = s.drag) !== null && d !== void 0 ? d : !0,
            O = typeof s == "object" && (f = s.filter) !== null && f !== void 0 ? f : !0,
            R = typeof s == "object" && s.position || void 0,
            P = typeof s == "object" && s.onDrag || void 0,
            B = typeof s == "object" && s.onDragStart || void 0,
            te = typeof s == "object" && s.onDragEnd || void 0;
        return j.useEffect(() => {
            x({
                x: R == null ? void 0 : R.x,
                y: R == null ? void 0 : R.y
            })
        }, [R, x]), rb(), j.createElement(C0.Provider, {
            value: {
                hideCopyButton: a
            }
        }, j.createElement(RD, {
            ref: y,
            className: e,
            fill: n,
            flat: r,
            oneLineLabels: o,
            hideTitleBar: !s,
            style: {
                display: w ? "block" : "none"
            }
        }, s && j.createElement(OD, {
            onDrag: W => {
                x(W), P == null || P(W)
            },
            onDragStart: W => B == null ? void 0 : B(W),
            onDragEnd: W => te == null ? void 0 : te(W),
            setFilter: m,
            toggle: W => c(ee => W ? ? !ee),
            toggled: l,
            title: M,
            drag: T,
            filterEnabled: O,
            from: R
        }), w && j.createElement(S0.Provider, {
            value: t
        }, j.createElement(gm, {
            isRoot: !0,
            fill: n,
            flat: r,
            tree: g,
            toggled: l
        }))))
    }),
    zD = ["isRoot"];
let Al = !1,
    fo = null;

function ym(t) {
    let {
        isRoot: e = !1
    } = t, n = tn(t, zD);
    return u.useEffect(() => (Al = !0, !e && fo && (fo.remove(), fo = null), () => {
        e || (Al = !1)
    }), [e]), j.createElement(LD, wn({
        store: hm
    }, n))
}

function ID(t) {
    u.useEffect(() => {
        t && !Al && (fo || (fo = document.getElementById("leva__root") || Object.assign(document.createElement("div"), {
            id: "leva__root"
        }), document.body && (document.body.appendChild(fo), qx(j.createElement(ym, {
            isRoot: !0
        }), fo))), Al = !0)
    }, [t])
}

function BD(t, e, n, r, i) {
    let o, s, a, l, c;
    return typeof t == "string" ? (s = t, o = e, Array.isArray(n) ? c = n : n && ("store" in n ? (l = n, c = r) : (a = n, Array.isArray(r) ? c = r : (l = r, c = i)))) : (o = t, Array.isArray(e) ? c = e : (l = e, c = n)), {
        schema: o,
        folderName: s,
        folderSettings: a,
        hookSettings: l,
        deps: c || []
    }
}

function un(t, e, n, r, i) {
    const {
        folderName: o,
        schema: s,
        folderSettings: a,
        hookSettings: l,
        deps: c
    } = BD(t, e, n, r, i), d = typeof s == "function", f = u.useRef(!1), h = u.useRef(!0), p = lm(() => {
        f.current = !0;
        const ee = typeof s == "function" ? s() : s;
        return o ? {
            [o]: at(ee, a)
        } : ee
    }, c), m = !(l != null && l.store);
    ID(m);
    const [g] = u.useState(() => (l == null ? void 0 : l.store) || hm), [y, x] = u.useMemo(() => g.getDataFromSchema(p), [g, p]), [w, M, T, O, R] = u.useMemo(() => {
        const ee = [],
            V = [],
            I = {},
            X = {},
            q = {};
        return Object.values(x).forEach(({
            path: Z,
            onChange: le,
            onEditStart: Se,
            onEditEnd: Me,
            transient: z
        }) => {
            ee.push(Z), le ? (I[Z] = le, z || V.push(Z)) : V.push(Z), Se && (X[Z] = Se), Me && (q[Z] = Me)
        }), [ee, V, I, X, q]
    }, [x]), P = u.useMemo(() => g.orderPaths(w), [w, g]), B = g_(g, M, y), te = u.useCallback(ee => {
        const V = Object.entries(ee).reduce((I, [X, q]) => Object.assign(I, {
            [x[X].path]: q
        }), {});
        g.set(V, !1)
    }, [g, x]), W = u.useCallback(ee => g.get(x[ee].path), [g, x]);
    return u.useEffect(() => {
        const ee = !h.current && f.current;
        return g.addData(y, ee), h.current = !1, f.current = !1, () => g.disposePaths(P)
    }, [g, P, y]), u.useEffect(() => {
        const ee = [];
        return Object.entries(T).forEach(([V, I]) => {
            I(g.get(V), V, ft({
                initial: !0,
                get: g.get
            }, g.getInput(V)));
            const X = g.useStore.subscribe(q => {
                const Z = q.data[V];
                return [Z.disabled ? void 0 : Z.value, Z]
            }, ([q, Z]) => I(q, V, ft({
                initial: !1,
                get: g.get
            }, Z)), {
                equalityFn: ga
            });
            ee.push(X)
        }), () => ee.forEach(V => V())
    }, [g, T]), u.useEffect(() => {
        const ee = [];
        return Object.entries(O).forEach(([V, I]) => ee.push(g.subscribeToEditStart(V, I))), Object.entries(R).forEach(([V, I]) => ee.push(g.subscribeToEditEnd(V, I))), () => ee.forEach(V => V())
    }, [O, R, g]), d ? [B, te, W] : B
}
ji(ti.SELECT, Bb);
ji(ti.IMAGE, q_);
ji(ti.NUMBER, $b);
ji(ti.COLOR, T_);
ji(ti.STRING, Kb);
ji(ti.BOOLEAN, rw);
ji(ti.INTERVAL, iD);
ji(ti.VECTOR3D, R_);
ji(ti.VECTOR2D, L_);
var xm = Symbol.for("immer-nothing"),
    Mp = Symbol.for("immer-draftable"),
    Rr = Symbol.for("immer-state");

function Jr(t, ...e) {
    throw new Error(`[Immer] minified error nr: ${t}. Full error at: https://bit.ly/3cXEKWf`)
}
var ss = Object.getPrototypeOf;

function as(t) {
    return !!t && !!t[Rr]
}

function So(t) {
    var e;
    return t ? bm(t) || Array.isArray(t) || !!t[Mp] || !!((e = t.constructor) != null && e[Mp]) || ic(t) || oc(t) : !1
}
var WD = Object.prototype.constructor.toString();

function bm(t) {
    if (!t || typeof t != "object") return !1;
    const e = ss(t);
    if (e === null) return !0;
    const n = Object.hasOwnProperty.call(e, "constructor") && e.constructor;
    return n === Object ? !0 : typeof n == "function" && Function.toString.call(n) === WD
}

function oa(t, e) {
    rc(t) === 0 ? Object.entries(t).forEach(([n, r]) => {
        e(n, r, t)
    }) : t.forEach((n, r) => e(r, n, t))
}

function rc(t) {
    const e = t[Rr];
    return e ? e.type_ : Array.isArray(t) ? 1 : ic(t) ? 2 : oc(t) ? 3 : 0
}

function _u(t, e) {
    return rc(t) === 2 ? t.has(e) : Object.prototype.hasOwnProperty.call(t, e)
}

function wm(t, e, n) {
    const r = rc(t);
    r === 2 ? t.set(e, n) : r === 3 ? t.add(n) : t[e] = n
}

function VD(t, e) {
    return t === e ? t !== 0 || 1 / t === 1 / e : t !== t && e !== e
}

function ic(t) {
    return t instanceof Map
}

function oc(t) {
    return t instanceof Set
}

function lo(t) {
    return t.copy_ || t.base_
}

function Du(t, e) {
    if (ic(t)) return new Map(t);
    if (oc(t)) return new Set(t);
    if (Array.isArray(t)) return Array.prototype.slice.call(t);
    if (!e && bm(t)) return ss(t) ? { ...t
    } : Object.assign(Object.create(null), t);
    const n = Object.getOwnPropertyDescriptors(t);
    delete n[Rr];
    let r = Reflect.ownKeys(n);
    for (let i = 0; i < r.length; i++) {
        const o = r[i],
            s = n[o];
        s.writable === !1 && (s.writable = !0, s.configurable = !0), (s.get || s.set) && (n[o] = {
            configurable: !0,
            writable: !0,
            enumerable: s.enumerable,
            value: t[o]
        })
    }
    return Object.create(ss(t), n)
}

function Nf(t, e = !1) {
    return sc(t) || as(t) || !So(t) || (rc(t) > 1 && (t.set = t.add = t.clear = t.delete = UD), Object.freeze(t), e && oa(t, (n, r) => Nf(r, !0))), t
}

function UD() {
    Jr(2)
}

function sc(t) {
    return Object.isFrozen(t)
}
var HD = {};

function Co(t) {
    const e = HD[t];
    return e || Jr(0, t), e
}
var sa;

function _m() {
    return sa
}

function GD(t, e) {
    return {
        drafts_: [],
        parent_: t,
        immer_: e,
        canAutoFreeze_: !0,
        unfinalizedDrafts_: 0
    }
}

function $p(t, e) {
    e && (Co("Patches"), t.patches_ = [], t.inversePatches_ = [], t.patchListener_ = e)
}

function Su(t) {
    Cu(t), t.drafts_.forEach(YD), t.drafts_ = null
}

function Cu(t) {
    t === sa && (sa = t.parent_)
}

function Ap(t) {
    return sa = GD(sa, t)
}

function YD(t) {
    const e = t[Rr];
    e.type_ === 0 || e.type_ === 1 ? e.revoke_() : e.revoked_ = !0
}

function Fp(t, e) {
    e.unfinalizedDrafts_ = e.drafts_.length;
    const n = e.drafts_[0];
    return t !== void 0 && t !== n ? (n[Rr].modified_ && (Su(e), Jr(4)), So(t) && (t = Fl(e, t), e.parent_ || kl(e, t)), e.patches_ && Co("Patches").generateReplacementPatches_(n[Rr].base_, t, e.patches_, e.inversePatches_)) : t = Fl(e, n, []), Su(e), e.patches_ && e.patchListener_(e.patches_, e.inversePatches_), t !== xm ? t : void 0
}

function Fl(t, e, n) {
    if (sc(e)) return e;
    const r = e[Rr];
    if (!r) return oa(e, (i, o) => kp(t, r, e, i, o, n)), e;
    if (r.scope_ !== t) return e;
    if (!r.modified_) return kl(t, r.base_, !0), r.base_;
    if (!r.finalized_) {
        r.finalized_ = !0, r.scope_.unfinalizedDrafts_--;
        const i = r.copy_;
        let o = i,
            s = !1;
        r.type_ === 3 && (o = new Set(i), i.clear(), s = !0), oa(o, (a, l) => kp(t, r, i, a, l, n, s)), kl(t, i, !1), n && t.patches_ && Co("Patches").generatePatches_(r, n, t.patches_, t.inversePatches_)
    }
    return r.copy_
}

function kp(t, e, n, r, i, o, s) {
    if (as(i)) {
        const a = o && e && e.type_ !== 3 && !_u(e.assigned_, r) ? o.concat(r) : void 0,
            l = Fl(t, i, a);
        if (wm(n, r, l), as(l)) t.canAutoFreeze_ = !1;
        else return
    } else s && n.add(i);
    if (So(i) && !sc(i)) {
        if (!t.immer_.autoFreeze_ && t.unfinalizedDrafts_ < 1) return;
        Fl(t, i), (!e || !e.scope_.parent_) && kl(t, i)
    }
}

function kl(t, e, n = !1) {
    !t.parent_ && t.immer_.autoFreeze_ && t.canAutoFreeze_ && Nf(e, n)
}

function XD(t, e) {
    const n = Array.isArray(t),
        r = {
            type_: n ? 1 : 0,
            scope_: e ? e.scope_ : _m(),
            modified_: !1,
            finalized_: !1,
            assigned_: {},
            parent_: e,
            base_: t,
            draft_: null,
            copy_: null,
            revoke_: null,
            isManual_: !1
        };
    let i = r,
        o = zf;
    n && (i = [r], o = aa);
    const {
        revoke: s,
        proxy: a
    } = Proxy.revocable(i, o);
    return r.draft_ = a, r.revoke_ = s, a
}
var zf = {
        get(t, e) {
            if (e === Rr) return t;
            const n = lo(t);
            if (!_u(n, e)) return qD(t, n, e);
            const r = n[e];
            return t.finalized_ || !So(r) ? r : r === Mc(t.base_, e) ? ($c(t), t.copy_[e] = Tu(r, t)) : r
        },
        has(t, e) {
            return e in lo(t)
        },
        ownKeys(t) {
            return Reflect.ownKeys(lo(t))
        },
        set(t, e, n) {
            const r = Dm(lo(t), e);
            if (r != null && r.set) return r.set.call(t.draft_, n), !0;
            if (!t.modified_) {
                const i = Mc(lo(t), e),
                    o = i == null ? void 0 : i[Rr];
                if (o && o.base_ === n) return t.copy_[e] = n, t.assigned_[e] = !1, !0;
                if (VD(n, i) && (n !== void 0 || _u(t.base_, e))) return !0;
                $c(t), Eu(t)
            }
            return t.copy_[e] === n && (n !== void 0 || e in t.copy_) || Number.isNaN(n) && Number.isNaN(t.copy_[e]) || (t.copy_[e] = n, t.assigned_[e] = !0), !0
        },
        deleteProperty(t, e) {
            return Mc(t.base_, e) !== void 0 || e in t.base_ ? (t.assigned_[e] = !1, $c(t), Eu(t)) : delete t.assigned_[e], t.copy_ && delete t.copy_[e], !0
        },
        getOwnPropertyDescriptor(t, e) {
            const n = lo(t),
                r = Reflect.getOwnPropertyDescriptor(n, e);
            return r && {
                writable: !0,
                configurable: t.type_ !== 1 || e !== "length",
                enumerable: r.enumerable,
                value: n[e]
            }
        },
        defineProperty() {
            Jr(11)
        },
        getPrototypeOf(t) {
            return ss(t.base_)
        },
        setPrototypeOf() {
            Jr(12)
        }
    },
    aa = {};
oa(zf, (t, e) => {
    aa[t] = function() {
        return arguments[0] = arguments[0][0], e.apply(this, arguments)
    }
});
aa.deleteProperty = function(t, e) {
    return aa.set.call(this, t, e, void 0)
};
aa.set = function(t, e, n) {
    return zf.set.call(this, t[0], e, n, t[0])
};

function Mc(t, e) {
    const n = t[Rr];
    return (n ? lo(n) : t)[e]
}

function qD(t, e, n) {
    var i;
    const r = Dm(e, n);
    return r ? "value" in r ? r.value : (i = r.get) == null ? void 0 : i.call(t.draft_) : void 0
}

function Dm(t, e) {
    if (!(e in t)) return;
    let n = ss(t);
    for (; n;) {
        const r = Object.getOwnPropertyDescriptor(n, e);
        if (r) return r;
        n = ss(n)
    }
}

function Eu(t) {
    t.modified_ || (t.modified_ = !0, t.parent_ && Eu(t.parent_))
}

function $c(t) {
    t.copy_ || (t.copy_ = Du(t.base_, t.scope_.immer_.useStrictShallowCopy_))
}
var KD = class {
    constructor(t) {
        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.produce = (e, n, r) => {
            if (typeof e == "function" && typeof n != "function") {
                const o = n;
                n = e;
                const s = this;
                return function(l = o, ...c) {
                    return s.produce(l, d => n.call(this, d, ...c))
                }
            }
            typeof n != "function" && Jr(6), r !== void 0 && typeof r != "function" && Jr(7);
            let i;
            if (So(e)) {
                const o = Ap(this),
                    s = Tu(e, void 0);
                let a = !0;
                try {
                    i = n(s), a = !1
                } finally {
                    a ? Su(o) : Cu(o)
                }
                return $p(o, r), Fp(i, o)
            } else if (!e || typeof e != "object") {
                if (i = n(e), i === void 0 && (i = e), i === xm && (i = void 0), this.autoFreeze_ && Nf(i, !0), r) {
                    const o = [],
                        s = [];
                    Co("Patches").generateReplacementPatches_(e, i, o, s), r(o, s)
                }
                return i
            } else Jr(1, e)
        }, this.produceWithPatches = (e, n) => {
            if (typeof e == "function") return (s, ...a) => this.produceWithPatches(s, l => e(l, ...a));
            let r, i;
            return [this.produce(e, n, (s, a) => {
                r = s, i = a
            }), r, i]
        }, typeof(t == null ? void 0 : t.autoFreeze) == "boolean" && this.setAutoFreeze(t.autoFreeze), typeof(t == null ? void 0 : t.useStrictShallowCopy) == "boolean" && this.setUseStrictShallowCopy(t.useStrictShallowCopy)
    }
    createDraft(t) {
        So(t) || Jr(8), as(t) && (t = ZD(t));
        const e = Ap(this),
            n = Tu(t, void 0);
        return n[Rr].isManual_ = !0, Cu(e), n
    }
    finishDraft(t, e) {
        const n = t && t[Rr];
        (!n || !n.isManual_) && Jr(9);
        const {
            scope_: r
        } = n;
        return $p(r, e), Fp(void 0, r)
    }
    setAutoFreeze(t) {
        this.autoFreeze_ = t
    }
    setUseStrictShallowCopy(t) {
        this.useStrictShallowCopy_ = t
    }
    applyPatches(t, e) {
        let n;
        for (n = e.length - 1; n >= 0; n--) {
            const i = e[n];
            if (i.path.length === 0 && i.op === "replace") {
                t = i.value;
                break
            }
        }
        n > -1 && (e = e.slice(n + 1));
        const r = Co("Patches").applyPatches_;
        return as(t) ? r(t, e) : this.produce(t, i => r(i, e))
    }
};

function Tu(t, e) {
    const n = ic(t) ? Co("MapSet").proxyMap_(t, e) : oc(t) ? Co("MapSet").proxySet_(t, e) : XD(t, e);
    return (e ? e.scope_ : _m()).drafts_.push(n), n
}

function ZD(t) {
    return as(t) || Jr(10, t), Sm(t)
}

function Sm(t) {
    if (!So(t) || sc(t)) return t;
    const e = t[Rr];
    let n;
    if (e) {
        if (!e.modified_) return e.base_;
        e.finalized_ = !0, n = Du(t, e.scope_.immer_.useStrictShallowCopy_)
    } else n = Du(t, !0);
    return oa(n, (r, i) => {
        wm(n, r, Sm(i))
    }), e && (e.finalized_ = !1), n
}
var Mr = new KD,
    QD = Mr.produce;
Mr.produceWithPatches.bind(Mr);
Mr.setAutoFreeze.bind(Mr);
Mr.setUseStrictShallowCopy.bind(Mr);
Mr.applyPatches.bind(Mr);
Mr.createDraft.bind(Mr);
Mr.finishDraft.bind(Mr);
const JD = t => (e, n, r) => (r.setState = (i, o, ...s) => {
        const a = typeof i == "function" ? QD(i) : i;
        return e(a, o, ...s)
    }, t(r.setState, n, r)),
    eS = JD,
    tS = t => (e, n, r) => {
        const i = r.subscribe;
        return r.subscribe = (s, a, l) => {
            let c = s;
            if (a) {
                const d = (l == null ? void 0 : l.equalityFn) || Object.is;
                let f = s(r.getState());
                c = h => {
                    const p = s(h);
                    if (!d(f, p)) {
                        const m = f;
                        a(f = p, m)
                    }
                }, l != null && l.fireImmediately && a(f, f)
            }
            return i(c)
        }, t(e, n, r)
    },
    ac = tS,
    If = us(ac(eS(t => ({
        scroll: 0,
        velocity: 0,
        setState: e => t(n => Gt.merge(n, e))
    })))),
    _a = "/",
    nS = `${_a}data/`,
    xs = `${_a}assets/`,
    rS = `${xs}fonts/`,
    Rs = `${xs}sounds/`,
    ln = `${xs}models/`,
    Pu = `${xs}images/`,
    iS = `${xs}videos/`,
    or = `${xs}textures/`,
    oS = "https://www.gstatic.com/draco/v1/decoders/",
    Cm = 7.7 - .1,
    Op = 1920 * 1080,
    Ol = {
        SMALL: "(max-width: 1023px)",
        LARGE: "(min-width: 1024px)"
    };

function sS() {
    return [{
        name: "config",
        type: "json",
        src: `${nS}config.json`
    }, {
        name: "plane.model",
        type: "gltf",
        src: `${ln}surface-plane.glb`
    }, {
        name: "uprising.model",
        type: "gltf",
        src: `${ln}uprising/uprising.glb`
    }, {
        name: "uprising.portal",
        type: "gltf",
        src: `${ln}uprising/uprising-light-reference.gltf`
    }, {
        name: "ufl.model",
        type: "gltf",
        src: `${ln}ufl/ufl.glb`
    }, {
        name: "ufl.portal",
        type: "gltf",
        src: `${ln}ufl/ufl-panels.glb`
    }, {
        name: "boombloom.model",
        type: "gltf",
        src: `${ln}boom-bloom/boombloom.glb`
    }, {
        name: "boombloom.portal",
        type: "gltf",
        src: `${ln}boom-bloom/boombloom-panels.glb`
    }, {
        name: "doublepoint.model",
        type: "gltf",
        src: `${ln}doublepoint/doublepoint.glb`
    }, {
        name: "doublepoint.portal",
        type: "gltf",
        src: `${ln}doublepoint/doublepoint-panels.glb`
    }, {
        name: "seacat.model",
        type: "gltf",
        src: `${ln}seacat/seacat.glb`
    }, {
        name: "seacat.portal",
        type: "gltf",
        src: `${ln}seacat/seacat-panels.glb`
    }, {
        name: "planetfarms.model",
        type: "gltf",
        src: `${ln}planet-farms/planet-farms.glb`
    }, {
        name: "planetfarms.portal",
        type: "gltf",
        src: `${ln}planet-farms/planet-farms-panels.glb`
    }, {
        name: "mariacallas.model",
        type: "gltf",
        src: `${ln}maria-callas/callas.glb`
    }, {
        name: "mariacallas.portal",
        type: "gltf",
        src: `${ln}maria-callas/callas-panels.glb`
    }, {
        name: "oropress.model",
        type: "gltf",
        src: `${ln}oropress/oropress.glb`
    }, {
        name: "oropress.portal",
        type: "gltf",
        src: `${ln}oropress/oropress-panels.glb`
    }, {
        name: "igoodi.model",
        type: "gltf",
        src: `${ln}igoodi/igoodi.glb`
    }, {
        name: "igoodi.portal",
        type: "gltf",
        src: `${ln}igoodi/igoodi-panels.glb`
    }, {
        name: "mausoleum.model",
        type: "gltf",
        src: `${ln}mausoleum/mausoleum.glb`
    }, {
        name: "mausoleum.portal",
        type: "gltf",
        src: `${ln}mausoleum/mausoleum-panels.glb`
    }, {
        name: "underground.model",
        type: "gltf",
        src: `${ln}about/glb/about.glb`
    }, {
        name: "underground-ao",
        type: "texture",
        src: `${ln}about/tex/cube-ao.png`
    }, {
        name: "underground-bump",
        type: "texture",
        src: `${ln}about/tex/cube-height.png`
    }, {
        name: "underground-roughness",
        type: "texture",
        src: `${ln}about/tex/cube-roughness.png`
    }, {
        name: "leaf",
        type: "texture",
        src: `${or}leaf.png`
    }, {
        name: "noise",
        type: "texture",
        src: `${or}noise.png`
    }, {
        name: "normal",
        type: "texture",
        src: `${or}normal-map.jpg`
    }, {
        name: "pattern",
        type: "texture",
        src: `${or}pattern.png`
    }, {
        name: "tech.pattern",
        type: "texture",
        src: `${or}tech-pattern.png`
    }, {
        name: "smoke",
        type: "texture",
        src: `${or}smoke.jpg`
    }, {
        name: "spark",
        type: "texture",
        src: `${or}spark.jpg`
    }, {
        name: "lut.cube",
        type: "lut",
        src: `${or}lut.cube`
    }, {
        name: "cube",
        type: "cube",
        src: [`${or}cube160/px.png`, `${or}cube160/nx.png`, `${or}cube160/py.png`, `${or}cube160/ny.png`, `${or}cube160/pz.png`, `${or}cube160/nz.png`]
    }]
}

function aS() {
    return [{
        name: "ambient",
        type: "audio",
        src: `${Rs}ambient.mp3`
    }, {
        name: "transition",
        type: "audio",
        src: `${Rs}transition.mp3`
    }, {
        name: "cameraTransition",
        type: "audio",
        src: `${Rs}cameraTransition.mp3`
    }, {
        name: "hover",
        type: "audio",
        src: `${Rs}hover.mp3`
    }, {
        name: "underground",
        type: "audio",
        src: `${Rs}underground.mp3`
    }]
}
const jp = (t, e) => t && t.$ref ? { ...Gt.reduce(t.$ref.split("."), (n, r) => n[r], {
            settings: e
        }),
        ...t.extend
    } : t,
    lS = (t, e, n) => t.map(({
        uuid: r,
        contents: i,
        components: o,
        builder: s
    }) => ({
        uuid: r,
        builder: s,
        contents: { ...i,
            ...n.shared
        },
        components: o.map(({
            settings: a,
            modifier: l,
            ...c
        }) => ({ ...c,
            ...jp(a, e),
            ...jp(l, e)
        }))
    })),
    cS = ({
        routes: t,
        scenes: e,
        settings: n,
        locale: r
    }) => ({
        scenes: lS(e, n, r),
        settings: n,
        routes: t,
        locale: r
    });
var Em = {
    exports: {}
};
(function(t) {
    (function() {
        function e(C, L, ce) {
            return C.call.apply(C.bind, arguments)
        }

        function n(C, L, ce) {
            if (!C) throw Error();
            if (2 < arguments.length) {
                var oe = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var ve = Array.prototype.slice.call(arguments);
                    return Array.prototype.unshift.apply(ve, oe), C.apply(L, ve)
                }
            }
            return function() {
                return C.apply(L, arguments)
            }
        }

        function r(C, L, ce) {
            return r = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? e : n, r.apply(null, arguments)
        }
        var i = Date.now || function() {
            return +new Date
        };

        function o(C, L) {
            this.a = C, this.o = L || C, this.c = this.o.document
        }
        var s = !!window.FontFace;

        function a(C, L, ce, oe) {
            if (L = C.c.createElement(L), ce)
                for (var ve in ce) ce.hasOwnProperty(ve) && (ve == "style" ? L.style.cssText = ce[ve] : L.setAttribute(ve, ce[ve]));
            return oe && L.appendChild(C.c.createTextNode(oe)), L
        }

        function l(C, L, ce) {
            C = C.c.getElementsByTagName(L)[0], C || (C = document.documentElement), C.insertBefore(ce, C.lastChild)
        }

        function c(C) {
            C.parentNode && C.parentNode.removeChild(C)
        }

        function d(C, L, ce) {
            L = L || [], ce = ce || [];
            for (var oe = C.className.split(/\s+/), ve = 0; ve < L.length; ve += 1) {
                for (var Ee = !1, Ae = 0; Ae < oe.length; Ae += 1)
                    if (L[ve] === oe[Ae]) {
                        Ee = !0;
                        break
                    }
                Ee || oe.push(L[ve])
            }
            for (L = [], ve = 0; ve < oe.length; ve += 1) {
                for (Ee = !1, Ae = 0; Ae < ce.length; Ae += 1)
                    if (oe[ve] === ce[Ae]) {
                        Ee = !0;
                        break
                    }
                Ee || L.push(oe[ve])
            }
            C.className = L.join(" ").replace(/\s+/g, " ").replace(/^\s+|\s+$/, "")
        }

        function f(C, L) {
            for (var ce = C.className.split(/\s+/), oe = 0, ve = ce.length; oe < ve; oe++)
                if (ce[oe] == L) return !0;
            return !1
        }

        function h(C) {
            return C.o.location.hostname || C.a.location.hostname
        }

        function p(C, L, ce) {
            function oe() {
                Oe && ve && Ee && (Oe(Ae), Oe = null)
            }
            L = a(C, "link", {
                rel: "stylesheet",
                href: L,
                media: "all"
            });
            var ve = !1,
                Ee = !0,
                Ae = null,
                Oe = ce || null;
            s ? (L.onload = function() {
                ve = !0, oe()
            }, L.onerror = function() {
                ve = !0, Ae = Error("Stylesheet failed to load"), oe()
            }) : setTimeout(function() {
                ve = !0, oe()
            }, 0), l(C, "head", L)
        }

        function m(C, L, ce, oe) {
            var ve = C.c.getElementsByTagName("head")[0];
            if (ve) {
                var Ee = a(C, "script", {
                        src: L
                    }),
                    Ae = !1;
                return Ee.onload = Ee.onreadystatechange = function() {
                    Ae || this.readyState && this.readyState != "loaded" && this.readyState != "complete" || (Ae = !0, ce && ce(null), Ee.onload = Ee.onreadystatechange = null, Ee.parentNode.tagName == "HEAD" && ve.removeChild(Ee))
                }, ve.appendChild(Ee), setTimeout(function() {
                    Ae || (Ae = !0, ce && ce(Error("Script load timeout")))
                }, oe || 5e3), Ee
            }
            return null
        }

        function g() {
            this.a = 0, this.c = null
        }

        function y(C) {
            return C.a++,
                function() {
                    C.a--, w(C)
                }
        }

        function x(C, L) {
            C.c = L, w(C)
        }

        function w(C) {
            C.a == 0 && C.c && (C.c(), C.c = null)
        }

        function M(C) {
            this.a = C || "-"
        }
        M.prototype.c = function(C) {
            for (var L = [], ce = 0; ce < arguments.length; ce++) L.push(arguments[ce].replace(/[\W_]+/g, "").toLowerCase());
            return L.join(this.a)
        };

        function T(C, L) {
            this.c = C, this.f = 4, this.a = "n";
            var ce = (L || "n4").match(/^([nio])([1-9])$/i);
            ce && (this.a = ce[1], this.f = parseInt(ce[2], 10))
        }

        function O(C) {
            return B(C) + " " + (C.f + "00") + " 300px " + R(C.c)
        }

        function R(C) {
            var L = [];
            C = C.split(/,\s*/);
            for (var ce = 0; ce < C.length; ce++) {
                var oe = C[ce].replace(/['"]/g, "");
                oe.indexOf(" ") != -1 || /^\d/.test(oe) ? L.push("'" + oe + "'") : L.push(oe)
            }
            return L.join(",")
        }

        function P(C) {
            return C.a + C.f
        }

        function B(C) {
            var L = "normal";
            return C.a === "o" ? L = "oblique" : C.a === "i" && (L = "italic"), L
        }

        function te(C) {
            var L = 4,
                ce = "n",
                oe = null;
            return C && ((oe = C.match(/(normal|oblique|italic)/i)) && oe[1] && (ce = oe[1].substr(0, 1).toLowerCase()), (oe = C.match(/([1-9]00|normal|bold)/i)) && oe[1] && (/bold/i.test(oe[1]) ? L = 7 : /[1-9]00/.test(oe[1]) && (L = parseInt(oe[1].substr(0, 1), 10)))), ce + L
        }

        function W(C, L) {
            this.c = C, this.f = C.o.document.documentElement, this.h = L, this.a = new M("-"), this.j = L.events !== !1, this.g = L.classes !== !1
        }

        function ee(C) {
            C.g && d(C.f, [C.a.c("wf", "loading")]), I(C, "loading")
        }

        function V(C) {
            if (C.g) {
                var L = f(C.f, C.a.c("wf", "active")),
                    ce = [],
                    oe = [C.a.c("wf", "loading")];
                L || ce.push(C.a.c("wf", "inactive")), d(C.f, ce, oe)
            }
            I(C, "inactive")
        }

        function I(C, L, ce) {
            C.j && C.h[L] && (ce ? C.h[L](ce.c, P(ce)) : C.h[L]())
        }

        function X() {
            this.c = {}
        }

        function q(C, L, ce) {
            var oe = [],
                ve;
            for (ve in L)
                if (L.hasOwnProperty(ve)) {
                    var Ee = C.c[ve];
                    Ee && oe.push(Ee(L[ve], ce))
                }
            return oe
        }

        function Z(C, L) {
            this.c = C, this.f = L, this.a = a(this.c, "span", {
                "aria-hidden": "true"
            }, this.f)
        }

        function le(C) {
            l(C.c, "body", C.a)
        }

        function Se(C) {
            return "display:block;position:absolute;top:-9999px;left:-9999px;font-size:300px;width:auto;height:auto;line-height:normal;margin:0;padding:0;font-variant:normal;white-space:nowrap;font-family:" + R(C.c) + ";" + ("font-style:" + B(C) + ";font-weight:" + (C.f + "00") + ";")
        }

        function Me(C, L, ce, oe, ve, Ee) {
            this.g = C, this.j = L, this.a = oe, this.c = ce, this.f = ve || 3e3, this.h = Ee || void 0
        }
        Me.prototype.start = function() {
            var C = this.c.o.document,
                L = this,
                ce = i(),
                oe = new Promise(function(Ae, Oe) {
                    function yt() {
                        i() - ce >= L.f ? Oe() : C.fonts.load(O(L.a), L.h).then(function(St) {
                            1 <= St.length ? Ae() : setTimeout(yt, 25)
                        }, function() {
                            Oe()
                        })
                    }
                    yt()
                }),
                ve = null,
                Ee = new Promise(function(Ae, Oe) {
                    ve = setTimeout(Oe, L.f)
                });
            Promise.race([Ee, oe]).then(function() {
                ve && (clearTimeout(ve), ve = null), L.g(L.a)
            }, function() {
                L.j(L.a)
            })
        };

        function z(C, L, ce, oe, ve, Ee, Ae) {
            this.v = C, this.B = L, this.c = ce, this.a = oe, this.s = Ae || "BESbswy", this.f = {}, this.w = ve || 3e3, this.u = Ee || null, this.m = this.j = this.h = this.g = null, this.g = new Z(this.c, this.s), this.h = new Z(this.c, this.s), this.j = new Z(this.c, this.s), this.m = new Z(this.c, this.s), C = new T(this.a.c + ",serif", P(this.a)), C = Se(C), this.g.a.style.cssText = C, C = new T(this.a.c + ",sans-serif", P(this.a)), C = Se(C), this.h.a.style.cssText = C, C = new T("serif", P(this.a)), C = Se(C), this.j.a.style.cssText = C, C = new T("sans-serif", P(this.a)), C = Se(C), this.m.a.style.cssText = C, le(this.g), le(this.h), le(this.j), le(this.m)
        }
        var ge = {
                D: "serif",
                C: "sans-serif"
            },
            $e = null;

        function Xe() {
            if ($e === null) {
                var C = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent);
                $e = !!C && (536 > parseInt(C[1], 10) || parseInt(C[1], 10) === 536 && 11 >= parseInt(C[2], 10))
            }
            return $e
        }
        z.prototype.start = function() {
            this.f.serif = this.j.a.offsetWidth, this.f["sans-serif"] = this.m.a.offsetWidth, this.A = i(), wt(this)
        };

        function tt(C, L, ce) {
            for (var oe in ge)
                if (ge.hasOwnProperty(oe) && L === C.f[ge[oe]] && ce === C.f[ge[oe]]) return !0;
            return !1
        }

        function wt(C) {
            var L = C.g.a.offsetWidth,
                ce = C.h.a.offsetWidth,
                oe;
            (oe = L === C.f.serif && ce === C.f["sans-serif"]) || (oe = Xe() && tt(C, L, ce)), oe ? i() - C.A >= C.w ? Xe() && tt(C, L, ce) && (C.u === null || C.u.hasOwnProperty(C.a.c)) ? Ye(C, C.v) : Ye(C, C.B) : Ue(C) : Ye(C, C.v)
        }

        function Ue(C) {
            setTimeout(r(function() {
                wt(this)
            }, C), 50)
        }

        function Ye(C, L) {
            setTimeout(r(function() {
                c(this.g.a), c(this.h.a), c(this.j.a), c(this.m.a), L(this.a)
            }, C), 0)
        }

        function Ge(C, L, ce) {
            this.c = C, this.a = L, this.f = 0, this.m = this.j = !1, this.s = ce
        }
        var rt = null;
        Ge.prototype.g = function(C) {
            var L = this.a;
            L.g && d(L.f, [L.a.c("wf", C.c, P(C).toString(), "active")], [L.a.c("wf", C.c, P(C).toString(), "loading"), L.a.c("wf", C.c, P(C).toString(), "inactive")]), I(L, "fontactive", C), this.m = !0, it(this)
        }, Ge.prototype.h = function(C) {
            var L = this.a;
            if (L.g) {
                var ce = f(L.f, L.a.c("wf", C.c, P(C).toString(), "active")),
                    oe = [],
                    ve = [L.a.c("wf", C.c, P(C).toString(), "loading")];
                ce || oe.push(L.a.c("wf", C.c, P(C).toString(), "inactive")), d(L.f, oe, ve)
            }
            I(L, "fontinactive", C), it(this)
        };

        function it(C) {
            --C.f == 0 && C.j && (C.m ? (C = C.a, C.g && d(C.f, [C.a.c("wf", "active")], [C.a.c("wf", "loading"), C.a.c("wf", "inactive")]), I(C, "active")) : V(C.a))
        }

        function lt(C) {
            this.j = C, this.a = new X, this.h = 0, this.f = this.g = !0
        }
        lt.prototype.load = function(C) {
            this.c = new o(this.j, C.context || this.j), this.g = C.events !== !1, this.f = C.classes !== !1, Ne(this, new W(this.c, C), C)
        };

        function Lt(C, L, ce, oe, ve) {
            var Ee = --C.h == 0;
            (C.f || C.g) && setTimeout(function() {
                var Ae = ve || null,
                    Oe = oe || null || {};
                if (ce.length === 0 && Ee) V(L.a);
                else {
                    L.f += ce.length, Ee && (L.j = Ee);
                    var yt, St = [];
                    for (yt = 0; yt < ce.length; yt++) {
                        var ut = ce[yt],
                            Nt = Oe[ut.c],
                            Xt = L.a,
                            Rn = ut;
                        if (Xt.g && d(Xt.f, [Xt.a.c("wf", Rn.c, P(Rn).toString(), "loading")]), I(Xt, "fontloading", Rn), Xt = null, rt === null)
                            if (window.FontFace) {
                                var Rn = /Gecko.*Firefox\/(\d+)/.exec(window.navigator.userAgent),
                                    Ft = /OS X.*Version\/10\..*Safari/.exec(window.navigator.userAgent) && /Apple/.exec(window.navigator.vendor);
                                rt = Rn ? 42 < parseInt(Rn[1], 10) : !Ft
                            } else rt = !1;
                        rt ? Xt = new Me(r(L.g, L), r(L.h, L), L.c, ut, L.s, Nt) : Xt = new z(r(L.g, L), r(L.h, L), L.c, ut, L.s, Ae, Nt), St.push(Xt)
                    }
                    for (yt = 0; yt < St.length; yt++) St[yt].start()
                }
            }, 0)
        }

        function Ne(C, L, ce) {
            var ve = [],
                oe = ce.timeout;
            ee(L);
            var ve = q(C.a, ce, C.c),
                Ee = new Ge(C.c, L, oe);
            for (C.h = ve.length, L = 0, ce = ve.length; L < ce; L++) ve[L].load(function(Ae, Oe, yt) {
                Lt(C, Ee, Ae, Oe, yt)
            })
        }

        function ct(C, L) {
            this.c = C, this.a = L
        }
        ct.prototype.load = function(C) {
            function L() {
                if (Ee["__mti_fntLst" + oe]) {
                    var Ae = Ee["__mti_fntLst" + oe](),
                        Oe = [],
                        yt;
                    if (Ae)
                        for (var St = 0; St < Ae.length; St++) {
                            var ut = Ae[St].fontfamily;
                            Ae[St].fontStyle != null && Ae[St].fontWeight != null ? (yt = Ae[St].fontStyle + Ae[St].fontWeight, Oe.push(new T(ut, yt))) : Oe.push(new T(ut))
                        }
                    C(Oe)
                } else setTimeout(function() {
                    L()
                }, 50)
            }
            var ce = this,
                oe = ce.a.projectId,
                ve = ce.a.version;
            if (oe) {
                var Ee = ce.c.o;
                m(this.c, (ce.a.api || "https://fast.fonts.net/jsapi") + "/" + oe + ".js" + (ve ? "?v=" + ve : ""), function(Ae) {
                    Ae ? C([]) : (Ee["__MonotypeConfiguration__" + oe] = function() {
                        return ce.a
                    }, L())
                }).id = "__MonotypeAPIScript__" + oe
            } else C([])
        };

        function ot(C, L) {
            this.c = C, this.a = L
        }
        ot.prototype.load = function(C) {
            var L, ce, oe = this.a.urls || [],
                ve = this.a.families || [],
                Ee = this.a.testStrings || {},
                Ae = new g;
            for (L = 0, ce = oe.length; L < ce; L++) p(this.c, oe[L], y(Ae));
            var Oe = [];
            for (L = 0, ce = ve.length; L < ce; L++)
                if (oe = ve[L].split(":"), oe[1])
                    for (var yt = oe[1].split(","), St = 0; St < yt.length; St += 1) Oe.push(new T(oe[0], yt[St]));
                else Oe.push(new T(oe[0]));
            x(Ae, function() {
                C(Oe, Ee)
            })
        };

        function gt(C, L) {
            C ? this.c = C : this.c = re, this.a = [], this.f = [], this.g = L || ""
        }
        var re = "https://fonts.googleapis.com/css";

        function pt(C, L) {
            for (var ce = L.length, oe = 0; oe < ce; oe++) {
                var ve = L[oe].split(":");
                ve.length == 3 && C.f.push(ve.pop());
                var Ee = "";
                ve.length == 2 && ve[1] != "" && (Ee = ":"), C.a.push(ve.join(Ee))
            }
        }

        function It(C) {
            if (C.a.length == 0) throw Error("No fonts to load!");
            if (C.c.indexOf("kit=") != -1) return C.c;
            for (var L = C.a.length, ce = [], oe = 0; oe < L; oe++) ce.push(C.a[oe].replace(/ /g, "+"));
            return L = C.c + "?family=" + ce.join("%7C"), 0 < C.f.length && (L += "&subset=" + C.f.join(",")), 0 < C.g.length && (L += "&text=" + encodeURIComponent(C.g)), L
        }

        function At(C) {
            this.f = C, this.a = [], this.c = {}
        }
        var Je = {
                latin: "BESbswy",
                "latin-ext": "çöüğş",
                cyrillic: "йяЖ",
                greek: "αβΣ",
                khmer: "កខគ",
                Hanuman: "កខគ"
            },
            fn = {
                thin: "1",
                extralight: "2",
                "extra-light": "2",
                ultralight: "2",
                "ultra-light": "2",
                light: "3",
                regular: "4",
                book: "4",
                medium: "5",
                "semi-bold": "6",
                semibold: "6",
                "demi-bold": "6",
                demibold: "6",
                bold: "7",
                "extra-bold": "8",
                extrabold: "8",
                "ultra-bold": "8",
                ultrabold: "8",
                black: "9",
                heavy: "9",
                l: "3",
                r: "4",
                b: "7"
            },
            Ce = {
                i: "i",
                italic: "i",
                n: "n",
                normal: "n"
            },
            _e = /^(thin|(?:(?:extra|ultra)-?)?light|regular|book|medium|(?:(?:semi|demi|extra|ultra)-?)?bold|black|heavy|l|r|b|[1-9]00)?(n|i|normal|italic)?$/;

        function Ve(C) {
            for (var L = C.f.length, ce = 0; ce < L; ce++) {
                var oe = C.f[ce].split(":"),
                    ve = oe[0].replace(/\+/g, " "),
                    Ee = ["n4"];
                if (2 <= oe.length) {
                    var Ae, Oe = oe[1];
                    if (Ae = [], Oe)
                        for (var Oe = Oe.split(","), yt = Oe.length, St = 0; St < yt; St++) {
                            var ut;
                            if (ut = Oe[St], ut.match(/^[\w-]+$/)) {
                                var Nt = _e.exec(ut.toLowerCase());
                                if (Nt == null) ut = "";
                                else {
                                    if (ut = Nt[2], ut = ut == null || ut == "" ? "n" : Ce[ut], Nt = Nt[1], Nt == null || Nt == "") Nt = "4";
                                    else var Xt = fn[Nt],
                                        Nt = Xt || (isNaN(Nt) ? "4" : Nt.substr(0, 1));
                                    ut = [ut, Nt].join("")
                                }
                            } else ut = "";
                            ut && Ae.push(ut)
                        }
                    0 < Ae.length && (Ee = Ae), oe.length == 3 && (oe = oe[2], Ae = [], oe = oe ? oe.split(",") : Ae, 0 < oe.length && (oe = Je[oe[0]]) && (C.c[ve] = oe))
                }
                for (C.c[ve] || (oe = Je[ve]) && (C.c[ve] = oe), oe = 0; oe < Ee.length; oe += 1) C.a.push(new T(ve, Ee[oe]))
            }
        }

        function qe(C, L) {
            this.c = C, this.a = L
        }
        var pe = {
            Arimo: !0,
            Cousine: !0,
            Tinos: !0
        };
        qe.prototype.load = function(C) {
            var L = new g,
                ce = this.c,
                oe = new gt(this.a.api, this.a.text),
                ve = this.a.families;
            pt(oe, ve);
            var Ee = new At(ve);
            Ve(Ee), p(ce, It(oe), y(L)), x(L, function() {
                C(Ee.a, Ee.c, pe)
            })
        };

        function Mt(C, L) {
            this.c = C, this.a = L
        }
        Mt.prototype.load = function(C) {
            var L = this.a.id,
                ce = this.c.o;
            L ? m(this.c, (this.a.api || "https://use.typekit.net") + "/" + L + ".js", function(oe) {
                if (oe) C([]);
                else if (ce.Typekit && ce.Typekit.config && ce.Typekit.config.fn) {
                    oe = ce.Typekit.config.fn;
                    for (var ve = [], Ee = 0; Ee < oe.length; Ee += 2)
                        for (var Ae = oe[Ee], Oe = oe[Ee + 1], yt = 0; yt < Oe.length; yt++) ve.push(new T(Ae, Oe[yt]));
                    try {
                        ce.Typekit.load({
                            events: !1,
                            classes: !1,
                            async: !0
                        })
                    } catch {}
                    C(ve)
                }
            }, 2e3) : C([])
        };

        function Bt(C, L) {
            this.c = C, this.f = L, this.a = []
        }
        Bt.prototype.load = function(C) {
            var L = this.f.id,
                ce = this.c.o,
                oe = this;
            L ? (ce.__webfontfontdeckmodule__ || (ce.__webfontfontdeckmodule__ = {}), ce.__webfontfontdeckmodule__[L] = function(ve, Ee) {
                for (var Ae = 0, Oe = Ee.fonts.length; Ae < Oe; ++Ae) {
                    var yt = Ee.fonts[Ae];
                    oe.a.push(new T(yt.name, te("font-weight:" + yt.weight + ";font-style:" + yt.style)))
                }
                C(oe.a)
            }, m(this.c, (this.f.api || "https://f.fontdeck.com/s/css/js/") + h(this.c) + "/" + L + ".js", function(ve) {
                ve && C([])
            })) : C([])
        };
        var vt = new lt(window);
        vt.a.c.custom = function(C, L) {
            return new ot(L, C)
        }, vt.a.c.fontdeck = function(C, L) {
            return new Bt(L, C)
        }, vt.a.c.monotype = function(C, L) {
            return new ct(L, C)
        }, vt.a.c.typekit = function(C, L) {
            return new Mt(L, C)
        }, vt.a.c.google = function(C, L) {
            return new qe(L, C)
        };
        var Yt = {
            load: r(vt.load, vt)
        };
        t.exports ? t.exports = Yt : (window.WebFont = Yt, window.WebFontConfig && vt.load(window.WebFontConfig))
    })()
})(Em);
var uS = Em.exports;
const fS = cs(uS),
    dS = () => new Promise(t => {
        fS.load({
            active: t,
            classes: !1,
            google: {
                families: ["Roboto Condensed:300,400,700"]
            },
            custom: {
                urls: [`${rS}/Matter.css`],
                families: ["Matter"]
            }
        })
    }),
    ko = {
        TEXTURE: "texture",
        JSON: "json",
        GLTF: "gltf",
        CUBE: "cube",
        LUT: "lut"
    },
    Tm = new ey;
Tm.setDecoderPath(oS);
const pS = (t, e) => {
        let n;
        switch (t.type) {
            case ko.TEXTURE:
                n = new ff(e);
                break;
            case ko.JSON:
                n = new Fv(e);
                break;
            case ko.CUBE:
                n = new Av(e);
                break;
            case ko.LUT:
                n = new nv(e);
                break;
            case ko.GLTF:
                n = new ty(e), n.setDRACOLoader(Tm);
                break
        }
        return n
    },
    Gn = us(ac((t, e) => ({
        cache: new Map,
        compiled: !1,
        loading: !1,
        loaded: !1,
        progress: 0,
        complete: () => t({
            compiled: !0
        }),
        compile: () => t({
            progress: 1
        }),
        load: () => new Promise(n => {
            const r = () => {
                const i = new kv;
                i.onStart = () => t({
                    loading: !0
                }), i.onProgress = (o, s, a) => t({
                    progress: s / a * .9
                }), i.onLoad = () => {
                    t({
                        loading: !1,
                        loaded: !0
                    }), n(e().cache)
                }, Gt.forEach(sS(), o => {
                    const s = pS(o, i);
                    s == null || s.load(o.src, a => {
                        const l = ko.JSON === o.type ? cS(JSON.parse(a)) : a;
                        e().cache.set(o.name, l)
                    })
                })
            };
            dS().then(r)
        })
    }))),
    rn = t => Gn.getState().cache.get(t),
    nr = () => rn("config") || {},
    no = t => {
        const {
            scene: e
        } = rn(t);
        return e.children[0]
    },
    Pm = t => no(t).children[0],
    Bn = us(ac(t => ({
        route: {
            index: -1,
            mode: null,
            initial: !1
        },
        leaf: null,
        setCurrentRoute: e => t({
            route: e
        }),
        setCurrentLeaf: e => t({
            leaf: e
        })
    }))),
    Ru = () => Bn.getState().route,
    fi = us(ac(t => ({
        dragState: {},
        moveState: {},
        wheelState: {},
        keysState: {},
        setDragGestureState: e => t(({
            dragState: n
        }) => ({
            dragState: { ...n,
                ...e
            }
        })),
        setMoveGestureState: e => t(({
            moveState: n
        }) => ({
            moveState: { ...n,
                ...e
            }
        })),
        setWheelGestureState: e => t(({
            wheelState: n
        }) => ({
            wheelState: { ...n,
                ...e
            }
        })),
        setKeysGestureState: e => t(({
            keysState: n
        }) => ({
            keysState: { ...n,
                ...e
            }
        }))
    }))),
    hS = us(t => ({
        active: !1,
        setActive: e => t(() => ({
            active: e
        }))
    })),
    Ac = window.DeviceOrientationEvent;
class mS {
    constructor(e) {
        ke(this, "object");
        ke(this, "enabled", !0);
        ke(this, "hasValue", !1);
        ke(this, "deviceOrientation", {});
        ke(this, "screenOrientation", 0);
        ke(this, "alphaOffset", 0);
        ke(this, "zee", new dt(0, 0, 1));
        ke(this, "euler", new Ov);
        ke(this, "q0", new Yo);
        ke(this, "q1", new Yo(-Math.sqrt(.5), 0, 0, Math.sqrt(.5)));
        ke(this, "_onBoundDeviceOrientationChangeEvent");
        ke(this, "_onBoundScreenOrientationChangeEvent");
        this.object = e, this.object.rotation.reorder("YXZ"), this._onBoundDeviceOrientationChangeEvent = this._onDeviceOrientationChangeEvent.bind(this), this._onBoundScreenOrientationChangeEvent = this._onScreenOrientationChangeEvent.bind(this)
    }
    _onDeviceOrientationChangeEvent(e) {
        this.deviceOrientation = e
    }
    _onScreenOrientationChangeEvent() {
        this.screenOrientation = window.orientation || 0
    }
    setObjectQuaternion(e, n, r, i, o) {
        this.euler.set(r, n, -i, "YXZ"), e.setFromEuler(this.euler), e.multiply(this.q1), e.multiply(this.q0.setFromAxisAngle(this.zee, -o))
    }
    connect() {
        this._onBoundScreenOrientationChangeEvent(), Ac !== void 0 && typeof Ac.requestPermission == "function" ? Ac.requestPermission().then(e => {
            e === "granted" && (window.addEventListener("orientationchange", this._onBoundScreenOrientationChangeEvent, !1), window.addEventListener("deviceorientation", this._onBoundDeviceOrientationChangeEvent, !1))
        }).catch(function() {}) : (window.addEventListener("orientationchange", this._onBoundScreenOrientationChangeEvent, !1), window.addEventListener("deviceorientation", this._onBoundDeviceOrientationChangeEvent, !1)), this.enabled = !0
    }
    disconnect() {
        window.removeEventListener("orientationchange", this._onBoundScreenOrientationChangeEvent, !1), window.removeEventListener("deviceorientation", this._onBoundDeviceOrientationChangeEvent, !1), this.enabled = !1
    }
    update() {
        if (this.enabled === !1) return;
        const e = this.deviceOrientation;
        if (e) {
            const n = e.alpha ? He.degToRad(e.alpha) + this.alphaOffset : 0,
                r = e.beta ? He.degToRad(e.beta) : 0,
                i = e.gamma ? He.degToRad(e.gamma) : 0,
                o = this.screenOrientation ? He.degToRad(this.screenOrientation) : 0;
            this.setObjectQuaternion(this.object.quaternion, n, r, i, o), this.hasValue = this.hasValue || e.alpha !== void 0 && e.beta !== void 0 && e.gamma !== void 0
        }
    }
    dispose() {
        this.disconnect()
    }
}

function gS(t) {
    const e = u.useRef(0),
        n = u.useRef(0),
        r = u.useRef(0),
        i = u.useCallback(o => {
            t({
                time: n.current,
                delta: r.current
            }), r.current = o / 1e3 - n.current, n.current = o / 1e3, e.current = requestAnimationFrame(i)
        }, [t]);
    u.useEffect(() => (e.current = requestAnimationFrame(i), () => cancelAnimationFrame(e.current)), [i])
}
const ao = {},
    Ba = (t, e) => {
        if (e && (ao[t] = e), ao[t] !== void 0) return ao[t];
        const n = decodeURI(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURI(t).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
        return n == "0" ? (ao[t] = 0, 0) : n.length && n != "false" ? (ao[t] = n, n) : (ao[t] = location.search.includes(t), ao[t])
    },
    Or = (t, e) => {
        if (!Array.isArray(e)) return !!~t.indexOf(e);
        for (let n = e.length - 1; n >= 0; n--)
            if (~t.indexOf(e[n])) return !0;
        return !1
    },
    An = (t, e) => e.children.find(n => n.name === t),
    Mu = t => t.replace(/\//g, "-").split(".")[0],
    Rm = (t, e, n = 1) => {
        let r = t * n,
            i = e * n;
        if (r * i > Op) {
            const o = r / i;
            i = Math.sqrt(Op / o), r = Math.ceil(i * o), i = Math.ceil(i)
        }
        return {
            width: r,
            height: i
        }
    };

function Lp(t) {
    const e = u.useMemo(() => new Di(window.innerWidth, window.innerHeight, {
            minFilter: Ti,
            magFilter: Ti,
            type: df,
            ...t
        }), [t]),
        n = u.useCallback(() => {
            const {
                width: r,
                height: i
            } = Rm(window.innerWidth, window.innerHeight);
            e.setSize(r, i)
        }, [e]);
    return u.useEffect(() => (window.addEventListener("resize", n), () => {
        window.removeEventListener("resize", n)
    }), [n]), u.useEffect(() => () => e.dispose(), [e]), e
}
let vS = class {
    constructor() {
        let e, n = this;
        this.agent = navigator.userAgent.toLowerCase(), this.detect = function(r) {
            return Or(this.agent, r)
        }, this.touchCapable = !!navigator.maxTouchPoints, this.pixelRatio = window.devicePixelRatio, this.system = {}, this.system.retina = window.devicePixelRatio > 1, this.system.webworker = window.Worker !== void 0, window._NODE_ || (this.system.geolocation = navigator.geolocation !== void 0), window._NODE_ || (this.system.pushstate = window.history.pushState !== void 0), this.system.webcam = !!(navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia), this.system.language = window.navigator.userLanguage || window.navigator.language, this.system.webaudio = window.AudioContext !== void 0, this.system.xr = navigator.getVRDisplays || navigator.xr, this.system.exokit = n.detect("exokit");
        try {
            this.system.localStorage = window.localStorage !== void 0
        } catch {
            this.system.localStorage = !1
        }
        this.system.fullscreen = document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled, this.system.os = n.detect(["exokit"]) && navigator.platform == "linux" ? "magicleap" : n.detect(["ipad", "iphone", "ios"]) || n.detect("mac") && n.touchCapable && Math.max(screen.width, screen.height) < 1370 ? "ios" : n.detect(["android", "kindle"]) ? "android" : n.detect(["blackberry"]) ? "blackberry" : n.detect(["mac os"]) ? "mac" : n.detect(["windows", "iemobile"]) ? "windows" : n.detect(["linux"]) ? "linux" : "unknown", this.system.version = function() {
            try {
                if (n.system.os == "ios") {
                    if (Or(n.agent, "intel mac")) {
                        let s = n.agent.split("version/")[1].split(" ")[0].split(".");
                        return +(s[0] + "." + s[1])
                    }
                    let r = n.agent.split("os ")[1].split("_"),
                        i = r[0],
                        o = r[1].split(" ")[0];
                    return +(i + "." + o)
                }
                if (n.system.os == "android") {
                    let r = n.agent.split("android ")[1].split(";")[0];
                    return r.length > 3 && (r = r.slice(0, -2)), r.charAt(r.length - 1) == "." && (r = r.slice(0, -1)), Number(r)
                }
                if (n.system.os == "windows") return Or(n.agent, "rv:11") ? 11 : Number(n.agent.split("windows phone ")[1].split(";")[0])
            } catch {}
            return -1
        }(), this.system.browser = n.system.os == "ios" ? n.detect(["twitter", "fbios"]) ? "social" : n.detect(["crios"]) ? "chrome" : n.detect(["safari"]) ? "safari" : "unknown" : n.system.os == "android" ? n.detect(["twitter", "fb", "facebook"]) ? "social" : n.detect(["chrome"]) ? "chrome" : n.detect(["firefox"]) ? "firefox" : "browser" : n.detect(["msie"]) || n.detect(["trident"]) && n.detect(["rv:"]) || n.detect(["windows"]) && n.detect(["edge"]) ? "ie" : n.detect(["chrome"]) ? "chrome" : n.detect(["safari"]) ? "safari" : n.detect(["firefox"]) ? "firefox" : "unknown", this.system.browserVersion = function() {
            try {
                if (n.system.browser == "chrome") return Number(n.agent.split("chrome/")[1].split(".")[0]);
                if (n.system.browser == "firefox") return Number(n.agent.split("firefox/")[1].split(".")[0]);
                if (n.system.browser == "safari") return Number(n.agent.split("version/")[1].split(".")[0].split(".")[0]);
                if (n.system.browser == "ie") return n.detect(["msie"]) ? Number(n.agent.split("msie ")[1].split(".")[0]) : n.detect(["rv:"]) ? Number(n.agent.split("rv:")[1].split(".")[0]) : Number(n.agent.split("edge/")[1].split(".")[0])
            } catch {
                return -1
            }
        }(), this.mobile = !(window._NODE_ || !("ontouchstart" in window) && !("onpointerdown" in window) || !Or(n.system.os, ["ios", "android", "magicleap"])) && {}, this.mobile && this.detect(["windows"]) && !this.detect(["touch"]) && (this.mobile = !1), this.mobile && (this.mobile.tablet = Math.max(window.screen ? screen.width : window.innerWidth, window.screen ? screen.height : window.innerHeight) > 1e3, this.mobile.phone = !this.mobile.tablet, this.mobile.pwa = !(!window.matchMedia || !window.matchMedia("(display-mode: standalone)").matches) || !!window.navigator.standalone), this.media = {}, this.media.audio = !!document.createElement("audio").canPlayType && (n.detect(["firefox", "opera"]) ? "ogg" : "mp3"), this.media.video = !!(e = document.createElement("video")).canPlayType && (e.canPlayType("video/webm;") ? "webm" : "mp4"), this.media.webrtc = !!(window.webkitRTCPeerConnection || window.mozRTCPeerConnection || window.msRTCPeerConnection || window.oRTCPeerConnection || window.RTCPeerConnection), this.graphics = {}, this.graphics.webgl = function() {
            let r = !1;
            Object.defineProperty(n.graphics, "webgl", {
                get: () => {
                    if (r) return !1;
                    if (n.graphics._webglContext) return n.graphics._webglContext;
                    try {
                        const i = ["webgl2", "webgl", "experimental-webgl"],
                            o = document.createElement("canvas");
                        let s;
                        for (let c = 0; c < i.length && (s = o.getContext(i[c]), !s); c++);
                        let a = s.getExtension("WEBGL_debug_renderer_info"),
                            l = {};
                        if (a) {
                            let c = a.UNMASKED_RENDERER_WEBGL;
                            l.gpu = s.getParameter(c).toLowerCase()
                        }
                        return l.renderer = s.getParameter(s.RENDERER).toLowerCase(), l.version = s.getParameter(s.VERSION).toLowerCase(), l.glsl = s.getParameter(s.SHADING_LANGUAGE_VERSION).toLowerCase(), l.extensions = s.getSupportedExtensions(), l.webgl2 = Or(l.version, ["webgl 2", "webgl2"]), l.canvas = o, l.context = s, l.detect = function(c) {
                            if (l.gpu && Or(l.gpu.toLowerCase(), c) || l.version && Or(l.version.toLowerCase(), c)) return !0;
                            for (let d = 0; d < l.extensions.length; d++)
                                if (Or(l.extensions[d].toLowerCase(), c)) return !0;
                            return !1
                        }, l.webgl2 || l.detect("instance") || window.AURA || (r = !0), n.graphics._webglContext = l, l
                    } catch {
                        return !1
                    }
                },
                set: i => {
                    i === !1 && (r = !0)
                }
            })
        }(), this.graphics.metal = function() {
            if (!window.Metal) return !1;
            let r = {};
            return r.gpu = Metal.device.getName().toLowerCase(), r.detect = function(i) {
                return Or(r.gpu, i)
            }, r
        }(), this.graphics.gpu = function() {
            if (!n.graphics.webgl && !n.graphics.metal) return !1;
            let r = {};
            return ["metal", "webgl"].forEach(i => {
                n.graphics[i] && !r.identifier && (r.detect = n.graphics[i].detect, r.identifier = n.graphics[i].gpu)
            }), r
        }(), this.graphics.canvas = !!document.createElement("canvas").getContext
    }
};
const {
    pixelRatio: Mm,
    graphics: Jn,
    system: gr,
    mobile: Qn,
    media: yS,
    agent: xS,
    detect: $m
} = new vS;

function lc() {
    return {
        pixelRatio: Mm,
        graphics: Jn,
        system: gr,
        mobile: Qn,
        media: yS,
        agent: xS,
        detect: $m
    }
}
class bS {
    constructor() {
        var e = this,
            n = {};
        for (var r in e.detect = function(i) {
                if (Jn.gpu) return Jn.gpu.detect(i)
            }, e.detectAll = function() {
                if (Jn.gpu) {
                    for (var i = !0, o = 0; o < arguments.length; o++) Jn.gpu.detect(arguments[o]) || (i = !1);
                    return i
                }
            }, e.matchGPU = function(i, o, s = 99999) {
                let a = function(c) {
                    if (n[c]) return n[c];
                    if (!e.detect(c)) return -1;
                    try {
                        var d = Number(e.gpu.split(c)[1].split(" ")[0]);
                        return n[c] = d, d
                    } catch {
                        return -1
                    }
                }(i);
                return a >= o && a < s
            }, e.gpu = Jn.gpu ? Jn.gpu.identifier : "", gr.os == "ios" && e.gpu == "apple gpu" && new wS, e.BLACKLIST = new _S().match(), e.T0 = !(Qn || !e.BLACKLIST && !e.detect("radeon(tm) r5") && !e.detect("hd graphics family") && !e.matchGPU("hd graphics ", 1e3, 5001) && !(e.matchGPU("hd graphics ", 0, 618) && Mm > 1) && !(e.detect(["hd graphics", "iris"]) && Math.max(window.innerWidth, window.innerHeight) > 1800) && e.gpu.toLowerCase() !== "intel iris opengl engine" && !e.matchGPU("iris(tm) graphics ", 1e3)), e.T1 = !(e.BLACKLIST || Qn || e.T0 || !e.matchGPU("iris(tm) graphics ", 540, 1e3) && !e.matchGPU("hd graphics ", 514, 1e3) && e.detect(["nvidia", "amd", "radeon", "geforce"])), e.T2 = !e.BLACKLIST && !Qn && !(!e.detect(["nvidia", "amd", "radeon", "geforce"]) || e.T1 || e.T0), e.T3 = !(e.BLACKLIST || Qn || !e.detect(["titan", "amd radeon pro", "quadro", "radeon(tm) graphics"]) && !e.matchGPU("gtx ", 940) && !e.matchGPU("radeon (tm) rx ", 400) && !e.matchGPU("radeon rx ", 400) && !e.matchGPU("radeon pro ", 420)), e.T4 = !(e.BLACKLIST || Qn || !e.detect(["titan", "quadro", "radeon vii", "vega"]) && !e.matchGPU("gtx ", 1040) && !e.matchGPU("rtx") && !e.matchGPU("radeon rx ", 500)), e.T5 = !(e.BLACKLIST || Qn || !e.detect(["titan", "radeon vii"]) && !e.matchGPU("gtx ", 1080) && !e.matchGPU("rtx ", 2060) && !e.matchGPU("radeon rx ", 5500)), e.MT0 = !!Qn && (!!e.BLACKLIST || !(gr.os != "ios" || !e.detect("a7")) || !(gr.os != "android" || !e.detect("sgx")) || (e.detect("adreno") ? e.matchGPU("adreno (tm) ", 0, 415) : !!e.detect("mali") && e.matchGPU("mali-t", 0, 628))), e.MT1 = !(!Qn || e.BLACKLIST || (gr.os != "ios" || !e.detect(["a8", "a9"])) && (gr.os != "android" || e.MT0)), e.MT2 = function() {
                return !Qn || e.BLACKLIST ? !1 : gr.os == "ios" && e.detect("a10") || e.detect("nvidia tegra") && $m("pixel c") ? !0 : e.detect("mali-g") ? e.matchGPU("mali-g", 73) : e.detect("adreno") && (e.matchGPU("adreno (tm) ", 600, 616) || e.matchGPU("adreno (tm) ", 420)) ? !0 : !!e.detect("mali-g")
            }(), e.MT3 = !!Qn && !e.BLACKLIST && (!(gr.os != "ios" || !e.detect(["a11", "a12"])) || !!e.matchGPU("adreno (tm) ", 530, 600) || (e.detect("mali-g") ? e.matchGPU("mali-g", 71) : !(!Or(navigator.platform.toLowerCase(), ["mac", "windows"]) || gr.browser != "chrome"))), e.MT4 = !!Qn && !e.BLACKLIST && (!(gr.os != "ios" || !e.detect(["a13", "a14", "a15", "a16", "a17", "a18"])) || (e.detect("adreno") ? e.matchGPU("adreno (tm) ", 630) : !(!Or(navigator.platform.toLowerCase(), ["mac", "windows"]) || gr.browser != "chrome"))), e.lt = function(i) {
                return e.TIER > -1 && e.TIER <= i
            }, e.gt = function(i) {
                return e.TIER > -1 && e.TIER >= i
            }, e.eq = function(i) {
                return e.TIER > -1 && e.TIER == i
            }, e.mobileEq = function(i) {
                return e.M_TIER > -1 && e.M_TIER == i
            }, e.mobileLT = function(i) {
                return e.M_TIER > -1 && e.M_TIER <= i
            }, e.mobileGT = function(i) {
                return e.M_TIER > -1 && e.M_TIER >= i
            }, e) r.charAt(0) == "T" && e[r] === !0 && (e.TIER = Number(r.charAt(1))), r.slice(0, 2) == "MT" && e[r] === !0 && (e.M_TIER = Number(r.charAt(2)));
        Ba("gpu") !== !1 && (Qn || Or(Ba("gpu").toString(), "m") ? (e.TIER = -1, e.M_TIER = Number(Ba("gpu").slice(1))) : e.TIER = Number(Ba("gpu"))), e.OVERSIZED = !Qn && e.TIER < 2 && Math.max(window.innerWidth, window.innerHeight) > 1500, gr.browser == "ie" && (e.OVERSIZED = !0), e.initialized = !0
    }
}
class wS {
    constructor() {
        let e = Math.min(screen.width, screen.height) + "x" + Math.max(screen.width, screen.height),
            n = this.test();
        switch (e) {
            case "320x480":
                Jn.webgl.gpu = "legacy";
                break;
            case "320x568":
                Jn.webgl.gpu = n <= 400 ? "apple a8" : n <= 500 ? "apple a7" : "legacy";
                break;
            case "375x812":
            case "414x896":
                Jn.webgl.gpu = n <= 160 ? "apple a13" : n <= 180 ? "apple a12" : "apple a11";
                break;
            default:
            case "414x736":
            case "375x667":
            case "768x1024":
                Jn.webgl.gpu = n <= 160 ? "apple a13" : n <= 180 ? "apple a12" : n <= 220 ? "apple a11" : n <= 250 ? "apple a10" : n <= 360 ? "apple a9" : n <= 400 ? "apple a8" : n <= 600 ? "apple a7" : "legacy";
                break;
            case "834x1112":
                Jn.webgl.gpu = n <= 160 ? "apple a13" : n <= 180 ? "apple a12" : n <= 220 ? "apple a11" : "apple a10";
                break;
            case "834x1194":
                Jn.webgl.gpu = "apple a12";
                break;
            case "1024x1366":
                Jn.webgl.gpu = n <= 160 ? "apple a13" : n <= 180 ? "apple a12" : n <= 220 ? "apple a11" : n <= 250 ? "apple a10" : "apple a9"
        }
    }
    test() {
        let e = [];

        function n() {
            return function(s) {
                return r(s).filter(i).pop()
            }(1e11)
        }

        function r(o) {
            var s, a = [],
                l = Math.sqrt(o);
            for (s = 2; s <= l; s++) o % s == 0 && a.push(s);
            return a
        }

        function i(o) {
            return r(o).length === 0
        }
        for (let o = 0; o < 3; o++) {
            let s = performance.now();
            n(), e.push(10 * (performance.now() - s))
        }
        return e.sort((o, s) => o - s), e[0]
    }
}
class _S {
    constructor() {
        return this
    }
    match() {
        return !Jn.gpu || Jn.gpu.detect(["radeon hd 6970m", "radeon hd 6770m", "radeon hd 6490m", "radeon hd 6630m", "radeon hd 6750m", "radeon hd 5750", "radeon hd 5670", "radeon hd 4850", "radeon hd 4870", "radeon hd 4670", "geforce 9400m", "geforce 320m", "geforce 330m", "geforce gt 130", "geforce gt 120", "geforce gtx 285", "geforce 8600", "geforce 9600m", "geforce 9400m", "geforce 8800 gs", "geforce 8800 gt", "quadro fx 5", "quadro fx 4", "radeon hd 2600", "radeon hd 2400", "radeon hd 2600", "radeon r9 200", "mali-4", "mali-3", "mali-2", "google swiftshader", "sgx543", "legacy", "sgx 543"])
    }
}
const la = new bS;

function Np(t) {
    if (la.BLACKLIST) return "F";
    switch (t) {
        case 5:
            return "A++";
        case 4:
            return "A+";
        case 3:
            return "A";
        case 2:
            return "B";
        case 1:
            return "C";
        case 0:
            return "D"
    }
}

function DS() {
    return Np(Qn ? la.M_TIER : la.TIER)
}

function Am() {
    return {
        tier: DS(),
        tierValue: Qn ? la.M_TIER : la.TIER
    }
}

function Da() {
    const {
        tierValue: t
    } = Am(), {
        system: e,
        graphics: n,
        mobile: r
    } = lc(), i = u.useCallback(() => e.os === "ios" && r && r.phone, [e, r]), o = u.useCallback(() => !i(), [i]), s = u.useCallback(() => t > 1, [t]), a = u.useCallback(() => i() ? 1.5 : 1, [i]), l = u.useCallback(() => !i() && n.webgl.webgl2 && t > 1 ? 8 : 0, [n, t, i]);
    return {
        getDPR: a,
        getSamples: l,
        needsWebgl1: i,
        needsPosprocessing: o,
        needsAnimationScrub: s
    }
}
const Hi = window.document,
    zp = typeof Hi.hidden < "u" ? "hidden" : typeof Hi.msHidden < "u" ? "msHidden" : "webkitHidden",
    Ip = typeof Hi.hidden < "u" ? "visibilitychange" : typeof Hi.msHidden < "u" ? "msvisibilitychange" : "webkitvisibilitychange";

function Bf() {
    const [t, e] = u.useState(Hi[zp]);
    return u.useEffect(() => {
        function n() {
            e(Hi[zp])
        }
        return Hi.addEventListener(Ip, n), () => {
            Hi.removeEventListener(Ip, n)
        }
    }, []), t
}
const Wa = {
        PAINT: "paint",
        MOUNT: "mount",
        RENDER: "render",
        DISPOSE: "dispose"
    },
    Va = {
        SUCCESS: "#cbf078",
        WARNING: "#f1b963",
        DANGER: "#e46161",
        INFOS: "#a997df"
    },
    Ua = (t, e, n = !1) => {
        n && console.log(`%c${t}`, `color: #111111; background-color: ${e}; padding: .25em;`)
    };

function bt(t, e = !1) {
    return u.useLayoutEffect(() => {
        Ua(`${t}::${Wa.PAINT}`, Va.INFOS, e)
    }, [t, e]), u.useEffect(() => (Ua(`${t}::${Wa.MOUNT}`, Va.SUCCESS, e), () => {
        Ua(`${t}::${Wa.DISPOSE}`, Va.DANGER, e)
    }), [t, e]), Ua(`${t}::${Wa.RENDER}`, Va.WARNING, e), null
}

function SS() {
    const {
        mobile: t
    } = lc(), [e] = u.useState(() => new Oh), [n] = u.useState(() => new Yo), [r] = u.useState(() => new Yo), [i] = u.useState(() => new Yo), [o] = u.useState(() => new mS(e)), s = u.useRef(!1), a = u.useCallback(() => n, [n]), l = u.useCallback(() => s.current, []), c = u.useCallback(d => {
        t && (o.update(), o.hasValue && (s.current || (s.current = !0, i.copy(e.quaternion), r.copy(e.quaternion)), i.slerp(e.quaternion, d * 2), r.slerp(i, d * 2), n.copy(r).invert().multiply(i)))
    }, [t, e, o, r, i, n]);
    return u.useEffect(() => (o.connect(), () => {
        o.disconnect()
    })), {
        getQuaternion: a,
        hasQuaternion: l,
        update: c
    }
}

function CS() {
    const [t] = u.useState(new pf), e = u.useMemo(() => Sa(), []), n = u.useRef(he.timeline({
        paused: !0,
        onUpdate: () => t.dispatchEvent({
            type: "update"
        })
    })), r = u.useRef({
        fog: {
            near: 0,
            far: 0
        },
        camera: {
            position: {
                x: 0,
                y: 0,
                z: 0
            },
            target: {
                x: 0,
                y: 0,
                z: 0
            }
        },
        portal: {
            emissive: "#ffffff",
            emissiveIntensity: 0
        },
        model: {
            emissive: "#ffffff",
            emissiveIntensity: 0
        }
    }), i = u.useCallback(() => r.current, []), o = u.useCallback(() => n.current.play(), []), s = u.useCallback(() => n.current.isActive(), []), a = u.useCallback(() => {
        const {
            scenes: l,
            settings: c
        } = nr(), d = Gt.find(l[0].components, f => f.name === "BaseModel");
        n.current.add(he.timeline({
            defaults: {
                duration: 3,
                ease: "power2.out"
            }
        }).fromTo(r.current.camera.position, {
            x: -3,
            y: 0,
            z: 2
        }, {
            x: e.x,
            y: 0,
            z: e.z
        }).fromTo(r.current.camera.target, {
            x: 0,
            y: 0,
            z: 0
        }, {
            x: 0,
            y: 0,
            z: 0
        }, "<")).add(he.timeline({
            defaults: {
                duration: 3,
                ease: "power2.out"
            }
        }).fromTo(r.current.fog, {
            near: 0
        }, {
            near: 1
        }).fromTo(r.current.fog, {
            far: 0
        }, {
            far: 1
        }, "<"), "<").add(he.fromTo(r.current.portal, {
            emissive: "#ffffff",
            emissiveIntensity: 2.8
        }, {
            emissive: c.portal.emissive,
            emissiveIntensity: c.portal.emissiveIntensity,
            ease: "power2.out",
            duration: 3
        }), "<").add(he.fromTo(r.current.model, {
            emissive: "#ffffff",
            emissiveIntensity: 3.35
        }, {
            emissive: d.emissive,
            emissiveIntensity: d.emissiveIntensity,
            ease: "power2.out",
            duration: 3
        }), "<").call(() => t.dispatchEvent({
            type: "playHeaderTimeline"
        }), [], "<+1.2").call(() => t.dispatchEvent({
            type: "playFooterTimeline"
        }), [], "<+.2").call(() => t.dispatchEvent({
            type: "playLandingTimeline"
        }), [], "<+.2")
    }, [t, e]);
    return {
        observer: t,
        isAnimating: s,
        create: a,
        play: o,
        get: i
    }
}

function ES() {
    const [t] = u.useState(new pf), e = u.useRef(he.timeline({
        paused: !0,
        data: {
            uuid: void 0
        },
        onUpdate: function() {
            t.dispatchEvent({
                type: "update",
                uuid: this.data.uuid
            })
        }
    })), n = u.useRef({
        camera: {
            x: 0,
            y: 0,
            z: 0
        },
        portal: {
            emissive: 0,
            particles: {
                reveal: 0
            }
        },
        effects: {
            colorCorrection: {
                hue: 0
            }
        }
    }), r = u.useCallback(() => n.current, []), i = u.useCallback(a => {
        e.current.data.uuid = a, e.current.restart()
    }, []), o = u.useCallback(() => e.current.isActive(), []), s = u.useCallback(() => {
        const {
            settings: a
        } = nr();
        e.current.add(he.to(n.current.camera, {
            motionPath: {
                fromCurrent: !1,
                path: [{
                    z: 0
                }, {
                    z: -.15
                }, {
                    z: 0
                }]
            },
            ease: "power3.out",
            duration: 3
        })).add(he.timeline().to(n.current.portal.particles, {
            reveal: 3.5,
            duration: 6,
            ease: "power3.out"
        }).to(n.current.portal, {
            motionPath: {
                fromCurrent: !1,
                path: [{
                    emissive: a.portal.emissiveIntensity
                }, {
                    emissive: a.portal.emissiveIntensity + .5
                }, {
                    emissive: a.portal.emissiveIntensity
                }]
            },
            ease: "power3.out",
            duration: 3
        }, "<"), "<")
    }, []);
    return {
        observer: t,
        isAnimating: o,
        create: s,
        play: i,
        get: r
    }
}
const Fm = u.createContext(void 0),
    TS = ({
        children: t
    }) => {
        const e = CS(),
            n = ES();
        u.useLayoutEffect(() => {
            const i = Gn.subscribe(o => o.compiled, () => {
                e.create(), n.create()
            });
            return () => {
                i()
            }
        }, [e, n]), u.useEffect(() => {
            const i = Gn.subscribe(o => o.compiled, () => {
                e.observer.dispatchEvent({
                    type: "update"
                }), e.play()
            });
            return () => {
                i()
            }
        }, [e]), u.useEffect(() => {
            const i = o => {
                n.play(o.detail.uuid)
            };
            return document.addEventListener("hover", i), () => {
                document.removeEventListener("hover", i)
            }
        }, [n]);
        const r = u.useMemo(() => ({
            intro: e,
            hover: n
        }), [e, n]);
        return bt("IntroAnimationProvider"), v.jsx(Fm.Provider, {
            value: r,
            children: t
        })
    },
    cc = () => {
        const t = u.useContext(Fm);
        if (t === void 0) throw new Error("useAnimations must be used within a AnimationsProvider");
        return t
    };

function Wf(t) {
    const {
        intro: e
    } = cc(), n = u.useCallback(() => t(e.get()), [e, t]);
    u.useEffect(() => (e.observer.addEventListener("update", n), () => {
        e.observer.removeEventListener("update", n)
    }), [e, n])
}

function Vf(t) {
    const {
        hover: e
    } = cc(), n = u.useCallback(r => t(e.get(), r), [e, t]);
    u.useEffect(() => (e.observer.addEventListener("update", n), () => {
        e.observer.removeEventListener("update", n)
    }), [e, n])
}

function Uf(t, e) {
    const {
        intro: n
    } = cc(), r = u.useCallback(e, [e]);
    u.useEffect(() => (n.observer.addEventListener(t, r), () => {
        n.observer.removeEventListener(t, r)
    }), [n, t, r])
}

function PS(t) {
    Uf("playHeaderTimeline", t)
}

function RS(t) {
    Uf("playFooterTimeline", t)
}

function MS(t) {
    Uf("playLandingTimeline", t)
}
const $u = () => window.innerWidth < 768 ? new dt(0, -.25, 0) : new dt,
    Sa = () => new dt(0, 0, 4.3).add($u()),
    Hf = t => He.mapLinear(He.clamp(Math.abs(t), -$u().y, 1), -$u().y, 1, 0, 1),
    uc = t => He.clamp(Math.abs(t), 1.8, 2.4),
    $S = ({
        mobile: t,
        desktop: e
    }) => {
        const n = [t[0], e[0]],
            r = [t[1], e[1]],
            i = Math.min(Math.max(window.innerWidth, r[0]), r[1]),
            o = r[1] - r[0],
            s = n[1] - n[0],
            a = (i - r[0]) / o * s;
        return Math.round(n[0] + a)
    },
    AS = ({
        fov: t,
        far: e,
        near: n
    }) => {
        const r = SS(),
            i = u.useMemo(() => Sa(), []),
            o = u.useMemo(() => new dt(0, i.y, 0), [i.y]),
            [s] = u.useState(() => new Yo(0, 0, 0, .5)),
            [a] = u.useState(() => new dt(0, 0, 0)),
            [l] = u.useState(() => new dt(0, 0, 0)),
            [c] = u.useState(() => new dt(0, 0, 0)),
            [d] = u.useState(() => new dt(0, 1, 0)),
            [f] = u.useState(() => new dt(0, 1, 0)),
            h = Gn(g => g.compiled),
            p = Gr(),
            m = cc();
        return hr(({
            camera: g
        }) => {
            const y = g;
            return y.position.copy(i), y.near = n, y.far = e, y.fov = $S(t), y.updateProjectionMatrix(), y
        }), kn(({
            camera: g
        }, y) => {
            const x = m.intro.get(),
                w = m.hover.get(),
                M = p.leafMotionValue.get(),
                T = p.cameraMotionValue.get(),
                O = p.motionValue.getVelocity() * .2,
                R = p.cameraMotionValue.getVelocity() * .1,
                P = He.clamp(Math.abs(O + R), 0, .5);
            d.setX(1 - M), a.setX(He.lerp(a.x, l.x * d.x, y * 2)), a.setY(He.lerp(a.y, l.y * d.x, y * 2)), o.setX(x.camera.target.x), o.setY(x.camera.target.y + T * .9 + M), c.setZ(He.lerp(c.z, P, y * 2)), g.position.setX(x.camera.position.x + a.x), g.position.setY(x.camera.position.y + a.y + T + M), g.position.setZ(x.camera.position.z + w.camera.z + c.z - T * .2);
            const B = f.multiply(d);
            g.up.lerp(B, y), g.lookAt(o), r.update(y), r.hasQuaternion() && !m.intro.isAnimating() && g.quaternion.premultiply(s).multiply(r.getQuaternion())
        }), u.useEffect(() => {
            const g = fi.subscribe(y => y.moveState, y => {
                const x = y.xy ? y.xy[0] : window.innerWidth / 2,
                    w = y.xy ? y.xy[1] : window.innerHeight / 2,
                    M = x / window.innerWidth * 2 - 1,
                    T = -(w / window.innerHeight) * 2 + 1;
                f.set(h ? He.clamp(l.x - M, -.3, .3) : 0, 1, 0), l.set(M, T * .2, 0)
            }, {
                fireImmediately: !0
            });
            return () => {
                g()
            }
        }, [h, l, f]), bt("Camera"), v.jsx(v.Fragment, {})
    },
    FS = t => {
        const n = hr(({
                camera: i
            }) => i),
            r = Sa();
        return un("Camera", {
            near: {
                value: t.near,
                min: 0,
                max: 1,
                onChange: i => {
                    n.near = i, n.updateProjectionMatrix()
                }
            },
            far: {
                value: t.far,
                min: 0,
                max: 10,
                onChange: i => {
                    n.far = i, n.updateProjectionMatrix()
                }
            },
            Position: at({
                x: {
                    value: r.x,
                    min: -5,
                    max: 5,
                    onChange: i => n.position.setX(i)
                },
                y: {
                    value: r.y,
                    step: .01,
                    min: -5,
                    max: 5,
                    onChange: i => n.position.setY(i)
                },
                z: {
                    value: r.z,
                    min: 0,
                    max: 10,
                    onChange: i => n.position.setZ(i)
                }
            })
        }), v.jsx(AS, { ...t
        })
    },
    kS = () => {
        const {
            settings: t
        } = nr();
        return v.jsx(FS, { ...t.camera
        })
    };

function OS(t, e) {
    if (Object.is(t, e)) return !0;
    if (typeof t != "object" || t === null || typeof e != "object" || e === null) return !1;
    if (t instanceof Map && e instanceof Map) {
        if (t.size !== e.size) return !1;
        for (const [r, i] of t)
            if (!Object.is(i, e.get(r))) return !1;
        return !0
    }
    if (t instanceof Set && e instanceof Set) {
        if (t.size !== e.size) return !1;
        for (const r of t)
            if (!e.has(r)) return !1;
        return !0
    }
    const n = Object.keys(t);
    if (n.length !== Object.keys(e).length) return !1;
    for (let r = 0; r < n.length; r++)
        if (!Object.prototype.hasOwnProperty.call(e, n[r]) || !Object.is(t[n[r]], e[n[r]])) return !1;
    return !0
}
const km = u.createContext(void 0),
    jS = ({
        children: t
    }) => {
        const e = u.useRef([]),
            n = u.useRef(0),
            r = u.useRef(0),
            i = kc(0),
            o = u.useRef(0),
            s = u.useRef(0),
            a = u.useMemo(() => Sa(), []),
            l = kc(a.y),
            c = kc(0),
            d = u.useCallback(() => o.current, []),
            f = u.useCallback(() => s.current, []),
            h = u.useCallback((T, O) => T === 0 && O === e.current.length - 3 ? 1 : T === e.current.length - 3 && O === 0 ? -1 : Math.sign(T - O), []),
            p = u.useCallback(() => {
                const T = e.current.length - 1;
                return n.current === T || r.current === T
            }, []),
            m = u.useCallback(() => {
                const T = e.current.length - 2;
                return n.current === T || r.current === T
            }, []),
            g = u.useCallback(T => {
                const O = e.current.length - 2,
                    R = T % O;
                return R >= 0 ? R : R + O
            }, []),
            y = u.useCallback(T => {
                const O = Math.ceil(T);
                return m() || p() ? s.current > 0 ? r.current : n.current : g(O)
            }, [g, m, p]),
            x = u.useCallback(T => {
                const O = Math.floor(T);
                return m() || p() ? s.current > 0 ? n.current : r.current : g(O)
            }, [g, m, p]);
        u.useEffect(() => {
            const T = fi.subscribe(O => O.wheelState, O => {
                Gn.getState().compiled && (i.isAnimating() || m() || p() || i.dispatchEvent({
                    type: "change",
                    direction: O.direction[1]
                }))
            });
            return () => {
                T()
            }
        }, [i, m, p]), u.useEffect(() => {
            let T = 0,
                O = 0;
            const R = fi.subscribe(P => P.dragState, P => {
                if (Gn.getState().compiled && !(P.distance[0] < 10 || m() || p()))
                    if (T = Math.sign(P.movement[0]) < 0 ? 1 : -1, T !== s.current && (s.current = T), P.direction[0] !== 0 && (O = -P.direction[0]), P.last) P.elapsedTime > 300 && Math.abs(P.movement[0]) < window.innerWidth / 4 ? i.to(o.current, {
                        duration: .6,
                        ease: "power2.out"
                    }) : (i.dispatchEvent({
                        type: "change",
                        direction: O
                    }), T = 0);
                    else {
                        const B = -P.movement[0] / window.innerWidth,
                            te = o.current + B;
                        i.to(te, {
                            duration: .6,
                            ease: "power2.out"
                        })
                    }
            });
            return () => {
                R()
            }
        }, [i, m, p]), u.useEffect(() => {
            const T = fi.subscribe(O => O.keysState, O => {
                if (Gn.getState().compiled && !(i.isAnimating() || m() || p()) && (O.key === "ArrowLeft" || O.key === "ArrowRight" || O.key === "ArrowUp" || O.key === "ArrowDown")) {
                    const R = O.key === "ArrowLeft" || O.key === "ArrowUp" ? -1 : O.key === "ArrowRight" || O.key === "ArrowDown" ? 1 : 0;
                    i.dispatchEvent({
                        type: "change",
                        direction: R
                    })
                }
            });
            return () => {
                T()
            }
        }, [i, m, p]), u.useEffect(() => {
            const T = Bn.subscribe(O => [O.route, O.leaf], ([O, R], [P, B]) => {
                const te = e.current.length - 1;
                if (n.current = R ? te : O.index, r.current = B ? te : P.index, s.current = h(n.current, r.current), n.current !== r.current) {
                    if (O.initial && !(R || B)) m() ? l.set(-1) : (o.current = n.current, i.set(n.current));
                    else if (n.current > -1)
                        if (m()) {
                            if (B) {
                                r.current = n.current, n.current = o.current, c.set(0), l.set(-1), l.dispatchEvent({
                                    type: "start",
                                    value: r.current,
                                    previous: n.current,
                                    direction: 1
                                }), l.dispatchEvent({
                                    type: "update",
                                    value: -1
                                }), l.dispatchEvent({
                                    type: "complete",
                                    value: r.current,
                                    direction: 1
                                });
                                return
                            }
                            const W = s.current > 0 ? -1 : a.y,
                                ee = s.current > 0 ? 1.8 : uc(l.get());
                            l.to(W, {
                                duration: ee,
                                ease: "expoCurve.inOut",
                                onStart: () => l.dispatchEvent({
                                    type: "start",
                                    value: n.current,
                                    previous: r.current,
                                    direction: s.current
                                }),
                                onComplete: () => {
                                    s.current < 0 && (r.current = n.current), l.dispatchEvent({
                                        type: "complete",
                                        value: n.current,
                                        direction: s.current
                                    })
                                }
                            })
                        } else p() ? (c.to(R ? 1 : 0, {
                            duration: 1.8,
                            ease: "expoCurve.inOut",
                            onStart: () => c.dispatchEvent({
                                type: "start",
                                value: R,
                                direction: s.current
                            }),
                            onComplete: () => {
                                s.current < 0 && (r.current = n.current), c.dispatchEvent({
                                    type: "complete",
                                    value: n.current,
                                    direction: s.current
                                })
                            }
                        }), !R && g(o.current) !== n.current && (o.current = n.current, i.set(n.current), l.dispatchEvent({
                            type: "start",
                            value: n.current,
                            direction: 1
                        }), l.dispatchEvent({
                            type: "update",
                            value: a.y
                        }))) : (o.current += s.current, i.to(o.current, {
                            onStart: () => i.dispatchEvent({
                                type: "start",
                                value: n.current
                            }),
                            onComplete: () => i.dispatchEvent({
                                type: "complete",
                                value: n.current
                            }),
                            ease: "power2.out",
                            duration: 1
                        }))
                }
            }, {
                fireImmediately: !0,
                equalityFn: OS
            });
            return () => {
                T()
            }
        }, [i, c, l, a.y, g, h, m, p]);
        const w = u.useCallback(T => {
            l.isAnimating() || l.set(-1 - T.progress * Cm)
        }, [l]);
        u.useEffect(() => (l.addEventListener("scroll", w), () => {
            l.removeEventListener("scroll", w)
        }), [l, w]), u.useEffect(() => {
            const T = Gn.subscribe(O => O.loaded, O => {
                const {
                    scenes: R
                } = nr();
                O && (e.current = R)
            });
            return () => {
                T()
            }
        }, []);
        const M = u.useMemo(() => ({
            motionValue: i,
            leafMotionValue: c,
            cameraMotionValue: l,
            getDirection: f,
            getCurrentIndex: d,
            getIndexFromValue: g,
            getNextMotionIndex: y,
            getPrevMotionIndex: x,
            needsUnderground: m,
            needsUpperground: p
        }), [i, c, l, f, d, g, y, x, m, p]);
        return bt("TransitionProvider"), v.jsx(km.Provider, {
            value: M,
            children: t
        })
    },
    Gr = () => {
        const t = u.useContext(km);
        if (t === void 0) throw new Error("useTransition must be used within a TransitionProvider");
        return t
    };
/*!
 * VelocityTracker: 3.12.2
 * https://greensock.com
 *
 * Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var ui, Au, Ws, Om, Oo, Wo, Fu, jm, Lm = function() {
        return ui || typeof window < "u" && (ui = window.gsap)
    },
    ku = {},
    LS = function(e) {
        return Math.round(e * 1e4) / 1e4
    },
    Ou = function(e) {
        return jm(e).id
    },
    ks = function(e) {
        return ku[Ou(typeof e == "string" ? Ws(e)[0] : e)]
    },
    Bp = function(e) {
        var n = Oo,
            r;
        if (e - Fu >= .05)
            for (Fu = e; n;) r = n.g(n.t, n.p), (r !== n.v1 || e - n.t1 > .2) && (n.v2 = n.v1, n.v1 = r, n.t2 = n.t1, n.t1 = e), n = n._next
    },
    NS = {
        deg: 360,
        rad: Math.PI * 2
    },
    Fc = function() {
        ui = Lm(), ui && (Ws = ui.utils.toArray, Om = ui.utils.getUnit, jm = ui.core.getCache, Wo = ui.ticker, Au = 1)
    },
    zS = function(e, n, r, i) {
        this.t = e, this.p = n, this.g = e._gsap.get, this.rCap = NS[r || Om(this.g(e, n))], this.v1 = this.v2 = 0, this.t1 = this.t2 = Wo.time, i && (this._next = i, i._prev = this)
    },
    Ca = function() {
        function t(n, r) {
            Au || Fc(), this.target = Ws(n)[0], ku[Ou(this.target)] = this, this._props = {}, r && this.add(r)
        }
        t.register = function(r) {
            ui = r, Fc()
        };
        var e = t.prototype;
        return e.get = function(r, i) {
            var o = this._props[r] || console.warn("Not tracking " + r + " velocity."),
                s, a, l;
            return s = parseFloat(i ? o.v1 : o.g(o.t, o.p)), a = s - parseFloat(o.v2), l = o.rCap, l && (a = a % l, a !== a % (l / 2) && (a = a < 0 ? a + l : a - l)), LS(a / ((i ? o.t1 : Wo.time) - o.t2))
        }, e.getAll = function() {
            var r = {},
                i = this._props,
                o;
            for (o in i) r[o] = this.get(o);
            return r
        }, e.isTracking = function(r) {
            return r in this._props
        }, e.add = function(r, i) {
            r in this._props || (Oo || (Wo.add(Bp), Fu = Wo.time), Oo = this._props[r] = new zS(this.target, r, i, Oo))
        }, e.remove = function(r) {
            var i = this._props[r],
                o, s;
            i && (o = i._prev, s = i._next, o && (o._next = s), s ? s._prev = o : Oo === i && (Wo.remove(Bp), Oo = 0), delete this._props[r])
        }, e.kill = function(r) {
            for (var i in this._props) this.remove(i);
            r || delete ku[Ou(this.target)]
        }, t.track = function(r, i, o) {
            Au || Fc();
            for (var s = [], a = Ws(r), l = i.split(","), c = (o || "").split(","), d = a.length, f, h; d--;) {
                for (f = ks(a[d]) || new t(a[d]), h = l.length; h--;) f.add(l[h], c[h] || c[0]);
                s.push(f)
            }
            return s
        }, t.untrack = function(r, i) {
            var o = (i || "").split(",");
            Ws(r).forEach(function(s) {
                var a = ks(s);
                a && (o.length ? o.forEach(function(l) {
                    return a.remove(l)
                }) : a.kill(1))
            })
        }, t.isTracking = function(r, i) {
            var o = ks(r);
            return o && o.isTracking(i)
        }, t.getVelocity = function(r, i) {
            var o = ks(r);
            return !o || !o.isTracking(i) ? console.warn("Not tracking velocity of " + i) : o.get(i)
        }, t
    }();
Ca.getByTarget = ks;
Lm() && ui.registerPlugin(Ca);
/*!
 * InertiaPlugin 3.12.2
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var $n, Nm, Wp, zm, ju, Vs, Im, Bm, Wm, Gf, Vm, Us, Lu, Um, jl = Ca.getByTarget,
    Hm = function() {
        return $n || typeof window < "u" && ($n = window.gsap) && $n.registerPlugin && $n
    },
    IS = function(e) {
        return typeof e == "string"
    },
    ca = function(e) {
        return typeof e == "number"
    },
    Xi = function(e) {
        return typeof e == "object"
    },
    Nu = function(e) {
        return typeof e == "function"
    },
    BS = 1,
    Gm = Array.isArray,
    WS = function(e) {
        return e
    },
    go = 1e10,
    Vp = 1 / go,
    Ym = .05,
    VS = function(e) {
        return Math.round(e * 1e4) / 1e4
    },
    US = function(e, n, r) {
        for (var i in n) !(i in e) && i !== r && (e[i] = n[i]);
        return e
    },
    HS = function t(e) {
        var n = {},
            r, i;
        for (r in e) n[r] = Xi(i = e[r]) && !Gm(i) ? t(i) : i;
        return n
    },
    Up = function(e, n, r, i, o) {
        var s = n.length,
            a = 0,
            l = go,
            c, d, f, h;
        if (Xi(e)) {
            for (; s--;) {
                c = n[s], d = 0;
                for (f in e) h = c[f] - e[f], d += h * h;
                d < l && (a = s, l = d)
            }
            if ((o || go) < go && o < Math.sqrt(l)) return e
        } else
            for (; s--;) c = n[s], d = c - e, d < 0 && (d = -d), d < l && c >= i && c <= r && (a = s, l = d);
        return n[a]
    },
    Xm = function(e, n, r, i, o, s, a) {
        if (e.end === "auto") return e;
        var l = e.end,
            c, d;
        if (r = isNaN(r) ? go : r, i = isNaN(i) ? -go : i, Xi(n)) {
            if (c = n.calculated ? n : (Nu(l) ? l(n, a) : Up(n, l, r, i, s)) || n, !n.calculated) {
                for (d in c) n[d] = c[d];
                n.calculated = !0
            }
            c = c[o]
        } else c = Nu(l) ? l(n, a) : Gm(l) ? Up(n, l, r, i, s) : parseFloat(l);
        return c > r ? c = r : c < i && (c = i), {
            max: c,
            min: c,
            unitFactor: e.unitFactor
        }
    },
    Ll = function(e, n, r) {
        return isNaN(e[n]) ? r : +e[n]
    },
    Yf = function(e, n) {
        return n * Ym * e / Gf
    },
    Hp = function(e, n, r) {
        return Math.abs((n - e) * Gf / r / Ym)
    },
    qm = {
        resistance: 1,
        checkpoint: 1,
        preventOvershoot: 1,
        linkedProps: 1,
        radius: 1,
        duration: 1
    },
    Km = function(e, n, r, i) {
        if (n.linkedProps) {
            var o = n.linkedProps.split(","),
                s = {},
                a, l, c, d, f, h;
            for (a = 0; a < o.length; a++) l = o[a], c = n[l], c && (ca(c.velocity) ? d = c.velocity : (f = f || jl(e), d = f && f.isTracking(l) ? f.get(l) : 0), h = Math.abs(d / Ll(c, "resistance", i)), s[l] = parseFloat(r(e, l)) + Yf(d, h));
            return s
        }
    },
    GS = function(e, n, r, i, o, s) {
        if (r === void 0 && (r = 10), i === void 0 && (i = .2), o === void 0 && (o = 1), s === void 0 && (s = 0), IS(e) && (e = zm(e)[0]), !e) return 0;
        var a = 0,
            l = go,
            c = n.inertia || n,
            d = Wm(e).get,
            f = Ll(c, "resistance", Vs.resistance),
            h, p, m, g, y, x, w, M, T, O;
        O = Km(e, c, d, f);
        for (h in c) qm[h] || (p = c[h], Xi(p) || (M = M || jl(e), M && M.isTracking(h) ? p = ca(p) ? {
            velocity: p
        } : {
            velocity: M.get(h)
        } : (g = +p || 0, m = Math.abs(g / f))), Xi(p) && (ca(p.velocity) ? g = p.velocity : (M = M || jl(e), g = M && M.isTracking(h) ? M.get(h) : 0), m = Vm(i, r, Math.abs(g / Ll(p, "resistance", f))), y = parseFloat(d(e, h)) || 0, x = y + Yf(g, m), "end" in p && (p = Xm(p, O && h in O ? O : x, p.max, p.min, h, c.radius, g), s && (Us === n && (Us = c = HS(n)), c[h] = US(p, c[h], "end"))), "max" in p && x > +p.max + Vp ? (T = p.unitFactor || Vs.unitFactors[h] || 1, w = y > p.max && p.min !== p.max || g * T > -15 && g * T < 45 ? i + (r - i) * .1 : Hp(y, p.max, g), w + o < l && (l = w + o)) : "min" in p && x < +p.min - Vp && (T = p.unitFactor || Vs.unitFactors[h] || 1, w = y < p.min && p.min !== p.max || g * T > -45 && g * T < 15 ? i + (r - i) * .1 : Hp(y, p.min, g), w + o < l && (l = w + o)), w > a && (a = w)), m > a && (a = m));
        return a > l && (a = l), a > r ? r : a < i ? i : a
    },
    Gp = function() {
        $n = Hm(), $n && (Wp = $n.parseEase, zm = $n.utils.toArray, Im = $n.utils.getUnit, Wm = $n.core.getCache, Vm = $n.utils.clamp, Lu = $n.core.getStyleSaver, Um = $n.core.reverting || function() {}, ju = Wp("power3"), Gf = ju(.05), Bm = $n.core.PropTween, $n.config({
            resistance: 100,
            unitFactors: {
                time: 1e3,
                totalTime: 1e3,
                progress: 1e3,
                totalProgress: 1e3
            }
        }), Vs = $n.config(), $n.registerPlugin(Ca), Nm = 1)
    },
    Ea = {
        version: "3.12.2",
        name: "inertia",
        register: function(e) {
            $n = e, Gp()
        },
        init: function(e, n, r, i, o) {
            Nm || Gp();
            var s = jl(e);
            if (n === "auto") {
                if (!s) {
                    console.warn("No inertia tracking on " + e + ". InertiaPlugin.track(target) first.");
                    return
                }
                n = s.getAll()
            }
            this.styles = Lu && typeof e.style == "object" && Lu(e), this.target = e, this.tween = r, Us = n;
            var a = e._gsap,
                l = a.get,
                c = n.duration,
                d = Xi(c),
                f = n.preventOvershoot || d && c.overshoot === 0,
                h = Ll(n, "resistance", Vs.resistance),
                p = ca(c) ? c : GS(e, n, d && c.max || 10, d && c.min || .2, d && "overshoot" in c ? +c.overshoot : f ? 0 : 1, !0),
                m, g, y, x, w, M, T, O, R;
            n = Us, Us = 0, R = Km(e, n, l, h);
            for (m in n) qm[m] || (g = n[m], Nu(g) && (g = g(i, e, o)), ca(g) ? w = g : Xi(g) && !isNaN(g.velocity) ? w = +g.velocity : s && s.isTracking(m) ? w = s.get(m) : console.warn("ERROR: No velocity was defined for " + e + " property: " + m), M = Yf(w, p), O = 0, y = l(e, m), x = Im(y), y = parseFloat(y), Xi(g) && (T = y + M, "end" in g && (g = Xm(g, R && m in R ? R : T, g.max, g.min, m, n.radius, w)), "max" in g && +g.max < T ? f || g.preventOvershoot ? M = g.max - y : O = g.max - y - M : "min" in g && +g.min > T && (f || g.preventOvershoot ? M = g.min - y : O = g.min - y - M)), this._props.push(m), this.styles && this.styles.save(m), this._pt = new Bm(this._pt, e, m, y, 0, WS, 0, a.set(e, m, this)), this._pt.u = x || 0, this._pt.c1 = M, this._pt.c2 = O);
            return r.duration(p), BS
        },
        render: function(e, n) {
            var r = n._pt;
            if (e = ju(n.tween._time / n.tween._dur), e || !Um())
                for (; r;) r.set(r.t, r.p, VS(r.s + r.c1 * e + r.c2 * e * e) + r.u, r.d, e), r = r._next;
            else n.styles.revert()
        }
    };
"track,untrack,isTracking,getVelocity,getByTarget".split(",").forEach(function(t) {
    return Ea[t] = Ca[t]
});
Hm() && $n.registerPlugin(Ea);
class YS extends pf {
    constructor(n) {
        super();
        ke(this, "motion");
        ke(this, "timeline");
        ke(this, "velocityTracker");
        this.motion = {
            value: n
        }, this.timeline = he.timeline({
            onUpdate: () => this.dispatchEvent({
                type: "update",
                value: this.get()
            })
        }), this.velocityTracker = Ea.track(this.motion, "value")[0]
    }
    to(n, r) {
        return this.timeline.clear().to(this.motion, {
            value: n,
            ...r
        })
    }
    get() {
        return he.getProperty(this.motion, "value")
    }
    set(n) {
        he.set(this.motion, {
            value: n
        })
    }
    getVelocity() {
        return this.velocityTracker.get("value")
    }
    isAnimating() {
        return this.timeline.isActive()
    }
}

function kc(t) {
    u.useMemo(() => he.registerPlugin(Ea), []);
    const [e] = u.useState(new YS(t));
    return e
}
const XS = () => {
        const {
            routes: t
        } = nr(), e = Gr(), n = kh(), r = u.useCallback(i => {
            const o = e.getCurrentIndex() + i.direction,
                s = e.getIndexFromValue(o);
            n(t[s].path, {
                state: {
                    mode: Ig.TRANSITION
                },
                replace: !1
            })
        }, [t, e, n]);
        return u.useEffect(() => (e.motionValue.addEventListener("change", r), () => {
            e.motionValue.removeEventListener("change", r)
        }), [e, r]), null
    },
    qS = () => v.jsx("h1", {
        className: "sr-only",
        children: "About"
    }),
    KS = () => v.jsx("h1", {
        className: "sr-only",
        children: "Home"
    }),
    ZS = () => v.jsx("h1", {
        className: "sr-only",
        children: "Work"
    }),
    Xf = u.forwardRef(({
        children: t,
        className: e,
        ...n
    }, r) => v.jsx("div", {
        ref: r,
        className: Kt("grid grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-x-8 md:gap-x-10 lg:gap-x-12", e),
        ...n,
        children: t
    })),
    ki = u.forwardRef(({
        children: t,
        className: e,
        ...n
    }, r) => v.jsx("div", {
        ref: r,
        className: Kt("container", e),
        ...n,
        children: t
    })),
    Ta = u.forwardRef(({
        children: t,
        className: e,
        ...n
    }, r) => v.jsx("div", {
        ref: r,
        className: Kt("grid gap-x-8 md:gap-x-10 lg:gap-x-12 gap-y-8 grid-rows-4 md:grid-rows-8 pl-[var(--gap)] first:pl-[var(--cp)] last:pr-[var(--cp)] py-[9.6rem] md:py-[10rem]", e),
        ...n,
        children: t
    })),
    QS = () => {
        const t = Am(),
            e = lc(),
            {
                needsWebgl1: n,
                getDPR: r,
                getSamples: i,
                needsPosprocessing: o
            } = Da(),
            {
                visible: s
            } = un("Device", {
                visible: {
                    value: !1,
                    label: "Show specs"
                }
            }),
            a = u.useCallback((l, c) => v.jsxs("li", {
                className: "leading-[2.4rem]",
                children: [v.jsx("span", {
                    className: "text-primary",
                    children: `${l}: `
                }), v.jsx("span", {
                    className: "",
                    children: c
                })]
            }), []);
        return v.jsx("div", {
            className: Kt("fixed top-[2rem] left-[2rem] bottom-[2rem] right-[2rem] bg-black/60 border-white/50 border-[.1rem] backdrop-blur-sm overflow-auto z-50", {
                hidden: !s
            }),
            children: v.jsxs("div", {
                className: "relative p-8 flex flex-col space-y-12",
                children: [v.jsxs("div", {
                    className: "font-condensed flex flex-col space-y-4",
                    children: [v.jsx("h2", {
                        className: "text-[2rem]",
                        children: "Performance Results"
                    }), v.jsxs("ul", {
                        className: "flex flex-col space-y-6",
                        children: [a("User Agent", e.agent), a("WebGL Version", e.graphics._webglContext.version), a("GPU", e.graphics.gpu.identifier), a("GPU Tier", `${t.tier} [${t.tierValue}]`), a("System", e.system.os), a("Browser", e.system.browser), a("Mobile", JSON.stringify(e.mobile)), a("Language", e.system.language.toUpperCase()), a("DPR", e.pixelRatio)]
                    })]
                }), v.jsxs("div", {
                    className: "font-condensed flex flex-col space-y-4",
                    children: [v.jsx("h3", {
                        className: "text-[2rem]",
                        children: "Project-Specific Tests"
                    }), v.jsxs("ul", {
                        className: "flex flex-col space-y-6",
                        children: [a("DPR", `${r()}`), a("Samples", `${i()}`), a("WebGL Version", `${n()?1:2}`), a("Postprocessing", `${o()?"all":"partial"}`)]
                    })]
                })]
            })
        })
    },
    JS = u.forwardRef((t, e) => v.jsxs("svg", {
        ref: e,
        width: "100",
        height: "127",
        viewBox: "0 0 100 127",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: "w-[3rem] h-[3.8rem] md:w-[5rem] md:h-[6.3rem]",
        ...t,
        children: [v.jsx("path", {
            d: "M49.4858 22.5896L36.804 43.3533C36.804 43.3533 62.7044 108.161 63.6661 110.643C65.3548 115.03 64.5272 117.435 62.8609 119.695C62.4472 120.263 61.8097 120.897 61.0828 121.543C53.221 102.371 23.8315 30.6724 22.6013 27.5217C16.171 11.0666 21.7402 0 21.7402 0L0 43.164C0 43.164 26.0234 108.817 26.795 110.643C31.8275 122.578 22.9815 126.241 22.9815 126.241H99.8886L58.2982 28.4012C56.7996 24.8831 53.3328 22.5896 49.4858 22.5896Z",
            fill: "white"
        }), v.jsx("path", {
            d: "M81.1453 32.5985H82.9011V24.1928H85.9988V22.5896H78.0364V24.1928H81.1453V32.5985Z",
            fill: "white"
        }), v.jsx("path", {
            d: "M97.2154 22.5896L94.3636 29.9042L91.5007 22.5896H88.7161V32.5985H90.4719V24.1928H90.5278L93.8492 32.5985H94.8445L98.1995 24.1928H98.2442V32.5985H100V22.5896H97.2154Z",
            fill: "white"
        })]
    })),
    eC = u.forwardRef(({
        onLeafTimelineStart: t,
        onLeafTimelineReverse: e,
        ...n
    }, r) => {
        const {
            scenes: i,
            locale: o
        } = nr(), s = u.useRef(he.timeline({
            paused: !0
        })), a = u.useRef(he.timeline({
            paused: !0,
            onStart: t,
            onReverseComplete: e
        })), l = u.useRef(null), c = wr([l, r]);
        return u.useLayoutEffect(() => {
            const d = he.context(() => {
                s.current.fromTo("[data-gsap-label]", {
                    yPercent: 0
                }, {
                    yPercent: -100,
                    duration: 1.4,
                    ease: "power4.inOut"
                }), a.current.fromTo("[data-gsap-link-line]", {
                    x: 0,
                    scaleX: 1
                }, {
                    x: -20,
                    scaleX: 0,
                    duration: 1,
                    transformOrigin: "left center",
                    ease: "power3.inOut"
                }).fromTo("[data-gsap-link-label]", {
                    yPercent: 0,
                    skewY: 0
                }, {
                    yPercent: 120,
                    skewY: 30,
                    duration: 1,
                    ease: "power3.inOut"
                }, "<+.2")
            }, l.current);
            return () => {
                d.revert()
            }
        }, []), u.useEffect(() => {
            const d = Bn.subscribe(f => f.route, f => {
                s.current.timeScale(f.initial ? 9999 : 1), f.index === i.length - 2 ? s.current.play() : s.current.reverse()
            }, {
                fireImmediately: !0
            });
            return () => {
                d()
            }
        }, [i]), u.useEffect(() => {
            const d = Bn.subscribe(f => f.leaf, f => {
                he.delayedCall(f ? 0 : .6, () => {
                    f ? a.current.play() : a.current.reverse()
                })
            });
            return () => {
                d()
            }
        }, []), v.jsxs("button", {
            ref: c,
            className: "relative block p-[.5rem] -m-[.5rem] group",
            ...n,
            children: [v.jsx("span", {
                className: "relative block overflow-hidden",
                children: v.jsx("span", {
                    className: "relative block overflow-hidden",
                    "data-gsap-link-label": !0,
                    children: v.jsxs("span", {
                        className: "relative block",
                        "data-gsap-label": !0,
                        children: [v.jsx("span", {
                            className: "relative font-condensed text-regular md:text-regular-lg block p-[.1rem]",
                            children: o.header.about
                        }), v.jsx("span", {
                            className: "absolute font-condensed text-regular md:text-regular-lg block top-0 left-0 p-[.1rem] translate-y-full",
                            children: o.header.works
                        })]
                    })
                })
            }), v.jsxs("span", {
                className: "absolute left-[.6rem] right-[.6rem] bottom-[.1rem] md:-bottom-0 h-[.2rem]",
                "data-gsap-link-line": !0,
                children: [v.jsx("span", {
                    className: "absolute top-0 left-0 w-full h-full origin-top-right transition-transform duration-300 ease-out delay-100 bg-white group-hover:delay-0 group-hover:ease-in-out group-hover:translate-x-[1rem] group-hover:scale-x-0"
                }), v.jsx("span", {
                    className: "absolute top-0 left-0 w-full h-full origin-top-left -translate-x-[1rem] scale-x-0 transition-transform duration-300 ease-out bg-white group-hover:ease-in-out group-hover:delay-100 group-hover:translate-x-0 group-hover:scale-100"
                })]
            })]
        })
    }),
    tC = u.forwardRef((t, e) => {
        const n = kh(),
            {
                routes: r
            } = nr(),
            [i, o] = u.useState(!0),
            s = Gn(m => m.compiled),
            a = u.useRef(0),
            l = u.useRef(0),
            c = u.useRef(!1),
            d = u.useRef(he.timeline({
                paused: !0
            })),
            f = u.useRef(null),
            h = wr([f, e]),
            p = () => {
                const m = r.length - 1,
                    g = c.current,
                    y = l.current,
                    w = a.current < m ? m : g ? 0 : y;
                n(r[w].path, {
                    state: {
                        mode: Ig.NAVIGATION
                    }
                })
            };
        return u.useLayoutEffect(() => {
            const m = he.context(() => {
                d.current.add(he.fromTo("[data-gsap-logo]", {
                    x: 20,
                    yPercent: 120,
                    skewY: 40
                }, {
                    x: 0,
                    yPercent: 0,
                    skewY: 0,
                    duration: 1,
                    ease: "power3.out"
                })).add(he.timeline().fromTo("[data-gsap-link-label]", {
                    yPercent: 120,
                    skewY: 30
                }, {
                    yPercent: 0,
                    skewY: 0,
                    duration: 1,
                    ease: "power3.out"
                }).fromTo("[data-gsap-link-line]", {
                    x: -20,
                    scaleX: 0
                }, {
                    x: 0,
                    scaleX: 1,
                    duration: 1,
                    transformOrigin: "left center",
                    ease: "power3.out"
                }, "<+.2"), "<+.3")
            }, f.current);
            return () => {
                m.revert()
            }
        }, []), u.useEffect(() => {
            const m = Bn.subscribe(g => g.route, (g, y) => {
                c.current = g.initial, a.current = g.index, l.current = y.index
            }, {
                fireImmediately: !0
            });
            return () => {
                m()
            }
        }, []), PS(() => {
            d.current.play()
        }), bt("Header"), v.jsx("header", {
            ref: h,
            ...t,
            className: Kt("fixed left-0 top-0 w-full z-20", {
                hidden: !s
            }),
            children: v.jsx(ki, {
                children: v.jsxs("div", {
                    className: "position relative translate-y-[calc(1.9rem+2.5rem)] md:translate-y-[calc(3.2rem+5rem)]",
                    children: [v.jsx("div", {
                        className: "absolute top-0 left-0 -translate-y-1/2 overflow-hidden",
                        children: v.jsx(JS, {
                            "data-gsap-logo": !0
                        })
                    }), v.jsx("div", {
                        className: Kt("absolute top-0 right-0 -translate-y-1/2", {
                            "pointer-events-none": !i
                        }),
                        children: v.jsx(eC, {
                            onLeafTimelineStart: () => o(!1),
                            onLeafTimelineReverse: () => o(!0),
                            onClick: p
                        })
                    })]
                })
            })
        })
    }),
    Zm = u.createContext(void 0),
    nC = ({
        children: t
    }) => {
        const [e] = u.useState(() => new jv), [n] = u.useState(() => new Lv), [r] = u.useState(() => new Map), [i, o] = u.useState(!1), s = u.useMemo(() => -1200, []), a = Bf(), l = Gr(), c = u.useCallback(() => {
            Gt.forEach(aS(), x => {
                e.load(x.src, w => {
                    const M = x.name,
                        T = new Nv(n),
                        O = M === "ambient" || M === "underground",
                        R = 1;
                    T.setVolume(R), T.setBuffer(w), T.setLoop(O), T.userData = {
                        volume: R
                    }, r.set(M, T)
                })
            })
        }, [e, n, r]), d = u.useCallback(x => r.get(x), [r]), f = u.useCallback(x => {
            const w = d(x);
            w && w.pause()
        }, [d]), h = u.useCallback((x, w = !0) => {
            const M = d(x);
            if (M) return w && M.stop(), M.play()
        }, [d]), p = u.useCallback(() => {
            r.forEach(x => {
                x.userData.volume = 0, x.setVolume(0)
            })
        }, [r]), m = u.useCallback(() => {
            r.forEach(x => {
                x.userData.volume = 1, x.setVolume(1)
            })
        }, [r]), g = u.useCallback(() => {
            o(x => !x), i ? m() : p()
        }, [i, p, m]);
        u.useEffect(() => {
            a ? p() : i || m()
        }, [a, i, p, m]), u.useEffect(() => {
            const x = () => {
                    const R = h("ambient");
                    R && (document.removeEventListener("click", x), l.needsUnderground() && R.setDetune(s))
                },
                w = () => {
                    h("hover")
                },
                M = () => {
                    h("transition")
                },
                T = () => {
                    const P = uc(l.cameraMotionValue.get()) - 1.2;
                    he.delayedCall(P, () => {
                        h("cameraTransition")
                    })
                },
                O = R => {
                    const P = s * Hf(R.value),
                        B = d("ambient");
                    B && B.setDetune(P)
                };
            return document.addEventListener("click", x), document.addEventListener("hover", w), l.motionValue.addEventListener("start", M), l.cameraMotionValue.addEventListener("start", T), l.cameraMotionValue.addEventListener("update", O), () => {
                l.cameraMotionValue.removeEventListener("update", O), l.cameraMotionValue.removeEventListener("start", T), l.motionValue.removeEventListener("start", M), document.removeEventListener("click", x), document.removeEventListener("hover", w)
            }
        }, [l, s, d, h]), u.useEffect(() => {
            const x = Gn.subscribe(w => w.loaded, w => w && c());
            return () => {
                x()
            }
        }, [c]);
        const y = u.useMemo(() => ({
            muted: i,
            playSound: h,
            stopSound: f,
            toggleSound: g
        }), [i, h, f, g]);
        return bt("SoundMixerProvider"), v.jsx(Zm.Provider, {
            value: y,
            children: t
        })
    },
    rC = () => {
        const t = u.useContext(Zm);
        if (t === void 0) throw new Error("useSoundMixer must be used within a SoundMixerProvider");
        return t
    },
    iC = {
        h1: "h1",
        h2: "h2",
        h3: "h3",
        p: "p",
        span: "span"
    },
    an = u.forwardRef(({
        children: t,
        className: e,
        variant: n = "span",
        component: r,
        size: i = "regular",
        paragraph: o = !1,
        strong: s = !1,
        ...a
    }, l) => {
        const c = r || (o ? "p" : iC[n]) || "span",
            d = u.useMemo(() => Kt("font-condensed", {
                "text-large md:text-large-lg": i === "large",
                "text-small md:text-small-lg": i === "small",
                "text-regular md:text-regular-lg": i === "regular",
                "font-bold md:font-bold": s
            }), [i, s]),
            f = u.useMemo(() => ({
                h1: Kt("font-heading text-h1 md:text-h1-lg -my-[.1em]", {
                    "font-light md:font-light": s
                }),
                h2: Kt("font-heading text-h2 md:text-h2-lg -my-[.1em]", {
                    "font-normal md:font-normal": s
                }),
                h3: Kt("font-heading text-h3 md:text-h3-lg -my-[.1em]", {
                    "font-normal md:font-normal": s
                }),
                p: d,
                span: d
            }), [s, d]);
        return v.jsx(c, {
            ref: l,
            className: Kt(f[n], e),
            ...a,
            children: t
        })
    });
/*!
 * paths 3.12.2
 * https://greensock.com
 *
 * Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var oC = /[achlmqstvz]|(-?\d*\.?\d*(?:e[\-+]?\d+)?)[0-9]/ig,
    sC = /(?:(-)?\d*\.?\d*(?:e[\-+]?\d+)?)[0-9]/ig,
    aC = /[\+\-]?\d*\.?\d+e[\+\-]?\d+/ig,
    lC = /(^[#\.][a-z]|[a-y][a-z])/i,
    cC = Math.PI / 180,
    uC = 180 / Math.PI,
    Ha = Math.sin,
    Ga = Math.cos,
    Ir = Math.abs,
    wi = Math.sqrt,
    fC = Math.atan2,
    zu = 1e8,
    Yp = function(e) {
        return typeof e == "string"
    },
    Qm = function(e) {
        return typeof e == "number"
    },
    dC = function(e) {
        return typeof e > "u"
    },
    pC = {},
    hC = {},
    Nl = 1e5,
    Jm = function(e) {
        return Math.round((e + zu) % 1 * Nl) / Nl || (e < 0 ? 0 : 1)
    },
    Ht = function(e) {
        return Math.round(e * Nl) / Nl || 0
    },
    Xp = function(e) {
        return Math.round(e * 1e10) / 1e10 || 0
    },
    qp = function(e, n, r, i) {
        var o = e[n],
            s = i === 1 ? 6 : Iu(o, r, i);
        if (s && s + r + 2 < o.length) return e.splice(n, 0, o.slice(0, r + s + 2)), o.splice(0, r + s), 1
    },
    eg = function(e, n, r) {
        var i = e.length,
            o = ~~(r * i);
        if (e[o] > n) {
            for (; --o && e[o] > n;);
            o < 0 && (o = 0)
        } else
            for (; e[++o] < n && o < i;);
        return o < i ? o : i - 1
    },
    mC = function(e, n) {
        var r = e.length;
        for (n || e.reverse(); r--;) e[r].reversed || yC(e[r])
    },
    Kp = function(e, n) {
        return n.totalLength = e.totalLength, e.samples ? (n.samples = e.samples.slice(0), n.lookup = e.lookup.slice(0), n.minLength = e.minLength, n.resolution = e.resolution) : e.totalPoints && (n.totalPoints = e.totalPoints), n
    },
    gC = function(e, n) {
        var r = e.length,
            i = e[r - 1] || [],
            o = i.length;
        r && n[0] === i[o - 2] && n[1] === i[o - 1] && (n = i.concat(n.slice(2)), r--), e[r] = n
    };

function cl(t) {
    t = Yp(t) && lC.test(t) && document.querySelector(t) || t;
    var e = t.getAttribute ? t : 0,
        n;
    return e && (t = t.getAttribute("d")) ? (e._gsPath || (e._gsPath = {}), n = e._gsPath[t], n && !n._dirty ? n : e._gsPath[t] = ua(t)) : t ? Yp(t) ? ua(t) : Qm(t[0]) ? [t] : t : console.warn("Expecting a <path> element or an SVG path data string")
}

function vC(t) {
    for (var e = [], n = 0; n < t.length; n++) e[n] = Kp(t[n], t[n].slice(0));
    return Kp(t, e)
}

function yC(t) {
    var e = 0,
        n;
    for (t.reverse(); e < t.length; e += 2) n = t[e], t[e] = t[e + 1], t[e + 1] = n;
    t.reversed = !t.reversed
}
var xC = function(e, n) {
        var r = document.createElementNS("http://www.w3.org/2000/svg", "path"),
            i = [].slice.call(e.attributes),
            o = i.length,
            s;
        for (n = "," + n + ","; --o > -1;) s = i[o].nodeName.toLowerCase(), n.indexOf("," + s + ",") < 0 && r.setAttributeNS(null, s, i[o].nodeValue);
        return r
    },
    bC = {
        rect: "rx,ry,x,y,width,height",
        circle: "r,cx,cy",
        ellipse: "rx,ry,cx,cy",
        line: "x1,x2,y1,y2"
    },
    wC = function(e, n) {
        for (var r = n ? n.split(",") : [], i = {}, o = r.length; --o > -1;) i[r[o]] = +e.getAttribute(r[o]) || 0;
        return i
    };

function _C(t, e) {
    var n = t.tagName.toLowerCase(),
        r = .552284749831,
        i, o, s, a, l, c, d, f, h, p, m, g, y, x, w, M, T, O, R, P, B, te;
    return n === "path" || !t.getBBox ? t : (c = xC(t, "x,y,width,height,cx,cy,rx,ry,r,x1,x2,y1,y2,points"), te = wC(t, bC[n]), n === "rect" ? (a = te.rx, l = te.ry || a, o = te.x, s = te.y, p = te.width - a * 2, m = te.height - l * 2, a || l ? (g = o + a * (1 - r), y = o + a, x = y + p, w = x + a * r, M = x + a, T = s + l * (1 - r), O = s + l, R = O + m, P = R + l * r, B = R + l, i = "M" + M + "," + O + " V" + R + " C" + [M, P, w, B, x, B, x - (x - y) / 3, B, y + (x - y) / 3, B, y, B, g, B, o, P, o, R, o, R - (R - O) / 3, o, O + (R - O) / 3, o, O, o, T, g, s, y, s, y + (x - y) / 3, s, x - (x - y) / 3, s, x, s, w, s, M, T, M, O].join(",") + "z") : i = "M" + (o + p) + "," + s + " v" + m + " h" + -p + " v" + -m + " h" + p + "z") : n === "circle" || n === "ellipse" ? (n === "circle" ? (a = l = te.r, f = a * r) : (a = te.rx, l = te.ry, f = l * r), o = te.cx, s = te.cy, d = a * r, i = "M" + (o + a) + "," + s + " C" + [o + a, s + f, o + d, s + l, o, s + l, o - d, s + l, o - a, s + f, o - a, s, o - a, s - f, o - d, s - l, o, s - l, o + d, s - l, o + a, s - f, o + a, s].join(",") + "z") : n === "line" ? i = "M" + te.x1 + "," + te.y1 + " L" + te.x2 + "," + te.y2 : (n === "polyline" || n === "polygon") && (h = (t.getAttribute("points") + "").match(sC) || [], o = h.shift(), s = h.shift(), i = "M" + o + "," + s + " L" + h.join(","), n === "polygon" && (i += "," + o + "," + s + "z")), c.setAttribute("d", qf(c._gsRawPath = ua(i))), e && t.parentNode && (t.parentNode.insertBefore(c, t), t.parentNode.removeChild(t)), c)
}

function tg(t, e, n) {
    var r = t[e],
        i = t[e + 2],
        o = t[e + 4],
        s;
    return r += (i - r) * n, i += (o - i) * n, r += (i - r) * n, s = i + (o + (t[e + 6] - o) * n - i) * n - r, r = t[e + 1], i = t[e + 3], o = t[e + 5], r += (i - r) * n, i += (o - i) * n, r += (i - r) * n, Ht(fC(i + (o + (t[e + 7] - o) * n - i) * n - r, s) * uC)
}

function ng(t, e, n) {
    n = dC(n) ? 1 : Xp(n) || 0, e = Xp(e) || 0;
    var r = Math.max(0, ~~(Ir(n - e) - 1e-8)),
        i = vC(t);
    if (e > n && (e = 1 - e, n = 1 - n, mC(i), i.totalLength = 0), e < 0 || n < 0) {
        var o = Math.abs(~~Math.min(e, n)) + 1;
        e += o, n += o
    }
    i.totalLength || vo(i);
    var s = n > 1,
        a = Zp(i, e, pC, !0),
        l = Zp(i, n, hC),
        c = l.segment,
        d = a.segment,
        f = l.segIndex,
        h = a.segIndex,
        p = l.i,
        m = a.i,
        g = h === f,
        y = p === m && g,
        x, w, M, T, O, R, P, B;
    if (s || r) {
        for (x = f < h || g && p < m || y && l.t < a.t, qp(i, h, m, a.t) && (h++, x || (f++, y ? (l.t = (l.t - a.t) / (1 - a.t), p = 0) : g && (p -= m))), Math.abs(1 - (n - e)) < 1e-5 ? f = h - 1 : !l.t && f ? f-- : qp(i, f, p, l.t) && x && h++, a.t === 1 && (h = (h + 1) % i.length), O = [], R = i.length, P = 1 + R * r, B = h, P += (R - h + f) % R, T = 0; T < P; T++) gC(O, i[B++ % R]);
        i = O
    } else if (M = l.t === 1 ? 6 : Iu(c, p, l.t), e !== n)
        for (w = Iu(d, m, y ? a.t / l.t : a.t), g && (M += w), c.splice(p + M + 2), (w || m) && d.splice(0, m + w), T = i.length; T--;)(T < h || T > f) && i.splice(T, 1);
    else c.angle = tg(c, p + M, 0), p += M, a = c[p], l = c[p + 1], c.length = c.totalLength = 0, c.totalPoints = i.totalPoints = 8, c.push(a, l, a, l, a, l, a, l);
    return i.totalLength = 0, i
}

function DC(t, e, n) {
    e = e || 0, t.samples || (t.samples = [], t.lookup = []);
    var r = ~~t.resolution || 12,
        i = 1 / r,
        o = n ? e + n * 6 + 1 : t.length,
        s = t[e],
        a = t[e + 1],
        l = e ? e / 6 * r : 0,
        c = t.samples,
        d = t.lookup,
        f = (e ? t.minLength : zu) || zu,
        h = c[l + n * r - 1],
        p = e ? c[l - 1] : 0,
        m, g, y, x, w, M, T, O, R, P, B, te, W, ee, V, I, X;
    for (c.length = d.length = 0, g = e + 2; g < o; g += 6) {
        if (y = t[g + 4] - s, x = t[g + 2] - s, w = t[g] - s, O = t[g + 5] - a, R = t[g + 3] - a, P = t[g + 1] - a, M = T = B = te = 0, Ir(y) < .01 && Ir(O) < .01 && Ir(w) + Ir(P) < .01) t.length > 8 && (t.splice(g, 6), g -= 6, o -= 6);
        else
            for (m = 1; m <= r; m++) ee = i * m, W = 1 - ee, M = T - (T = (ee * ee * y + 3 * W * (ee * x + W * w)) * ee), B = te - (te = (ee * ee * O + 3 * W * (ee * R + W * P)) * ee), I = wi(B * B + M * M), I < f && (f = I), p += I, c[l++] = p;
        s += y, a += O
    }
    if (h)
        for (h -= p; l < c.length; l++) c[l] += h;
    if (c.length && f) {
        if (t.totalLength = X = c[c.length - 1] || 0, t.minLength = f, X / f < 9999)
            for (I = V = 0, m = 0; m < X; m += f) d[I++] = c[V] < m ? ++V : V
    } else t.totalLength = c[0] = 0;
    return e ? p - c[e / 2 - 1] : p
}

function vo(t, e) {
    var n, r, i;
    for (i = n = r = 0; i < t.length; i++) t[i].resolution = ~~e || 12, r += t[i].length, n += DC(t[i]);
    return t.totalPoints = r, t.totalLength = n, t
}

function Iu(t, e, n) {
    if (n <= 0 || n >= 1) return 0;
    var r = t[e],
        i = t[e + 1],
        o = t[e + 2],
        s = t[e + 3],
        a = t[e + 4],
        l = t[e + 5],
        c = t[e + 6],
        d = t[e + 7],
        f = r + (o - r) * n,
        h = o + (a - o) * n,
        p = i + (s - i) * n,
        m = s + (l - s) * n,
        g = f + (h - f) * n,
        y = p + (m - p) * n,
        x = a + (c - a) * n,
        w = l + (d - l) * n;
    return h += (x - h) * n, m += (w - m) * n, t.splice(e + 2, 4, Ht(f), Ht(p), Ht(g), Ht(y), Ht(g + (h - g) * n), Ht(y + (m - y) * n), Ht(h), Ht(m), Ht(x), Ht(w)), t.samples && t.samples.splice(e / 6 * t.resolution | 0, 0, 0, 0, 0, 0, 0, 0), 6
}

function Zp(t, e, n, r) {
    n = n || {}, t.totalLength || vo(t), (e < 0 || e > 1) && (e = Jm(e));
    var i = 0,
        o = t[0],
        s, a, l, c, d, f, h;
    if (!e) h = f = i = 0, o = t[0];
    else if (e === 1) h = 1, i = t.length - 1, o = t[i], f = o.length - 8;
    else {
        if (t.length > 1) {
            for (l = t.totalLength * e, d = f = 0;
                (d += t[f++].totalLength) < l;) i = f;
            o = t[i], c = d - o.totalLength, e = (l - c) / (d - c) || 0
        }
        s = o.samples, a = o.resolution, l = o.totalLength * e, f = o.lookup.length ? o.lookup[~~(l / o.minLength)] || 0 : eg(s, l, e), c = f ? s[f - 1] : 0, d = s[f], d < l && (c = d, d = s[++f]), h = 1 / a * ((l - c) / (d - c) + f % a), f = ~~(f / a) * 6, r && h === 1 && (f + 6 < o.length ? (f += 6, h = 0) : i + 1 < t.length && (f = h = 0, o = t[++i]))
    }
    return n.t = h, n.i = f, n.path = t, n.segment = o, n.segIndex = i, n
}

function Qp(t, e, n, r) {
    var i = t[0],
        o = r || {},
        s, a, l, c, d, f, h, p, m;
    if ((e < 0 || e > 1) && (e = Jm(e)), i.lookup || vo(t), t.length > 1) {
        for (l = t.totalLength * e, d = f = 0;
            (d += t[f++].totalLength) < l;) i = t[f];
        c = d - i.totalLength, e = (l - c) / (d - c) || 0
    }
    return s = i.samples, a = i.resolution, l = i.totalLength * e, f = i.lookup.length ? i.lookup[e < 1 ? ~~(l / i.minLength) : i.lookup.length - 1] || 0 : eg(s, l, e), c = f ? s[f - 1] : 0, d = s[f], d < l && (c = d, d = s[++f]), h = 1 / a * ((l - c) / (d - c) + f % a) || 0, m = 1 - h, f = ~~(f / a) * 6, p = i[f], o.x = Ht((h * h * (i[f + 6] - p) + 3 * m * (h * (i[f + 4] - p) + m * (i[f + 2] - p))) * h + p), o.y = Ht((h * h * (i[f + 7] - (p = i[f + 1])) + 3 * m * (h * (i[f + 5] - p) + m * (i[f + 3] - p))) * h + p), n && (o.angle = i.totalLength ? tg(i, f, h >= 1 ? 1 - 1e-9 : h || 1e-9) : i.angle || 0), o
}

function Vo(t, e, n, r, i, o, s) {
    for (var a = t.length, l, c, d, f, h; --a > -1;)
        for (l = t[a], c = l.length, d = 0; d < c; d += 2) f = l[d], h = l[d + 1], l[d] = f * e + h * r + o, l[d + 1] = f * n + h * i + s;
    return t._dirty = 1, t
}

function SC(t, e, n, r, i, o, s, a, l) {
    if (!(t === a && e === l)) {
        n = Ir(n), r = Ir(r);
        var c = i % 360 * cC,
            d = Ga(c),
            f = Ha(c),
            h = Math.PI,
            p = h * 2,
            m = (t - a) / 2,
            g = (e - l) / 2,
            y = d * m + f * g,
            x = -f * m + d * g,
            w = y * y,
            M = x * x,
            T = w / (n * n) + M / (r * r);
        T > 1 && (n = wi(T) * n, r = wi(T) * r);
        var O = n * n,
            R = r * r,
            P = (O * R - O * M - R * w) / (O * M + R * w);
        P < 0 && (P = 0);
        var B = (o === s ? -1 : 1) * wi(P),
            te = B * (n * x / r),
            W = B * -(r * y / n),
            ee = (t + a) / 2,
            V = (e + l) / 2,
            I = ee + (d * te - f * W),
            X = V + (f * te + d * W),
            q = (y - te) / n,
            Z = (x - W) / r,
            le = (-y - te) / n,
            Se = (-x - W) / r,
            Me = q * q + Z * Z,
            z = (Z < 0 ? -1 : 1) * Math.acos(q / wi(Me)),
            ge = (q * Se - Z * le < 0 ? -1 : 1) * Math.acos((q * le + Z * Se) / wi(Me * (le * le + Se * Se)));
        isNaN(ge) && (ge = h), !s && ge > 0 ? ge -= p : s && ge < 0 && (ge += p), z %= p, ge %= p;
        var $e = Math.ceil(Ir(ge) / (p / 4)),
            Xe = [],
            tt = ge / $e,
            wt = 4 / 3 * Ha(tt / 2) / (1 + Ga(tt / 2)),
            Ue = d * n,
            Ye = f * n,
            Ge = f * -r,
            rt = d * r,
            it;
        for (it = 0; it < $e; it++) i = z + it * tt, y = Ga(i), x = Ha(i), q = Ga(i += tt), Z = Ha(i), Xe.push(y - wt * x, x + wt * y, q + wt * Z, Z - wt * q, q, Z);
        for (it = 0; it < Xe.length; it += 2) y = Xe[it], x = Xe[it + 1], Xe[it] = y * Ue + x * Ge + I, Xe[it + 1] = y * Ye + x * rt + X;
        return Xe[it - 2] = a, Xe[it - 1] = l, Xe
    }
}

function ua(t) {
    var e = (t + "").replace(aC, function(te) {
            var W = +te;
            return W < 1e-4 && W > -1e-4 ? 0 : W
        }).match(oC) || [],
        n = [],
        r = 0,
        i = 0,
        o = 2 / 3,
        s = e.length,
        a = 0,
        l = "ERROR: malformed path: " + t,
        c, d, f, h, p, m, g, y, x, w, M, T, O, R, P, B = function(W, ee, V, I) {
            w = (V - W) / 3, M = (I - ee) / 3, g.push(W + w, ee + M, V - w, I - M, V, I)
        };
    if (!t || !isNaN(e[0]) || isNaN(e[1])) return console.log(l), n;
    for (c = 0; c < s; c++)
        if (O = p, isNaN(e[c]) ? (p = e[c].toUpperCase(), m = p !== e[c]) : c--, f = +e[c + 1], h = +e[c + 2], m && (f += r, h += i), c || (y = f, x = h), p === "M") g && (g.length < 8 ? n.length -= 1 : a += g.length), r = y = f, i = x = h, g = [f, h], n.push(g), c += 2, p = "L";
        else if (p === "C") g || (g = [0, 0]), m || (r = i = 0), g.push(f, h, r + e[c + 3] * 1, i + e[c + 4] * 1, r += e[c + 5] * 1, i += e[c + 6] * 1), c += 6;
    else if (p === "S") w = r, M = i, (O === "C" || O === "S") && (w += r - g[g.length - 4], M += i - g[g.length - 3]), m || (r = i = 0), g.push(w, M, f, h, r += e[c + 3] * 1, i += e[c + 4] * 1), c += 4;
    else if (p === "Q") w = r + (f - r) * o, M = i + (h - i) * o, m || (r = i = 0), r += e[c + 3] * 1, i += e[c + 4] * 1, g.push(w, M, r + (f - r) * o, i + (h - i) * o, r, i), c += 4;
    else if (p === "T") w = r - g[g.length - 4], M = i - g[g.length - 3], g.push(r + w, i + M, f + (r + w * 1.5 - f) * o, h + (i + M * 1.5 - h) * o, r = f, i = h), c += 2;
    else if (p === "H") B(r, i, r = f, i), c += 1;
    else if (p === "V") B(r, i, r, i = f + (m ? i - r : 0)), c += 1;
    else if (p === "L" || p === "Z") p === "Z" && (f = y, h = x, g.closed = !0), (p === "L" || Ir(r - f) > .5 || Ir(i - h) > .5) && (B(r, i, f, h), p === "L" && (c += 2)), r = f, i = h;
    else if (p === "A") {
        if (R = e[c + 4], P = e[c + 5], w = e[c + 6], M = e[c + 7], d = 7, R.length > 1 && (R.length < 3 ? (M = w, w = P, d--) : (M = P, w = R.substr(2), d -= 2), P = R.charAt(1), R = R.charAt(0)), T = SC(r, i, +e[c + 1], +e[c + 2], +e[c + 3], +R, +P, (m ? r : 0) + w * 1, (m ? i : 0) + M * 1), c += d, T)
            for (d = 0; d < T.length; d++) g.push(T[d]);
        r = g[g.length - 2], i = g[g.length - 1]
    } else console.log(l);
    return c = g.length, c < 6 ? (n.pop(), c = 0) : g[0] === g[c - 2] && g[1] === g[c - 1] && (g.closed = !0), n.totalPoints = a + c, n
}

function CC(t, e) {
    e === void 0 && (e = 1);
    for (var n = t[0], r = 0, i = [n, r], o = 2; o < t.length; o += 2) i.push(n, r, t[o], r = (t[o] - n) * e / 2, n = t[o], -r);
    return i
}

function Bu(t, e) {
    Ir(t[0] - t[2]) < 1e-4 && Ir(t[1] - t[3]) < 1e-4 && (t = t.slice(2));
    var n = t.length - 2,
        r = +t[0],
        i = +t[1],
        o = +t[2],
        s = +t[3],
        a = [r, i, r, i],
        l = o - r,
        c = s - i,
        d = Math.abs(t[n] - r) < .001 && Math.abs(t[n + 1] - i) < .001,
        f, h, p, m, g, y, x, w, M, T, O, R, P, B, te;
    for (d && (t.push(o, s), o = r, s = i, r = t[n - 2], i = t[n - 1], t.unshift(r, i), n += 4), e = e || e === 0 ? +e : 1, p = 2; p < n; p += 2) f = r, h = i, r = o, i = s, o = +t[p + 2], s = +t[p + 3], !(r === o && i === s) && (m = l, g = c, l = o - r, c = s - i, y = wi(m * m + g * g), x = wi(l * l + c * c), w = wi(Math.pow(l / x + m / y, 2) + Math.pow(c / x + g / y, 2)), M = (y + x) * e * .25 / w, T = r - (r - f) * (y ? M / y : 0), O = r + (o - r) * (x ? M / x : 0), R = r - (T + ((O - T) * (y * 3 / (y + x) + .5) / 4 || 0)), P = i - (i - h) * (y ? M / y : 0), B = i + (s - i) * (x ? M / x : 0), te = i - (P + ((B - P) * (y * 3 / (y + x) + .5) / 4 || 0)), (r !== f || i !== h) && a.push(Ht(T + R), Ht(P + te), Ht(r), Ht(i), Ht(O + R), Ht(B + te)));
    return r !== o || i !== s || a.length < 4 ? a.push(Ht(o), Ht(s), Ht(o), Ht(s)) : a.length -= 2, a.length === 2 ? a.push(r, i, r, i, r, i) : d && (a.splice(0, 6), a.length = a.length - 6), a
}

function qf(t) {
    Qm(t[0]) && (t = [t]);
    var e = "",
        n = t.length,
        r, i, o, s;
    for (i = 0; i < n; i++) {
        for (s = t[i], e += "M" + Ht(s[0]) + "," + Ht(s[1]) + " C", r = s.length, o = 2; o < r; o++) e += Ht(s[o++]) + "," + Ht(s[o++]) + " " + Ht(s[o++]) + "," + Ht(s[o++]) + " " + Ht(s[o++]) + "," + Ht(s[o]) + " ";
        s.closed && (e += "z")
    }
    return e
}
/*!
 * matrix 3.12.2
 * https://greensock.com
 *
 * Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var Si, yo, Kf, Ko, Os, ul, zl, Hs, Br = "transform",
    Wu = Br + "Origin",
    rg, ig = function(e) {
        var n = e.ownerDocument || e;
        for (!(Br in e.style) && ("msTransform" in e.style) && (Br = "msTransform", Wu = Br + "Origin"); n.parentNode && (n = n.parentNode););
        if (yo = window, zl = new fa, n) {
            Si = n, Kf = n.documentElement, Ko = n.body, Hs = Si.createElementNS("http://www.w3.org/2000/svg", "g"), Hs.style.transform = "none";
            var r = n.createElement("div"),
                i = n.createElement("div");
            Ko.appendChild(r), r.appendChild(i), r.style.position = "static", r.style[Br] = "translate3d(0,0,1px)", rg = i.offsetParent !== r, Ko.removeChild(r)
        }
        return n
    },
    EC = function(e) {
        for (var n, r; e && e !== Ko;) r = e._gsap, r && r.uncache && r.get(e, "x"), r && !r.scaleX && !r.scaleY && r.renderTransform && (r.scaleX = r.scaleY = 1e-4, r.renderTransform(1, r), n ? n.push(r) : n = [r]), e = e.parentNode;
        return n
    },
    og = [],
    sg = [],
    TC = function() {
        return yo.pageYOffset || Si.scrollTop || Kf.scrollTop || Ko.scrollTop || 0
    },
    PC = function() {
        return yo.pageXOffset || Si.scrollLeft || Kf.scrollLeft || Ko.scrollLeft || 0
    },
    Zf = function(e) {
        return e.ownerSVGElement || ((e.tagName + "").toLowerCase() === "svg" ? e : null)
    },
    RC = function t(e) {
        if (yo.getComputedStyle(e).position === "fixed") return !0;
        if (e = e.parentNode, e && e.nodeType === 1) return t(e)
    },
    Oc = function t(e, n) {
        if (e.parentNode && (Si || ig(e))) {
            var r = Zf(e),
                i = r ? r.getAttribute("xmlns") || "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml",
                o = r ? n ? "rect" : "g" : "div",
                s = n !== 2 ? 0 : 100,
                a = n === 3 ? 100 : 0,
                l = "position:absolute;display:block;pointer-events:none;margin:0;padding:0;",
                c = Si.createElementNS ? Si.createElementNS(i.replace(/^https/, "http"), o) : Si.createElement(o);
            return n && (r ? (ul || (ul = t(e)), c.setAttribute("width", .01), c.setAttribute("height", .01), c.setAttribute("transform", "translate(" + s + "," + a + ")"), ul.appendChild(c)) : (Os || (Os = t(e), Os.style.cssText = l), c.style.cssText = l + "width:0.1px;height:0.1px;top:" + a + "px;left:" + s + "px", Os.appendChild(c))), c
        }
        throw "Need document and parent."
    },
    MC = function(e) {
        for (var n = new fa, r = 0; r < e.numberOfItems; r++) n.multiply(e.getItem(r).matrix);
        return n
    },
    $C = function(e) {
        var n = e.getCTM(),
            r;
        return n || (r = e.style[Br], e.style[Br] = "none", e.appendChild(Hs), n = Hs.getCTM(), e.removeChild(Hs), r ? e.style[Br] = r : e.style.removeProperty(Br.replace(/([A-Z])/g, "-$1").toLowerCase())), n || zl.clone()
    },
    AC = function(e, n) {
        var r = Zf(e),
            i = e === r,
            o = r ? og : sg,
            s = e.parentNode,
            a, l, c, d, f, h;
        if (e === yo) return e;
        if (o.length || o.push(Oc(e, 1), Oc(e, 2), Oc(e, 3)), a = r ? ul : Os, r) i ? (c = $C(e), d = -c.e / c.a, f = -c.f / c.d, l = zl) : e.getBBox ? (c = e.getBBox(), l = e.transform ? e.transform.baseVal : {}, l = l.numberOfItems ? l.numberOfItems > 1 ? MC(l) : l.getItem(0).matrix : zl, d = l.a * c.x + l.c * c.y, f = l.b * c.x + l.d * c.y) : (l = new fa, d = f = 0), n && e.tagName.toLowerCase() === "g" && (d = f = 0), (i ? r : s).appendChild(a), a.setAttribute("transform", "matrix(" + l.a + "," + l.b + "," + l.c + "," + l.d + "," + (l.e + d) + "," + (l.f + f) + ")");
        else {
            if (d = f = 0, rg)
                for (l = e.offsetParent, c = e; c && (c = c.parentNode) && c !== l && c.parentNode;)(yo.getComputedStyle(c)[Br] + "").length > 4 && (d = c.offsetLeft, f = c.offsetTop, c = 0);
            if (h = yo.getComputedStyle(e), h.position !== "absolute" && h.position !== "fixed")
                for (l = e.offsetParent; s && s !== l;) d += s.scrollLeft || 0, f += s.scrollTop || 0, s = s.parentNode;
            c = a.style, c.top = e.offsetTop - f + "px", c.left = e.offsetLeft - d + "px", c[Br] = h[Br], c[Wu] = h[Wu], c.position = h.position === "fixed" ? "fixed" : "absolute", e.parentNode.appendChild(a)
        }
        return a
    },
    jc = function(e, n, r, i, o, s, a) {
        return e.a = n, e.b = r, e.c = i, e.d = o, e.e = s, e.f = a, e
    },
    fa = function() {
        function t(n, r, i, o, s, a) {
            n === void 0 && (n = 1), r === void 0 && (r = 0), i === void 0 && (i = 0), o === void 0 && (o = 1), s === void 0 && (s = 0), a === void 0 && (a = 0), jc(this, n, r, i, o, s, a)
        }
        var e = t.prototype;
        return e.inverse = function() {
            var r = this.a,
                i = this.b,
                o = this.c,
                s = this.d,
                a = this.e,
                l = this.f,
                c = r * s - i * o || 1e-10;
            return jc(this, s / c, -i / c, -o / c, r / c, (o * l - s * a) / c, -(r * l - i * a) / c)
        }, e.multiply = function(r) {
            var i = this.a,
                o = this.b,
                s = this.c,
                a = this.d,
                l = this.e,
                c = this.f,
                d = r.a,
                f = r.c,
                h = r.b,
                p = r.d,
                m = r.e,
                g = r.f;
            return jc(this, d * i + h * s, d * o + h * a, f * i + p * s, f * o + p * a, l + m * i + g * s, c + m * o + g * a)
        }, e.clone = function() {
            return new t(this.a, this.b, this.c, this.d, this.e, this.f)
        }, e.equals = function(r) {
            var i = this.a,
                o = this.b,
                s = this.c,
                a = this.d,
                l = this.e,
                c = this.f;
            return i === r.a && o === r.b && s === r.c && a === r.d && l === r.e && c === r.f
        }, e.apply = function(r, i) {
            i === void 0 && (i = {});
            var o = r.x,
                s = r.y,
                a = this.a,
                l = this.b,
                c = this.c,
                d = this.d,
                f = this.e,
                h = this.f;
            return i.x = o * a + s * c + f || 0, i.y = o * l + s * d + h || 0, i
        }, t
    }();

function Zo(t, e, n, r) {
    if (!t || !t.parentNode || (Si || ig(t)).documentElement === t) return new fa;
    var i = EC(t),
        o = Zf(t),
        s = o ? og : sg,
        a = AC(t, n),
        l = s[0].getBoundingClientRect(),
        c = s[1].getBoundingClientRect(),
        d = s[2].getBoundingClientRect(),
        f = a.parentNode,
        h = !r && RC(t),
        p = new fa((c.left - l.left) / 100, (c.top - l.top) / 100, (d.left - l.left) / 100, (d.top - l.top) / 100, l.left + (h ? 0 : PC()), l.top + (h ? 0 : TC()));
    if (f.removeChild(a), i)
        for (l = i.length; l--;) c = i[l], c.scaleX = c.scaleY = 0, c.renderTransform(1, c);
    return e ? p.inverse() : p
}
/*!
 * MotionPathPlugin 3.12.2
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var FC = "x,translateX,left,marginLeft,xPercent".split(","),
    kC = "y,translateY,top,marginTop,yPercent".split(","),
    OC = Math.PI / 180,
    jr, ag, jo, Vu, Lc, Jp, jC = function() {
        return jr || typeof window < "u" && (jr = window.gsap) && jr.registerPlugin && jr
    },
    Ms = function(e, n, r, i) {
        for (var o = n.length, s = i === 2 ? 0 : i, a = 0; a < o; a++) e[s] = parseFloat(n[a][r]), i === 2 && (e[s + 1] = 0), s += 2;
        return e
    },
    Uo = function(e, n, r) {
        return parseFloat(e._gsap.get(e, n, r || "px")) || 0
    },
    lg = function(e) {
        var n = e[0],
            r = e[1],
            i;
        for (i = 2; i < e.length; i += 2) n = e[i] += n, r = e[i + 1] += r
    },
    eh = function(e, n, r, i, o, s, a, l, c) {
        if (a.type === "cubic") n = [n];
        else {
            a.fromCurrent !== !1 && n.unshift(Uo(r, i, l), o ? Uo(r, o, c) : 0), a.relative && lg(n);
            var d = o ? Bu : CC;
            n = [d(n, a.curviness)]
        }
        return n = s(cg(n, r, a)), Il(e, r, i, n, "x", l), o && Il(e, r, o, n, "y", c), vo(n, a.resolution || (a.curviness === 0 ? 20 : 12))
    },
    LC = function(e) {
        return e
    },
    NC = /[-+\.]*\d+\.?(?:e-|e\+)?\d*/g,
    th = function(e, n, r) {
        var i = Zo(e),
            o = 0,
            s = 0,
            a;
        return (e.tagName + "").toLowerCase() === "svg" ? (a = e.viewBox.baseVal, a.width || (a = {
            width: +e.getAttribute("width"),
            height: +e.getAttribute("height")
        })) : a = n && e.getBBox && e.getBBox(), n && n !== "auto" && (o = n.push ? n[0] * (a ? a.width : e.offsetWidth || 0) : n.x, s = n.push ? n[1] * (a ? a.height : e.offsetHeight || 0) : n.y), r.apply(o || s ? i.apply({
            x: o,
            y: s
        }) : {
            x: i.e,
            y: i.f
        })
    },
    Uu = function(e, n, r, i) {
        var o = Zo(e.parentNode, !0, !0),
            s = o.clone().multiply(Zo(n)),
            a = th(e, r, o),
            l = th(n, i, o),
            c = l.x,
            d = l.y,
            f;
        return s.e = s.f = 0, i === "auto" && n.getTotalLength && n.tagName.toLowerCase() === "path" && (f = n.getAttribute("d").match(NC) || [], f = s.apply({
            x: +f[0],
            y: +f[1]
        }), c += f.x, d += f.y), f && (f = s.apply(n.getBBox()), c -= f.x, d -= f.y), s.e = c - a.x, s.f = d - a.y, s
    },
    cg = function(e, n, r) {
        var i = r.align,
            o = r.matrix,
            s = r.offsetX,
            a = r.offsetY,
            l = r.alignOrigin,
            c = e[0][0],
            d = e[0][1],
            f = Uo(n, "x"),
            h = Uo(n, "y"),
            p, m, g;
        return !e || !e.length ? cl("M0,0L0,0") : (i && (i === "self" || (p = Vu(i)[0] || n) === n ? Vo(e, 1, 0, 0, 1, f - c, h - d) : (l && l[2] !== !1 ? jr.set(n, {
            transformOrigin: l[0] * 100 + "% " + l[1] * 100 + "%"
        }) : l = [Uo(n, "xPercent") / -100, Uo(n, "yPercent") / -100], m = Uu(n, p, l, "auto"), g = m.apply({
            x: c,
            y: d
        }), Vo(e, m.a, m.b, m.c, m.d, f + m.e - (g.x - m.e), h + m.f - (g.y - m.f)))), o ? Vo(e, o.a, o.b, o.c, o.d, o.e, o.f) : (s || a) && Vo(e, 1, 0, 0, 1, s || 0, a || 0), e)
    },
    Il = function(e, n, r, i, o, s) {
        var a = n._gsap,
            l = a.harness,
            c = l && l.aliases && l.aliases[r],
            d = c && c.indexOf(",") < 0 ? c : r,
            f = e._pt = new ag(e._pt, n, d, 0, 0, LC, 0, a.set(n, d, e));
        f.u = jo(a.get(n, d, s)) || 0, f.path = i, f.pp = o, e._props.push(d)
    },
    zC = function(e, n) {
        return function(r) {
            return e || n !== 1 ? ng(r, e, n) : r
        }
    },
    bs = {
        version: "3.12.2",
        name: "motionPath",
        register: function(e, n, r) {
            jr = e, jo = jr.utils.getUnit, Vu = jr.utils.toArray, Lc = jr.core.getStyleSaver, Jp = jr.core.reverting || function() {}, ag = r
        },
        init: function(e, n, r) {
            if (!jr) return console.warn("Please gsap.registerPlugin(MotionPathPlugin)"), !1;
            (!(typeof n == "object" && !n.style) || !n.path) && (n = {
                path: n
            });
            var i = [],
                o = n,
                s = o.path,
                a = o.autoRotate,
                l = o.unitX,
                c = o.unitY,
                d = o.x,
                f = o.y,
                h = s[0],
                p = zC(n.start, "end" in n ? n.end : 1),
                m, g;
            if (this.rawPaths = i, this.target = e, this.tween = r, this.styles = Lc && Lc(e, "transform"), (this.rotate = a || a === 0) && (this.rOffset = parseFloat(a) || 0, this.radians = !!n.useRadians, this.rProp = n.rotation || "rotation", this.rSet = e._gsap.set(e, this.rProp, this), this.ru = jo(e._gsap.get(e, this.rProp)) || 0), Array.isArray(s) && !("closed" in s) && typeof h != "number") {
                for (g in h) !d && ~FC.indexOf(g) ? d = g : !f && ~kC.indexOf(g) && (f = g);
                d && f ? i.push(eh(this, Ms(Ms([], s, d, 0), s, f, 1), e, d, f, p, n, l || jo(s[0][d]), c || jo(s[0][f]))) : d = f = 0;
                for (g in h) g !== d && g !== f && i.push(eh(this, Ms([], s, g, 2), e, g, 0, p, n, jo(s[0][g])))
            } else m = p(cg(cl(n.path), e, n)), vo(m, n.resolution), i.push(m), Il(this, e, n.x || "x", m, "x", n.unitX || "px"), Il(this, e, n.y || "y", m, "y", n.unitY || "px")
        },
        render: function(e, n) {
            var r = n.rawPaths,
                i = r.length,
                o = n._pt;
            if (n.tween._time || !Jp()) {
                for (e > 1 ? e = 1 : e < 0 && (e = 0); i--;) Qp(r[i], e, !i && n.rotate, r[i]);
                for (; o;) o.set(o.t, o.p, o.path[o.pp] + o.u, o.d, e), o = o._next;
                n.rotate && n.rSet(n.target, n.rProp, r[0].angle * (n.radians ? OC : 1) + n.rOffset + n.ru, n, e)
            } else n.styles.revert()
        },
        getLength: function(e) {
            return vo(cl(e)).totalLength
        },
        sliceRawPath: ng,
        getRawPath: cl,
        pointsToSegment: Bu,
        stringToRawPath: ua,
        rawPathToString: qf,
        transformRawPath: Vo,
        getGlobalMatrix: Zo,
        getPositionOnPath: Qp,
        cacheRawPathMeasurements: vo,
        convertToPath: function(e, n) {
            return Vu(e).map(function(r) {
                return _C(r, n !== !1)
            })
        },
        convertCoordinates: function(e, n, r) {
            var i = Zo(n, !0, !0).multiply(Zo(e));
            return r ? i.apply(r) : i
        },
        getAlignMatrix: Uu,
        getRelativePosition: function(e, n, r, i) {
            var o = Uu(e, n, r, i);
            return {
                x: o.e,
                y: o.f
            }
        },
        arrayToRawPath: function(e, n) {
            n = n || {};
            var r = Ms(Ms([], e, n.x || "x", 0), e, n.y || "y", 1);
            return n.relative && lg(r), [n.type === "cubic" ? r : Bu(r, n.curviness)]
        }
    };
jC() && jr.registerPlugin(bs);
const IC = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(bs), []);
        const {
            scenes: n,
            locale: r
        } = nr(), i = Gr(), o = u.useRef(null), s = u.useRef(null);
        u.useLayoutEffect(() => {
            const l = he.context(() => {
                he.to("[data-gsap-line]", {
                    motionPath: {
                        fromCurrent: !1,
                        path: [{
                            scaleY: 0,
                            yPercent: -50
                        }, {
                            scaleY: 1,
                            yPercent: 0
                        }, {
                            scaleY: 0,
                            yPercent: 100
                        }]
                    },
                    transformOrigin: "top center",
                    ease: "power2.inOut",
                    duration: 1.5,
                    repeat: -1
                }), o.current = he.timeline({
                    paused: !0,
                    defaults: {
                        duration: .6,
                        ease: "power2.inOut"
                    }
                }).fromTo("[data-gsap-root]", {
                    scaleY: 0
                }, {
                    scaleY: 1
                }, "<").fromTo("[data-gsap-label]", {
                    yPercent: 100
                }, {
                    yPercent: 0
                }, "<+.1")
            }, s.current);
            return () => {
                l.revert()
            }
        }, []), u.useEffect(() => {
            const l = Bn.subscribe(c => c.route, (c, d) => {
                var f, h;
                c.index === n.length - 2 ? he.delayedCall(.8, () => {
                    var p;
                    return (p = o.current) == null ? void 0 : p.play()
                }) : d.index === n.length - 2 && !((f = o.current) != null && f.reversed()) && ((h = o.current) == null || h.reverse())
            }, {
                fireImmediately: !1
            });
            return () => {
                l()
            }
        }, [n]);
        const a = u.useCallback(l => {
            var c, d, f, h;
            l.progress === 0 && ((c = o.current) != null && c.reversed()) && !i.cameraMotionValue.isAnimating() ? (d = o.current) == null || d.play() : l.progress > 0 && !((f = o.current) != null && f.reversed()) && ((h = o.current) == null || h.reverse())
        }, [i]);
        return u.useEffect(() => (i.cameraMotionValue.addEventListener("scroll", a), () => {
            i.cameraMotionValue.removeEventListener("scroll", a)
        }), [i, a]), u.useImperativeHandle(e, () => ({
            timeline: o.current
        }), []), v.jsxs("div", {
            ref: s,
            className: "relative",
            children: [v.jsx("div", {
                className: "absolute top-1/2 left-0 w-[.2rem] h-[3.2rem] md:h-[5.4rem] -translate-y-1/2 bg-primary overflow-hidden",
                "data-gsap-root": !0,
                children: v.jsx("div", {
                    className: "absolute top-0 left-0 w-full h-full bg-white",
                    "data-gsap-line": !0
                })
            }), v.jsx("div", {
                className: "overflow-hidden hidden md:block",
                children: v.jsx(an, {
                    className: "text-white block ml-6 md:ml-10 whitespace-nowrap",
                    "data-gsap-label": !0,
                    children: r.shared.cta_scroll
                })
            })]
        })
    }),
    BC = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(bs), []);
        const {
            scenes: n,
            locale: r
        } = nr(), i = Gr(), o = u.useRef(null), s = u.useRef(null);
        return u.useLayoutEffect(() => {
            const a = he.context(() => {
                he.to("[data-gsap-line]", {
                    motionPath: {
                        fromCurrent: !1,
                        path: [{
                            scaleX: 0,
                            xPercent: 50
                        }, {
                            scaleX: 1,
                            xPercent: 0
                        }, {
                            scaleX: 0,
                            xPercent: -100
                        }]
                    },
                    transformOrigin: "right center",
                    ease: "power2.inOut",
                    duration: 1.5,
                    repeat: -1
                }), o.current = he.timeline({
                    paused: !0,
                    defaults: {
                        duration: .6,
                        ease: "power2.inOut"
                    }
                }).fromTo("[data-gsap-root]", {
                    scaleX: 0
                }, {
                    scaleX: 1
                }, "<").fromTo("[data-gsap-label]", {
                    yPercent: 100
                }, {
                    yPercent: 0
                }, "<+.1")
            }, s.current);
            return () => {
                a.revert()
            }
        }, []), u.useEffect(() => {
            const a = Bn.subscribe(l => l.route, (l, c) => {
                var d, f;
                if (l.index === 0) {
                    const h = uc(i.cameraMotionValue.get()),
                        p = c.index === n.length - 2 ? h - .8 : 0;
                    he.delayedCall(p, () => {
                        var m;
                        return (m = o.current) == null ? void 0 : m.play()
                    })
                } else c.index === 0 && !((d = o.current) != null && d.reversed()) && ((f = o.current) == null || f.reverse())
            }, {
                fireImmediately: !1
            });
            return () => {
                a()
            }
        }, [i, n]), u.useImperativeHandle(e, () => ({
            timeline: o.current
        }), []), v.jsxs("div", {
            ref: s,
            className: "relative",
            children: [v.jsx("div", {
                className: "absolute -top-4 md:-top-6 left-0 right-0 h-[.2rem] bg-primary-dark overflow-hidden",
                "data-gsap-root": !0,
                children: v.jsx("div", {
                    className: "absolute top-0 left-0 w-full h-full bg-primary",
                    "data-gsap-line": !0
                })
            }), v.jsx("div", {
                className: "overflow-hidden",
                children: v.jsx(an, {
                    className: "text-secondary block whitespace-nowrap",
                    "data-gsap-label": !0,
                    children: r.shared.cta_swipe
                })
            })]
        })
    }),
    WC = u.forwardRef(({
        muted: t,
        className: e,
        ...n
    }, r) => {
        const i = u.useRef(null),
            o = u.useRef(0),
            s = u.useRef({
                value: 2
            }),
            a = 5,
            l = .08;
        return gS(() => {
            let c = "";
            o.current += l;
            for (let d = 0; d < 1; d += 1 / 7) c += "".concat((1 + 8 * d).toFixed(2), ",").concat((5 + Math.sin(d * a + o.current) * s.current.value).toFixed(2), " ");
            i.current.setAttribute("points", c)
        }), u.useEffect(() => {
            he.to(s.current, {
                value: t ? .3 : 2,
                duration: .8,
                ease: "power2.out"
            })
        }, [t]), v.jsx("button", {
            ref: r,
            "aria-label": "toggle-audio",
            className: Kt("relative w-[4.4rem] h-[4.4rem] translate-x-[2rem] translate-y-[1.4rem]", e),
            ...n,
            children: v.jsx("svg", {
                width: "24px",
                height: "24px",
                viewBox: "0 0 10 10",
                className: "stroke-1 stroke-white fill-none",
                children: v.jsx("polyline", {
                    ref: i,
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeDasharray: 11,
                    "data-gsap-audio-icon": !0
                })
            })
        })
    }),
    VC = u.forwardRef((t, e) => {
        const {
            scenes: n,
            locale: r
        } = nr(), {
            muted: i,
            toggleSound: o
        } = rC(), s = Gn(h => h.compiled), a = u.useRef(he.timeline({
            delay: .3,
            paused: !0
        })), l = u.useRef(null), c = wr([l, e]), d = u.useRef(null), f = u.useRef(null);
        return u.useLayoutEffect(() => {
            const h = he.context(() => {
                a.current.add(he.timeline().add(he.fromTo(["[data-gsap-colophon]", "[data-gsap-privacy]", "[data-gsap-email]"], {
                    yPercent: 120
                }, {
                    yPercent: 0,
                    duration: 1,
                    ease: "power3.out"
                })).add(he.fromTo("[data-gsap-audio-icon]", {
                    strokeDashoffset: 11
                }, {
                    strokeDashoffset: 0,
                    duration: 1,
                    ease: "power4.out"
                }), "<+.3"))
            }, l.current);
            return () => {
                h.revert()
            }
        }, []), RS(() => {
            var h, p;
            a.current.play(), Ru().index === 0 ? (h = d.current) == null || h.timeline.play() : Ru().index === n.length - 1 && ((p = f.current) == null || p.timeline.play())
        }), bt("Footer"), v.jsx("footer", {
            ref: c,
            ...t,
            className: Kt("fixed left-0 bottom-0 w-full z-20", {
                hidden: !s
            }),
            children: v.jsx(ki, {
                children: v.jsxs("div", {
                    className: "relative -translate-y-10 md:-translate-y-20",
                    children: [v.jsx("div", {
                        className: "absolute left-0 bottom-0",
                        children: v.jsxs("div", {
                            className: "flex flex-col items-start space-y-10 md:space-y-16 xl:space-y-20",
                            children: [v.jsxs("div", {
                                className: "relative",
                                children: [v.jsx("div", {
                                    className: "absolute bottom-0 left-0",
                                    children: v.jsx(BC, {
                                        ref: d
                                    })
                                }), v.jsx("div", {
                                    className: "absolute bottom-0 left-0",
                                    children: v.jsx(IC, {
                                        ref: f
                                    })
                                })]
                            }), v.jsxs("div", {
                                className: "flex flex-col md:flex-row-reverse items-baseline",
                                children: [v.jsxs("span", {
                                    className: "flex space-x-3 md:space-x-4 overflow-hidden",
                                    children: [v.jsx("a", {
                                        href: `${_a}${r.footer.privacy.href}`,
                                        target: "_blank",
                                        className: "inline-flex text-primary",
                                        "data-gsap-privacy": !0,
                                        children: v.jsx(an, {
                                            size: "small",
                                            children: r.footer.privacy.label
                                        })
                                    }), v.jsx("a", {
                                        href: r.footer.email.href,
                                        target: "_blank",
                                        className: "inline-flex text-primary underline",
                                        "data-gsap-email": !0,
                                        children: v.jsx(an, {
                                            size: "small",
                                            children: r.footer.email.label
                                        })
                                    })]
                                }), v.jsx(an, {
                                    paragraph: !0,
                                    size: "small",
                                    className: "text-secondary mr-3 md:mr-4 overflow-hidden",
                                    children: v.jsx("span", {
                                        className: "inline-block",
                                        "data-gsap-colophon": !0,
                                        children: r.footer.colophon
                                    })
                                })]
                            })]
                        })
                    }), v.jsx("div", {
                        className: "absolute right-0 bottom-0",
                        children: v.jsx(WC, {
                            muted: i,
                            onClick: o
                        })
                    })]
                })
            })
        })
    });

function nh(t, e) {
    for (var n = 0; n < e.length; n++) {
        var r = e[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
    }
}

function UC(t, e, n) {
    return e && nh(t.prototype, e), n && nh(t, n), t
}
/*!
 * Observer 3.12.2
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var Yn, Hu, Tr, Gi, Yi, Qo, ug, co, Gs, fg, Ci, Zr, dg, pg = function() {
        return Yn || typeof window < "u" && (Yn = window.gsap) && Yn.registerPlugin && Yn
    },
    hg = 1,
    Ho = [],
    $t = [],
    di = [],
    Ys = Date.now,
    Gu = function(e, n) {
        return n
    },
    HC = function() {
        var e = Gs.core,
            n = e.bridge || {},
            r = e._scrollers,
            i = e._proxies;
        r.push.apply(r, $t), i.push.apply(i, di), $t = r, di = i, Gu = function(s, a) {
            return n[s](a)
        }
    },
    qi = function(e, n) {
        return ~di.indexOf(e) && di[di.indexOf(e) + 1][n]
    },
    Xs = function(e) {
        return !!~fg.indexOf(e)
    },
    sr = function(e, n, r, i, o) {
        return e.addEventListener(n, r, {
            passive: !i,
            capture: !!o
        })
    },
    ir = function(e, n, r, i) {
        return e.removeEventListener(n, r, !!i)
    },
    Ya = "scrollLeft",
    Xa = "scrollTop",
    Yu = function() {
        return Ci && Ci.isPressed || $t.cache++
    },
    Bl = function(e, n) {
        var r = function i(o) {
            if (o || o === 0) {
                hg && (Tr.history.scrollRestoration = "manual");
                var s = Ci && Ci.isPressed;
                o = i.v = Math.round(o) || (Ci && Ci.iOS ? 1 : 0), e(o), i.cacheID = $t.cache, s && Gu("ss", o)
            } else(n || $t.cache !== i.cacheID || Gu("ref")) && (i.cacheID = $t.cache, i.v = e());
            return i.v + i.offset
        };
        return r.offset = 0, e && r
    },
    fr = {
        s: Ya,
        p: "left",
        p2: "Left",
        os: "right",
        os2: "Right",
        d: "width",
        d2: "Width",
        a: "x",
        sc: Bl(function(t) {
            return arguments.length ? Tr.scrollTo(t, Fn.sc()) : Tr.pageXOffset || Gi[Ya] || Yi[Ya] || Qo[Ya] || 0
        })
    },
    Fn = {
        s: Xa,
        p: "top",
        p2: "Top",
        os: "bottom",
        os2: "Bottom",
        d: "height",
        d2: "Height",
        a: "y",
        op: fr,
        sc: Bl(function(t) {
            return arguments.length ? Tr.scrollTo(fr.sc(), t) : Tr.pageYOffset || Gi[Xa] || Yi[Xa] || Qo[Xa] || 0
        })
    },
    vr = function(e, n) {
        return (n && n._ctx && n._ctx.selector || Yn.utils.toArray)(e)[0] || (typeof e == "string" && Yn.config().nullTargetWarn !== !1 ? console.warn("Element not found:", e) : null)
    },
    eo = function(e, n) {
        var r = n.s,
            i = n.sc;
        Xs(e) && (e = Gi.scrollingElement || Yi);
        var o = $t.indexOf(e),
            s = i === Fn.sc ? 1 : 2;
        !~o && (o = $t.push(e) - 1), $t[o + s] || sr(e, "scroll", Yu);
        var a = $t[o + s],
            l = a || ($t[o + s] = Bl(qi(e, r), !0) || (Xs(e) ? i : Bl(function(c) {
                return arguments.length ? e[r] = c : e[r]
            })));
        return l.target = e, a || (l.smooth = Yn.getProperty(e, "scrollBehavior") === "smooth"), l
    },
    Xu = function(e, n, r) {
        var i = e,
            o = e,
            s = Ys(),
            a = s,
            l = n || 50,
            c = Math.max(500, l * 3),
            d = function(m, g) {
                var y = Ys();
                g || y - s > l ? (o = i, i = m, a = s, s = y) : r ? i += m : i = o + (m - o) / (y - a) * (s - a)
            },
            f = function() {
                o = i = r ? 0 : i, a = s = 0
            },
            h = function(m) {
                var g = a,
                    y = o,
                    x = Ys();
                return (m || m === 0) && m !== i && d(m), s === a || x - a > c ? 0 : (i + (r ? y : -y)) / ((r ? x : s) - g) * 1e3
            };
        return {
            update: d,
            reset: f,
            getVelocity: h
        }
    },
    $s = function(e, n) {
        return n && !e._gsapAllow && e.preventDefault(), e.changedTouches ? e.changedTouches[0] : e
    },
    rh = function(e) {
        var n = Math.max.apply(Math, e),
            r = Math.min.apply(Math, e);
        return Math.abs(n) >= Math.abs(r) ? n : r
    },
    mg = function() {
        Gs = Yn.core.globals().ScrollTrigger, Gs && Gs.core && HC()
    },
    gg = function(e) {
        return Yn = e || pg(), Yn && typeof document < "u" && document.body && (Tr = window, Gi = document, Yi = Gi.documentElement, Qo = Gi.body, fg = [Tr, Gi, Yi, Qo], Yn.utils.clamp, dg = Yn.core.context || function() {}, co = "onpointerenter" in Qo ? "pointer" : "mouse", ug = Pn.isTouch = Tr.matchMedia && Tr.matchMedia("(hover: none), (pointer: coarse)").matches ? 1 : "ontouchstart" in Tr || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? 2 : 0, Zr = Pn.eventTypes = ("ontouchstart" in Yi ? "touchstart,touchmove,touchcancel,touchend" : "onpointerdown" in Yi ? "pointerdown,pointermove,pointercancel,pointerup" : "mousedown,mousemove,mouseup,mouseup").split(","), setTimeout(function() {
            return hg = 0
        }, 500), mg(), Hu = 1), Hu
    };
fr.op = Fn;
$t.cache = 0;
var Pn = function() {
    function t(n) {
        this.init(n)
    }
    var e = t.prototype;
    return e.init = function(r) {
        Hu || gg(Yn) || console.warn("Please gsap.registerPlugin(Observer)"), Gs || mg();
        var i = r.tolerance,
            o = r.dragMinimum,
            s = r.type,
            a = r.target,
            l = r.lineHeight,
            c = r.debounce,
            d = r.preventDefault,
            f = r.onStop,
            h = r.onStopDelay,
            p = r.ignore,
            m = r.wheelSpeed,
            g = r.event,
            y = r.onDragStart,
            x = r.onDragEnd,
            w = r.onDrag,
            M = r.onPress,
            T = r.onRelease,
            O = r.onRight,
            R = r.onLeft,
            P = r.onUp,
            B = r.onDown,
            te = r.onChangeX,
            W = r.onChangeY,
            ee = r.onChange,
            V = r.onToggleX,
            I = r.onToggleY,
            X = r.onHover,
            q = r.onHoverEnd,
            Z = r.onMove,
            le = r.ignoreCheck,
            Se = r.isNormalizer,
            Me = r.onGestureStart,
            z = r.onGestureEnd,
            ge = r.onWheel,
            $e = r.onEnable,
            Xe = r.onDisable,
            tt = r.onClick,
            wt = r.scrollSpeed,
            Ue = r.capture,
            Ye = r.allowClicks,
            Ge = r.lockAxis,
            rt = r.onLockAxis;
        this.target = a = vr(a) || Yi, this.vars = r, p && (p = Yn.utils.toArray(p)), i = i || 1e-9, o = o || 0, m = m || 1, wt = wt || 1, s = s || "wheel,touch,pointer", c = c !== !1, l || (l = parseFloat(Tr.getComputedStyle(Qo).lineHeight) || 22);
        var it, lt, Lt, Ne, ct, ot, gt, re = this,
            pt = 0,
            It = 0,
            At = eo(a, fr),
            Je = eo(a, Fn),
            fn = At(),
            Ce = Je(),
            _e = ~s.indexOf("touch") && !~s.indexOf("pointer") && Zr[0] === "pointerdown",
            Ve = Xs(a),
            qe = a.ownerDocument || Gi,
            pe = [0, 0, 0],
            Mt = [0, 0, 0],
            Bt = 0,
            vt = function() {
                return Bt = Ys()
            },
            Yt = function(ze, Ct) {
                return (re.event = ze) && p && ~p.indexOf(ze.target) || Ct && _e && ze.pointerType !== "touch" || le && le(ze, Ct)
            },
            C = function() {
                re._vx.reset(), re._vy.reset(), lt.pause(), f && f(re)
            },
            L = function() {
                var ze = re.deltaX = rh(pe),
                    Ct = re.deltaY = rh(Mt),
                    Wt = Math.abs(ze) >= i,
                    Fe = Math.abs(Ct) >= i;
                ee && (Wt || Fe) && ee(re, ze, Ct, pe, Mt), Wt && (O && re.deltaX > 0 && O(re), R && re.deltaX < 0 && R(re), te && te(re), V && re.deltaX < 0 != pt < 0 && V(re), pt = re.deltaX, pe[0] = pe[1] = pe[2] = 0), Fe && (B && re.deltaY > 0 && B(re), P && re.deltaY < 0 && P(re), W && W(re), I && re.deltaY < 0 != It < 0 && I(re), It = re.deltaY, Mt[0] = Mt[1] = Mt[2] = 0), (Ne || Lt) && (Z && Z(re), Lt && (w(re), Lt = !1), Ne = !1), ot && !(ot = !1) && rt && rt(re), ct && (ge(re), ct = !1), it = 0
            },
            ce = function(ze, Ct, Wt) {
                pe[Wt] += ze, Mt[Wt] += Ct, re._vx.update(ze), re._vy.update(Ct), c ? it || (it = requestAnimationFrame(L)) : L()
            },
            oe = function(ze, Ct) {
                Ge && !gt && (re.axis = gt = Math.abs(ze) > Math.abs(Ct) ? "x" : "y", ot = !0), gt !== "y" && (pe[2] += ze, re._vx.update(ze, !0)), gt !== "x" && (Mt[2] += Ct, re._vy.update(Ct, !0)), c ? it || (it = requestAnimationFrame(L)) : L()
            },
            ve = function(ze) {
                if (!Yt(ze, 1)) {
                    ze = $s(ze, d);
                    var Ct = ze.clientX,
                        Wt = ze.clientY,
                        Fe = Ct - re.x,
                        ht = Wt - re.y,
                        Ke = re.isDragging;
                    re.x = Ct, re.y = Wt, (Ke || Math.abs(re.startX - Ct) >= o || Math.abs(re.startY - Wt) >= o) && (w && (Lt = !0), Ke || (re.isDragging = !0), oe(Fe, ht), Ke || y && y(re))
                }
            },
            Ee = re.onPress = function(je) {
                Yt(je, 1) || je && je.button || (re.axis = gt = null, lt.pause(), re.isPressed = !0, je = $s(je), pt = It = 0, re.startX = re.x = je.clientX, re.startY = re.y = je.clientY, re._vx.reset(), re._vy.reset(), sr(Se ? a : qe, Zr[1], ve, d, !0), re.deltaX = re.deltaY = 0, M && M(re))
            },
            Ae = re.onRelease = function(je) {
                if (!Yt(je, 1)) {
                    ir(Se ? a : qe, Zr[1], ve, !0);
                    var ze = !isNaN(re.y - re.startY),
                        Ct = re.isDragging && (Math.abs(re.x - re.startX) > 3 || Math.abs(re.y - re.startY) > 3),
                        Wt = $s(je);
                    !Ct && ze && (re._vx.reset(), re._vy.reset(), d && Ye && Yn.delayedCall(.08, function() {
                        if (Ys() - Bt > 300 && !je.defaultPrevented) {
                            if (je.target.click) je.target.click();
                            else if (qe.createEvent) {
                                var Fe = qe.createEvent("MouseEvents");
                                Fe.initMouseEvent("click", !0, !0, Tr, 1, Wt.screenX, Wt.screenY, Wt.clientX, Wt.clientY, !1, !1, !1, !1, 0, null), je.target.dispatchEvent(Fe)
                            }
                        }
                    })), re.isDragging = re.isGesturing = re.isPressed = !1, f && !Se && lt.restart(!0), x && Ct && x(re), T && T(re, Ct)
                }
            },
            Oe = function(ze) {
                return ze.touches && ze.touches.length > 1 && (re.isGesturing = !0) && Me(ze, re.isDragging)
            },
            yt = function() {
                return (re.isGesturing = !1) || z(re)
            },
            St = function(ze) {
                if (!Yt(ze)) {
                    var Ct = At(),
                        Wt = Je();
                    ce((Ct - fn) * wt, (Wt - Ce) * wt, 1), fn = Ct, Ce = Wt, f && lt.restart(!0)
                }
            },
            ut = function(ze) {
                if (!Yt(ze)) {
                    ze = $s(ze, d), ge && (ct = !0);
                    var Ct = (ze.deltaMode === 1 ? l : ze.deltaMode === 2 ? Tr.innerHeight : 1) * m;
                    ce(ze.deltaX * Ct, ze.deltaY * Ct, 0), f && !Se && lt.restart(!0)
                }
            },
            Nt = function(ze) {
                if (!Yt(ze)) {
                    var Ct = ze.clientX,
                        Wt = ze.clientY,
                        Fe = Ct - re.x,
                        ht = Wt - re.y;
                    re.x = Ct, re.y = Wt, Ne = !0, (Fe || ht) && oe(Fe, ht)
                }
            },
            Xt = function(ze) {
                re.event = ze, X(re)
            },
            Rn = function(ze) {
                re.event = ze, q(re)
            },
            Ft = function(ze) {
                return Yt(ze) || $s(ze, d) && tt(re)
            };
        lt = re._dc = Yn.delayedCall(h || .25, C).pause(), re.deltaX = re.deltaY = 0, re._vx = Xu(0, 50, !0), re._vy = Xu(0, 50, !0), re.scrollX = At, re.scrollY = Je, re.isDragging = re.isGesturing = re.isPressed = !1, dg(this), re.enable = function(je) {
            return re.isEnabled || (sr(Ve ? qe : a, "scroll", Yu), s.indexOf("scroll") >= 0 && sr(Ve ? qe : a, "scroll", St, d, Ue), s.indexOf("wheel") >= 0 && sr(a, "wheel", ut, d, Ue), (s.indexOf("touch") >= 0 && ug || s.indexOf("pointer") >= 0) && (sr(a, Zr[0], Ee, d, Ue), sr(qe, Zr[2], Ae), sr(qe, Zr[3], Ae), Ye && sr(a, "click", vt, !1, !0), tt && sr(a, "click", Ft), Me && sr(qe, "gesturestart", Oe), z && sr(qe, "gestureend", yt), X && sr(a, co + "enter", Xt), q && sr(a, co + "leave", Rn), Z && sr(a, co + "move", Nt)), re.isEnabled = !0, je && je.type && Ee(je), $e && $e(re)), re
        }, re.disable = function() {
            re.isEnabled && (Ho.filter(function(je) {
                return je !== re && Xs(je.target)
            }).length || ir(Ve ? qe : a, "scroll", Yu), re.isPressed && (re._vx.reset(), re._vy.reset(), ir(Se ? a : qe, Zr[1], ve, !0)), ir(Ve ? qe : a, "scroll", St, Ue), ir(a, "wheel", ut, Ue), ir(a, Zr[0], Ee, Ue), ir(qe, Zr[2], Ae), ir(qe, Zr[3], Ae), ir(a, "click", vt, !0), ir(a, "click", Ft), ir(qe, "gesturestart", Oe), ir(qe, "gestureend", yt), ir(a, co + "enter", Xt), ir(a, co + "leave", Rn), ir(a, co + "move", Nt), re.isEnabled = re.isPressed = re.isDragging = !1, Xe && Xe(re))
        }, re.kill = re.revert = function() {
            re.disable();
            var je = Ho.indexOf(re);
            je >= 0 && Ho.splice(je, 1), Ci === re && (Ci = 0)
        }, Ho.push(re), Se && Xs(a) && (Ci = re), re.enable(g)
    }, UC(t, [{
        key: "velocityX",
        get: function() {
            return this._vx.getVelocity()
        }
    }, {
        key: "velocityY",
        get: function() {
            return this._vy.getVelocity()
        }
    }]), t
}();
Pn.version = "3.12.2";
Pn.create = function(t) {
    return new Pn(t)
};
Pn.register = gg;
Pn.getAll = function() {
    return Ho.slice()
};
Pn.getById = function(t) {
    return Ho.filter(function(e) {
        return e.vars.id === t
    })[0]
};
pg() && Yn.registerPlugin(Pn);
/*!
 * ScrollTrigger 3.12.2
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var Be, Lo, Ot, vn, Qr, cn, vg, Wl, Vl, Go, fl, qa, Zn, fc, qu, lr, ih, oh, No, yg, Nc, xg, Dr, bg, wg, _g, Vi, Ku, Qf, Jo, Jf, zc, Ka = 1,
    ur = Date.now,
    Ic = ur(),
    Wr = 0,
    js = 0,
    sh = function(e, n, r) {
        var i = Cr(e) && (e.substr(0, 6) === "clamp(" || e.indexOf("max") > -1);
        return r["_" + n + "Clamp"] = i, i ? e.substr(6, e.length - 7) : e
    },
    ah = function(e, n) {
        return n && (!Cr(e) || e.substr(0, 6) !== "clamp(") ? "clamp(" + e + ")" : e
    },
    GC = function t() {
        return js && requestAnimationFrame(t)
    },
    lh = function() {
        return fc = 1
    },
    ch = function() {
        return fc = 0
    },
    ci = function(e) {
        return e
    },
    Ls = function(e) {
        return Math.round(e * 1e5) / 1e5 || 0
    },
    Dg = function() {
        return typeof window < "u"
    },
    Sg = function() {
        return Be || Dg() && (Be = window.gsap) && Be.registerPlugin && Be
    },
    Eo = function(e) {
        return !!~vg.indexOf(e)
    },
    Cg = function(e) {
        return (e === "Height" ? Jf : Ot["inner" + e]) || Qr["client" + e] || cn["client" + e]
    },
    Eg = function(e) {
        return qi(e, "getBoundingClientRect") || (Eo(e) ? function() {
            return vl.width = Ot.innerWidth, vl.height = Jf, vl
        } : function() {
            return _i(e)
        })
    },
    YC = function(e, n, r) {
        var i = r.d,
            o = r.d2,
            s = r.a;
        return (s = qi(e, "getBoundingClientRect")) ? function() {
            return s()[i]
        } : function() {
            return (n ? Cg(o) : e["client" + o]) || 0
        }
    },
    XC = function(e, n) {
        return !n || ~di.indexOf(e) ? Eg(e) : function() {
            return vl
        }
    },
    Ei = function(e, n) {
        var r = n.s,
            i = n.d2,
            o = n.d,
            s = n.a;
        return Math.max(0, (r = "scroll" + i) && (s = qi(e, r)) ? s() - Eg(e)()[o] : Eo(e) ? (Qr[r] || cn[r]) - Cg(i) : e[r] - e["offset" + i])
    },
    Za = function(e, n) {
        for (var r = 0; r < No.length; r += 3)(!n || ~n.indexOf(No[r + 1])) && e(No[r], No[r + 1], No[r + 2])
    },
    Cr = function(e) {
        return typeof e == "string"
    },
    dr = function(e) {
        return typeof e == "function"
    },
    dl = function(e) {
        return typeof e == "number"
    },
    uo = function(e) {
        return typeof e == "object"
    },
    As = function(e, n, r) {
        return e && e.progress(n ? 0 : 1) && r && e.pause()
    },
    Bc = function(e, n) {
        if (e.enabled) {
            var r = n(e);
            r && r.totalTime && (e.callbackAnimation = r)
        }
    },
    Ao = Math.abs,
    Tg = "left",
    Pg = "top",
    ed = "right",
    td = "bottom",
    xo = "width",
    bo = "height",
    qs = "Right",
    Ks = "Left",
    Zs = "Top",
    Qs = "Bottom",
    En = "padding",
    Lr = "margin",
    ls = "Width",
    nd = "Height",
    Hn = "px",
    Nr = function(e) {
        return Ot.getComputedStyle(e)
    },
    qC = function(e) {
        var n = Nr(e).position;
        e.style.position = n === "absolute" || n === "fixed" ? n : "relative"
    },
    uh = function(e, n) {
        for (var r in n) r in e || (e[r] = n[r]);
        return e
    },
    _i = function(e, n) {
        var r = n && Nr(e)[qu] !== "matrix(1, 0, 0, 1, 0, 0)" && Be.to(e, {
                x: 0,
                y: 0,
                xPercent: 0,
                yPercent: 0,
                rotation: 0,
                rotationX: 0,
                rotationY: 0,
                scale: 1,
                skewX: 0,
                skewY: 0
            }).progress(1),
            i = e.getBoundingClientRect();
        return r && r.progress(0).kill(), i
    },
    Zu = function(e, n) {
        var r = n.d2;
        return e["offset" + r] || e["client" + r] || 0
    },
    Rg = function(e) {
        var n = [],
            r = e.labels,
            i = e.duration(),
            o;
        for (o in r) n.push(r[o] / i);
        return n
    },
    KC = function(e) {
        return function(n) {
            return Be.utils.snap(Rg(e), n)
        }
    },
    rd = function(e) {
        var n = Be.utils.snap(e),
            r = Array.isArray(e) && e.slice(0).sort(function(i, o) {
                return i - o
            });
        return r ? function(i, o, s) {
            s === void 0 && (s = .001);
            var a;
            if (!o) return n(i);
            if (o > 0) {
                for (i -= s, a = 0; a < r.length; a++)
                    if (r[a] >= i) return r[a];
                return r[a - 1]
            } else
                for (a = r.length, i += s; a--;)
                    if (r[a] <= i) return r[a];
            return r[0]
        } : function(i, o, s) {
            s === void 0 && (s = .001);
            var a = n(i);
            return !o || Math.abs(a - i) < s || a - i < 0 == o < 0 ? a : n(o < 0 ? i - e : i + e)
        }
    },
    ZC = function(e) {
        return function(n, r) {
            return rd(Rg(e))(n, r.direction)
        }
    },
    Qa = function(e, n, r, i) {
        return r.split(",").forEach(function(o) {
            return e(n, o, i)
        })
    },
    Ln = function(e, n, r, i, o) {
        return e.addEventListener(n, r, {
            passive: !i,
            capture: !!o
        })
    },
    jn = function(e, n, r, i) {
        return e.removeEventListener(n, r, !!i)
    },
    Ja = function(e, n, r) {
        r = r && r.wheelHandler, r && (e(n, "wheel", r), e(n, "touchmove", r))
    },
    fh = {
        startColor: "green",
        endColor: "red",
        indent: 0,
        fontSize: "16px",
        fontWeight: "normal"
    },
    el = {
        toggleActions: "play",
        anticipatePin: 0
    },
    Ul = {
        top: 0,
        left: 0,
        center: .5,
        bottom: 1,
        right: 1
    },
    pl = function(e, n) {
        if (Cr(e)) {
            var r = e.indexOf("="),
                i = ~r ? +(e.charAt(r - 1) + 1) * parseFloat(e.substr(r + 1)) : 0;
            ~r && (e.indexOf("%") > r && (i *= n / 100), e = e.substr(0, r - 1)), e = i + (e in Ul ? Ul[e] * n : ~e.indexOf("%") ? parseFloat(e) * n / 100 : parseFloat(e) || 0)
        }
        return e
    },
    tl = function(e, n, r, i, o, s, a, l) {
        var c = o.startColor,
            d = o.endColor,
            f = o.fontSize,
            h = o.indent,
            p = o.fontWeight,
            m = vn.createElement("div"),
            g = Eo(r) || qi(r, "pinType") === "fixed",
            y = e.indexOf("scroller") !== -1,
            x = g ? cn : r,
            w = e.indexOf("start") !== -1,
            M = w ? c : d,
            T = "border-color:" + M + ";font-size:" + f + ";color:" + M + ";font-weight:" + p + ";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";
        return T += "position:" + ((y || l) && g ? "fixed;" : "absolute;"), (y || l || !g) && (T += (i === Fn ? ed : td) + ":" + (s + parseFloat(h)) + "px;"), a && (T += "box-sizing:border-box;text-align:left;width:" + a.offsetWidth + "px;"), m._isStart = w, m.setAttribute("class", "gsap-marker-" + e + (n ? " marker-" + n : "")), m.style.cssText = T, m.innerText = n || n === 0 ? e + "-" + n : e, x.children[0] ? x.insertBefore(m, x.children[0]) : x.appendChild(m), m._offset = m["offset" + i.op.d2], hl(m, 0, i, w), m
    },
    hl = function(e, n, r, i) {
        var o = {
                display: "block"
            },
            s = r[i ? "os2" : "p2"],
            a = r[i ? "p2" : "os2"];
        e._isFlipped = i, o[r.a + "Percent"] = i ? -100 : 0, o[r.a] = i ? "1px" : 0, o["border" + s + ls] = 1, o["border" + a + ls] = 0, o[r.p] = n + "px", Be.set(e, o)
    },
    Rt = [],
    Qu = {},
    da, dh = function() {
        return ur() - Wr > 34 && (da || (da = requestAnimationFrame(Ri)))
    },
    Fo = function() {
        (!Dr || !Dr.isPressed || Dr.startX > cn.clientWidth) && ($t.cache++, Dr ? da || (da = requestAnimationFrame(Ri)) : Ri(), Wr || Po("scrollStart"), Wr = ur())
    },
    Wc = function() {
        _g = Ot.innerWidth, wg = Ot.innerHeight
    },
    Ns = function() {
        $t.cache++, !Zn && !xg && !vn.fullscreenElement && !vn.webkitFullscreenElement && (!bg || _g !== Ot.innerWidth || Math.abs(Ot.innerHeight - wg) > Ot.innerHeight * .25) && Wl.restart(!0)
    },
    To = {},
    QC = [],
    Mg = function t() {
        return jn(Dt, "scrollEnd", t) || po(!0)
    },
    Po = function(e) {
        return To[e] && To[e].map(function(n) {
            return n()
        }) || QC
    },
    Sr = [],
    $g = function(e) {
        for (var n = 0; n < Sr.length; n += 5)(!e || Sr[n + 4] && Sr[n + 4].query === e) && (Sr[n].style.cssText = Sr[n + 1], Sr[n].getBBox && Sr[n].setAttribute("transform", Sr[n + 2] || ""), Sr[n + 3].uncache = 1)
    },
    id = function(e, n) {
        var r;
        for (lr = 0; lr < Rt.length; lr++) r = Rt[lr], r && (!n || r._ctx === n) && (e ? r.kill(1) : r.revert(!0, !0));
        n && $g(n), n || Po("revert")
    },
    Ag = function(e, n) {
        $t.cache++, (n || !cr) && $t.forEach(function(r) {
            return dr(r) && r.cacheID++ && (r.rec = 0)
        }), Cr(e) && (Ot.history.scrollRestoration = Qf = e)
    },
    cr, wo = 0,
    ph, JC = function() {
        if (ph !== wo) {
            var e = ph = wo;
            requestAnimationFrame(function() {
                return e === wo && po(!0)
            })
        }
    },
    Fg = function() {
        cn.appendChild(Jo), Jf = Jo.offsetHeight || Ot.innerHeight, cn.removeChild(Jo)
    },
    po = function(e, n) {
        if (Wr && !e) {
            Ln(Dt, "scrollEnd", Mg);
            return
        }
        Fg(), cr = Dt.isRefreshing = !0, $t.forEach(function(i) {
            return dr(i) && ++i.cacheID && (i.rec = i())
        });
        var r = Po("refreshInit");
        yg && Dt.sort(), n || id(), $t.forEach(function(i) {
            dr(i) && (i.smooth && (i.target.style.scrollBehavior = "auto"), i(0))
        }), Rt.slice(0).forEach(function(i) {
            return i.refresh()
        }), Rt.forEach(function(i, o) {
            if (i._subPinOffset && i.pin) {
                var s = i.vars.horizontal ? "offsetWidth" : "offsetHeight",
                    a = i.pin[s];
                i.revert(!0, 1), i.adjustPinSpacing(i.pin[s] - a), i.refresh()
            }
        }), Rt.forEach(function(i) {
            var o = Ei(i.scroller, i._dir);
            (i.vars.end === "max" || i._endClamp && i.end > o) && i.setPositions(i.start, Math.max(i.start + 1, o), !0)
        }), r.forEach(function(i) {
            return i && i.render && i.render(-1)
        }), $t.forEach(function(i) {
            dr(i) && (i.smooth && requestAnimationFrame(function() {
                return i.target.style.scrollBehavior = "smooth"
            }), i.rec && i(i.rec))
        }), Ag(Qf, 1), Wl.pause(), wo++, cr = 2, Ri(2), Rt.forEach(function(i) {
            return dr(i.vars.onRefresh) && i.vars.onRefresh(i)
        }), cr = Dt.isRefreshing = !1, Po("refresh")
    },
    Ju = 0,
    ml = 1,
    Js, Ri = function(e) {
        if (!cr || e === 2) {
            Dt.isUpdating = !0, Js && Js.update(0);
            var n = Rt.length,
                r = ur(),
                i = r - Ic >= 50,
                o = n && Rt[0].scroll();
            if (ml = Ju > o ? -1 : 1, cr || (Ju = o), i && (Wr && !fc && r - Wr > 200 && (Wr = 0, Po("scrollEnd")), fl = Ic, Ic = r), ml < 0) {
                for (lr = n; lr-- > 0;) Rt[lr] && Rt[lr].update(0, i);
                ml = 1
            } else
                for (lr = 0; lr < n; lr++) Rt[lr] && Rt[lr].update(0, i);
            Dt.isUpdating = !1
        }
        da = 0
    },
    ef = [Tg, Pg, td, ed, Lr + Qs, Lr + qs, Lr + Zs, Lr + Ks, "display", "flexShrink", "float", "zIndex", "gridColumnStart", "gridColumnEnd", "gridRowStart", "gridRowEnd", "gridArea", "justifySelf", "alignSelf", "placeSelf", "order"],
    gl = ef.concat([xo, bo, "boxSizing", "max" + ls, "max" + nd, "position", Lr, En, En + Zs, En + qs, En + Qs, En + Ks]),
    eE = function(e, n, r) {
        es(r);
        var i = e._gsap;
        if (i.spacerIsNative) es(i.spacerState);
        else if (e._gsap.swappedIn) {
            var o = n.parentNode;
            o && (o.insertBefore(e, n), o.removeChild(n))
        }
        e._gsap.swappedIn = !1
    },
    Vc = function(e, n, r, i) {
        if (!e._gsap.swappedIn) {
            for (var o = ef.length, s = n.style, a = e.style, l; o--;) l = ef[o], s[l] = r[l];
            s.position = r.position === "absolute" ? "absolute" : "relative", r.display === "inline" && (s.display = "inline-block"), a[td] = a[ed] = "auto", s.flexBasis = r.flexBasis || "auto", s.overflow = "visible", s.boxSizing = "border-box", s[xo] = Zu(e, fr) + Hn, s[bo] = Zu(e, Fn) + Hn, s[En] = a[Lr] = a[Pg] = a[Tg] = "0", es(i), a[xo] = a["max" + ls] = r[xo], a[bo] = a["max" + nd] = r[bo], a[En] = r[En], e.parentNode !== n && (e.parentNode.insertBefore(n, e), n.appendChild(e)), e._gsap.swappedIn = !0
        }
    },
    tE = /([A-Z])/g,
    es = function(e) {
        if (e) {
            var n = e.t.style,
                r = e.length,
                i = 0,
                o, s;
            for ((e.t._gsap || Be.core.getCache(e.t)).uncache = 1; i < r; i += 2) s = e[i + 1], o = e[i], s ? n[o] = s : n[o] && n.removeProperty(o.replace(tE, "-$1").toLowerCase())
        }
    },
    nl = function(e) {
        for (var n = gl.length, r = e.style, i = [], o = 0; o < n; o++) i.push(gl[o], r[gl[o]]);
        return i.t = e, i
    },
    nE = function(e, n, r) {
        for (var i = [], o = e.length, s = r ? 8 : 0, a; s < o; s += 2) a = e[s], i.push(a, a in n ? n[a] : e[s + 1]);
        return i.t = e.t, i
    },
    vl = {
        left: 0,
        top: 0
    },
    hh = function(e, n, r, i, o, s, a, l, c, d, f, h, p, m) {
        dr(e) && (e = e(l)), Cr(e) && e.substr(0, 3) === "max" && (e = h + (e.charAt(4) === "=" ? pl("0" + e.substr(3), r) : 0));
        var g = p ? p.time() : 0,
            y, x, w;
        if (p && p.seek(0), isNaN(e) || (e = +e), dl(e)) p && (e = Be.utils.mapRange(p.scrollTrigger.start, p.scrollTrigger.end, 0, h, e)), a && hl(a, r, i, !0);
        else {
            dr(n) && (n = n(l));
            var M = (e || "0").split(" "),
                T, O, R, P;
            w = vr(n, l) || cn, T = _i(w) || {}, (!T || !T.left && !T.top) && Nr(w).display === "none" && (P = w.style.display, w.style.display = "block", T = _i(w), P ? w.style.display = P : w.style.removeProperty("display")), O = pl(M[0], T[i.d]), R = pl(M[1] || "0", r), e = T[i.p] - c[i.p] - d + O + o - R, a && hl(a, R, i, r - R < 20 || a._isStart && R > 20), r -= r - R
        }
        if (m && (l[m] = e || -.001, e < 0 && (e = 0)), s) {
            var B = e + r,
                te = s._isStart;
            y = "scroll" + i.d2, hl(s, B, i, te && B > 20 || !te && (f ? Math.max(cn[y], Qr[y]) : s.parentNode[y]) <= B + 1), f && (c = _i(a), f && (s.style[i.op.p] = c[i.op.p] - i.op.m - s._offset + Hn))
        }
        return p && w && (y = _i(w), p.seek(h), x = _i(w), p._caScrollDist = y[i.p] - x[i.p], e = e / p._caScrollDist * h), p && p.seek(g), p ? e : Math.round(e)
    },
    rE = /(webkit|moz|length|cssText|inset)/i,
    mh = function(e, n, r, i) {
        if (e.parentNode !== n) {
            var o = e.style,
                s, a;
            if (n === cn) {
                e._stOrig = o.cssText, a = Nr(e);
                for (s in a) !+s && !rE.test(s) && a[s] && typeof o[s] == "string" && s !== "0" && (o[s] = a[s]);
                o.top = r, o.left = i
            } else o.cssText = e._stOrig;
            Be.core.getCache(e).uncache = 1, n.appendChild(e)
        }
    },
    kg = function(e, n, r) {
        var i = n,
            o = i;
        return function(s) {
            var a = Math.round(e());
            return a !== i && a !== o && Math.abs(a - i) > 3 && Math.abs(a - o) > 3 && (s = a, r && r()), o = i, i = s, s
        }
    },
    rl = function(e, n, r) {
        var i = {};
        i[n.p] = "+=" + r, Be.set(e, i)
    },
    gh = function(e, n) {
        var r = eo(e, n),
            i = "_scroll" + n.p2,
            o = function s(a, l, c, d, f) {
                var h = s.tween,
                    p = l.onComplete,
                    m = {};
                c = c || r();
                var g = kg(r, c, function() {
                    h.kill(), s.tween = 0
                });
                return f = d && f || 0, d = d || a - c, h && h.kill(), l[i] = a, l.modifiers = m, m[i] = function() {
                    return g(c + d * h.ratio + f * h.ratio * h.ratio)
                }, l.onUpdate = function() {
                    $t.cache++, Ri()
                }, l.onComplete = function() {
                    s.tween = 0, p && p.call(h)
                }, h = s.tween = Be.to(e, l), h
            };
        return e[i] = r, r.wheelHandler = function() {
            return o.tween && o.tween.kill() && (o.tween = 0)
        }, Ln(e, "wheel", r.wheelHandler), Dt.isTouch && Ln(e, "touchmove", r.wheelHandler), o
    },
    Dt = function() {
        function t(n, r) {
            Lo || t.register(Be) || console.warn("Please gsap.registerPlugin(ScrollTrigger)"), Ku(this), this.init(n, r)
        }
        var e = t.prototype;
        return e.init = function(r, i) {
            if (this.progress = this.start = 0, this.vars && this.kill(!0, !0), !js) {
                this.update = this.refresh = this.kill = ci;
                return
            }
            r = uh(Cr(r) || dl(r) || r.nodeType ? {
                trigger: r
            } : r, el);
            var o = r,
                s = o.onUpdate,
                a = o.toggleClass,
                l = o.id,
                c = o.onToggle,
                d = o.onRefresh,
                f = o.scrub,
                h = o.trigger,
                p = o.pin,
                m = o.pinSpacing,
                g = o.invalidateOnRefresh,
                y = o.anticipatePin,
                x = o.onScrubComplete,
                w = o.onSnapComplete,
                M = o.once,
                T = o.snap,
                O = o.pinReparent,
                R = o.pinSpacer,
                P = o.containerAnimation,
                B = o.fastScrollEnd,
                te = o.preventOverlaps,
                W = r.horizontal || r.containerAnimation && r.horizontal !== !1 ? fr : Fn,
                ee = !f && f !== 0,
                V = vr(r.scroller || Ot),
                I = Be.core.getCache(V),
                X = Eo(V),
                q = ("pinType" in r ? r.pinType : qi(V, "pinType") || X && "fixed") === "fixed",
                Z = [r.onEnter, r.onLeave, r.onEnterBack, r.onLeaveBack],
                le = ee && r.toggleActions.split(" "),
                Se = "markers" in r ? r.markers : el.markers,
                Me = X ? 0 : parseFloat(Nr(V)["border" + W.p2 + ls]) || 0,
                z = this,
                ge = r.onRefreshInit && function() {
                    return r.onRefreshInit(z)
                },
                $e = YC(V, X, W),
                Xe = XC(V, X),
                tt = 0,
                wt = 0,
                Ue = 0,
                Ye = eo(V, W),
                Ge, rt, it, lt, Lt, Ne, ct, ot, gt, re, pt, It, At, Je, fn, Ce, _e, Ve, qe, pe, Mt, Bt, vt, Yt, C, L, ce, oe, ve, Ee, Ae, Oe, yt, St, ut, Nt, Xt, Rn, Ft;
            if (z._startClamp = z._endClamp = !1, z._dir = W, y *= 45, z.scroller = V, z.scroll = P ? P.time.bind(P) : Ye, lt = Ye(), z.vars = r, i = i || r.animation, "refreshPriority" in r && (yg = 1, r.refreshPriority === -9999 && (Js = z)), I.tweenScroll = I.tweenScroll || {
                    top: gh(V, Fn),
                    left: gh(V, fr)
                }, z.tweenTo = Ge = I.tweenScroll[W.p], z.scrubDuration = function(Fe) {
                    yt = dl(Fe) && Fe, yt ? Oe ? Oe.duration(Fe) : Oe = Be.to(i, {
                        ease: "expo",
                        totalProgress: "+=0",
                        duration: yt,
                        paused: !0,
                        onComplete: function() {
                            return x && x(z)
                        }
                    }) : (Oe && Oe.progress(1).kill(), Oe = 0)
                }, i && (i.vars.lazy = !1, i._initted && !z.isReverted || i.vars.immediateRender !== !1 && r.immediateRender !== !1 && i.duration() && i.render(0, !0, !0), z.animation = i.pause(), i.scrollTrigger = z, z.scrubDuration(f), Ee = 0, l || (l = i.vars.id)), T && ((!uo(T) || T.push) && (T = {
                    snapTo: T
                }), "scrollBehavior" in cn.style && Be.set(X ? [cn, Qr] : V, {
                    scrollBehavior: "auto"
                }), $t.forEach(function(Fe) {
                    return dr(Fe) && Fe.target === (X ? vn.scrollingElement || Qr : V) && (Fe.smooth = !1)
                }), it = dr(T.snapTo) ? T.snapTo : T.snapTo === "labels" ? KC(i) : T.snapTo === "labelsDirectional" ? ZC(i) : T.directional !== !1 ? function(Fe, ht) {
                    return rd(T.snapTo)(Fe, ur() - wt < 500 ? 0 : ht.direction)
                } : Be.utils.snap(T.snapTo), St = T.duration || {
                    min: .1,
                    max: 2
                }, St = uo(St) ? Go(St.min, St.max) : Go(St, St), ut = Be.delayedCall(T.delay || yt / 2 || .1, function() {
                    var Fe = Ye(),
                        ht = ur() - wt < 500,
                        Ke = Ge.tween;
                    if ((ht || Math.abs(z.getVelocity()) < 10) && !Ke && !fc && tt !== Fe) {
                        var xt = (Fe - Ne) / Je,
                            dn = i && !ee ? i.totalProgress() : xt,
                            mt = ht ? 0 : (dn - Ae) / (ur() - fl) * 1e3 || 0,
                            nn = Be.utils.clamp(-xt, 1 - xt, Ao(mt / 2) * mt / .185),
                            pn = xt + (T.inertia === !1 ? 0 : nn),
                            hn = Go(0, 1, it(pn, z)),
                            zt = Math.round(Ne + hn * Je),
                            k = T,
                            _ = k.onStart,
                            D = k.onInterrupt,
                            $ = k.onComplete;
                        if (Fe <= ct && Fe >= Ne && zt !== Fe) {
                            if (Ke && !Ke._initted && Ke.data <= Ao(zt - Fe)) return;
                            T.inertia === !1 && (nn = hn - xt), Ge(zt, {
                                duration: St(Ao(Math.max(Ao(pn - dn), Ao(hn - dn)) * .185 / mt / .05 || 0)),
                                ease: T.ease || "power3",
                                data: Ao(zt - Fe),
                                onInterrupt: function() {
                                    return ut.restart(!0) && D && D(z)
                                },
                                onComplete: function() {
                                    z.update(), tt = Ye(), Ee = Ae = i && !ee ? i.totalProgress() : z.progress, w && w(z), $ && $(z)
                                }
                            }, Fe, nn * Je, zt - Fe - nn * Je), _ && _(z, Ge.tween)
                        }
                    } else z.isActive && tt !== Fe && ut.restart(!0)
                }).pause()), l && (Qu[l] = z), h = z.trigger = vr(h || p !== !0 && p), Ft = h && h._gsap && h._gsap.stRevert, Ft && (Ft = Ft(z)), p = p === !0 ? h : vr(p), Cr(a) && (a = {
                    targets: h,
                    className: a
                }), p && (m === !1 || m === Lr || (m = !m && p.parentNode && p.parentNode.style && Nr(p.parentNode).display === "flex" ? !1 : En), z.pin = p, rt = Be.core.getCache(p), rt.spacer ? fn = rt.pinState : (R && (R = vr(R), R && !R.nodeType && (R = R.current || R.nativeElement), rt.spacerIsNative = !!R, R && (rt.spacerState = nl(R))), rt.spacer = Ve = R || vn.createElement("div"), Ve.classList.add("pin-spacer"), l && Ve.classList.add("pin-spacer-" + l), rt.pinState = fn = nl(p)), r.force3D !== !1 && Be.set(p, {
                    force3D: !0
                }), z.spacer = Ve = rt.spacer, ve = Nr(p), Yt = ve[m + W.os2], pe = Be.getProperty(p), Mt = Be.quickSetter(p, W.a, Hn), Vc(p, Ve, ve), _e = nl(p)), Se) {
                It = uo(Se) ? uh(Se, fh) : fh, re = tl("scroller-start", l, V, W, It, 0), pt = tl("scroller-end", l, V, W, It, 0, re), qe = re["offset" + W.op.d2];
                var je = vr(qi(V, "content") || V);
                ot = this.markerStart = tl("start", l, je, W, It, qe, 0, P), gt = this.markerEnd = tl("end", l, je, W, It, qe, 0, P), P && (Rn = Be.quickSetter([ot, gt], W.a, Hn)), !q && !(di.length && qi(V, "fixedMarkers") === !0) && (qC(X ? cn : V), Be.set([re, pt], {
                    force3D: !0
                }), L = Be.quickSetter(re, W.a, Hn), oe = Be.quickSetter(pt, W.a, Hn))
            }
            if (P) {
                var ze = P.vars.onUpdate,
                    Ct = P.vars.onUpdateParams;
                P.eventCallback("onUpdate", function() {
                    z.update(0, 0, 1), ze && ze.apply(P, Ct || [])
                })
            }
            if (z.previous = function() {
                    return Rt[Rt.indexOf(z) - 1]
                }, z.next = function() {
                    return Rt[Rt.indexOf(z) + 1]
                }, z.revert = function(Fe, ht) {
                    if (!ht) return z.kill(!0);
                    var Ke = Fe !== !1 || !z.enabled,
                        xt = Zn;
                    Ke !== z.isReverted && (Ke && (Nt = Math.max(Ye(), z.scroll.rec || 0), Ue = z.progress, Xt = i && i.progress()), ot && [ot, gt, re, pt].forEach(function(dn) {
                        return dn.style.display = Ke ? "none" : "block"
                    }), Ke && (Zn = z, z.update(Ke)), p && (!O || !z.isActive) && (Ke ? eE(p, Ve, fn) : Vc(p, Ve, Nr(p), C)), Ke || z.update(Ke), Zn = xt, z.isReverted = Ke)
                }, z.refresh = function(Fe, ht, Ke, xt) {
                    if (!((Zn || !z.enabled) && !ht)) {
                        if (p && Fe && Wr) {
                            Ln(t, "scrollEnd", Mg);
                            return
                        }!cr && ge && ge(z), Zn = z, Ge.tween && !Ke && (Ge.tween.kill(), Ge.tween = 0), Oe && Oe.pause(), g && i && i.revert({
                            kill: !1
                        }).invalidate(), z.isReverted || z.revert(!0, !0), z._subPinOffset = !1;
                        var dn = $e(),
                            mt = Xe(),
                            nn = P ? P.duration() : Ei(V, W),
                            pn = Je <= .01,
                            hn = 0,
                            zt = xt || 0,
                            k = uo(Ke) ? Ke.end : r.end,
                            _ = r.endTrigger || h,
                            D = uo(Ke) ? Ke.start : r.start || (r.start === 0 || !h ? 0 : p ? "0 0" : "0 100%"),
                            $ = z.pinnedContainer = r.pinnedContainer && vr(r.pinnedContainer, z),
                            A = h && Math.max(0, Rt.indexOf(z)) || 0,
                            N = A,
                            G, Q, J, Y, fe, K, me, De, Te, xe, ne, b, F;
                        for (Se && uo(Ke) && (b = Be.getProperty(re, W.p), F = Be.getProperty(pt, W.p)); N--;) K = Rt[N], K.end || K.refresh(0, 1) || (Zn = z), me = K.pin, me && (me === h || me === p || me === $) && !K.isReverted && (xe || (xe = []), xe.unshift(K), K.revert(!0, !0)), K !== Rt[N] && (A--, N--);
                        for (dr(D) && (D = D(z)), D = sh(D, "start", z), Ne = hh(D, h, dn, W, Ye(), ot, re, z, mt, Me, q, nn, P, z._startClamp && "_startClamp") || (p ? -.001 : 0), dr(k) && (k = k(z)), Cr(k) && !k.indexOf("+=") && (~k.indexOf(" ") ? k = (Cr(D) ? D.split(" ")[0] : "") + k : (hn = pl(k.substr(2), dn), k = Cr(D) ? D : (P ? Be.utils.mapRange(0, P.duration(), P.scrollTrigger.start, P.scrollTrigger.end, Ne) : Ne) + hn, _ = h)), k = sh(k, "end", z), ct = Math.max(Ne, hh(k || (_ ? "100% 0" : nn), _, dn, W, Ye() + hn, gt, pt, z, mt, Me, q, nn, P, z._endClamp && "_endClamp")) || -.001, hn = 0, N = A; N--;) K = Rt[N], me = K.pin, me && K.start - K._pinPush <= Ne && !P && K.end > 0 && (G = K.end - (z._startClamp ? Math.max(0, K.start) : K.start), (me === h && K.start - K._pinPush < Ne || me === $) && isNaN(D) && (hn += G * (1 - K.progress)), me === p && (zt += G));
                        if (Ne += hn, ct += hn, z._startClamp && (z._startClamp += hn), z._endClamp && !cr && (z._endClamp = ct || -.001, ct = Math.min(ct, Ei(V, W))), Je = ct - Ne || (Ne -= .01) && .001, pn && (Ue = Be.utils.clamp(0, 1, Be.utils.normalize(Ne, ct, Nt))), z._pinPush = zt, ot && hn && (G = {}, G[W.a] = "+=" + hn, $ && (G[W.p] = "-=" + Ye()), Be.set([ot, gt], G)), p) G = Nr(p), Y = W === Fn, J = Ye(), Bt = parseFloat(pe(W.a)) + zt, !nn && ct > 1 && (ne = (X ? vn.scrollingElement || Qr : V).style, ne = {
                            style: ne,
                            value: ne["overflow" + W.a.toUpperCase()]
                        }, X && Nr(cn)["overflow" + W.a.toUpperCase()] !== "scroll" && (ne.style["overflow" + W.a.toUpperCase()] = "scroll")), Vc(p, Ve, G), _e = nl(p), Q = _i(p, !0), De = q && eo(V, Y ? fr : Fn)(), m && (C = [m + W.os2, Je + zt + Hn], C.t = Ve, N = m === En ? Zu(p, W) + Je + zt : 0, N && C.push(W.d, N + Hn), es(C), $ && Rt.forEach(function(E) {
                            E.pin === $ && E.vars.pinSpacing !== !1 && (E._subPinOffset = !0)
                        }), q && Ye(Nt)), q && (fe = {
                            top: Q.top + (Y ? J - Ne : De) + Hn,
                            left: Q.left + (Y ? De : J - Ne) + Hn,
                            boxSizing: "border-box",
                            position: "fixed"
                        }, fe[xo] = fe["max" + ls] = Math.ceil(Q.width) + Hn, fe[bo] = fe["max" + nd] = Math.ceil(Q.height) + Hn, fe[Lr] = fe[Lr + Zs] = fe[Lr + qs] = fe[Lr + Qs] = fe[Lr + Ks] = "0", fe[En] = G[En], fe[En + Zs] = G[En + Zs], fe[En + qs] = G[En + qs], fe[En + Qs] = G[En + Qs], fe[En + Ks] = G[En + Ks], Ce = nE(fn, fe, O), cr && Ye(0)), i ? (Te = i._initted, Nc(1), i.render(i.duration(), !0, !0), vt = pe(W.a) - Bt + Je + zt, ce = Math.abs(Je - vt) > 1, q && ce && Ce.splice(Ce.length - 2, 2), i.render(0, !0, !0), Te || i.invalidate(!0), i.parent || i.totalTime(i.totalTime()), Nc(0)) : vt = Je, ne && (ne.value ? ne.style["overflow" + W.a.toUpperCase()] = ne.value : ne.style.removeProperty("overflow-" + W.a));
                        else if (h && Ye() && !P)
                            for (Q = h.parentNode; Q && Q !== cn;) Q._pinOffset && (Ne -= Q._pinOffset, ct -= Q._pinOffset), Q = Q.parentNode;
                        xe && xe.forEach(function(E) {
                            return E.revert(!1, !0)
                        }), z.start = Ne, z.end = ct, lt = Lt = cr ? Nt : Ye(), !P && !cr && (lt < Nt && Ye(Nt), z.scroll.rec = 0), z.revert(!1, !0), wt = ur(), ut && (tt = -1, ut.restart(!0)), Zn = 0, i && ee && (i._initted || Xt) && i.progress() !== Xt && i.progress(Xt || 0, !0).render(i.time(), !0, !0), (pn || Ue !== z.progress || P) && (i && !ee && i.totalProgress(P && Ne < -.001 && !Ue ? Be.utils.normalize(Ne, ct, 0) : Ue, !0), z.progress = pn || (lt - Ne) / Je === Ue ? 0 : Ue), p && m && (Ve._pinOffset = Math.round(z.progress * vt)), Oe && Oe.invalidate(), isNaN(b) || (b -= Be.getProperty(re, W.p), F -= Be.getProperty(pt, W.p), rl(re, W, b), rl(ot, W, b - (xt || 0)), rl(pt, W, F), rl(gt, W, F - (xt || 0))), pn && !cr && z.update(), d && !cr && !At && (At = !0, d(z), At = !1)
                    }
                }, z.getVelocity = function() {
                    return (Ye() - Lt) / (ur() - fl) * 1e3 || 0
                }, z.endAnimation = function() {
                    As(z.callbackAnimation), i && (Oe ? Oe.progress(1) : i.paused() ? ee || As(i, z.direction < 0, 1) : As(i, i.reversed()))
                }, z.labelToScroll = function(Fe) {
                    return i && i.labels && (Ne || z.refresh() || Ne) + i.labels[Fe] / i.duration() * Je || 0
                }, z.getTrailing = function(Fe) {
                    var ht = Rt.indexOf(z),
                        Ke = z.direction > 0 ? Rt.slice(0, ht).reverse() : Rt.slice(ht + 1);
                    return (Cr(Fe) ? Ke.filter(function(xt) {
                        return xt.vars.preventOverlaps === Fe
                    }) : Ke).filter(function(xt) {
                        return z.direction > 0 ? xt.end <= Ne : xt.start >= ct
                    })
                }, z.update = function(Fe, ht, Ke) {
                    if (!(P && !Ke && !Fe)) {
                        var xt = cr === !0 ? Nt : z.scroll(),
                            dn = Fe ? 0 : (xt - Ne) / Je,
                            mt = dn < 0 ? 0 : dn > 1 ? 1 : dn || 0,
                            nn = z.progress,
                            pn, hn, zt, k, _, D, $, A;
                        if (ht && (Lt = lt, lt = P ? Ye() : xt, T && (Ae = Ee, Ee = i && !ee ? i.totalProgress() : mt)), y && !mt && p && !Zn && !Ka && Wr && Ne < xt + (xt - Lt) / (ur() - fl) * y && (mt = 1e-4), mt !== nn && z.enabled) {
                            if (pn = z.isActive = !!mt && mt < 1, hn = !!nn && nn < 1, D = pn !== hn, _ = D || !!mt != !!nn, z.direction = mt > nn ? 1 : -1, z.progress = mt, _ && !Zn && (zt = mt && !nn ? 0 : mt === 1 ? 1 : nn === 1 ? 2 : 3, ee && (k = !D && le[zt + 1] !== "none" && le[zt + 1] || le[zt], A = i && (k === "complete" || k === "reset" || k in i))), te && (D || A) && (A || f || !i) && (dr(te) ? te(z) : z.getTrailing(te).forEach(function(J) {
                                    return J.endAnimation()
                                })), ee || (Oe && !Zn && !Ka ? (Oe._dp._time - Oe._start !== Oe._time && Oe.render(Oe._dp._time - Oe._start), Oe.resetTo ? Oe.resetTo("totalProgress", mt, i._tTime / i._tDur) : (Oe.vars.totalProgress = mt, Oe.invalidate().restart())) : i && i.totalProgress(mt, !!(Zn && (wt || Fe)))), p) {
                                if (Fe && m && (Ve.style[m + W.os2] = Yt), !q) Mt(Ls(Bt + vt * mt));
                                else if (_) {
                                    if ($ = !Fe && mt > nn && ct + 1 > xt && xt + 1 >= Ei(V, W), O)
                                        if (!Fe && (pn || $)) {
                                            var N = _i(p, !0),
                                                G = xt - Ne;
                                            mh(p, cn, N.top + (W === Fn ? G : 0) + Hn, N.left + (W === Fn ? 0 : G) + Hn)
                                        } else mh(p, Ve);
                                    es(pn || $ ? Ce : _e), ce && mt < 1 && pn || Mt(Bt + (mt === 1 && !$ ? vt : 0))
                                }
                            }
                            T && !Ge.tween && !Zn && !Ka && ut.restart(!0), a && (D || M && mt && (mt < 1 || !zc)) && Vl(a.targets).forEach(function(J) {
                                return J.classList[pn || M ? "add" : "remove"](a.className)
                            }), s && !ee && !Fe && s(z), _ && !Zn ? (ee && (A && (k === "complete" ? i.pause().totalProgress(1) : k === "reset" ? i.restart(!0).pause() : k === "restart" ? i.restart(!0) : i[k]()), s && s(z)), (D || !zc) && (c && D && Bc(z, c), Z[zt] && Bc(z, Z[zt]), M && (mt === 1 ? z.kill(!1, 1) : Z[zt] = 0), D || (zt = mt === 1 ? 1 : 3, Z[zt] && Bc(z, Z[zt]))), B && !pn && Math.abs(z.getVelocity()) > (dl(B) ? B : 2500) && (As(z.callbackAnimation), Oe ? Oe.progress(1) : As(i, k === "reverse" ? 1 : !mt, 1))) : ee && s && !Zn && s(z)
                        }
                        if (oe) {
                            var Q = P ? xt / P.duration() * (P._caScrollDist || 0) : xt;
                            L(Q + (re._isFlipped ? 1 : 0)), oe(Q)
                        }
                        Rn && Rn(-xt / P.duration() * (P._caScrollDist || 0))
                    }
                }, z.enable = function(Fe, ht) {
                    z.enabled || (z.enabled = !0, Ln(V, "resize", Ns), X || Ln(V, "scroll", Fo), ge && Ln(t, "refreshInit", ge), Fe !== !1 && (z.progress = Ue = 0, lt = Lt = tt = Ye()), ht !== !1 && z.refresh())
                }, z.getTween = function(Fe) {
                    return Fe && Ge ? Ge.tween : Oe
                }, z.setPositions = function(Fe, ht, Ke, xt) {
                    if (P) {
                        var dn = P.scrollTrigger,
                            mt = P.duration(),
                            nn = dn.end - dn.start;
                        Fe = dn.start + nn * Fe / mt, ht = dn.start + nn * ht / mt
                    }
                    z.refresh(!1, !1, {
                        start: ah(Fe, Ke && !!z._startClamp),
                        end: ah(ht, Ke && !!z._endClamp)
                    }, xt), z.update()
                }, z.adjustPinSpacing = function(Fe) {
                    if (C && Fe) {
                        var ht = C.indexOf(W.d) + 1;
                        C[ht] = parseFloat(C[ht]) + Fe + Hn, C[1] = parseFloat(C[1]) + Fe + Hn, es(C)
                    }
                }, z.disable = function(Fe, ht) {
                    if (z.enabled && (Fe !== !1 && z.revert(!0, !0), z.enabled = z.isActive = !1, ht || Oe && Oe.pause(), Nt = 0, rt && (rt.uncache = 1), ge && jn(t, "refreshInit", ge), ut && (ut.pause(), Ge.tween && Ge.tween.kill() && (Ge.tween = 0)), !X)) {
                        for (var Ke = Rt.length; Ke--;)
                            if (Rt[Ke].scroller === V && Rt[Ke] !== z) return;
                        jn(V, "resize", Ns), X || jn(V, "scroll", Fo)
                    }
                }, z.kill = function(Fe, ht) {
                    z.disable(Fe, ht), Oe && !ht && Oe.kill(), l && delete Qu[l];
                    var Ke = Rt.indexOf(z);
                    Ke >= 0 && Rt.splice(Ke, 1), Ke === lr && ml > 0 && lr--, Ke = 0, Rt.forEach(function(xt) {
                        return xt.scroller === z.scroller && (Ke = 1)
                    }), Ke || cr || (z.scroll.rec = 0), i && (i.scrollTrigger = null, Fe && i.revert({
                        kill: !1
                    }), ht || i.kill()), ot && [ot, gt, re, pt].forEach(function(xt) {
                        return xt.parentNode && xt.parentNode.removeChild(xt)
                    }), Js === z && (Js = 0), p && (rt && (rt.uncache = 1), Ke = 0, Rt.forEach(function(xt) {
                        return xt.pin === p && Ke++
                    }), Ke || (rt.spacer = 0)), r.onKill && r.onKill(z)
                }, Rt.push(z), z.enable(!1, !1), Ft && Ft(z), i && i.add && !Je) {
                var Wt = z.update;
                z.update = function() {
                    z.update = Wt, Ne || ct || z.refresh()
                }, Be.delayedCall(.01, z.update), Je = .01, Ne = ct = 0
            } else z.refresh();
            p && JC()
        }, t.register = function(r) {
            return Lo || (Be = r || Sg(), Dg() && window.document && t.enable(), Lo = js), Lo
        }, t.defaults = function(r) {
            if (r)
                for (var i in r) el[i] = r[i];
            return el
        }, t.disable = function(r, i) {
            js = 0, Rt.forEach(function(s) {
                return s[i ? "kill" : "disable"](r)
            }), jn(Ot, "wheel", Fo), jn(vn, "scroll", Fo), clearInterval(qa), jn(vn, "touchcancel", ci), jn(cn, "touchstart", ci), Qa(jn, vn, "pointerdown,touchstart,mousedown", lh), Qa(jn, vn, "pointerup,touchend,mouseup", ch), Wl.kill(), Za(jn);
            for (var o = 0; o < $t.length; o += 3) Ja(jn, $t[o], $t[o + 1]), Ja(jn, $t[o], $t[o + 2])
        }, t.enable = function() {
            if (Ot = window, vn = document, Qr = vn.documentElement, cn = vn.body, Be && (Vl = Be.utils.toArray, Go = Be.utils.clamp, Ku = Be.core.context || ci, Nc = Be.core.suppressOverwrites || ci, Qf = Ot.history.scrollRestoration || "auto", Ju = Ot.pageYOffset, Be.core.globals("ScrollTrigger", t), cn)) {
                js = 1, Jo = document.createElement("div"), Jo.style.height = "100vh", Jo.style.position = "absolute", Fg(), GC(), Pn.register(Be), t.isTouch = Pn.isTouch, Vi = Pn.isTouch && /(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent), Ln(Ot, "wheel", Fo), vg = [Ot, vn, Qr, cn], Be.matchMedia ? (t.matchMedia = function(l) {
                    var c = Be.matchMedia(),
                        d;
                    for (d in l) c.add(d, l[d]);
                    return c
                }, Be.addEventListener("matchMediaInit", function() {
                    return id()
                }), Be.addEventListener("matchMediaRevert", function() {
                    return $g()
                }), Be.addEventListener("matchMedia", function() {
                    po(0, 1), Po("matchMedia")
                }), Be.matchMedia("(orientation: portrait)", function() {
                    return Wc(), Wc
                })) : console.warn("Requires GSAP 3.11.0 or later"), Wc(), Ln(vn, "scroll", Fo);
                var r = cn.style,
                    i = r.borderTopStyle,
                    o = Be.core.Animation.prototype,
                    s, a;
                for (o.revert || Object.defineProperty(o, "revert", {
                        value: function() {
                            return this.time(-.01, !0)
                        }
                    }), r.borderTopStyle = "solid", s = _i(cn), Fn.m = Math.round(s.top + Fn.sc()) || 0, fr.m = Math.round(s.left + fr.sc()) || 0, i ? r.borderTopStyle = i : r.removeProperty("border-top-style"), qa = setInterval(dh, 250), Be.delayedCall(.5, function() {
                        return Ka = 0
                    }), Ln(vn, "touchcancel", ci), Ln(cn, "touchstart", ci), Qa(Ln, vn, "pointerdown,touchstart,mousedown", lh), Qa(Ln, vn, "pointerup,touchend,mouseup", ch), qu = Be.utils.checkPrefix("transform"), gl.push(qu), Lo = ur(), Wl = Be.delayedCall(.2, po).pause(), No = [vn, "visibilitychange", function() {
                        var l = Ot.innerWidth,
                            c = Ot.innerHeight;
                        vn.hidden ? (ih = l, oh = c) : (ih !== l || oh !== c) && Ns()
                    }, vn, "DOMContentLoaded", po, Ot, "load", po, Ot, "resize", Ns], Za(Ln), Rt.forEach(function(l) {
                        return l.enable(0, 1)
                    }), a = 0; a < $t.length; a += 3) Ja(jn, $t[a], $t[a + 1]), Ja(jn, $t[a], $t[a + 2])
            }
        }, t.config = function(r) {
            "limitCallbacks" in r && (zc = !!r.limitCallbacks);
            var i = r.syncInterval;
            i && clearInterval(qa) || (qa = i) && setInterval(dh, i), "ignoreMobileResize" in r && (bg = t.isTouch === 1 && r.ignoreMobileResize), "autoRefreshEvents" in r && (Za(jn) || Za(Ln, r.autoRefreshEvents || "none"), xg = (r.autoRefreshEvents + "").indexOf("resize") === -1)
        }, t.scrollerProxy = function(r, i) {
            var o = vr(r),
                s = $t.indexOf(o),
                a = Eo(o);
            ~s && $t.splice(s, a ? 6 : 2), i && (a ? di.unshift(Ot, i, cn, i, Qr, i) : di.unshift(o, i))
        }, t.clearMatchMedia = function(r) {
            Rt.forEach(function(i) {
                return i._ctx && i._ctx.query === r && i._ctx.kill(!0, !0)
            })
        }, t.isInViewport = function(r, i, o) {
            var s = (Cr(r) ? vr(r) : r).getBoundingClientRect(),
                a = s[o ? xo : bo] * i || 0;
            return o ? s.right - a > 0 && s.left + a < Ot.innerWidth : s.bottom - a > 0 && s.top + a < Ot.innerHeight
        }, t.positionInViewport = function(r, i, o) {
            Cr(r) && (r = vr(r));
            var s = r.getBoundingClientRect(),
                a = s[o ? xo : bo],
                l = i == null ? a / 2 : i in Ul ? Ul[i] * a : ~i.indexOf("%") ? parseFloat(i) * a / 100 : parseFloat(i) || 0;
            return o ? (s.left + l) / Ot.innerWidth : (s.top + l) / Ot.innerHeight
        }, t.killAll = function(r) {
            if (Rt.slice(0).forEach(function(o) {
                    return o.vars.id !== "ScrollSmoother" && o.kill()
                }), r !== !0) {
                var i = To.killAll || [];
                To = {}, i.forEach(function(o) {
                    return o()
                })
            }
        }, t
    }();
Dt.version = "3.12.2";
Dt.saveStyles = function(t) {
    return t ? Vl(t).forEach(function(e) {
        if (e && e.style) {
            var n = Sr.indexOf(e);
            n >= 0 && Sr.splice(n, 5), Sr.push(e, e.style.cssText, e.getBBox && e.getAttribute("transform"), Be.core.getCache(e), Ku())
        }
    }) : Sr
};
Dt.revert = function(t, e) {
    return id(!t, e)
};
Dt.create = function(t, e) {
    return new Dt(t, e)
};
Dt.refresh = function(t) {
    return t ? Ns() : (Lo || Dt.register()) && po(!0)
};
Dt.update = function(t) {
    return ++$t.cache && Ri(t === !0 ? 2 : 0)
};
Dt.clearScrollMemory = Ag;
Dt.maxScroll = function(t, e) {
    return Ei(t, e ? fr : Fn)
};
Dt.getScrollFunc = function(t, e) {
    return eo(vr(t), e ? fr : Fn)
};
Dt.getById = function(t) {
    return Qu[t]
};
Dt.getAll = function() {
    return Rt.filter(function(t) {
        return t.vars.id !== "ScrollSmoother"
    })
};
Dt.isScrolling = function() {
    return !!Wr
};
Dt.snapDirectional = rd;
Dt.addEventListener = function(t, e) {
    var n = To[t] || (To[t] = []);
    ~n.indexOf(e) || n.push(e)
};
Dt.removeEventListener = function(t, e) {
    var n = To[t],
        r = n && n.indexOf(e);
    r >= 0 && n.splice(r, 1)
};
Dt.batch = function(t, e) {
    var n = [],
        r = {},
        i = e.interval || .016,
        o = e.batchMax || 1e9,
        s = function(c, d) {
            var f = [],
                h = [],
                p = Be.delayedCall(i, function() {
                    d(f, h), f = [], h = []
                }).pause();
            return function(m) {
                f.length || p.restart(!0), f.push(m.trigger), h.push(m), o <= f.length && p.progress(1)
            }
        },
        a;
    for (a in e) r[a] = a.substr(0, 2) === "on" && dr(e[a]) && a !== "onRefreshInit" ? s(a, e[a]) : e[a];
    return dr(o) && (o = o(), Ln(Dt, "refresh", function() {
        return o = e.batchMax()
    })), Vl(t).forEach(function(l) {
        var c = {};
        for (a in r) c[a] = r[a];
        c.trigger = l, n.push(Dt.create(c))
    }), n
};
var vh = function(e, n, r, i) {
        return n > i ? e(i) : n < 0 && e(0), r > i ? (i - n) / (r - n) : r < 0 ? n / (n - r) : 1
    },
    Uc = function t(e, n) {
        n === !0 ? e.style.removeProperty("touch-action") : e.style.touchAction = n === !0 ? "auto" : n ? "pan-" + n + (Pn.isTouch ? " pinch-zoom" : "") : "none", e === Qr && t(cn, n)
    },
    il = {
        auto: 1,
        scroll: 1
    },
    iE = function(e) {
        var n = e.event,
            r = e.target,
            i = e.axis,
            o = (n.changedTouches ? n.changedTouches[0] : n).target,
            s = o._gsap || Be.core.getCache(o),
            a = ur(),
            l;
        if (!s._isScrollT || a - s._isScrollT > 2e3) {
            for (; o && o !== cn && (o.scrollHeight <= o.clientHeight && o.scrollWidth <= o.clientWidth || !(il[(l = Nr(o)).overflowY] || il[l.overflowX]));) o = o.parentNode;
            s._isScroll = o && o !== r && !Eo(o) && (il[(l = Nr(o)).overflowY] || il[l.overflowX]), s._isScrollT = a
        }(s._isScroll || i === "x") && (n.stopPropagation(), n._gsapAllow = !0)
    },
    Og = function(e, n, r, i) {
        return Pn.create({
            target: e,
            capture: !0,
            debounce: !1,
            lockAxis: !0,
            type: n,
            onWheel: i = i && iE,
            onPress: i,
            onDrag: i,
            onScroll: i,
            onEnable: function() {
                return r && Ln(vn, Pn.eventTypes[0], xh, !1, !0)
            },
            onDisable: function() {
                return jn(vn, Pn.eventTypes[0], xh, !0)
            }
        })
    },
    oE = /(input|label|select|textarea)/i,
    yh, xh = function(e) {
        var n = oE.test(e.target.tagName);
        (n || yh) && (e._gsapAllow = !0, yh = n)
    },
    sE = function(e) {
        uo(e) || (e = {}), e.preventDefault = e.isNormalizer = e.allowClicks = !0, e.type || (e.type = "wheel,touch"), e.debounce = !!e.debounce, e.id = e.id || "normalizer";
        var n = e,
            r = n.normalizeScrollX,
            i = n.momentum,
            o = n.allowNestedScroll,
            s = n.onRelease,
            a, l, c = vr(e.target) || Qr,
            d = Be.core.globals().ScrollSmoother,
            f = d && d.get(),
            h = Vi && (e.content && vr(e.content) || f && e.content !== !1 && !f.smooth() && f.content()),
            p = eo(c, Fn),
            m = eo(c, fr),
            g = 1,
            y = (Pn.isTouch && Ot.visualViewport ? Ot.visualViewport.scale * Ot.visualViewport.width : Ot.outerWidth) / Ot.innerWidth,
            x = 0,
            w = dr(i) ? function() {
                return i(a)
            } : function() {
                return i || 2.8
            },
            M, T, O = Og(c, e.type, !0, o),
            R = function() {
                return T = !1
            },
            P = ci,
            B = ci,
            te = function() {
                l = Ei(c, Fn), B = Go(Vi ? 1 : 0, l), r && (P = Go(0, Ei(c, fr))), M = wo
            },
            W = function() {
                h._gsap.y = Ls(parseFloat(h._gsap.y) + p.offset) + "px", h.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + parseFloat(h._gsap.y) + ", 0, 1)", p.offset = p.cacheID = 0
            },
            ee = function() {
                if (T) {
                    requestAnimationFrame(R);
                    var Se = Ls(a.deltaY / 2),
                        Me = B(p.v - Se);
                    if (h && Me !== p.v + p.offset) {
                        p.offset = Me - p.v;
                        var z = Ls((parseFloat(h && h._gsap.y) || 0) - p.offset);
                        h.style.transform = "matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, " + z + ", 0, 1)", h._gsap.y = z + "px", p.cacheID = $t.cache, Ri()
                    }
                    return !0
                }
                p.offset && W(), T = !0
            },
            V, I, X, q, Z = function() {
                te(), V.isActive() && V.vars.scrollY > l && (p() > l ? V.progress(1) && p(l) : V.resetTo("scrollY", l))
            };
        return h && Be.set(h, {
            y: "+=0"
        }), e.ignoreCheck = function(le) {
            return Vi && le.type === "touchmove" && ee() || g > 1.05 && le.type !== "touchstart" || a.isGesturing || le.touches && le.touches.length > 1
        }, e.onPress = function() {
            T = !1;
            var le = g;
            g = Ls((Ot.visualViewport && Ot.visualViewport.scale || 1) / y), V.pause(), le !== g && Uc(c, g > 1.01 ? !0 : r ? !1 : "x"), I = m(), X = p(), te(), M = wo
        }, e.onRelease = e.onGestureStart = function(le, Se) {
            if (p.offset && W(), !Se) q.restart(!0);
            else {
                $t.cache++;
                var Me = w(),
                    z, ge;
                r && (z = m(), ge = z + Me * .05 * -le.velocityX / .227, Me *= vh(m, z, ge, Ei(c, fr)), V.vars.scrollX = P(ge)), z = p(), ge = z + Me * .05 * -le.velocityY / .227, Me *= vh(p, z, ge, Ei(c, Fn)), V.vars.scrollY = B(ge), V.invalidate().duration(Me).play(.01), (Vi && V.vars.scrollY >= l || z >= l - 1) && Be.to({}, {
                    onUpdate: Z,
                    duration: Me
                })
            }
            s && s(le)
        }, e.onWheel = function() {
            V._ts && V.pause(), ur() - x > 1e3 && (M = 0, x = ur())
        }, e.onChange = function(le, Se, Me, z, ge) {
            if (wo !== M && te(), Se && r && m(P(z[2] === Se ? I + (le.startX - le.x) : m() + Se - z[1])), Me) {
                p.offset && W();
                var $e = ge[2] === Me,
                    Xe = $e ? X + le.startY - le.y : p() + Me - ge[1],
                    tt = B(Xe);
                $e && Xe !== tt && (X += tt - Xe), p(tt)
            }(Me || Se) && Ri()
        }, e.onEnable = function() {
            Uc(c, r ? !1 : "x"), Dt.addEventListener("refresh", Z), Ln(Ot, "resize", Z), p.smooth && (p.target.style.scrollBehavior = "auto", p.smooth = m.smooth = !1), O.enable()
        }, e.onDisable = function() {
            Uc(c, !0), jn(Ot, "resize", Z), Dt.removeEventListener("refresh", Z), O.kill()
        }, e.lockAxis = e.lockAxis !== !1, a = new Pn(e), a.iOS = Vi, Vi && !p() && p(1), Vi && Be.ticker.add(ci), q = a._dc, V = Be.to(a, {
            ease: "power4",
            paused: !0,
            scrollX: r ? "+=0.1" : "+=0",
            scrollY: "+=0.1",
            modifiers: {
                scrollY: kg(p, p(), function() {
                    return V.pause()
                })
            },
            onUpdate: Ri,
            onComplete: q.vars.onComplete
        }), a
    };
Dt.sort = function(t) {
    return Rt.sort(t || function(e, n) {
        return (e.vars.refreshPriority || 0) * -1e6 + e.start - (n.start + (n.vars.refreshPriority || 0) * -1e6)
    })
};
Dt.observe = function(t) {
    return new Pn(t)
};
Dt.normalizeScroll = function(t) {
    if (typeof t > "u") return Dr;
    if (t === !0 && Dr) return Dr.enable();
    if (t === !1) return Dr && Dr.kill();
    var e = t instanceof Pn ? t : sE(t);
    return Dr && Dr.target === e.target && Dr.kill(), Eo(e.target) && (Dr = e), e
};
Dt.core = {
    _getVelocityProp: Xu,
    _inputObserver: Og,
    _scrollers: $t,
    _proxies: di,
    bridge: {
        ss: function() {
            Wr || Po("scrollStart"), Wr = ur()
        },
        ref: function() {
            return Zn
        }
    }
};
Sg() && Be.registerPlugin(Dt);
class tf extends Rv {
    transformDelta(e) {
        const {
            enable: n
        } = this.options;
        return n ? {
            x: 0,
            y: 0
        } : e
    }
}
ke(tf, "pluginName", "prevent"), ke(tf, "defaultOptions", {
    enable: !0
});
const aE = u.forwardRef(({
        children: t,
        ...e
    }, n) => {
        u.useMemo(() => he.registerPlugin(Dt), []);
        const r = u.useRef(null),
            i = u.useRef(null),
            o = u.useCallback(() => i.current, []),
            s = u.useCallback(() => i.current.containerEl, []),
            a = u.useCallback(() => {
                const f = i.current.offset.y,
                    h = i.current.limit.y;
                return f / h
            }, []),
            l = u.useCallback(f => {
                he.set(s(), {
                    pointerEvents: f ? "auto" : "none"
                }), i.current.updatePluginOptions("prevent", {
                    enable: !f
                }), f && i.current.update()
            }, [s]),
            c = u.useCallback(f => {
                i.current.addListener(() => {
                    f(a())
                })
            }, [a]),
            d = u.useCallback(f => {
                const h = f * i.current.limit.y;
                i.current.scrollTo(0, h, 0)
            }, []);
        return u.useLayoutEffect(() => (gd.use(tf), i.current = gd.init(r.current, {
            damping: .1,
            renderByPixels: !0,
            alwaysShowTracks: !0,
            continuousScrolling: !1,
            delegateTo: document.body
        }), Dt.defaults({
            scroller: i.current.containerEl
        }), Dt.scrollerProxy(i.current.containerEl, {
            scrollTop(f) {
                return arguments.length && (i.current.scrollTop = f), i.current.scrollTop
            }
        }), i.current.addListener(() => Dt.update()), () => {
            i.current.destroy()
        }), []), u.useImperativeHandle(n, () => ({
            enable: l,
            scrollTo: d,
            getInstance: o,
            getRootElement: s,
            addScrollListener: c
        }), [l, d, o, s, c]), v.jsx(v.Fragment, {
            children: v.jsx("div", {
                ref: r,
                ...e,
                children: t
            })
        })
    }),
    lE = u.forwardRef(({
        children: t,
        className: e,
        variant: n = "dark",
        ...r
    }, i) => v.jsx("a", {
        ref: i,
        ...r,
        className: Kt("relative inline-block w-full h-auto md:w-auto overflow-hidden transition-shadow duration-500 ease-out group bg-primary pt-[1.6rem] px-[2.4rem] pb-[1.2rem] before:absolute before:top-0 before:left-0 before:w-full before:h-full before:bg-white before:z-0 before:transition-transform before:duration-300 before:ease-out", {
            "before:translate-y-full hover:before:translate-y-0 shadow-[0_0_40px_5px_rgba(228,103,103,.6)] hover:shadow-[0_0_40px_5px_rgba(255,255,255,.5)]": n === "dark",
            "before:translate-y-0 hover:before:-translate-y-full shadow-[0_0_40px_5px_rgba(255,255,255,.5)] hover:shadow-[0_0_40px_5px_rgba(228,103,103,.6)]": n === "light"
        }, e),
        children: v.jsx("span", {
            "data-label": t,
            className: Kt("relative font-condensed text-regular-lg inline-block overflow-hidden z-10 after:content-[attr(data-label)] after:text-primary after:absolute after:top-0 after:left-0 after:w-full after:h-full after:translate-y-full after:transition-transform after:duration-300 group-hover:after:translate-y-0", {
                "text-white after:text-primary": n === "dark",
                "text-primary after:text-white": n === "light"
            }),
            children: v.jsx("span", {
                className: "relative inline-block transition-transform duration-300 group-hover:-translate-y-full",
                children: t
            })
        })
    }));
var nf = {
    exports: {}
};
(function(t, e) {
    (function(n, r) {
        r(e)
    })(uf, function(n) {
        var r = /([\uD800-\uDBFF][\uDC00-\uDFFF](?:[\u200D\uFE0F][\uD800-\uDBFF][\uDC00-\uDFFF]){2,}|\uD83D\uDC69(?:\u200D(?:(?:\uD83D\uDC69\u200D)?\uD83D\uDC67|(?:\uD83D\uDC69\u200D)?\uD83D\uDC66)|\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC69\u200D(?:\uD83D\uDC69\u200D)?\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D(?:\uD83D\uDC69\u200D)?\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]\uFE0F|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC6F\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3C-\uDD3E\uDDD6-\uDDDF])\u200D[\u2640\u2642]\uFE0F|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF6\uD83C\uDDE6|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uFE0F\u200D[\u2640\u2642]|(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642])\uFE0F|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\uD83D\uDC69\u200D[\u2695\u2696\u2708]|\uD83D\uDC68(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708]))\uFE0F|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83D\uDC69\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69]))|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67)\uDB40\uDC7F|\uD83D\uDC68(?:\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:(?:\uD83D[\uDC68\uDC69])\u200D)?\uD83D\uDC66\u200D\uD83D\uDC66|(?:(?:\uD83D[\uDC68\uDC69])\u200D)?\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92])|(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]))|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDD1-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|\uD83D\uDC68(?:\u200D(?:(?:(?:\uD83D[\uDC68\uDC69])\u200D)?\uD83D\uDC67|(?:(?:\uD83D[\uDC68\uDC69])\u200D)?\uD83D\uDC66)|\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC69\uDC6E\uDC70-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD26\uDD30-\uDD39\uDD3D\uDD3E\uDDD1-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])?|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDEEB\uDEEC\uDEF4-\uDEF8]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD4C\uDD50-\uDD6B\uDD80-\uDD97\uDDC0\uDDD0-\uDDE6])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u2660\u2663\u2665\u2666\u2668\u267B\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEF8]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD4C\uDD50-\uDD6B\uDD80-\uDD97\uDDC0\uDDD0-\uDDE6])\uFE0F)/;

        function i(V) {
            var I = V.nodeType,
                X = "";
            if (I === 1 || I === 9 || I === 11) {
                if (typeof V.textContent == "string") return V.textContent;
                for (V = V.firstChild; V; V = V.nextSibling) X += i(V)
            } else if (I === 3 || I === 4) return V.nodeValue;
            return X
        }
        /*!
         * SplitText: 3.12.2
         * https://greensock.com
         *
         * @license Copyright 2008-2023, GreenSock. All rights reserved.
         * Subject to the terms at https://greensock.com/standard-license or for
         * Club GreenSock members, the agreement issued with that membership.
         * @author: Jack Doyle, jack@greensock.com
         */
        var o, s, a, l, c, d, f = /(?:\r|\n|\t\t)/g,
            h = /(?:\s\s+)/g,
            p = function(I) {
                o = document, s = window, l = l || I || s.gsap || console.warn("Please gsap.registerPlugin(SplitText)"), l && (d = l.utils.toArray, c = l.core.context || function() {}, a = 1)
            },
            m = function(I) {
                return s.getComputedStyle(I)
            },
            g = function(I) {
                return I.position === "absolute" || I.absolute === !0
            },
            y = function(I, X) {
                for (var q = X.length, Z; --q > -1;)
                    if (Z = X[q], I.substr(0, Z.length) === Z) return Z.length
            },
            x = " style='position:relative;display:inline-block;'",
            w = function(I, X) {
                I === void 0 && (I = "");
                var q = ~I.indexOf("++"),
                    Z = 1;
                return q && (I = I.split("++").join("")),
                    function() {
                        return "<" + X + x + (I ? " class='" + I + (q ? Z++ : "") + "'>" : ">")
                    }
            },
            M = function V(I, X, q) {
                var Z = I.nodeType;
                if (Z === 1 || Z === 9 || Z === 11)
                    for (I = I.firstChild; I; I = I.nextSibling) V(I, X, q);
                else(Z === 3 || Z === 4) && (I.nodeValue = I.nodeValue.split(X).join(q))
            },
            T = function(I, X) {
                for (var q = X.length; --q > -1;) I.push(X[q])
            },
            O = function(I, X, q) {
                for (var Z; I && I !== X;) {
                    if (Z = I._next || I.nextSibling, Z) return Z.textContent.charAt(0) === q;
                    I = I.parentNode || I._parent
                }
            },
            R = function V(I) {
                var X = d(I.childNodes),
                    q = X.length,
                    Z, le;
                for (Z = 0; Z < q; Z++) le = X[Z], le._isSplit ? V(le) : Z && le.previousSibling && le.previousSibling.nodeType === 3 ? (le.previousSibling.nodeValue += le.nodeType === 3 ? le.nodeValue : le.firstChild.nodeValue, I.removeChild(le)) : le.nodeType !== 3 && (I.insertBefore(le.firstChild, le), I.removeChild(le))
            },
            P = function(I, X) {
                return parseFloat(X[I]) || 0
            },
            B = function(I, X, q, Z, le, Se, Me) {
                var z = m(I),
                    ge = P("paddingLeft", z),
                    $e = -999,
                    Xe = P("borderBottomWidth", z) + P("borderTopWidth", z),
                    tt = P("borderLeftWidth", z) + P("borderRightWidth", z),
                    wt = P("paddingTop", z) + P("paddingBottom", z),
                    Ue = P("paddingLeft", z) + P("paddingRight", z),
                    Ye = P("fontSize", z) * (X.lineThreshold || .2),
                    Ge = z.textAlign,
                    rt = [],
                    it = [],
                    lt = [],
                    Lt = X.wordDelimiter || " ",
                    Ne = X.tag ? X.tag : X.span ? "span" : "div",
                    ct = X.type || X.split || "chars,words,lines",
                    ot = le && ~ct.indexOf("lines") ? [] : null,
                    gt = ~ct.indexOf("words"),
                    re = ~ct.indexOf("chars"),
                    pt = g(X),
                    It = X.linesClass,
                    At = ~(It || "").indexOf("++"),
                    Je = [],
                    fn = z.display === "flex",
                    Ce = I.style.display,
                    _e, Ve, qe, pe, Mt, Bt, vt, Yt, C, L, ce, oe;
                for (At && (It = It.split("++").join("")), fn && (I.style.display = "block"), Ve = I.getElementsByTagName("*"), qe = Ve.length, Mt = [], _e = 0; _e < qe; _e++) Mt[_e] = Ve[_e];
                if (ot || pt)
                    for (_e = 0; _e < qe; _e++) pe = Mt[_e], Bt = pe.parentNode === I, (Bt || pt || re && !gt) && (oe = pe.offsetTop, ot && Bt && Math.abs(oe - $e) > Ye && (pe.nodeName !== "BR" || _e === 0) && (vt = [], ot.push(vt), $e = oe), pt && (pe._x = pe.offsetLeft, pe._y = oe, pe._w = pe.offsetWidth, pe._h = pe.offsetHeight), ot && ((pe._isSplit && Bt || !re && Bt || gt && Bt || !gt && pe.parentNode.parentNode === I && !pe.parentNode._isSplit) && (vt.push(pe), pe._x -= ge, O(pe, I, Lt) && (pe._wordEnd = !0)), pe.nodeName === "BR" && (pe.nextSibling && pe.nextSibling.nodeName === "BR" || _e === 0) && ot.push([])));
                for (_e = 0; _e < qe; _e++) {
                    if (pe = Mt[_e], Bt = pe.parentNode === I, pe.nodeName === "BR") {
                        ot || pt ? (pe.parentNode && pe.parentNode.removeChild(pe), Mt.splice(_e--, 1), qe--) : gt || I.appendChild(pe);
                        continue
                    }
                    if (pt && (C = pe.style, !gt && !Bt && (pe._x += pe.parentNode._x, pe._y += pe.parentNode._y), C.left = pe._x + "px", C.top = pe._y + "px", C.position = "absolute", C.display = "block", C.width = pe._w + 1 + "px", C.height = pe._h + "px"), !gt && re)
                        if (pe._isSplit)
                            for (pe._next = Ve = pe.nextSibling, pe.parentNode.appendChild(pe); Ve && Ve.nodeType === 3 && Ve.textContent === " ";) pe._next = Ve.nextSibling, pe.parentNode.appendChild(Ve), Ve = Ve.nextSibling;
                        else pe.parentNode._isSplit ? (pe._parent = pe.parentNode, !pe.previousSibling && pe.firstChild && (pe.firstChild._isFirst = !0), pe.nextSibling && pe.nextSibling.textContent === " " && !pe.nextSibling.nextSibling && Je.push(pe.nextSibling), pe._next = pe.nextSibling && pe.nextSibling._isFirst ? null : pe.nextSibling, pe.parentNode.removeChild(pe), Mt.splice(_e--, 1), qe--) : Bt || (oe = !pe.nextSibling && O(pe.parentNode, I, Lt), pe.parentNode._parent && pe.parentNode._parent.appendChild(pe), oe && pe.parentNode.appendChild(o.createTextNode(" ")), Ne === "span" && (pe.style.display = "inline"), rt.push(pe));
                    else pe.parentNode._isSplit && !pe._isSplit && pe.innerHTML !== "" ? it.push(pe) : re && !pe._isSplit && (Ne === "span" && (pe.style.display = "inline"), rt.push(pe))
                }
                for (_e = Je.length; --_e > -1;) Je[_e].parentNode.removeChild(Je[_e]);
                if (ot) {
                    for (pt && (L = o.createElement(Ne), I.appendChild(L), ce = L.offsetWidth + "px", oe = L.offsetParent === I ? 0 : I.offsetLeft, I.removeChild(L)), C = I.style.cssText, I.style.cssText = "display:none;"; I.firstChild;) I.removeChild(I.firstChild);
                    for (Yt = Lt === " " && (!pt || !gt && !re), _e = 0; _e < ot.length; _e++) {
                        for (vt = ot[_e], L = o.createElement(Ne), L.style.cssText = "display:block;text-align:" + Ge + ";position:" + (pt ? "absolute;" : "relative;"), It && (L.className = It + (At ? _e + 1 : "")), lt.push(L), qe = vt.length, Ve = 0; Ve < qe; Ve++) vt[Ve].nodeName !== "BR" && (pe = vt[Ve], L.appendChild(pe), Yt && pe._wordEnd && L.appendChild(o.createTextNode(" ")), pt && (Ve === 0 && (L.style.top = pe._y + "px", L.style.left = ge + oe + "px"), pe.style.top = "0px", oe && (pe.style.left = pe._x - oe + "px")));
                        qe === 0 ? L.innerHTML = "&nbsp;" : !gt && !re && (R(L), M(L, String.fromCharCode(160), " ")), pt && (L.style.width = ce, L.style.height = pe._h + "px"), I.appendChild(L)
                    }
                    I.style.cssText = C
                }
                pt && (Me > I.clientHeight && (I.style.height = Me - wt + "px", I.clientHeight < Me && (I.style.height = Me + Xe + "px")), Se > I.clientWidth && (I.style.width = Se - Ue + "px", I.clientWidth < Se && (I.style.width = Se + tt + "px"))), fn && (Ce ? I.style.display = Ce : I.style.removeProperty("display")), T(q, rt), gt && T(Z, it), T(le, lt)
            },
            te = function(I, X, q, Z) {
                var le = X.tag ? X.tag : X.span ? "span" : "div",
                    Se = X.type || X.split || "chars,words,lines",
                    Me = ~Se.indexOf("chars"),
                    z = g(X),
                    ge = X.wordDelimiter || " ",
                    $e = ge !== " " ? "" : z ? "&#173; " : " ",
                    Xe = "</" + le + ">",
                    tt = 1,
                    wt = X.specialChars ? typeof X.specialChars == "function" ? X.specialChars : y : null,
                    Ue, Ye, Ge, rt, it, lt, Lt, Ne, ct = o.createElement("div"),
                    ot = I.parentNode;
                for (ot.insertBefore(ct, I), ct.textContent = I.nodeValue, ot.removeChild(I), I = ct, Ue = i(I), Lt = Ue.indexOf("<") !== -1, X.reduceWhiteSpace !== !1 && (Ue = Ue.replace(h, " ").replace(f, "")), Lt && (Ue = Ue.split("<").join("{{LT}}")), it = Ue.length, Ye = (Ue.charAt(0) === " " ? $e : "") + q(), Ge = 0; Ge < it; Ge++)
                    if (lt = Ue.charAt(Ge), wt && (Ne = wt(Ue.substr(Ge), X.specialChars))) lt = Ue.substr(Ge, Ne || 1), Ye += Me && lt !== " " ? Z() + lt + "</" + le + ">" : lt, Ge += Ne - 1;
                    else if (lt === ge && Ue.charAt(Ge - 1) !== ge && Ge) {
                    for (Ye += tt ? Xe : "", tt = 0; Ue.charAt(Ge + 1) === ge;) Ye += $e, Ge++;
                    Ge === it - 1 ? Ye += $e : Ue.charAt(Ge + 1) !== ")" && (Ye += $e + q(), tt = 1)
                } else lt === "{" && Ue.substr(Ge, 6) === "{{LT}}" ? (Ye += Me ? Z() + "{{LT}}</" + le + ">" : "{{LT}}", Ge += 5) : lt.charCodeAt(0) >= 55296 && lt.charCodeAt(0) <= 56319 || Ue.charCodeAt(Ge + 1) >= 65024 && Ue.charCodeAt(Ge + 1) <= 65039 ? (rt = ((Ue.substr(Ge, 12).split(r) || [])[1] || "").length || 2, Ye += Me && lt !== " " ? Z() + Ue.substr(Ge, rt) + "</" + le + ">" : Ue.substr(Ge, rt), Ge += rt - 1) : Ye += Me && lt !== " " ? Z() + lt + "</" + le + ">" : lt;
                I.outerHTML = Ye + (tt ? Xe : ""), Lt && M(ot, "{{LT}}", "<")
            },
            W = function V(I, X, q, Z) {
                var le = d(I.childNodes),
                    Se = le.length,
                    Me = g(X),
                    z, ge;
                if (I.nodeType !== 3 || Se > 1) {
                    for (X.absolute = !1, z = 0; z < Se; z++) ge = le[z], ge._next = ge._isFirst = ge._parent = ge._wordEnd = null, (ge.nodeType !== 3 || /\S+/.test(ge.nodeValue)) && (Me && ge.nodeType !== 3 && m(ge).display === "inline" && (ge.style.display = "inline-block", ge.style.position = "relative"), ge._isSplit = !0, V(ge, X, q, Z));
                    X.absolute = Me, I._isSplit = !0;
                    return
                }
                te(I, X, q, Z)
            },
            ee = function() {
                function V(X, q) {
                    a || p(), this.elements = d(X), this.chars = [], this.words = [], this.lines = [], this._originals = [], this.vars = q || {}, c(this), this.split(q)
                }
                var I = V.prototype;
                return I.split = function(q) {
                    this.isSplit && this.revert(), this.vars = q = q || this.vars, this._originals.length = this.chars.length = this.words.length = this.lines.length = 0;
                    for (var Z = this.elements.length, le = q.tag ? q.tag : q.span ? "span" : "div", Se = w(q.wordsClass, le), Me = w(q.charsClass, le), z, ge, $e; --Z > -1;) $e = this.elements[Z], this._originals[Z] = $e.innerHTML, z = $e.clientHeight, ge = $e.clientWidth, W($e, q, Se, Me), B($e, q, this.chars, this.words, this.lines, ge, z);
                    return this.chars.reverse(), this.words.reverse(), this.lines.reverse(), this.isSplit = !0, this
                }, I.revert = function() {
                    var q = this._originals;
                    if (!q) throw "revert() call wasn't scoped properly.";
                    return this.elements.forEach(function(Z, le) {
                        return Z.innerHTML = q[le]
                    }), this.chars = [], this.words = [], this.lines = [], this.isSplit = !1, this
                }, V.create = function(q, Z) {
                    return new V(q, Z)
                }, V
            }();
        ee.version = "3.12.2", ee.register = p, n.SplitText = ee, n.default = ee, Object.defineProperty(n, "__esModule", {
            value: !0
        })
    })
})(nf, nf.exports);
var cE = nf.exports;
const In = cs(cE),
    uE = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(In, Dt), []);
        const {
            blocks: n
        } = t, {
            locale: r
        } = nr(), i = Gr(), o = u.useRef(null), s = u.useRef(he.timeline({
            paused: !0
        })), a = u.useCallback(() => {
            o.current.enable(!1)
        }, []), l = u.useCallback(d => {
            const f = Math.abs(Math.min((d.value + 1) / Cm, 0));
            o.current.scrollTo(f)
        }, []), c = u.useCallback(d => {
            o.current.enable(d.direction > 0)
        }, []);
        return u.useLayoutEffect(() => {
            const d = he.context(f => {
                const h = f.selector || he.utils.selector;
                Gt.forEach(h("[data-gsap-block]"), (p, m) => {
                    const g = he.utils.selector(p),
                        y = m === 0,
                        x = g("[data-gsap-headline]")[0],
                        w = new In(x, {
                            type: "lines",
                            linesClass: "line"
                        });
                    new In(x, {
                        type: "lines",
                        linesClass: "line-wrap"
                    });
                    const M = w,
                        T = g("[data-gsap-subheadline]")[0],
                        O = g("[data-gsap-button]")[0],
                        R = he.timeline({
                            defaults: {
                                duration: .6,
                                ease: "power2.out"
                            },
                            paused: y
                        }).fromTo(m % 2 === 0 ? [...M.lines, T] : [T, ...M.lines], {
                            yPercent: 120
                        }, {
                            yPercent: 0,
                            stagger: {
                                amount: .3
                            }
                        });
                    O && R.add(he.fromTo(O, {
                        opacity: 0,
                        y: 30
                    }, {
                        opacity: 1,
                        y: 0
                    }), "<+.6"), y ? s.current = R : Dt.create({
                        animation: R,
                        trigger: p,
                        toggleActions: "play none none reverse",
                        start: "clamp(top bottom)",
                        markers: !1
                    })
                })
            }, o.current.getRootElement());
            return () => {
                d.revert()
            }
        }, []), u.useEffect(() => (i.cameraMotionValue.addEventListener("start", a), i.cameraMotionValue.addEventListener("update", l), i.cameraMotionValue.addEventListener("complete", c), () => {
            i.cameraMotionValue.removeEventListener("start", a), i.cameraMotionValue.removeEventListener("update", l), i.cameraMotionValue.removeEventListener("complete", c)
        }), [i, a, l, c]), u.useEffect(() => {
            o.current && o.current.addScrollListener(d => i.cameraMotionValue.dispatchEvent({
                type: "scroll",
                progress: d
            }))
        }, [i]), u.useImperativeHandle(e, () => ({
            timeline: s
        }), []), v.jsxs(aE, {
            ref: o,
            children: [n.map((d, f) => v.jsx(ki, {
                className: "relative w-full h-auto pt-[var(--ratio,_0%)] flex items-center justify-center",
                children: v.jsxs("div", {
                    className: "relative max-w-[84rem] h-auto space-y-[2.4rem] text-center -translate-y-1/2 md:-translate-y-1/4",
                    "data-gsap-block": !0,
                    children: [v.jsxs("div", {
                        className: Kt("flex space-y-[2.4rem]", {
                            "flex-col": f % 2 === 0,
                            "flex-col-reverse space-y-reverse": f % 2 === 1
                        }),
                        children: [v.jsx(an, {
                            variant: "h2",
                            component: f === 0 ? "h2" : "h3",
                            dangerouslySetInnerHTML: {
                                __html: d.headline
                            },
                            className: Kt({
                                "text-primary": f < 2,
                                "text-primary-light": f > 1
                            }),
                            "data-gsap-headline": !0
                        }), v.jsx(an, {
                            size: "large",
                            paragraph: !0,
                            className: Kt("overflow-hidden", {
                                "text-primary-light": f < 2,
                                "text-primary": f > 1
                            }),
                            children: v.jsx("span", {
                                className: "block",
                                dangerouslySetInnerHTML: {
                                    __html: d.subheadline
                                },
                                "data-gsap-subheadline": !0
                            })
                        })]
                    }), d.contacts && v.jsx(lE, {
                        href: r.footer.email.href,
                        variant: "light",
                        className: "md:!w-[12.2rem]",
                        "data-gsap-button": !0,
                        children: d.contacts
                    })]
                })
            }, f)), v.jsx(ki, {
                className: "relative w-full h-full"
            })]
        })
    }),
    fE = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(In), []);
        const {
            headline: n,
            subheadline: r,
            location: i,
            availability: o
        } = t, s = u.useRef(he.timeline({
            paused: !0
        })), a = u.useRef(null);
        return u.useLayoutEffect(() => {
            const l = he.context(c => {
                const d = c.selector || he.utils.selector,
                    f = new In("[data-gsap-headline]", {
                        type: "lines",
                        linesClass: "line"
                    });
                new In("[data-gsap-headline]", {
                    type: "lines",
                    linesClass: "line-wrap"
                });
                const h = f,
                    p = d("[data-gsap-subheadline]")[0],
                    m = d("[data-gsap-location]")[0],
                    g = d("[data-gsap-availability]")[0];
                s.current.fromTo([p, ...h.lines, m, g], {
                    yPercent: 130,
                    skewY: 2
                }, {
                    yPercent: 0,
                    skewY: 0,
                    duration: .8,
                    ease: "power3.out",
                    stagger: {
                        amount: .4
                    }
                }, "<")
            }, a.current);
            return () => {
                l.revert()
            }
        }, []), u.useImperativeHandle(e, () => ({
            timeline: s
        }), []), bt("Home"), v.jsx("div", {
            ref: a,
            className: "absolute select-none top-0 left-0 flex w-full h-full justify-center items-end md:items-center pb-24 md:pb-0 bg-gradient-to-t from-black from-0% via-black via-from-40% to-transparent to-60% md:bg-none",
            children: v.jsx(ki, {
                className: "mb-[7rem] md:mb-0",
                children: v.jsx(Xf, {
                    children: v.jsx("div", {
                        className: "col-span-4 md:col-span-6 lg:col-start-2 lg:col-span-10",
                        children: v.jsxs("div", {
                            className: "grid grid-cols-1 gap-4 md:gap-8",
                            children: [v.jsx("div", {
                                className: "col-span-1",
                                children: v.jsx("p", {
                                    className: "overflow-hidden mb-[.3em]",
                                    children: v.jsx(an, {
                                        className: "[&>b]:font-bold text-primary inline-block",
                                        dangerouslySetInnerHTML: {
                                            __html: r
                                        },
                                        "data-gsap-subheadline": !0
                                    })
                                })
                            }), v.jsx("div", {
                                className: "col-span-1 max-w-[92rem]",
                                children: v.jsx(an, {
                                    component: "h1",
                                    variant: "h2",
                                    className: "[&_b]:text-primary",
                                    dangerouslySetInnerHTML: {
                                        __html: n
                                    },
                                    "data-gsap-headline": !0
                                })
                            }), v.jsx("div", {
                                className: "col-span-1 lg:text-right",
                                children: v.jsxs("p", {
                                    className: "overflow-hidden leading-7 md:leading-8",
                                    children: [v.jsx("span", {
                                        className: "inline-block overflow-hidden",
                                        children: v.jsx(an, {
                                            className: "inline-block",
                                            dangerouslySetInnerHTML: {
                                                __html: i
                                            },
                                            "data-gsap-location": !0
                                        })
                                    }), v.jsx("br", {}), v.jsx("span", {
                                        className: "overflow-hidden",
                                        children: v.jsx(an, {
                                            strong: !0,
                                            className: "inline-block",
                                            dangerouslySetInnerHTML: {
                                                __html: o
                                            },
                                            "data-gsap-availability": !0
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                })
            })
        })
    }),
    dE = u.forwardRef(({
        children: t,
        className: e,
        variant: n = "dark",
        ...r
    }, i) => v.jsx("button", {
        ref: i,
        ...r,
        className: Kt("relative inline-block w-full h-auto md:w-auto overflow-hidden transition-shadow duration-500 ease-out group bg-primary pt-[1.6rem] px-[2.4rem] pb-[1.2rem] before:absolute before:top-0 before:left-0 before:w-full before:h-full before:bg-white before:z-0 before:transition-transform before:duration-300 before:ease-out", {
            "before:translate-y-full hover:before:translate-y-0 shadow-[0_0_40px_5px_rgba(228,103,103,.6)] hover:shadow-[0_0_40px_5px_rgba(255,255,255,.5)]": n === "dark",
            "before:translate-y-0 hover:before:-translate-y-full shadow-[0_0_40px_5px_rgba(255,255,255,.5)] hover:shadow-[0_0_40px_5px_rgba(228,103,103,.6)]": n === "light"
        }, e),
        children: v.jsx("span", {
            "data-label": t,
            className: Kt("relative font-condensed text-regular-lg inline-block overflow-hidden z-10 after:content-[attr(data-label)] after:text-primary after:absolute after:top-0 after:left-0 after:w-full after:h-full after:translate-y-full after:transition-transform after:duration-300 group-hover:after:translate-y-0", {
                "text-white after:text-primary": n === "dark",
                "text-primary after:text-white": n === "light"
            }),
            children: v.jsx("span", {
                className: "relative inline-block transition-transform duration-300 group-hover:-translate-y-full",
                children: t
            })
        })
    })),
    pE = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(In), []);
        const {
            uuid: n,
            role: r,
            title: i,
            client: o,
            description: s,
            link: a,
            prefix_work_client: l,
            prefix_work_role: c,
            cta_project: d
        } = t, f = u.useRef(he.timeline({
            paused: !0
        })), h = u.useRef(null), p = Bn(g => g.setCurrentLeaf), m = u.useCallback(g => {
            g.preventDefault(), p(n)
        }, [n, p]);
        return u.useLayoutEffect(() => {
            const g = he.context(y => {
                const x = y.selector || he.utils.selector;
                new In("[data-gsap-title]", {
                    type: "words,chars",
                    wordsClass: "word",
                    charsClass: "char-wrap"
                });
                const w = new In("[data-gsap-description]", {
                    type: "lines",
                    linesClass: "line"
                });
                new In("[data-gsap-description]", {
                    type: "lines",
                    linesClass: "line-wrap"
                });
                const M = x("[data-gsap-client]")[0],
                    T = new In("[data-gsap-title]", {
                        type: "chars",
                        charsClass: "char"
                    }),
                    O = x("[data-gsap-role]")[0],
                    R = w,
                    P = x("[data-gsap-button]")[0];
                f.current.fromTo(T.chars, {
                    x: 100
                }, {
                    x: 0,
                    duration: .8,
                    ease: "power3.out",
                    stagger: {
                        amount: .3
                    }
                }, "<").fromTo(T.chars, {
                    color: "#ffffff"
                }, {
                    color: "#e46767",
                    duration: .8,
                    ease: "power3.out",
                    stagger: {
                        amount: .6
                    }
                }, "<+.2").fromTo([M, O, ...R.lines], {
                    yPercent: 125,
                    skewY: 3
                }, {
                    yPercent: 0,
                    skewY: 0,
                    duration: .6,
                    ease: "power3.out",
                    stagger: {
                        amount: .3
                    }
                }, "<").fromTo([M, O, ...R.lines], {
                    color: "#ffffff"
                }, {
                    color: "#1276AA",
                    duration: .6,
                    ease: "power3.out",
                    stagger: {
                        amount: .5
                    }
                }, "<").fromTo(P, {
                    y: 20,
                    autoAlpha: 0
                }, {
                    y: 0,
                    autoAlpha: 1,
                    duration: .6,
                    ease: "power3.out"
                }, "<+.5")
            }, h.current);
            return () => {
                g.revert()
            }
        }, []), u.useImperativeHandle(e, () => ({
            timeline: f
        }), []), bt("Work"), v.jsx("div", {
            ref: h,
            className: "absolute select-none top-0 left-0 flex w-full h-full justify-center items-end md:items-center bg-gradient-to-t from-black from-0% via-black via-from-40% to-transparent to-60% md:bg-none",
            children: v.jsx(ki, {
                className: "pb-40 md:pb-0",
                children: v.jsx(Xf, {
                    children: v.jsx("div", {
                        className: "col-span-4 md:col-span-6 lg:col-start-2 lg:col-span-10 xl:col-start-3 xl:col-span-8",
                        children: v.jsxs("div", {
                            className: "grid grid-cols-1 gap-3 md:gap-8",
                            children: [v.jsx("div", {
                                className: "col-span-1",
                                children: v.jsx("p", {
                                    className: "overflow-hidden",
                                    children: v.jsxs("span", {
                                        className: "inline-block text-secondary",
                                        "data-gsap-client": !0,
                                        children: [v.jsx(an, {
                                            size: "regular",
                                            children: `${l}:`
                                        }), " ", v.jsx(an, {
                                            size: "regular",
                                            strong: !0,
                                            dangerouslySetInnerHTML: {
                                                __html: o
                                            }
                                        })]
                                    })
                                })
                            }), v.jsx("div", {
                                className: "col-span-1",
                                children: v.jsx(an, {
                                    component: "h1",
                                    variant: "h2",
                                    className: "heading text-primary",
                                    dangerouslySetInnerHTML: {
                                        __html: i
                                    },
                                    "data-gsap-title": !0
                                })
                            }), v.jsx("div", {
                                className: "col-span-1",
                                children: v.jsx("p", {
                                    className: "overflow-hidden",
                                    children: v.jsxs("span", {
                                        className: "inline-block text-secondary",
                                        "data-gsap-role": !0,
                                        children: [v.jsx(an, {
                                            size: "regular",
                                            children: `${c}:`
                                        }), " ", v.jsx(an, {
                                            size: "regular",
                                            strong: !0,
                                            children: r
                                        })]
                                    })
                                })
                            }), v.jsx("div", {
                                className: "col-span-1 max-w-[52rem]",
                                children: v.jsx(an, {
                                    size: "large",
                                    paragraph: !0,
                                    className: "text-secondary",
                                    dangerouslySetInnerHTML: {
                                        __html: s
                                    },
                                    "data-gsap-description": !0
                                })
                            }), a && v.jsx("div", {
                                className: "col-span-1 mt-6 md:mt-2",
                                children: v.jsx(dE, {
                                    onMouseEnter: () => document.dispatchEvent(new CustomEvent("hover", {
                                        detail: {
                                            uuid: n
                                        }
                                    })),
                                    onClick: m,
                                    "data-gsap-button": !0,
                                    children: d
                                })
                            })]
                        })
                    })
                })
            })
        })
    }),
    hE = () => {
        const {
            scenes: t
        } = nr(), e = Gr(), n = u.useRef([]), r = u.useRef([]), i = u.useRef([]), o = u.useCallback(p => {
            const m = r.current[p];
            Gt.forEach(r.current, (g, y) => {
                const x = i.current[y],
                    w = g.id === m.id;
                he.timeline().set(g, {
                    yPercent: 0,
                    xPercent: w ? 0 : 100
                }).set(x, {
                    yPercent: 0,
                    xPercent: w ? 0 : 100
                })
            })
        }, []), s = u.useCallback(p => n.current[p].timeline.current, []), a = u.useCallback(p => s(p).restart(), [s]), l = u.useCallback(p => s(p).reverse(), [s]), c = u.useCallback(p => {
            const m = p.value,
                g = e.getNextMotionIndex(m),
                y = e.getPrevMotionIndex(m),
                x = r.current[g],
                w = r.current[y],
                M = i.current[g],
                T = i.current[y],
                O = n.current[g],
                R = n.current[y];
            if (g === y) o(g);
            else {
                const P = (m % 1 + 1) % 1,
                    B = e.getDirection();
                he.timeline().add(he.timeline().set(x, {
                    yPercent: 0,
                    xPercent: (1 - P) * 100
                }).set(M, {
                    yPercent: 0,
                    xPercent: -(1 - P) * 95
                })).add(he.timeline().set(w, {
                    yPercent: 0,
                    xPercent: -P * 100
                }).set(T, {
                    yPercent: 0,
                    xPercent: P * 95
                }), "<");
                const W = (B > 0 ? R : O).timeline.current,
                    ee = B > 0 ? He.mapLinear(P, 0, .6, 1, 0) : He.mapLinear(P, 1, .6, 1, 0);
                W.pause().progress(ee)
            }
        }, [e, o]), d = u.useCallback(p => {
            const m = p.value,
                g = Hf(m),
                y = e.getNextMotionIndex(m),
                x = e.getPrevMotionIndex(m),
                w = r.current[y],
                M = r.current[x],
                T = i.current[y],
                O = i.current[x];
            (e.needsUnderground() || e.needsUpperground()) && he.timeline().add(he.timeline().set(w, {
                xPercent: 0,
                yPercent: -g * 100
            }).set(T, {
                xPercent: 0,
                yPercent: g * 90
            })).add(he.timeline().set(M, {
                xPercent: 0,
                yPercent: (1 - g) * 100
            }).set(O, {
                xPercent: 0,
                yPercent: -(1 - g) * 90
            }))
        }, [e]), f = u.useCallback(p => {
            a(p.value)
        }, [a]), h = u.useCallback(p => {
            const m = uc(e.cameraMotionValue.get()),
                g = p.direction > 0 ? .8 : m - .8;
            he.delayedCall(g, () => p.direction > 0 ? a(p.value) : l(p.previous))
        }, [e, a, l]);
        return u.useLayoutEffect(() => {
            Gt.forEach(r.current, (p, m) => {
                const g = i.current[m];
                p.id === "underground" ? he.timeline().set(p, {
                    yPercent: -100,
                    xPercent: 0
                }).set(g, {
                    yPercent: 100,
                    xPercent: 0
                }) : he.timeline().set(p, {
                    yPercent: 0,
                    xPercent: 100
                }).set(g, {
                    yPercent: 0,
                    xPercent: -100
                })
            })
        }, []), u.useEffect(() => (e.motionValue.addEventListener("start", f), e.motionValue.addEventListener("update", c), e.cameraMotionValue.addEventListener("start", h), e.cameraMotionValue.addEventListener("update", d), () => {
            e.motionValue.removeEventListener("start", f), e.motionValue.removeEventListener("update", c), e.cameraMotionValue.removeEventListener("start", h), e.cameraMotionValue.removeEventListener("update", d)
        }), [e, f, c, h, d]), u.useEffect(() => {
            const p = Bn.subscribe(m => m.leaf, m => {
                const g = Bn.getState().route.index,
                    y = r.current[g],
                    x = i.current[g];
                he.timeline().add(he.timeline({
                    defaults: {
                        duration: 1.8,
                        ease: "expoCurve.inOut"
                    }
                }).to(y, {
                    yPercent: m ? 100 : 0
                }).to(x, {
                    yPercent: m ? -90 : 0
                }, "<"))
            });
            return () => {
                p()
            }
        }, []), u.useEffect(() => {
            const p = Bn.subscribe(m => m.route, m => m.initial && o(m.index), {
                fireImmediately: !0
            });
            return () => {
                p()
            }
        }, [o]), MS(() => {
            a(Ru().index), e.needsUnderground() && a(0)
        }), bt("Views"), v.jsx(v.Fragment, {
            children: v.jsx("section", {
                className: "static",
                children: t.map(({
                    uuid: p,
                    contents: m
                }, g) => v.jsx("div", {
                    id: p,
                    ref: y => r.current[g] = y,
                    className: Kt("absolute top-0 left-0 w-full h-full overflow-hidden"),
                    children: v.jsx("div", {
                        ref: y => i.current[g] = y,
                        className: "absolute top-0 left-0 w-full h-full",
                        children: p === "underground" ? v.jsx(uE, {
                            ref: y => n.current[g] = y,
                            ...m
                        }) : p === "uprising" ? v.jsx(fE, {
                            ref: y => n.current[g] = y,
                            ...m
                        }) : p !== "upperground" ? v.jsx(pE, {
                            ref: y => n.current[g] = y,
                            uuid: p,
                            ...m
                        }) : null
                    })
                }, p))
            })
        })
    };

function rf() {
    return rf = Object.assign ? Object.assign.bind() : function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
        }
        return t
    }, rf.apply(this, arguments)
}

function Hl(t, e, n) {
    return Math.max(t, Math.min(e, n))
}
class mE {
    advance(e) {
        var n;
        if (!this.isRunning) return;
        let r = !1;
        if (this.lerp) this.value = (i = this.value, o = this.to, (1 - (s = 1 - Math.exp(-60 * this.lerp * e))) * i + s * o), Math.round(this.value) === this.to && (this.value = this.to, r = !0);
        else {
            this.currentTime += e;
            const a = Hl(0, this.currentTime / this.duration, 1);
            r = a >= 1;
            const l = r ? 1 : this.easing(a);
            this.value = this.from + (this.to - this.from) * l
        }
        var i, o, s;
        (n = this.onUpdate) == null || n.call(this, this.value, r), r && this.stop()
    }
    stop() {
        this.isRunning = !1
    }
    fromTo(e, n, {
        lerp: r = .1,
        duration: i = 1,
        easing: o = l => l,
        onStart: s,
        onUpdate: a
    }) {
        this.from = this.value = e, this.to = n, this.lerp = r, this.duration = i, this.easing = o, this.currentTime = 0, this.isRunning = !0, s == null || s(), this.onUpdate = a
    }
}
class gE {
    constructor({
        wrapper: e,
        content: n,
        autoResize: r = !0
    } = {}) {
        if (this.resize = () => {
                this.onWrapperResize(), this.onContentResize()
            }, this.onWrapperResize = () => {
                this.wrapper === window ? (this.width = window.innerWidth, this.height = window.innerHeight) : (this.width = this.wrapper.clientWidth, this.height = this.wrapper.clientHeight)
            }, this.onContentResize = () => {
                this.scrollHeight = this.content.scrollHeight, this.scrollWidth = this.content.scrollWidth
            }, this.wrapper = e, this.content = n, r) {
            const i = function(o, s) {
                let a;
                return function() {
                    let l = arguments,
                        c = this;
                    clearTimeout(a), a = setTimeout(function() {
                        o.apply(c, l)
                    }, 250)
                }
            }(this.resize);
            this.wrapper !== window && (this.wrapperResizeObserver = new ResizeObserver(i), this.wrapperResizeObserver.observe(this.wrapper)), this.contentResizeObserver = new ResizeObserver(i), this.contentResizeObserver.observe(this.content)
        }
        this.resize()
    }
    destroy() {
        var e, n;
        (e = this.wrapperResizeObserver) == null || e.disconnect(), (n = this.contentResizeObserver) == null || n.disconnect()
    }
    get limit() {
        return {
            x: this.scrollWidth - this.width,
            y: this.scrollHeight - this.height
        }
    }
}
class jg {
    constructor() {
        this.events = {}
    }
    emit(e, ...n) {
        let r = this.events[e] || [];
        for (let i = 0, o = r.length; i < o; i++) r[i](...n)
    }
    on(e, n) {
        var r;
        return (r = this.events[e]) != null && r.push(n) || (this.events[e] = [n]), () => {
            var i;
            this.events[e] = (i = this.events[e]) == null ? void 0 : i.filter(o => n !== o)
        }
    }
    off(e, n) {
        var r;
        this.events[e] = (r = this.events[e]) == null ? void 0 : r.filter(i => n !== i)
    }
    destroy() {
        this.events = {}
    }
}
class vE {
    constructor(e, {
        wheelMultiplier: n = 1,
        touchMultiplier: r = 2,
        normalizeWheel: i = !1
    }) {
        this.onTouchStart = o => {
            const {
                clientX: s,
                clientY: a
            } = o.targetTouches ? o.targetTouches[0] : o;
            this.touchStart.x = s, this.touchStart.y = a, this.lastDelta = {
                x: 0,
                y: 0
            }
        }, this.onTouchMove = o => {
            const {
                clientX: s,
                clientY: a
            } = o.targetTouches ? o.targetTouches[0] : o, l = -(s - this.touchStart.x) * this.touchMultiplier, c = -(a - this.touchStart.y) * this.touchMultiplier;
            this.touchStart.x = s, this.touchStart.y = a, this.lastDelta = {
                x: l,
                y: c
            }, this.emitter.emit("scroll", {
                deltaX: l,
                deltaY: c,
                event: o
            })
        }, this.onTouchEnd = o => {
            this.emitter.emit("scroll", {
                deltaX: this.lastDelta.x,
                deltaY: this.lastDelta.y,
                event: o
            })
        }, this.onWheel = o => {
            let {
                deltaX: s,
                deltaY: a
            } = o;
            this.normalizeWheel && (s = Hl(-100, s, 100), a = Hl(-100, a, 100)), s *= this.wheelMultiplier, a *= this.wheelMultiplier, this.emitter.emit("scroll", {
                deltaX: s,
                deltaY: a,
                event: o
            })
        }, this.element = e, this.wheelMultiplier = n, this.touchMultiplier = r, this.normalizeWheel = i, this.touchStart = {
            x: null,
            y: null
        }, this.emitter = new jg, this.element.addEventListener("wheel", this.onWheel, {
            passive: !1
        }), this.element.addEventListener("touchstart", this.onTouchStart, {
            passive: !1
        }), this.element.addEventListener("touchmove", this.onTouchMove, {
            passive: !1
        }), this.element.addEventListener("touchend", this.onTouchEnd, {
            passive: !1
        })
    }
    on(e, n) {
        return this.emitter.on(e, n)
    }
    destroy() {
        this.emitter.destroy(), this.element.removeEventListener("wheel", this.onWheel, {
            passive: !1
        }), this.element.removeEventListener("touchstart", this.onTouchStart, {
            passive: !1
        }), this.element.removeEventListener("touchmove", this.onTouchMove, {
            passive: !1
        }), this.element.removeEventListener("touchend", this.onTouchEnd, {
            passive: !1
        })
    }
}
class yE {
    constructor({
        wrapper: e = window,
        content: n = document.documentElement,
        wheelEventsTarget: r = e,
        eventsTarget: i = r,
        smoothWheel: o = !0,
        smoothTouch: s = !1,
        syncTouch: a = !1,
        syncTouchLerp: l = .1,
        __iosNoInertiaSyncTouchLerp: c = .4,
        touchInertiaMultiplier: d = 35,
        duration: f,
        easing: h = O => Math.min(1, 1.001 - Math.pow(2, -10 * O)),
        lerp: p = !f && .1,
        infinite: m = !1,
        orientation: g = "vertical",
        gestureOrientation: y = "vertical",
        touchMultiplier: x = 1,
        wheelMultiplier: w = 1,
        normalizeWheel: M = !1,
        autoResize: T = !0
    } = {}) {
        this.onVirtualScroll = ({
            deltaX: O,
            deltaY: R,
            event: P
        }) => {
            if (P.ctrlKey) return;
            const B = P.type.includes("touch"),
                te = P.type.includes("wheel");
            if (this.options.gestureOrientation === "both" && O === 0 && R === 0 || this.options.gestureOrientation === "vertical" && R === 0 || this.options.gestureOrientation === "horizontal" && O === 0 || B && this.options.gestureOrientation === "vertical" && this.scroll === 0 && !this.options.infinite && R <= 0) return;
            let W = P.composedPath();
            if (W = W.slice(0, W.indexOf(this.rootElement)), W.find(X => {
                    var q;
                    return (X.hasAttribute == null ? void 0 : X.hasAttribute("data-lenis-prevent")) || B && (X.hasAttribute == null ? void 0 : X.hasAttribute("data-lenis-prevent-touch")) || te && (X.hasAttribute == null ? void 0 : X.hasAttribute("data-lenis-prevent-wheel")) || ((q = X.classList) == null ? void 0 : q.contains("lenis"))
                })) return;
            if (this.isStopped || this.isLocked) return void P.preventDefault();
            if (this.isSmooth = (this.options.smoothTouch || this.options.syncTouch) && B || this.options.smoothWheel && te, !this.isSmooth) return this.isScrolling = !1, void this.animate.stop();
            P.preventDefault();
            let ee = R;
            this.options.gestureOrientation === "both" ? ee = Math.abs(R) > Math.abs(O) ? R : O : this.options.gestureOrientation === "horizontal" && (ee = O);
            const V = B && this.options.syncTouch,
                I = B && P.type === "touchend" && Math.abs(ee) > 1;
            I && (ee = this.velocity * this.options.touchInertiaMultiplier), this.scrollTo(this.targetScroll + ee, rf({
                programmatic: !1
            }, V && {
                lerp: I ? this.syncTouchLerp : this.options.__iosNoInertiaSyncTouchLerp
            }))
        }, this.onNativeScroll = () => {
            if (!this.__preventNextScrollEvent && !this.isScrolling) {
                const O = this.animatedScroll;
                this.animatedScroll = this.targetScroll = this.actualScroll, this.velocity = 0, this.direction = Math.sign(this.animatedScroll - O), this.emit()
            }
        }, window.lenisVersion = "1.0.29", e !== document.documentElement && e !== document.body || (e = window), this.options = {
            wrapper: e,
            content: n,
            wheelEventsTarget: r,
            eventsTarget: i,
            smoothWheel: o,
            smoothTouch: s,
            syncTouch: a,
            syncTouchLerp: l,
            __iosNoInertiaSyncTouchLerp: c,
            touchInertiaMultiplier: d,
            duration: f,
            easing: h,
            lerp: p,
            infinite: m,
            gestureOrientation: y,
            orientation: g,
            touchMultiplier: x,
            wheelMultiplier: w,
            normalizeWheel: M,
            autoResize: T
        }, this.animate = new mE, this.emitter = new jg, this.dimensions = new gE({
            wrapper: e,
            content: n,
            autoResize: T
        }), this.toggleClass("lenis", !0), this.velocity = 0, this.isLocked = !1, this.isStopped = !1, this.isSmooth = a || o || s, this.isScrolling = !1, this.targetScroll = this.animatedScroll = this.actualScroll, this.options.wrapper.addEventListener("scroll", this.onNativeScroll, {
            passive: !1
        }), this.virtualScroll = new vE(i, {
            touchMultiplier: x,
            wheelMultiplier: w,
            normalizeWheel: M
        }), this.virtualScroll.on("scroll", this.onVirtualScroll)
    }
    destroy() {
        this.emitter.destroy(), this.options.wrapper.removeEventListener("scroll", this.onNativeScroll, {
            passive: !1
        }), this.virtualScroll.destroy(), this.dimensions.destroy(), this.toggleClass("lenis", !1), this.toggleClass("lenis-smooth", !1), this.toggleClass("lenis-scrolling", !1), this.toggleClass("lenis-stopped", !1), this.toggleClass("lenis-locked", !1)
    }
    on(e, n) {
        return this.emitter.on(e, n)
    }
    off(e, n) {
        return this.emitter.off(e, n)
    }
    setScroll(e) {
        this.isHorizontal ? this.rootElement.scrollLeft = e : this.rootElement.scrollTop = e
    }
    resize() {
        this.dimensions.resize()
    }
    emit() {
        this.emitter.emit("scroll", this)
    }
    reset() {
        this.isLocked = !1, this.isScrolling = !1, this.animatedScroll = this.targetScroll = this.actualScroll, this.velocity = 0, this.animate.stop()
    }
    start() {
        this.isStopped = !1, this.reset()
    }
    stop() {
        this.isStopped = !0, this.animate.stop(), this.reset()
    }
    raf(e) {
        const n = e - (this.time || e);
        this.time = e, this.animate.advance(.001 * n)
    }
    scrollTo(e, {
        offset: n = 0,
        immediate: r = !1,
        lock: i = !1,
        duration: o = this.options.duration,
        easing: s = this.options.easing,
        lerp: a = !o && this.options.lerp,
        onComplete: l = null,
        force: c = !1,
        programmatic: d = !0
    } = {}) {
        if (!this.isStopped && !this.isLocked || c) {
            if (["top", "left", "start"].includes(e)) e = 0;
            else if (["bottom", "right", "end"].includes(e)) e = this.limit;
            else {
                var f;
                let h;
                if (typeof e == "string" ? h = document.querySelector(e) : (f = e) != null && f.nodeType && (h = e), h) {
                    if (this.options.wrapper !== window) {
                        const m = this.options.wrapper.getBoundingClientRect();
                        n -= this.isHorizontal ? m.left : m.top
                    }
                    const p = h.getBoundingClientRect();
                    e = (this.isHorizontal ? p.left : p.top) + this.animatedScroll
                }
            }
            if (typeof e == "number") {
                if (e += n, e = Math.round(e), this.options.infinite ? d && (this.targetScroll = this.animatedScroll = this.scroll) : e = Hl(0, e, this.limit), r) return this.animatedScroll = this.targetScroll = e, this.setScroll(this.scroll), this.reset(), void(l == null || l(this));
                if (!d) {
                    if (e === this.targetScroll) return;
                    this.targetScroll = e
                }
                this.animate.fromTo(this.animatedScroll, e, {
                    duration: o,
                    easing: s,
                    lerp: a,
                    onStart: () => {
                        i && (this.isLocked = !0), this.isScrolling = !0
                    },
                    onUpdate: (h, p) => {
                        this.isScrolling = !0, this.velocity = h - this.animatedScroll, this.direction = Math.sign(this.velocity), this.animatedScroll = h, this.setScroll(this.scroll), d && (this.targetScroll = h), p || this.emit(), p && (this.reset(), this.emit(), l == null || l(this), this.__preventNextScrollEvent = !0, requestAnimationFrame(() => {
                            delete this.__preventNextScrollEvent
                        }))
                    }
                })
            }
        }
    }
    get rootElement() {
        return this.options.wrapper === window ? document.documentElement : this.options.wrapper
    }
    get limit() {
        return this.dimensions.limit[this.isHorizontal ? "x" : "y"]
    }
    get isHorizontal() {
        return this.options.orientation === "horizontal"
    }
    get actualScroll() {
        return this.isHorizontal ? this.rootElement.scrollLeft : this.rootElement.scrollTop
    }
    get scroll() {
        return this.options.infinite ? (this.animatedScroll % (e = this.limit) + e) % e : this.animatedScroll;
        var e
    }
    get progress() {
        return this.limit === 0 ? 1 : this.scroll / this.limit
    }
    get isSmooth() {
        return this.__isSmooth
    }
    set isSmooth(e) {
        this.__isSmooth !== e && (this.__isSmooth = e, this.toggleClass("lenis-smooth", e))
    }
    get isScrolling() {
        return this.__isScrolling
    }
    set isScrolling(e) {
        this.__isScrolling !== e && (this.__isScrolling = e, this.toggleClass("lenis-scrolling", e))
    }
    get isStopped() {
        return this.__isStopped
    }
    set isStopped(e) {
        this.__isStopped !== e && (this.__isStopped = e, this.toggleClass("lenis-stopped", e))
    }
    get isLocked() {
        return this.__isLocked
    }
    set isLocked(e) {
        this.__isLocked !== e && (this.__isLocked = e, this.toggleClass("lenis-locked", e))
    }
    get className() {
        let e = "lenis";
        return this.isStopped && (e += " lenis-stopped"), this.isLocked && (e += " lenis-locked"), this.isScrolling && (e += " lenis-scrolling"), this.isSmooth && (e += " lenis-smooth"), e
    }
    toggleClass(e, n) {
        this.rootElement.classList.toggle(e, n), this.emitter.emit("className change", this)
    }
}
const xE = to({
        tDiffuse: null,
        uScrollDelta: 0,
        uAlign: 1,
        uImage: new xr,
        uResolution: new xr,
        projectionMatrixInverse: new qc
    }, `
  uniform mat4 projectionMatrixInverse;
  uniform float uScrollDelta;

  varying vec2 vFluidUv;
  varying vec2 vUv;

  void main() {
    #include <begin_vertex>

    // transformed *= 1.0 - abs(uScrollDelta) * 0.002;
    
    #include <project_vertex>

    vec4 screenUv = projectionMatrix * mvPosition;
    screenUv /= screenUv.w;

    vec2 fluidUv = screenUv.xy * 0.5 + 0.5;

    vFluidUv = fluidUv;
    vUv = uv;
  }`, `
  uniform sampler2D tDiffuse;
  uniform vec2 uImage;
  uniform vec2 uResolution;
  uniform float uScrollDelta;
  uniform float uAlign;

  varying vec2 vFluidUv;
  varying vec2 vUv;

  vec4 RGBShift(sampler2D tDiffuse, vec2 uv, float angle, float amount) {
    vec2 offset = amount * vec2(cos(angle), sin(angle));
    vec4 cr = texture2D(tDiffuse, uv + offset * 2.0);
    vec4 cga = texture2D(tDiffuse, uv);
    vec4 cb = texture2D(tDiffuse, uv + offset);
    return vec4(cr.r, cga.g, cb.b, cga.a);
  }

  vec2 contain(vec2 st, vec2 resolution, vec2 image, float align) {
    vec2 s = resolution;
    vec2 i = image;
    float rs = s.x / s.y;
    float ri = i.x / i.y;
    vec2 new = rs > ri ? vec2(i.x * s.y / i.y, s.y) : vec2(s.x, i.y * s.x / i.x);
    vec2 offset = (rs > ri ? vec2((s.x - new.x) / 2.0, 0.0) : vec2(0.0, ((s.y - new.y)*uAlign) / 1.0)) / s;
    return (st * s - offset * s) / new;
  }

  vec3 adjustSaturation(vec3 color, float value) {
    // https://www.w3.org/TR/WCAG21/#dfn-relative-luminance
    const vec3 luminosityFactor = vec3(0.2126, 0.7152, 0.0722);
    vec3 grayscale = vec3(dot(color, luminosityFactor));
  
    return mix(grayscale, color, 1.0 + value);
  }

  vec3 adjustContrast(vec3 color, float value) {
    return 0.5 + (1.0 + value) * (color - 0.5);
  }

  vec3 adjustBrightness(vec3 color, float value) {
    return color + value;
  }

  void main() {
    vec2 uv  = vUv;
    
    vec2 containUV = contain(uv, uResolution, uImage, uAlign);
    
    vec3 color = RGBShift(tDiffuse, containUV, 0.0, -uScrollDelta * 0.001).rgb;

    color = adjustSaturation(color, 0.6);

    gl_FragColor = vec4(color, 1.0);

    if (containUV.x < 0.0 || containUV.x > 1.0 || containUV.y < 0.0 || containUV.y > 1.0) {
      discard;
    }

    #include <tonemapping_fragment>
    #include <encodings_fragment>
  }`),
    bE = ({
        align: t,
        ...e
    }) => {
        u.useMemo(() => Ur({
            PlaneShaderMaterial: xE
        }), []);
        const n = u.useRef(null),
            {
                get: r
            } = hr(),
            i = u.useRef(0),
            o = u.useRef(0),
            s = u.useRef(0),
            a = u.useCallback(() => {
                const {
                    instance: l
                } = n.current, c = l.material, {
                    bbox: d
                } = l.userData;
                c.uniforms.uResolution.value.set(d.z, d.w)
            }, []);
        return u.useLayoutEffect(() => {
            const {
                instance: l
            } = n.current, c = new ff().load(e.src, d => {
                const f = l.material;
                f.uniforms.tDiffuse.value = d, f.uniforms.uAlign.value = t === "bottom" ? 0 : 1, f.uniforms.uImage.value.set(d.image.width, d.image.height)
            });
            return () => {
                c.dispose()
            }
        }, [e.src, t, r]), u.useLayoutEffect(() => {
            const l = s.current,
                c = If.subscribe(d => d.scroll, (d, f) => {
                    s.current && clearTimeout(s.current), o.current = i.current, i.current = d - f, i.current !== 0 && (s.current = setTimeout(() => {
                        o.current = i.current, i.current = 0
                    }, 400))
                });
            return () => {
                l && clearTimeout(l), c()
            }
        }, []), kn(() => {
            if (!Bn.getState().leaf) return;
            const l = n.current.instance.material;
            l.uniforms.uScrollDelta.value = He.lerp(l.uniforms.uScrollDelta.value, i.current, .15)
        }), u.useEffect(() => (window.addEventListener("resize", a), a(), () => {
            window.removeEventListener("resize", a)
        }), [a]), v.jsx(wE, {
            ref: n,
            ...e,
            children: v.jsx("planeShaderMaterial", {
                toneMapped: !1,
                transparent: !0,
                depthTest: !1,
                depthWrite: !1
            })
        })
    },
    of = ({
        uuid: t,
        className: e,
        ...n
    }) => {
        const r = u.useRef(null);
        return v.jsxs(v.Fragment, {
            children: [v.jsx("img", {
                ref: r,
                ...n,
                className: Kt(e, "opacity-0")
            }), v.jsx(Lg.In, {
                children: v.jsx(bE, {
                    target: r,
                    ...n
                }, t)
            })]
        })
    },
    wE = u.forwardRef(({
        target: t,
        children: e
    }, n) => {
        const r = hr(d => d.get),
            i = u.useRef(null),
            o = u.useCallback((d, f = 0) => {
                const h = d.fov * Math.PI / 180,
                    p = d.position.z - f,
                    m = 2 * Math.tan(h / 2) * Math.abs(p);
                return {
                    x: m * d.aspect,
                    y: m
                }
            }, []),
            s = u.useCallback(() => {
                i.current.userData.size = new xr, i.current.userData.viewport = new xr, i.current.userData.bbox = new yl, i.current.userData.scale = new xr
            }, []),
            a = u.useCallback(() => {
                if (!t.current) return;
                const {
                    viewport: d
                } = r(), f = t.current.getBoundingClientRect(), h = {
                    width: window.innerWidth,
                    height: window.innerHeight
                };
                i.current.userData.size.set(h.width, h.height), i.current.userData.viewport.set(d.width, d.height), i.current.userData.bbox.set(f.left, f.top, f.width, f.height), i.current.userData.scale.set(d.width / h.width, d.height / h.height)
            }, [t, r]),
            l = u.useCallback(() => {
                const {
                    size: d,
                    bbox: f
                } = i.current.userData, h = o(r().camera), p = He.mapLinear(f.x + f.z * .5, 0, d.x, -h.x * .5, h.x * .5), m = He.mapLinear(f.y + f.w * .5, 0, d.y, h.y * .5, -h.y * .5);
                i.current.scale.x = f.z * (h.x / d.width), i.current.scale.y = f.w * (h.y / d.height), i.current.position.x = p, i.current.position.y = m + 1
            }, [r, o]),
            c = u.useCallback(() => {
                a(), l()
            }, [a, l]);
        return u.useEffect(() => {
            const d = If.subscribe(f => f.scroll, (f, h) => {
                const p = h - f;
                i.current.userData.bbox.x += p, c()
            });
            return () => {
                d()
            }
        }, [c]), u.useEffect(() => (window.addEventListener("resize", c), s(), c(), () => {
            window.removeEventListener("resize", c)
        }), [s, c]), u.useImperativeHandle(n, () => ({
            instance: i.current
        }), []), v.jsxs("mesh", {
            ref: i,
            children: [v.jsx("planeGeometry", {
                args: [1, 1, 64, 64]
            }), e]
        })
    });
var bh, wh;
const _h = typeof window < "u" && ((bh = window.document) != null && bh.createElement || ((wh = window.navigator) == null ? void 0 : wh.product) === "ReactNative") ? j.useLayoutEffect : j.useEffect;

function _E() {
    const t = us(e => ({
        current: new Array,
        version: 0,
        set: e
    }));
    return {
        In: ({
            children: e
        }) => {
            const n = t(i => i.set),
                r = t(i => i.version);
            return _h(() => {
                n(i => ({
                    version: i.version + 1
                }))
            }, []), _h(() => (n(({
                current: i
            }) => ({
                current: [...i, e]
            })), () => n(({
                current: i
            }) => ({
                current: i.filter(o => o !== e)
            }))), [e, r]), null
        },
        Out: () => {
            const e = t(n => n.current);
            return j.createElement(j.Fragment, null, e)
        }
    }
}
const Lg = _E(),
    DE = () => v.jsx(Lg.Out, {}),
    SE = ({
        source1: t,
        source2: e
    }) => {
        const [n, r] = Xl({
            threshold: 0,
            triggerOnce: !0
        }), i = u.useMemo(() => Mu(t), [t]), o = u.useMemo(() => Mu(e), [e]), s = u.useRef(null), a = u.useRef(null);
        return u.useLayoutEffect(() => {
            const l = he.context(() => {
                s.current = he.timeline().add(he.timeline({
                    defaults: {
                        duration: 1,
                        ease: "power2.out"
                    }
                }).fromTo("[data-gsap-mask1]", {
                    xPercent: 100
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }).fromTo("[data-gsap-image1]", {
                    xPercent: -80
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }, "<")).add(he.timeline({
                    defaults: {
                        duration: 1,
                        ease: "power2.out"
                    }
                }).fromTo("[data-gsap-mask2]", {
                    xPercent: 100
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }).fromTo("[data-gsap-image2]", {
                    xPercent: -80
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }, "<"), "<+.1")
            }, a.current);
            return () => {
                l.revert()
            }
        }, []), u.useEffect(() => {
            r ? s.current.play() : s.current.reverse()
        }, [r]), v.jsxs(Ta, {
            ref: a,
            className: "h-full grid-cols-s5 lg:grid-cols-s6",
            children: [v.jsx("div", {
                ref: n,
                className: "row-span-2 md:row-span-4 col-span-4 col-start-2 lg:col-start-3",
                children: v.jsx("div", {
                    className: "relative w-full h-full overflow-hidden",
                    children: v.jsx("div", {
                        className: "relative w-full h-full overflow-hidden",
                        "data-gsap-mask1": !0,
                        children: v.jsx( of , {
                            uuid: i,
                            align: "bottom",
                            src: `${Pu}${t}`,
                            alt: "",
                            className: "shrink-0 w-full h-full object-contain object-right-bottom",
                            "data-gsap-image1": !0
                        })
                    })
                })
            }), v.jsx("div", {
                className: "row-span-2 md:row-span-4 col-span-4 col-start-2 lg:col-start-3",
                children: v.jsx("div", {
                    className: "relative w-full h-full overflow-hidden",
                    children: v.jsx("div", {
                        className: "relative w-full h-full overflow-hidden",
                        "data-gsap-mask2": !0,
                        children: v.jsx( of , {
                            uuid: o,
                            align: "top",
                            src: `${Pu}${e}`,
                            alt: "",
                            className: "shrink-0 w-full h-full object-contain object-right-top",
                            "data-gsap-image2": !0
                        })
                    })
                })
            })]
        })
    };
var sf = {
    exports: {}
};
(function(t, e) {
    (function(n, r) {
        r(e)
    })(uf, function(n) {
        var r = /[achlmqstvz]|(-?\d*\.?\d*(?:e[\-+]?\d+)?)[0-9]/ig,
            i = /(?:(-)?\d*\.?\d*(?:e[\-+]?\d+)?)[0-9]/ig,
            o = /[\+\-]?\d*\.?\d+e[\+\-]?\d+/ig,
            s = /(^[#\.][a-z]|[a-y][a-z])/i,
            a = Math.PI / 180,
            l = 180 / Math.PI,
            c = Math.sin,
            d = Math.cos,
            f = Math.abs,
            h = Math.sqrt,
            p = Math.atan2,
            m = 1e8,
            g = function(_) {
                return typeof _ == "string"
            },
            y = function(_) {
                return typeof _ == "number"
            },
            x = function(_) {
                return typeof _ > "u"
            },
            w = {},
            M = {},
            T = 1e5,
            O = function(_) {
                return Math.round((_ + m) % 1 * T) / T || (_ < 0 ? 0 : 1)
            },
            R = function(_) {
                return Math.round(_ * T) / T || 0
            },
            P = function(_) {
                return Math.round(_ * 1e10) / 1e10 || 0
            },
            B = function(_, D, $, A) {
                var N = _[D],
                    G = A === 1 ? 6 : tt(N, $, A);
                if (G && G + $ + 2 < N.length) return _.splice(D, 0, N.slice(0, $ + G + 2)), N.splice(0, $ + G), 1
            },
            te = function(_, D, $) {
                var A = _.length,
                    N = ~~($ * A);
                if (_[N] > D) {
                    for (; --N && _[N] > D;);
                    N < 0 && (N = 0)
                } else
                    for (; _[++N] < D && N < A;);
                return N < A ? N : A - 1
            },
            W = function(_, D) {
                var $ = _.length;
                for (D || _.reverse(); $--;) _[$].reversed || q(_[$])
            },
            ee = function(_, D) {
                return D.totalLength = _.totalLength, _.samples ? (D.samples = _.samples.slice(0), D.lookup = _.lookup.slice(0), D.minLength = _.minLength, D.resolution = _.resolution) : _.totalPoints && (D.totalPoints = _.totalPoints), D
            },
            V = function(_, D) {
                var $ = _.length,
                    A = _[$ - 1] || [],
                    N = A.length;
                $ && D[0] === A[N - 2] && D[1] === A[N - 1] && (D = A.concat(D.slice(2)), $--), _[$] = D
            };

        function I(k) {
            k = g(k) && s.test(k) && document.querySelector(k) || k;
            var _ = k.getAttribute ? k : 0,
                D;
            return _ && (k = k.getAttribute("d")) ? (_._gsPath || (_._gsPath = {}), D = _._gsPath[k], D && !D._dirty ? D : _._gsPath[k] = rt(k)) : k ? g(k) ? rt(k) : y(k[0]) ? [k] : k : console.warn("Expecting a <path> element or an SVG path data string")
        }

        function X(k) {
            for (var _ = [], D = 0; D < k.length; D++) _[D] = ee(k[D], k[D].slice(0));
            return ee(k, _)
        }

        function q(k) {
            var _ = 0,
                D;
            for (k.reverse(); _ < k.length; _ += 2) D = k[_], k[_] = k[_ + 1], k[_ + 1] = D;
            k.reversed = !k.reversed
        }
        var Z = function(_, D) {
                var $ = document.createElementNS("http://www.w3.org/2000/svg", "path"),
                    A = [].slice.call(_.attributes),
                    N = A.length,
                    G;
                for (D = "," + D + ","; --N > -1;) G = A[N].nodeName.toLowerCase(), D.indexOf("," + G + ",") < 0 && $.setAttributeNS(null, G, A[N].nodeValue);
                return $
            },
            le = {
                rect: "rx,ry,x,y,width,height",
                circle: "r,cx,cy",
                ellipse: "rx,ry,cx,cy",
                line: "x1,x2,y1,y2"
            },
            Se = function(_, D) {
                for (var $ = D ? D.split(",") : [], A = {}, N = $.length; --N > -1;) A[$[N]] = +_.getAttribute($[N]) || 0;
                return A
            };

        function Me(k, _) {
            var D = k.tagName.toLowerCase(),
                $ = .552284749831,
                A, N, G, Q, J, Y, fe, K, me, De, Te, xe, ne, b, F, E, U, ie, de, se, ye, ue;
            return D === "path" || !k.getBBox ? k : (Y = Z(k, "x,y,width,height,cx,cy,rx,ry,r,x1,x2,y1,y2,points"), ue = Se(k, le[D]), D === "rect" ? (Q = ue.rx, J = ue.ry || Q, N = ue.x, G = ue.y, De = ue.width - Q * 2, Te = ue.height - J * 2, Q || J ? (xe = N + Q * (1 - $), ne = N + Q, b = ne + De, F = b + Q * $, E = b + Q, U = G + J * (1 - $), ie = G + J, de = ie + Te, se = de + J * $, ye = de + J, A = "M" + E + "," + ie + " V" + de + " C" + [E, se, F, ye, b, ye, b - (b - ne) / 3, ye, ne + (b - ne) / 3, ye, ne, ye, xe, ye, N, se, N, de, N, de - (de - ie) / 3, N, ie + (de - ie) / 3, N, ie, N, U, xe, G, ne, G, ne + (b - ne) / 3, G, b - (b - ne) / 3, G, b, G, F, G, E, U, E, ie].join(",") + "z") : A = "M" + (N + De) + "," + G + " v" + Te + " h" + -De + " v" + -Te + " h" + De + "z") : D === "circle" || D === "ellipse" ? (D === "circle" ? (Q = J = ue.r, K = Q * $) : (Q = ue.rx, J = ue.ry, K = J * $), N = ue.cx, G = ue.cy, fe = Q * $, A = "M" + (N + Q) + "," + G + " C" + [N + Q, G + K, N + fe, G + J, N, G + J, N - fe, G + J, N - Q, G + K, N - Q, G, N - Q, G - K, N - fe, G - J, N, G - J, N + fe, G - J, N + Q, G - K, N + Q, G].join(",") + "z") : D === "line" ? A = "M" + ue.x1 + "," + ue.y1 + " L" + ue.x2 + "," + ue.y2 : (D === "polyline" || D === "polygon") && (me = (k.getAttribute("points") + "").match(i) || [], N = me.shift(), G = me.shift(), A = "M" + N + "," + G + " L" + me.join(","), D === "polygon" && (A += "," + N + "," + G + "z")), Y.setAttribute("d", Lt(Y._gsRawPath = rt(A))), _ && k.parentNode && (k.parentNode.insertBefore(Y, k), k.parentNode.removeChild(k)), Y)
        }

        function z(k, _, D) {
            var $ = k[_],
                A = k[_ + 2],
                N = k[_ + 4],
                G;
            return $ += (A - $) * D, A += (N - A) * D, $ += (A - $) * D, G = A + (N + (k[_ + 6] - N) * D - A) * D - $, $ = k[_ + 1], A = k[_ + 3], N = k[_ + 5], $ += (A - $) * D, A += (N - A) * D, $ += (A - $) * D, R(p(A + (N + (k[_ + 7] - N) * D - A) * D - $, G) * l)
        }

        function ge(k, _, D) {
            D = x(D) ? 1 : P(D) || 0, _ = P(_) || 0;
            var $ = Math.max(0, ~~(f(D - _) - 1e-8)),
                A = X(k);
            if (_ > D && (_ = 1 - _, D = 1 - D, W(A), A.totalLength = 0), _ < 0 || D < 0) {
                var N = Math.abs(~~Math.min(_, D)) + 1;
                _ += N, D += N
            }
            A.totalLength || Xe(A);
            var G = D > 1,
                Q = wt(A, _, w, !0),
                J = wt(A, D, M),
                Y = J.segment,
                fe = Q.segment,
                K = J.segIndex,
                me = Q.segIndex,
                De = J.i,
                Te = Q.i,
                xe = me === K,
                ne = De === Te && xe,
                b, F, E, U, ie, de, se, ye;
            if (G || $) {
                for (b = K < me || xe && De < Te || ne && J.t < Q.t, B(A, me, Te, Q.t) && (me++, b || (K++, ne ? (J.t = (J.t - Q.t) / (1 - Q.t), De = 0) : xe && (De -= Te))), Math.abs(1 - (D - _)) < 1e-5 ? K = me - 1 : !J.t && K ? K-- : B(A, K, De, J.t) && b && me++, Q.t === 1 && (me = (me + 1) % A.length), ie = [], de = A.length, se = 1 + de * $, ye = me, se += (de - me + K) % de, U = 0; U < se; U++) V(ie, A[ye++ % de]);
                A = ie
            } else if (E = J.t === 1 ? 6 : tt(Y, De, J.t), _ !== D)
                for (F = tt(fe, Te, ne ? Q.t / J.t : Q.t), xe && (E += F), Y.splice(De + E + 2), (F || Te) && fe.splice(0, Te + F), U = A.length; U--;)(U < me || U > K) && A.splice(U, 1);
            else Y.angle = z(Y, De + E, 0), De += E, Q = Y[De], J = Y[De + 1], Y.length = Y.totalLength = 0, Y.totalPoints = A.totalPoints = 8, Y.push(Q, J, Q, J, Q, J, Q, J);
            return A.totalLength = 0, A
        }

        function $e(k, _, D) {
            _ = _ || 0, k.samples || (k.samples = [], k.lookup = []);
            var $ = ~~k.resolution || 12,
                A = 1 / $,
                N = D ? _ + D * 6 + 1 : k.length,
                G = k[_],
                Q = k[_ + 1],
                J = _ ? _ / 6 * $ : 0,
                Y = k.samples,
                fe = k.lookup,
                K = (_ ? k.minLength : m) || m,
                me = Y[J + D * $ - 1],
                De = _ ? Y[J - 1] : 0,
                Te, xe, ne, b, F, E, U, ie, de, se, ye, ue, Pe, We, Ze, S, st;
            for (Y.length = fe.length = 0, xe = _ + 2; xe < N; xe += 6) {
                if (ne = k[xe + 4] - G, b = k[xe + 2] - G, F = k[xe] - G, ie = k[xe + 5] - Q, de = k[xe + 3] - Q, se = k[xe + 1] - Q, E = U = ye = ue = 0, f(ne) < .01 && f(ie) < .01 && f(F) + f(se) < .01) k.length > 8 && (k.splice(xe, 6), xe -= 6, N -= 6);
                else
                    for (Te = 1; Te <= $; Te++) We = A * Te, Pe = 1 - We, E = U - (U = (We * We * ne + 3 * Pe * (We * b + Pe * F)) * We), ye = ue - (ue = (We * We * ie + 3 * Pe * (We * de + Pe * se)) * We), S = h(ye * ye + E * E), S < K && (K = S), De += S, Y[J++] = De;
                G += ne, Q += ie
            }
            if (me)
                for (me -= De; J < Y.length; J++) Y[J] += me;
            if (Y.length && K) {
                if (k.totalLength = st = Y[Y.length - 1] || 0, k.minLength = K, st / K < 9999)
                    for (S = Ze = 0, Te = 0; Te < st; Te += K) fe[S++] = Y[Ze] < Te ? ++Ze : Ze
            } else k.totalLength = Y[0] = 0;
            return _ ? De - Y[_ / 2 - 1] : De
        }

        function Xe(k, _) {
            var D, $, A;
            for (A = D = $ = 0; A < k.length; A++) k[A].resolution = ~~_ || 12, $ += k[A].length, D += $e(k[A]);
            return k.totalPoints = $, k.totalLength = D, k
        }

        function tt(k, _, D) {
            if (D <= 0 || D >= 1) return 0;
            var $ = k[_],
                A = k[_ + 1],
                N = k[_ + 2],
                G = k[_ + 3],
                Q = k[_ + 4],
                J = k[_ + 5],
                Y = k[_ + 6],
                fe = k[_ + 7],
                K = $ + (N - $) * D,
                me = N + (Q - N) * D,
                De = A + (G - A) * D,
                Te = G + (J - G) * D,
                xe = K + (me - K) * D,
                ne = De + (Te - De) * D,
                b = Q + (Y - Q) * D,
                F = J + (fe - J) * D;
            return me += (b - me) * D, Te += (F - Te) * D, k.splice(_ + 2, 4, R(K), R(De), R(xe), R(ne), R(xe + (me - xe) * D), R(ne + (Te - ne) * D), R(me), R(Te), R(b), R(F)), k.samples && k.samples.splice(_ / 6 * k.resolution | 0, 0, 0, 0, 0, 0, 0, 0), 6
        }

        function wt(k, _, D, $) {
            D = D || {}, k.totalLength || Xe(k), (_ < 0 || _ > 1) && (_ = O(_));
            var A = 0,
                N = k[0],
                G, Q, J, Y, fe, K, me;
            if (!_) me = K = A = 0, N = k[0];
            else if (_ === 1) me = 1, A = k.length - 1, N = k[A], K = N.length - 8;
            else {
                if (k.length > 1) {
                    for (J = k.totalLength * _, fe = K = 0;
                        (fe += k[K++].totalLength) < J;) A = K;
                    N = k[A], Y = fe - N.totalLength, _ = (J - Y) / (fe - Y) || 0
                }
                G = N.samples, Q = N.resolution, J = N.totalLength * _, K = N.lookup.length ? N.lookup[~~(J / N.minLength)] || 0 : te(G, J, _), Y = K ? G[K - 1] : 0, fe = G[K], fe < J && (Y = fe, fe = G[++K]), me = 1 / Q * ((J - Y) / (fe - Y) + K % Q), K = ~~(K / Q) * 6, $ && me === 1 && (K + 6 < N.length ? (K += 6, me = 0) : A + 1 < k.length && (K = me = 0, N = k[++A]))
            }
            return D.t = me, D.i = K, D.path = k, D.segment = N, D.segIndex = A, D
        }

        function Ue(k, _, D, $) {
            var A = k[0],
                N = $ || {},
                G, Q, J, Y, fe, K, me, De, Te;
            if ((_ < 0 || _ > 1) && (_ = O(_)), A.lookup || Xe(k), k.length > 1) {
                for (J = k.totalLength * _, fe = K = 0;
                    (fe += k[K++].totalLength) < J;) A = k[K];
                Y = fe - A.totalLength, _ = (J - Y) / (fe - Y) || 0
            }
            return G = A.samples, Q = A.resolution, J = A.totalLength * _, K = A.lookup.length ? A.lookup[_ < 1 ? ~~(J / A.minLength) : A.lookup.length - 1] || 0 : te(G, J, _), Y = K ? G[K - 1] : 0, fe = G[K], fe < J && (Y = fe, fe = G[++K]), me = 1 / Q * ((J - Y) / (fe - Y) + K % Q) || 0, Te = 1 - me, K = ~~(K / Q) * 6, De = A[K], N.x = R((me * me * (A[K + 6] - De) + 3 * Te * (me * (A[K + 4] - De) + Te * (A[K + 2] - De))) * me + De), N.y = R((me * me * (A[K + 7] - (De = A[K + 1])) + 3 * Te * (me * (A[K + 5] - De) + Te * (A[K + 3] - De))) * me + De), D && (N.angle = A.totalLength ? z(A, K, me >= 1 ? 1 - 1e-9 : me || 1e-9) : A.angle || 0), N
        }

        function Ye(k, _, D, $, A, N, G) {
            for (var Q = k.length, J, Y, fe, K, me; --Q > -1;)
                for (J = k[Q], Y = J.length, fe = 0; fe < Y; fe += 2) K = J[fe], me = J[fe + 1], J[fe] = K * _ + me * $ + N, J[fe + 1] = K * D + me * A + G;
            return k._dirty = 1, k
        }

        function Ge(k, _, D, $, A, N, G, Q, J) {
            if (!(k === Q && _ === J)) {
                D = f(D), $ = f($);
                var Y = A % 360 * a,
                    fe = d(Y),
                    K = c(Y),
                    me = Math.PI,
                    De = me * 2,
                    Te = (k - Q) / 2,
                    xe = (_ - J) / 2,
                    ne = fe * Te + K * xe,
                    b = -K * Te + fe * xe,
                    F = ne * ne,
                    E = b * b,
                    U = F / (D * D) + E / ($ * $);
                U > 1 && (D = h(U) * D, $ = h(U) * $);
                var ie = D * D,
                    de = $ * $,
                    se = (ie * de - ie * E - de * F) / (ie * E + de * F);
                se < 0 && (se = 0);
                var ye = (N === G ? -1 : 1) * h(se),
                    ue = ye * (D * b / $),
                    Pe = ye * -($ * ne / D),
                    We = (k + Q) / 2,
                    Ze = (_ + J) / 2,
                    S = We + (fe * ue - K * Pe),
                    st = Ze + (K * ue + fe * Pe),
                    Et = (ne - ue) / D,
                    on = (b - Pe) / $,
                    Zt = (-ne - ue) / D,
                    $r = (-b - Pe) / $,
                    ri = Et * Et + on * on,
                    ii = (on < 0 ? -1 : 1) * Math.acos(Et / h(ri)),
                    Tt = (Et * $r - on * Zt < 0 ? -1 : 1) * Math.acos((Et * Zt + on * $r) / h(ri * (Zt * Zt + $r * $r)));
                isNaN(Tt) && (Tt = me), !G && Tt > 0 ? Tt -= De : G && Tt < 0 && (Tt += De), ii %= De, Tt %= De;
                var qn = Math.ceil(f(Tt) / (De / 4)),
                    Vt = [],
                    kt = Tt / qn,
                    mr = 4 / 3 * c(kt / 2) / (1 + d(kt / 2)),
                    Li = fe * D,
                    Ut = K * D,
                    Yr = K * -$,
                    _t = fe * $,
                    mn;
                for (mn = 0; mn < qn; mn++) A = ii + mn * kt, ne = d(A), b = c(A), Et = d(A += kt), on = c(A), Vt.push(ne - mr * b, b + mr * ne, Et + mr * on, on - mr * Et, Et, on);
                for (mn = 0; mn < Vt.length; mn += 2) ne = Vt[mn], b = Vt[mn + 1], Vt[mn] = ne * Li + b * Yr + S, Vt[mn + 1] = ne * Ut + b * _t + st;
                return Vt[mn - 2] = Q, Vt[mn - 1] = J, Vt
            }
        }

        function rt(k) {
            var _ = (k + "").replace(o, function(ue) {
                    var Pe = +ue;
                    return Pe < 1e-4 && Pe > -1e-4 ? 0 : Pe
                }).match(r) || [],
                D = [],
                $ = 0,
                A = 0,
                N = 2 / 3,
                G = _.length,
                Q = 0,
                J = "ERROR: malformed path: " + k,
                Y, fe, K, me, De, Te, xe, ne, b, F, E, U, ie, de, se, ye = function(Pe, We, Ze, S) {
                    F = (Ze - Pe) / 3, E = (S - We) / 3, xe.push(Pe + F, We + E, Ze - F, S - E, Ze, S)
                };
            if (!k || !isNaN(_[0]) || isNaN(_[1])) return console.log(J), D;
            for (Y = 0; Y < G; Y++)
                if (ie = De, isNaN(_[Y]) ? (De = _[Y].toUpperCase(), Te = De !== _[Y]) : Y--, K = +_[Y + 1], me = +_[Y + 2], Te && (K += $, me += A), Y || (ne = K, b = me), De === "M") xe && (xe.length < 8 ? D.length -= 1 : Q += xe.length), $ = ne = K, A = b = me, xe = [K, me], D.push(xe), Y += 2, De = "L";
                else if (De === "C") xe || (xe = [0, 0]), Te || ($ = A = 0), xe.push(K, me, $ + _[Y + 3] * 1, A + _[Y + 4] * 1, $ += _[Y + 5] * 1, A += _[Y + 6] * 1), Y += 6;
            else if (De === "S") F = $, E = A, (ie === "C" || ie === "S") && (F += $ - xe[xe.length - 4], E += A - xe[xe.length - 3]), Te || ($ = A = 0), xe.push(F, E, K, me, $ += _[Y + 3] * 1, A += _[Y + 4] * 1), Y += 4;
            else if (De === "Q") F = $ + (K - $) * N, E = A + (me - A) * N, Te || ($ = A = 0), $ += _[Y + 3] * 1, A += _[Y + 4] * 1, xe.push(F, E, $ + (K - $) * N, A + (me - A) * N, $, A), Y += 4;
            else if (De === "T") F = $ - xe[xe.length - 4], E = A - xe[xe.length - 3], xe.push($ + F, A + E, K + ($ + F * 1.5 - K) * N, me + (A + E * 1.5 - me) * N, $ = K, A = me), Y += 2;
            else if (De === "H") ye($, A, $ = K, A), Y += 1;
            else if (De === "V") ye($, A, $, A = K + (Te ? A - $ : 0)), Y += 1;
            else if (De === "L" || De === "Z") De === "Z" && (K = ne, me = b, xe.closed = !0), (De === "L" || f($ - K) > .5 || f(A - me) > .5) && (ye($, A, K, me), De === "L" && (Y += 2)), $ = K, A = me;
            else if (De === "A") {
                if (de = _[Y + 4], se = _[Y + 5], F = _[Y + 6], E = _[Y + 7], fe = 7, de.length > 1 && (de.length < 3 ? (E = F, F = se, fe--) : (E = se, F = de.substr(2), fe -= 2), se = de.charAt(1), de = de.charAt(0)), U = Ge($, A, +_[Y + 1], +_[Y + 2], +_[Y + 3], +de, +se, (Te ? $ : 0) + F * 1, (Te ? A : 0) + E * 1), Y += fe, U)
                    for (fe = 0; fe < U.length; fe++) xe.push(U[fe]);
                $ = xe[xe.length - 2], A = xe[xe.length - 1]
            } else console.log(J);
            return Y = xe.length, Y < 6 ? (D.pop(), Y = 0) : xe[0] === xe[Y - 2] && xe[1] === xe[Y - 1] && (xe.closed = !0), D.totalPoints = Q + Y, D
        }

        function it(k, _) {
            _ === void 0 && (_ = 1);
            for (var D = k[0], $ = 0, A = [D, $], N = 2; N < k.length; N += 2) A.push(D, $, k[N], $ = (k[N] - D) * _ / 2, D = k[N], -$);
            return A
        }

        function lt(k, _) {
            f(k[0] - k[2]) < 1e-4 && f(k[1] - k[3]) < 1e-4 && (k = k.slice(2));
            var D = k.length - 2,
                $ = +k[0],
                A = +k[1],
                N = +k[2],
                G = +k[3],
                Q = [$, A, $, A],
                J = N - $,
                Y = G - A,
                fe = Math.abs(k[D] - $) < .001 && Math.abs(k[D + 1] - A) < .001,
                K, me, De, Te, xe, ne, b, F, E, U, ie, de, se, ye, ue;
            for (fe && (k.push(N, G), N = $, G = A, $ = k[D - 2], A = k[D - 1], k.unshift($, A), D += 4), _ = _ || _ === 0 ? +_ : 1, De = 2; De < D; De += 2) K = $, me = A, $ = N, A = G, N = +k[De + 2], G = +k[De + 3], !($ === N && A === G) && (Te = J, xe = Y, J = N - $, Y = G - A, ne = h(Te * Te + xe * xe), b = h(J * J + Y * Y), F = h(Math.pow(J / b + Te / ne, 2) + Math.pow(Y / b + xe / ne, 2)), E = (ne + b) * _ * .25 / F, U = $ - ($ - K) * (ne ? E / ne : 0), ie = $ + (N - $) * (b ? E / b : 0), de = $ - (U + ((ie - U) * (ne * 3 / (ne + b) + .5) / 4 || 0)), se = A - (A - me) * (ne ? E / ne : 0), ye = A + (G - A) * (b ? E / b : 0), ue = A - (se + ((ye - se) * (ne * 3 / (ne + b) + .5) / 4 || 0)), ($ !== K || A !== me) && Q.push(R(U + de), R(se + ue), R($), R(A), R(ie + de), R(ye + ue)));
            return $ !== N || A !== G || Q.length < 4 ? Q.push(R(N), R(G), R(N), R(G)) : Q.length -= 2, Q.length === 2 ? Q.push($, A, $, A, $, A) : fe && (Q.splice(0, 6), Q.length = Q.length - 6), Q
        }

        function Lt(k) {
            y(k[0]) && (k = [k]);
            var _ = "",
                D = k.length,
                $, A, N, G;
            for (A = 0; A < D; A++) {
                for (G = k[A], _ += "M" + R(G[0]) + "," + R(G[1]) + " C", $ = G.length, N = 2; N < $; N++) _ += R(G[N++]) + "," + R(G[N++]) + " " + R(G[N++]) + "," + R(G[N++]) + " " + R(G[N++]) + "," + R(G[N]) + " ";
                G.closed && (_ += "z")
            }
            return _
        }
        var Ne, ct, ot, gt, re, pt, It, At, Je = "transform",
            fn = Je + "Origin",
            Ce, _e = function(_) {
                var D = _.ownerDocument || _;
                for (!(Je in _.style) && ("msTransform" in _.style) && (Je = "msTransform", fn = Je + "Origin"); D.parentNode && (D = D.parentNode););
                if (ct = window, It = new Ee, D) {
                    Ne = D, ot = D.documentElement, gt = D.body, At = Ne.createElementNS("http://www.w3.org/2000/svg", "g"), At.style.transform = "none";
                    var $ = D.createElement("div"),
                        A = D.createElement("div");
                    gt.appendChild($), $.appendChild(A), $.style.position = "static", $.style[Je] = "translate3d(0,0,1px)", Ce = A.offsetParent !== $, gt.removeChild($)
                }
                return D
            },
            Ve = function(_) {
                for (var D, $; _ && _ !== gt;) $ = _._gsap, $ && $.uncache && $.get(_, "x"), $ && !$.scaleX && !$.scaleY && $.renderTransform && ($.scaleX = $.scaleY = 1e-4, $.renderTransform(1, $), D ? D.push($) : D = [$]), _ = _.parentNode;
                return D
            },
            qe = [],
            pe = [],
            Mt = function() {
                return ct.pageYOffset || Ne.scrollTop || ot.scrollTop || gt.scrollTop || 0
            },
            Bt = function() {
                return ct.pageXOffset || Ne.scrollLeft || ot.scrollLeft || gt.scrollLeft || 0
            },
            vt = function(_) {
                return _.ownerSVGElement || ((_.tagName + "").toLowerCase() === "svg" ? _ : null)
            },
            Yt = function k(_) {
                if (ct.getComputedStyle(_).position === "fixed") return !0;
                if (_ = _.parentNode, _ && _.nodeType === 1) return k(_)
            },
            C = function k(_, D) {
                if (_.parentNode && (Ne || _e(_))) {
                    var $ = vt(_),
                        A = $ ? $.getAttribute("xmlns") || "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml",
                        N = $ ? D ? "rect" : "g" : "div",
                        G = D !== 2 ? 0 : 100,
                        Q = D === 3 ? 100 : 0,
                        J = "position:absolute;display:block;pointer-events:none;margin:0;padding:0;",
                        Y = Ne.createElementNS ? Ne.createElementNS(A.replace(/^https/, "http"), N) : Ne.createElement(N);
                    return D && ($ ? (pt || (pt = k(_)), Y.setAttribute("width", .01), Y.setAttribute("height", .01), Y.setAttribute("transform", "translate(" + G + "," + Q + ")"), pt.appendChild(Y)) : (re || (re = k(_), re.style.cssText = J), Y.style.cssText = J + "width:0.1px;height:0.1px;top:" + Q + "px;left:" + G + "px", re.appendChild(Y))), Y
                }
                throw "Need document and parent."
            },
            L = function(_) {
                for (var D = new Ee, $ = 0; $ < _.numberOfItems; $++) D.multiply(_.getItem($).matrix);
                return D
            },
            ce = function(_) {
                var D = _.getCTM(),
                    $;
                return D || ($ = _.style[Je], _.style[Je] = "none", _.appendChild(At), D = At.getCTM(), _.removeChild(At), $ ? _.style[Je] = $ : _.style.removeProperty(Je.replace(/([A-Z])/g, "-$1").toLowerCase())), D || It.clone()
            },
            oe = function(_, D) {
                var $ = vt(_),
                    A = _ === $,
                    N = $ ? qe : pe,
                    G = _.parentNode,
                    Q, J, Y, fe, K, me;
                if (_ === ct) return _;
                if (N.length || N.push(C(_, 1), C(_, 2), C(_, 3)), Q = $ ? pt : re, $) A ? (Y = ce(_), fe = -Y.e / Y.a, K = -Y.f / Y.d, J = It) : _.getBBox ? (Y = _.getBBox(), J = _.transform ? _.transform.baseVal : {}, J = J.numberOfItems ? J.numberOfItems > 1 ? L(J) : J.getItem(0).matrix : It, fe = J.a * Y.x + J.c * Y.y, K = J.b * Y.x + J.d * Y.y) : (J = new Ee, fe = K = 0), D && _.tagName.toLowerCase() === "g" && (fe = K = 0), (A ? $ : G).appendChild(Q), Q.setAttribute("transform", "matrix(" + J.a + "," + J.b + "," + J.c + "," + J.d + "," + (J.e + fe) + "," + (J.f + K) + ")");
                else {
                    if (fe = K = 0, Ce)
                        for (J = _.offsetParent, Y = _; Y && (Y = Y.parentNode) && Y !== J && Y.parentNode;)(ct.getComputedStyle(Y)[Je] + "").length > 4 && (fe = Y.offsetLeft, K = Y.offsetTop, Y = 0);
                    if (me = ct.getComputedStyle(_), me.position !== "absolute" && me.position !== "fixed")
                        for (J = _.offsetParent; G && G !== J;) fe += G.scrollLeft || 0, K += G.scrollTop || 0, G = G.parentNode;
                    Y = Q.style, Y.top = _.offsetTop - K + "px", Y.left = _.offsetLeft - fe + "px", Y[Je] = me[Je], Y[fn] = me[fn], Y.position = me.position === "fixed" ? "fixed" : "absolute", _.parentNode.appendChild(Q)
                }
                return Q
            },
            ve = function(_, D, $, A, N, G, Q) {
                return _.a = D, _.b = $, _.c = A, _.d = N, _.e = G, _.f = Q, _
            },
            Ee = function() {
                function k(D, $, A, N, G, Q) {
                    D === void 0 && (D = 1), $ === void 0 && ($ = 0), A === void 0 && (A = 0), N === void 0 && (N = 1), G === void 0 && (G = 0), Q === void 0 && (Q = 0), ve(this, D, $, A, N, G, Q)
                }
                var _ = k.prototype;
                return _.inverse = function() {
                    var $ = this.a,
                        A = this.b,
                        N = this.c,
                        G = this.d,
                        Q = this.e,
                        J = this.f,
                        Y = $ * G - A * N || 1e-10;
                    return ve(this, G / Y, -A / Y, -N / Y, $ / Y, (N * J - G * Q) / Y, -($ * J - A * Q) / Y)
                }, _.multiply = function($) {
                    var A = this.a,
                        N = this.b,
                        G = this.c,
                        Q = this.d,
                        J = this.e,
                        Y = this.f,
                        fe = $.a,
                        K = $.c,
                        me = $.b,
                        De = $.d,
                        Te = $.e,
                        xe = $.f;
                    return ve(this, fe * A + me * G, fe * N + me * Q, K * A + De * G, K * N + De * Q, J + Te * A + xe * G, Y + Te * N + xe * Q)
                }, _.clone = function() {
                    return new k(this.a, this.b, this.c, this.d, this.e, this.f)
                }, _.equals = function($) {
                    var A = this.a,
                        N = this.b,
                        G = this.c,
                        Q = this.d,
                        J = this.e,
                        Y = this.f;
                    return A === $.a && N === $.b && G === $.c && Q === $.d && J === $.e && Y === $.f
                }, _.apply = function($, A) {
                    A === void 0 && (A = {});
                    var N = $.x,
                        G = $.y,
                        Q = this.a,
                        J = this.b,
                        Y = this.c,
                        fe = this.d,
                        K = this.e,
                        me = this.f;
                    return A.x = N * Q + G * Y + K || 0, A.y = N * J + G * fe + me || 0, A
                }, k
            }();

        function Ae(k, _, D, $) {
            if (!k || !k.parentNode || (Ne || _e(k)).documentElement === k) return new Ee;
            var A = Ve(k),
                N = vt(k),
                G = N ? qe : pe,
                Q = oe(k, D),
                J = G[0].getBoundingClientRect(),
                Y = G[1].getBoundingClientRect(),
                fe = G[2].getBoundingClientRect(),
                K = Q.parentNode,
                me = !$ && Yt(k),
                De = new Ee((Y.left - J.left) / 100, (Y.top - J.top) / 100, (fe.left - J.left) / 100, (fe.top - J.top) / 100, J.left + (me ? 0 : Bt()), J.top + (me ? 0 : Mt()));
            if (K.removeChild(Q), A)
                for (J = A.length; J--;) Y = A[J], Y.scaleX = Y.scaleY = 0, Y.renderTransform(1, Y);
            return _ ? De.inverse() : De
        }
        /*!
         * MotionPathPlugin 3.12.2
         * https://greensock.com
         *
         * @license Copyright 2008-2023, GreenSock. All rights reserved.
         * Subject to the terms at https://greensock.com/standard-license or for
         * Club GreenSock members, the agreement issued with that membership.
         * @author: Jack Doyle, jack@greensock.com
         */
        var Oe = "x,translateX,left,marginLeft,xPercent".split(","),
            yt = "y,translateY,top,marginTop,yPercent".split(","),
            St = Math.PI / 180,
            ut, Nt, Xt, Rn, Ft, je, ze = function() {
                return ut || typeof window < "u" && (ut = window.gsap) && ut.registerPlugin && ut
            },
            Ct = function(_, D, $, A) {
                for (var N = D.length, G = A === 2 ? 0 : A, Q = 0; Q < N; Q++) _[G] = parseFloat(D[Q][$]), A === 2 && (_[G + 1] = 0), G += 2;
                return _
            },
            Wt = function(_, D, $) {
                return parseFloat(_._gsap.get(_, D, $ || "px")) || 0
            },
            Fe = function(_) {
                var D = _[0],
                    $ = _[1],
                    A;
                for (A = 2; A < _.length; A += 2) D = _[A] += D, $ = _[A + 1] += $
            },
            ht = function(_, D, $, A, N, G, Q, J, Y) {
                if (Q.type === "cubic") D = [D];
                else {
                    Q.fromCurrent !== !1 && D.unshift(Wt($, A, J), N ? Wt($, N, Y) : 0), Q.relative && Fe(D);
                    var fe = N ? lt : it;
                    D = [fe(D, Q.curviness)]
                }
                return D = G(nn(D, $, Q)), pn(_, $, A, D, "x", J), N && pn(_, $, N, D, "y", Y), Xe(D, Q.resolution || (Q.curviness === 0 ? 20 : 12))
            },
            Ke = function(_) {
                return _
            },
            xt = /[-+\.]*\d+\.?(?:e-|e\+)?\d*/g,
            dn = function(_, D, $) {
                var A = Ae(_),
                    N = 0,
                    G = 0,
                    Q;
                return (_.tagName + "").toLowerCase() === "svg" ? (Q = _.viewBox.baseVal, Q.width || (Q = {
                    width: +_.getAttribute("width"),
                    height: +_.getAttribute("height")
                })) : Q = D && _.getBBox && _.getBBox(), D && D !== "auto" && (N = D.push ? D[0] * (Q ? Q.width : _.offsetWidth || 0) : D.x, G = D.push ? D[1] * (Q ? Q.height : _.offsetHeight || 0) : D.y), $.apply(N || G ? A.apply({
                    x: N,
                    y: G
                }) : {
                    x: A.e,
                    y: A.f
                })
            },
            mt = function(_, D, $, A) {
                var N = Ae(_.parentNode, !0, !0),
                    G = N.clone().multiply(Ae(D)),
                    Q = dn(_, $, N),
                    J = dn(D, A, N),
                    Y = J.x,
                    fe = J.y,
                    K;
                return G.e = G.f = 0, A === "auto" && D.getTotalLength && D.tagName.toLowerCase() === "path" && (K = D.getAttribute("d").match(xt) || [], K = G.apply({
                    x: +K[0],
                    y: +K[1]
                }), Y += K.x, fe += K.y), K && (K = G.apply(D.getBBox()), Y -= K.x, fe -= K.y), G.e = Y - Q.x, G.f = fe - Q.y, G
            },
            nn = function(_, D, $) {
                var A = $.align,
                    N = $.matrix,
                    G = $.offsetX,
                    Q = $.offsetY,
                    J = $.alignOrigin,
                    Y = _[0][0],
                    fe = _[0][1],
                    K = Wt(D, "x"),
                    me = Wt(D, "y"),
                    De, Te, xe;
                return !_ || !_.length ? I("M0,0L0,0") : (A && (A === "self" || (De = Rn(A)[0] || D) === D ? Ye(_, 1, 0, 0, 1, K - Y, me - fe) : (J && J[2] !== !1 ? ut.set(D, {
                    transformOrigin: J[0] * 100 + "% " + J[1] * 100 + "%"
                }) : J = [Wt(D, "xPercent") / -100, Wt(D, "yPercent") / -100], Te = mt(D, De, J, "auto"), xe = Te.apply({
                    x: Y,
                    y: fe
                }), Ye(_, Te.a, Te.b, Te.c, Te.d, K + Te.e - (xe.x - Te.e), me + Te.f - (xe.y - Te.f)))), N ? Ye(_, N.a, N.b, N.c, N.d, N.e, N.f) : (G || Q) && Ye(_, 1, 0, 0, 1, G || 0, Q || 0), _)
            },
            pn = function(_, D, $, A, N, G) {
                var Q = D._gsap,
                    J = Q.harness,
                    Y = J && J.aliases && J.aliases[$],
                    fe = Y && Y.indexOf(",") < 0 ? Y : $,
                    K = _._pt = new Nt(_._pt, D, fe, 0, 0, Ke, 0, Q.set(D, fe, _));
                K.u = Xt(Q.get(D, fe, G)) || 0, K.path = A, K.pp = N, _._props.push(fe)
            },
            hn = function(_, D) {
                return function($) {
                    return _ || D !== 1 ? ge($, _, D) : $
                }
            },
            zt = {
                version: "3.12.2",
                name: "motionPath",
                register: function(_, D, $) {
                    ut = _, Xt = ut.utils.getUnit, Rn = ut.utils.toArray, Ft = ut.core.getStyleSaver, je = ut.core.reverting || function() {}, Nt = $
                },
                init: function(_, D, $) {
                    if (!ut) return console.warn("Please gsap.registerPlugin(MotionPathPlugin)"), !1;
                    (!(typeof D == "object" && !D.style) || !D.path) && (D = {
                        path: D
                    });
                    var A = [],
                        N = D,
                        G = N.path,
                        Q = N.autoRotate,
                        J = N.unitX,
                        Y = N.unitY,
                        fe = N.x,
                        K = N.y,
                        me = G[0],
                        De = hn(D.start, "end" in D ? D.end : 1),
                        Te, xe;
                    if (this.rawPaths = A, this.target = _, this.tween = $, this.styles = Ft && Ft(_, "transform"), (this.rotate = Q || Q === 0) && (this.rOffset = parseFloat(Q) || 0, this.radians = !!D.useRadians, this.rProp = D.rotation || "rotation", this.rSet = _._gsap.set(_, this.rProp, this), this.ru = Xt(_._gsap.get(_, this.rProp)) || 0), Array.isArray(G) && !("closed" in G) && typeof me != "number") {
                        for (xe in me) !fe && ~Oe.indexOf(xe) ? fe = xe : !K && ~yt.indexOf(xe) && (K = xe);
                        fe && K ? A.push(ht(this, Ct(Ct([], G, fe, 0), G, K, 1), _, fe, K, De, D, J || Xt(G[0][fe]), Y || Xt(G[0][K]))) : fe = K = 0;
                        for (xe in me) xe !== fe && xe !== K && A.push(ht(this, Ct([], G, xe, 2), _, xe, 0, De, D, Xt(G[0][xe])))
                    } else Te = De(nn(I(D.path), _, D)), Xe(Te, D.resolution), A.push(Te), pn(this, _, D.x || "x", Te, "x", D.unitX || "px"), pn(this, _, D.y || "y", Te, "y", D.unitY || "px")
                },
                render: function(_, D) {
                    var $ = D.rawPaths,
                        A = $.length,
                        N = D._pt;
                    if (D.tween._time || !je()) {
                        for (_ > 1 ? _ = 1 : _ < 0 && (_ = 0); A--;) Ue($[A], _, !A && D.rotate, $[A]);
                        for (; N;) N.set(N.t, N.p, N.path[N.pp] + N.u, N.d, _), N = N._next;
                        D.rotate && D.rSet(D.target, D.rProp, $[0].angle * (D.radians ? St : 1) + D.rOffset + D.ru, D, _)
                    } else D.styles.revert()
                },
                getLength: function(_) {
                    return Xe(I(_)).totalLength
                },
                sliceRawPath: ge,
                getRawPath: I,
                pointsToSegment: lt,
                stringToRawPath: rt,
                rawPathToString: Lt,
                transformRawPath: Ye,
                getGlobalMatrix: Ae,
                getPositionOnPath: Ue,
                cacheRawPathMeasurements: Xe,
                convertToPath: function(_, D) {
                    return Rn(_).map(function($) {
                        return Me($, D !== !1)
                    })
                },
                convertCoordinates: function(_, D, $) {
                    var A = Ae(D, !0, !0).multiply(Ae(_));
                    return $ ? A.apply($) : A
                },
                getAlignMatrix: mt,
                getRelativePosition: function(_, D, $, A) {
                    var N = mt(_, D, $, A);
                    return {
                        x: N.e,
                        y: N.f
                    }
                },
                arrayToRawPath: function(_, D) {
                    D = D || {};
                    var $ = Ct(Ct([], _, D.x || "x", 0), _, D.y || "y", 1);
                    return D.relative && Fe($), [D.type === "cubic" ? $ : lt($, D.curviness)]
                }
            };
        ze() && ut.registerPlugin(zt), n.MotionPathPlugin = zt, n.default = zt, Object.defineProperty(n, "__esModule", {
            value: !0
        })
    })
})(sf, sf.exports);
var CE = sf.exports;
const EE = cs(CE),
    TE = ({
        text1: t,
        text2: e,
        rowstart: n
    }) => {
        u.useMemo(() => he.registerPlugin(EE), []);
        const [r, i] = Xl({
            threshold: 0,
            triggerOnce: !0
        }), o = u.useRef(null), s = u.useRef(null);
        return u.useLayoutEffect(() => {
            const a = he.context(l => {
                const c = l.selector || he.utils.selector,
                    d = c("[data-gsap-text-large]")[0],
                    f = c("[data-gsap-text-regular]")[0],
                    h = he.matchMedia(s.current);
                h.add(Ol.SMALL, () => {
                    o.current = he.timeline().add(he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(d, {
                        autoAlpha: .2
                    }, {
                        autoAlpha: 1
                    }).fromTo(d, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff"
                    }, "<+.2")).add(he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(f, {
                        autoAlpha: .2
                    }, {
                        autoAlpha: 1
                    }).fromTo(f, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff"
                    }, "<+.2"), "<+.1")
                }), h.add(Ol.LARGE, () => {
                    const p = new In(d, {
                            type: "words",
                            wordsClass: "word"
                        }),
                        m = new In(f, {
                            type: "words",
                            wordsClass: "word"
                        });
                    return o.current = he.timeline().add(he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(p.words, {
                        autoAlpha: .2
                    }, {
                        autoAlpha: 1,
                        stagger: {
                            amount: .3
                        }
                    }).fromTo(p.words, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff",
                        stagger: {
                            amount: .3
                        }
                    }, "<+.2")).add(he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(m.words, {
                        autoAlpha: .3
                    }, {
                        autoAlpha: 1,
                        stagger: {
                            amount: .3
                        }
                    }).fromTo(m.words, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff",
                        stagger: {
                            amount: .3
                        }
                    }, "<+.2"), "<+.2"), () => {
                        p.revert(), m.revert()
                    }
                })
            }, s.current);
            return () => {
                a.revert()
            }
        }, []), u.useEffect(() => {
            i ? o.current.play() : o.current.reverse()
        }, [i]), v.jsxs(Ta, {
            ref: s,
            className: Kt("h-full gap-y-[4rem] grid-cols-s4 lg:grid-cols-s6 lg:md:grid-rows-8", {
                "grid-rows-[auto_auto_1fr] md:grid-rows-[auto_auto_1fr]": n[0] === 1,
                "grid-rows-[1fr_auto_auto_1fr] md:grid-rows-[1fr_auto_auto_1fr]": n[0] === 2,
                "grid-rows-[1fr_1fr_auto_auto_1fr] md:grid-rows-[1fr_1fr_auto_auto_1fr]": n[0] === 3,
                "grid-rows-[1fr_1fr_1fr_auto_auto md:grid-rows-[1fr_1fr_1fr_auto_auto]": n[0] === 4
            }),
            children: [v.jsx("div", {
                ref: r,
                className: Kt("col-span-3 col-start-2 lg:col-span-2 lg:col-start-3", {
                    "row-start-1": n[0] === 1,
                    "row-start-2": n[0] === 2,
                    "row-start-3": n[0] === 3,
                    "row-start-4": n[0] === 4,
                    "lg:row-start-1": n[1] === 1,
                    "lg:row-start-2": n[1] === 2,
                    "lg:row-start-3": n[1] === 3,
                    "lg:row-start-4": n[1] === 4,
                    "lg:row-start-5": n[1] === 5,
                    "lg:row-start-6": n[1] === 6
                }),
                children: v.jsx(an, {
                    size: "large",
                    paragraph: !0,
                    className: "text-white",
                    dangerouslySetInnerHTML: {
                        __html: t
                    },
                    "data-gsap-text-large": !0
                })
            }), v.jsx("div", {
                className: Kt("col-span-3 col-start-2 lg:col-span-2 lg:col-start-5", {
                    "row-start-2": n[0] === 1,
                    "row-start-3": n[0] === 2,
                    "row-start-4": n[0] === 3,
                    "row-start-5": n[0] === 4,
                    "lg:row-start-1": n[1] === 1,
                    "lg:row-start-2": n[1] === 2,
                    "lg:row-start-3": n[1] === 3,
                    "lg:row-start-4": n[1] === 4,
                    "lg:row-start-5": n[1] === 5,
                    "lg:row-start-6": n[1] === 6
                }),
                children: v.jsx(an, {
                    size: "regular",
                    paragraph: !0,
                    className: "text-white",
                    dangerouslySetInnerHTML: {
                        __html: e
                    },
                    "data-gsap-text-regular": !0
                })
            })]
        })
    },
    PE = ({
        source: t,
        orientation: e,
        rowspan: n,
        rowstart: r
    }) => {
        const [i, o] = Xl({
            threshold: 0,
            triggerOnce: !0
        }), s = u.useMemo(() => Mu(t), [t]), a = u.useRef(null), l = u.useRef(null);
        return u.useLayoutEffect(() => {
            const c = he.context(() => {
                a.current = he.timeline({
                    defaults: {
                        duration: 1,
                        ease: "power2.out"
                    }
                }).fromTo("[data-gsap-mask]", {
                    xPercent: 100
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }).fromTo("[data-gsap-image]", {
                    xPercent: -80
                }, {
                    xPercent: 0,
                    transformOrigin: "right"
                }, "<")
            }, l.current);
            return () => {
                c.revert()
            }
        }, []), u.useEffect(() => {
            o ? a.current.play() : a.current.reverse()
        }, [o]), v.jsx(Ta, {
            ref: l,
            className: Kt("h-full", {
                "grid-cols-s5 lg:grid-cols-s6": e === "portrait",
                "grid-cols-s8 lg:grid-cols-s9": e === "landscape"
            }),
            children: v.jsx("div", {
                ref: i,
                className: Kt({
                    "col-span-4 col-start-2 lg:col-start-3": e === "portrait",
                    "col-span-7 col-start-2 lg:col-start-3": e === "landscape"
                }, {
                    "row-span-1": n[0] === 1,
                    "row-span-2": n[0] === 2,
                    "row-span-3": n[0] === 3,
                    "row-span-4": n[0] === 4,
                    "md:row-span-1": n[1] === 1,
                    "md:row-span-2": n[1] === 2,
                    "md:row-span-3": n[1] === 3,
                    "md:row-span-4": n[1] === 4,
                    "md:row-span-5": n[1] === 5,
                    "md:row-span-6": n[1] === 6
                }, {
                    "row-start-1": r[0] === 1,
                    "row-start-2": r[0] === 2,
                    "row-start-3": r[0] === 3,
                    "row-start-4": r[0] === 4,
                    "md:row-start-1": r[1] === 1,
                    "md:row-start-2": r[1] === 2,
                    "md:row-start-3": r[1] === 3,
                    "md:row-start-4": r[1] === 4,
                    "md:row-start-5": r[1] === 5,
                    "md:row-start-6": r[1] === 6
                }),
                children: v.jsx("div", {
                    className: "relative w-full h-full overflow-hidden",
                    children: v.jsx("div", {
                        className: "relative w-full h-full overflow-hidden",
                        "data-gsap-mask": !0,
                        children: v.jsx( of , {
                            uuid: s,
                            align: "top",
                            src: `${Pu}${t}`,
                            alt: "",
                            className: "shrink-0 w-full h-full object-contain object-top",
                            "data-gsap-image": !0
                        })
                    })
                })
            })
        })
    },
    RE = ({
        text: t,
        rowstart: e
    }) => {
        const [n, r] = Xl({
            threshold: 0,
            triggerOnce: !0
        }), i = u.useRef(null), o = u.useRef(null);
        return u.useLayoutEffect(() => {
            const s = he.context(a => {
                const c = (a.selector || he.utils.selector)("[data-gsap-quote]")[0],
                    d = he.matchMedia(o.current);
                d.add(Ol.SMALL, () => {
                    i.current = he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(c, {
                        autoAlpha: .2
                    }, {
                        autoAlpha: 1
                    }).fromTo(c, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff"
                    }, "<+.2")
                }), d.add(Ol.LARGE, () => {
                    const f = new In(c, {
                        type: "words,chars",
                        charsClass: "char"
                    });
                    return i.current = he.timeline({
                        defaults: {
                            duration: 1.2,
                            ease: "power3.out"
                        }
                    }).fromTo(f.chars, {
                        autoAlpha: .2
                    }, {
                        autoAlpha: 1,
                        stagger: {
                            amount: .3
                        }
                    }).fromTo(f.chars, {
                        color: "#e46767"
                    }, {
                        color: "#ffffff",
                        stagger: {
                            amount: .3
                        }
                    }, "<+.2"), () => {
                        f.revert()
                    }
                })
            }, o.current);
            return () => {
                s.revert()
            }
        }, []), u.useEffect(() => {
            r ? i.current.play() : i.current.reverse()
        }, [r]), v.jsx(Ta, {
            ref: o,
            className: "h-full grid-cols-s4 md:grid-cols-s5 lg:grid-cols-s6",
            children: v.jsx("div", {
                ref: n,
                className: Kt("col-span-3 md:col-span-4 md:col-start-2 col-start-2 lg:col-start-3", {
                    "row-start-1": e[0] === 1,
                    "row-start-2": e[0] === 2,
                    "row-start-3": e[0] === 3,
                    "row-start-4": e[0] === 4,
                    "md:row-start-1": e[1] === 1,
                    "md:row-start-2": e[1] === 2,
                    "md:row-start-3": e[1] === 3,
                    "md:row-start-4": e[1] === 4,
                    "md:row-start-5": e[1] === 5,
                    "md:row-start-6": e[1] === 6
                }),
                children: v.jsx(an, {
                    variant: "h1",
                    paragraph: !0,
                    className: "text-white",
                    dangerouslySetInnerHTML: {
                        __html: t
                    },
                    "data-gsap-quote": !0
                })
            })
        })
    },
    ME = ({
        title: t,
        description: e,
        client: n,
        role: r,
        video: i,
        prefix_work_role: o,
        prefix_work_client: s
    }) => v.jsxs(Ta, {
        className: "items-center h-full grid-cols-s4 md:grid-cols-s6 lg:grid-cols-s11 grid-rows-[repeat(3,_1fr)] md:grid-rows-[repeat(3,_1fr)] lg:grid-rows-[1fr_auto_1fr]",
        children: [v.jsx("div", {
            className: "z-10 md:col-start-2 lg:col-start-2 col-span-4 lg:col-span-5 lg:row-start-2",
            children: v.jsxs("div", {
                className: "grid gap-y-[0.8rem] md:gap-y-[2.4rem]",
                children: [v.jsx(an, {
                    component: "h1",
                    variant: "h1",
                    className: "heading text-primary [&>.line-wrap]:pb-[.4rem] [&>.line-wrap]:-mb-[.4rem]",
                    dangerouslySetInnerHTML: {
                        __html: t
                    },
                    "data-gsap-hero-title": !0
                }), v.jsx("span", {
                    className: "block overflow-hidden",
                    children: v.jsxs("span", {
                        className: "block",
                        "data-gsap-hero-infos": !0,
                        children: [v.jsx(an, {
                            size: "regular",
                            children: `${s}:`
                        }), " ", v.jsx(an, {
                            size: "regular",
                            strong: !0,
                            dangerouslySetInnerHTML: {
                                __html: n
                            }
                        }), " ", v.jsx(an, {
                            size: "regular",
                            children: `${o}:`
                        }), " ", v.jsx(an, {
                            size: "regular",
                            strong: !0,
                            children: r
                        })]
                    })
                }), v.jsx(an, {
                    size: "large",
                    paragraph: !0,
                    className: "text-white",
                    dangerouslySetInnerHTML: {
                        __html: e
                    },
                    "data-gsap-hero-description": !0
                })]
            })
        }), v.jsx("div", {
            className: "col-span-4 md:col-span-6 row-start-2 lg:row-start-2 lg:col-start-6",
            children: v.jsxs("div", {
                className: "relative -mx-[var(--cp)] lg:mx-0 overflow-hidden",
                children: [v.jsx("div", {
                    className: "absolute top-0 left-0 w-full h-full bg-primary",
                    "data-gsap-hero-poster-primary": !0
                }), v.jsx("div", {
                    className: "absolute top-0 left-0 w-full h-full bg-white",
                    "data-gsap-hero-poster-white": !0
                }), v.jsx("div", {
                    className: "relative overflow-hidden",
                    "data-gsap-hero-poster-mask": !0,
                    children: v.jsx("video", {
                        width: "1280",
                        height: "720",
                        loop: !0,
                        muted: !0,
                        autoPlay: !0,
                        playsInline: !0,
                        className: "w-full h-auto object-cover bg-dark",
                        "data-gsap-hero-poster": !0,
                        children: v.jsx("source", {
                            src: `${iS}${i.source}`,
                            type: "video/mp4"
                        })
                    })
                })]
            })
        })]
    }),
    $E = Object.freeze(Object.defineProperty({
        __proto__: null,
        DoubleImage: SE,
        DoubleText: TE,
        Hero: ME,
        Image: PE,
        Quote: RE
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var af = {
    exports: {}
};
(function(t, e) {
    (function(n, r) {
        r(e)
    })(uf, function(n) {
        function r(ne, b) {
            ne.prototype = Object.create(b.prototype), ne.prototype.constructor = ne, ne.__proto__ = b
        }

        function i(ne) {
            if (ne === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return ne
        }
        var o, s, a, l, c, d, f, h, p = "transform",
            m = p + "Origin",
            g, y = function(b) {
                var F = b.ownerDocument || b;
                for (!(p in b.style) && ("msTransform" in b.style) && (p = "msTransform", m = p + "Origin"); F.parentNode && (F = F.parentNode););
                if (s = window, f = new I, F) {
                    o = F, a = F.documentElement, l = F.body, h = o.createElementNS("http://www.w3.org/2000/svg", "g"), h.style.transform = "none";
                    var E = F.createElement("div"),
                        U = F.createElement("div");
                    l.appendChild(E), E.appendChild(U), E.style.position = "static", E.style[p] = "translate3d(0,0,1px)", g = U.offsetParent !== E, l.removeChild(E)
                }
                return F
            },
            x = function(b) {
                for (var F, E; b && b !== l;) E = b._gsap, E && E.uncache && E.get(b, "x"), E && !E.scaleX && !E.scaleY && E.renderTransform && (E.scaleX = E.scaleY = 1e-4, E.renderTransform(1, E), F ? F.push(E) : F = [E]), b = b.parentNode;
                return F
            },
            w = [],
            M = [],
            T = function() {
                return s.pageYOffset || o.scrollTop || a.scrollTop || l.scrollTop || 0
            },
            O = function() {
                return s.pageXOffset || o.scrollLeft || a.scrollLeft || l.scrollLeft || 0
            },
            R = function(b) {
                return b.ownerSVGElement || ((b.tagName + "").toLowerCase() === "svg" ? b : null)
            },
            P = function ne(b) {
                if (s.getComputedStyle(b).position === "fixed") return !0;
                if (b = b.parentNode, b && b.nodeType === 1) return ne(b)
            },
            B = function ne(b, F) {
                if (b.parentNode && (o || y(b))) {
                    var E = R(b),
                        U = E ? E.getAttribute("xmlns") || "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml",
                        ie = E ? F ? "rect" : "g" : "div",
                        de = F !== 2 ? 0 : 100,
                        se = F === 3 ? 100 : 0,
                        ye = "position:absolute;display:block;pointer-events:none;margin:0;padding:0;",
                        ue = o.createElementNS ? o.createElementNS(U.replace(/^https/, "http"), ie) : o.createElement(ie);
                    return F && (E ? (d || (d = ne(b)), ue.setAttribute("width", .01), ue.setAttribute("height", .01), ue.setAttribute("transform", "translate(" + de + "," + se + ")"), d.appendChild(ue)) : (c || (c = ne(b), c.style.cssText = ye), ue.style.cssText = ye + "width:0.1px;height:0.1px;top:" + se + "px;left:" + de + "px", c.appendChild(ue))), ue
                }
                throw "Need document and parent."
            },
            te = function(b) {
                for (var F = new I, E = 0; E < b.numberOfItems; E++) F.multiply(b.getItem(E).matrix);
                return F
            },
            W = function(b) {
                var F = b.getCTM(),
                    E;
                return F || (E = b.style[p], b.style[p] = "none", b.appendChild(h), F = h.getCTM(), b.removeChild(h), E ? b.style[p] = E : b.style.removeProperty(p.replace(/([A-Z])/g, "-$1").toLowerCase())), F || f.clone()
            },
            ee = function(b, F) {
                var E = R(b),
                    U = b === E,
                    ie = E ? w : M,
                    de = b.parentNode,
                    se, ye, ue, Pe, We, Ze;
                if (b === s) return b;
                if (ie.length || ie.push(B(b, 1), B(b, 2), B(b, 3)), se = E ? d : c, E) U ? (ue = W(b), Pe = -ue.e / ue.a, We = -ue.f / ue.d, ye = f) : b.getBBox ? (ue = b.getBBox(), ye = b.transform ? b.transform.baseVal : {}, ye = ye.numberOfItems ? ye.numberOfItems > 1 ? te(ye) : ye.getItem(0).matrix : f, Pe = ye.a * ue.x + ye.c * ue.y, We = ye.b * ue.x + ye.d * ue.y) : (ye = new I, Pe = We = 0), F && b.tagName.toLowerCase() === "g" && (Pe = We = 0), (U ? E : de).appendChild(se), se.setAttribute("transform", "matrix(" + ye.a + "," + ye.b + "," + ye.c + "," + ye.d + "," + (ye.e + Pe) + "," + (ye.f + We) + ")");
                else {
                    if (Pe = We = 0, g)
                        for (ye = b.offsetParent, ue = b; ue && (ue = ue.parentNode) && ue !== ye && ue.parentNode;)(s.getComputedStyle(ue)[p] + "").length > 4 && (Pe = ue.offsetLeft, We = ue.offsetTop, ue = 0);
                    if (Ze = s.getComputedStyle(b), Ze.position !== "absolute" && Ze.position !== "fixed")
                        for (ye = b.offsetParent; de && de !== ye;) Pe += de.scrollLeft || 0, We += de.scrollTop || 0, de = de.parentNode;
                    ue = se.style, ue.top = b.offsetTop - We + "px", ue.left = b.offsetLeft - Pe + "px", ue[p] = Ze[p], ue[m] = Ze[m], ue.position = Ze.position === "fixed" ? "fixed" : "absolute", b.parentNode.appendChild(se)
                }
                return se
            },
            V = function(b, F, E, U, ie, de, se) {
                return b.a = F, b.b = E, b.c = U, b.d = ie, b.e = de, b.f = se, b
            },
            I = function() {
                function ne(F, E, U, ie, de, se) {
                    F === void 0 && (F = 1), E === void 0 && (E = 0), U === void 0 && (U = 0), ie === void 0 && (ie = 1), de === void 0 && (de = 0), se === void 0 && (se = 0), V(this, F, E, U, ie, de, se)
                }
                var b = ne.prototype;
                return b.inverse = function() {
                    var E = this.a,
                        U = this.b,
                        ie = this.c,
                        de = this.d,
                        se = this.e,
                        ye = this.f,
                        ue = E * de - U * ie || 1e-10;
                    return V(this, de / ue, -U / ue, -ie / ue, E / ue, (ie * ye - de * se) / ue, -(E * ye - U * se) / ue)
                }, b.multiply = function(E) {
                    var U = this.a,
                        ie = this.b,
                        de = this.c,
                        se = this.d,
                        ye = this.e,
                        ue = this.f,
                        Pe = E.a,
                        We = E.c,
                        Ze = E.b,
                        S = E.d,
                        st = E.e,
                        Et = E.f;
                    return V(this, Pe * U + Ze * de, Pe * ie + Ze * se, We * U + S * de, We * ie + S * se, ye + st * U + Et * de, ue + st * ie + Et * se)
                }, b.clone = function() {
                    return new ne(this.a, this.b, this.c, this.d, this.e, this.f)
                }, b.equals = function(E) {
                    var U = this.a,
                        ie = this.b,
                        de = this.c,
                        se = this.d,
                        ye = this.e,
                        ue = this.f;
                    return U === E.a && ie === E.b && de === E.c && se === E.d && ye === E.e && ue === E.f
                }, b.apply = function(E, U) {
                    U === void 0 && (U = {});
                    var ie = E.x,
                        de = E.y,
                        se = this.a,
                        ye = this.b,
                        ue = this.c,
                        Pe = this.d,
                        We = this.e,
                        Ze = this.f;
                    return U.x = ie * se + de * ue + We || 0, U.y = ie * ye + de * Pe + Ze || 0, U
                }, ne
            }();

        function X(ne, b, F, E) {
            if (!ne || !ne.parentNode || (o || y(ne)).documentElement === ne) return new I;
            var U = x(ne),
                ie = R(ne),
                de = ie ? w : M,
                se = ee(ne, F),
                ye = de[0].getBoundingClientRect(),
                ue = de[1].getBoundingClientRect(),
                Pe = de[2].getBoundingClientRect(),
                We = se.parentNode,
                Ze = !E && P(ne),
                S = new I((ue.left - ye.left) / 100, (ue.top - ye.top) / 100, (Pe.left - ye.left) / 100, (Pe.top - ye.top) / 100, ye.left + (Ze ? 0 : O()), ye.top + (Ze ? 0 : T()));
            if (We.removeChild(se), U)
                for (ye = U.length; ye--;) ue = U[ye], ue.scaleX = ue.scaleY = 0, ue.renderTransform(1, ue);
            return b ? S.inverse() : S
        }
        var q, Z, le, Se, Me, z, ge, $e, Xe, tt, wt, Ue, Ye, Ge, rt, it, lt, Lt, Ne, ct, ot = 0,
            gt = function() {
                return typeof window < "u"
            },
            re = function() {
                return q || gt() && (q = window.gsap) && q.registerPlugin && q
            },
            pt = function(b) {
                return typeof b == "function"
            },
            It = function(b) {
                return typeof b == "object"
            },
            At = function(b) {
                return typeof b > "u"
            },
            Je = function() {
                return !1
            },
            fn = "transform",
            Ce = "transformOrigin",
            _e = function(b) {
                return Math.round(b * 1e4) / 1e4
            },
            Ve = Array.isArray,
            qe = function(b, F) {
                var E = le.createElementNS ? le.createElementNS((F || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), b) : le.createElement(b);
                return E.style ? E : le.createElement(b)
            },
            pe = 180 / Math.PI,
            Mt = 1e20,
            Bt = new I,
            vt = Date.now || function() {
                return new Date().getTime()
            },
            Yt = [],
            C = {},
            L = 0,
            ce = /^(?:a|input|textarea|button|select)$/i,
            oe = 0,
            ve = {},
            Ee = {},
            Ae = function(b, F) {
                var E = {},
                    U;
                for (U in b) E[U] = F ? b[U] * F : b[U];
                return E
            },
            Oe = function(b, F) {
                for (var E in F) E in b || (b[E] = F[E]);
                return b
            },
            yt = function ne(b, F) {
                for (var E = b.length, U; E--;) F ? b[E].style.touchAction = F : b[E].style.removeProperty("touch-action"), U = b[E].children, U && U.length && ne(U, F)
            },
            St = function() {
                return Yt.forEach(function(b) {
                    return b()
                })
            },
            ut = function(b) {
                Yt.push(b), Yt.length === 1 && q.ticker.add(St)
            },
            Nt = function() {
                return !Yt.length && q.ticker.remove(St)
            },
            Xt = function(b) {
                for (var F = Yt.length; F--;) Yt[F] === b && Yt.splice(F, 1);
                q.to(Nt, {
                    overwrite: !0,
                    delay: 15,
                    duration: 0,
                    onComplete: Nt,
                    data: "_draggable"
                })
            },
            Rn = function(b, F) {
                for (var E in F) E in b || (b[E] = F[E]);
                return b
            },
            Ft = function(b, F, E, U) {
                if (b.addEventListener) {
                    var ie = Ye[F];
                    U = U || (wt ? {
                        passive: !1
                    } : null), b.addEventListener(ie || F, E, U), ie && F !== ie && b.addEventListener(F, E, U)
                }
            },
            je = function(b, F, E, U) {
                if (b.removeEventListener) {
                    var ie = Ye[F];
                    b.removeEventListener(ie || F, E, U), ie && F !== ie && b.removeEventListener(F, E, U)
                }
            },
            ze = function(b) {
                b.preventDefault && b.preventDefault(), b.preventManipulation && b.preventManipulation()
            },
            Ct = function(b, F) {
                for (var E = b.length; E--;)
                    if (b[E].identifier === F) return !0
            },
            Wt = function ne(b) {
                Ge = b.touches && ot < b.touches.length, je(b.target, "touchend", ne)
            },
            Fe = function(b) {
                Ge = b.touches && ot < b.touches.length, Ft(b.target, "touchend", Wt)
            },
            ht = function(b) {
                return Z.pageYOffset || b.scrollTop || b.documentElement.scrollTop || b.body.scrollTop || 0
            },
            Ke = function(b) {
                return Z.pageXOffset || b.scrollLeft || b.documentElement.scrollLeft || b.body.scrollLeft || 0
            },
            xt = function ne(b, F) {
                Ft(b, "scroll", F), mt(b.parentNode) || ne(b.parentNode, F)
            },
            dn = function ne(b, F) {
                je(b, "scroll", F), mt(b.parentNode) || ne(b.parentNode, F)
            },
            mt = function(b) {
                return !b || b === Se || b.nodeType === 9 || b === le.body || b === Z || !b.nodeType || !b.parentNode
            },
            nn = function(b, F) {
                var E = F === "x" ? "Width" : "Height",
                    U = "scroll" + E,
                    ie = "client" + E;
                return Math.max(0, mt(b) ? Math.max(Se[U], Me[U]) - (Z["inner" + E] || Se[ie] || Me[ie]) : b[U] - b[ie])
            },
            pn = function ne(b, F) {
                var E = nn(b, "x"),
                    U = nn(b, "y");
                mt(b) ? b = Ee : ne(b.parentNode, F), b._gsMaxScrollX = E, b._gsMaxScrollY = U, F || (b._gsScrollX = b.scrollLeft || 0, b._gsScrollY = b.scrollTop || 0)
            },
            hn = function(b, F, E) {
                var U = b.style;
                U && (At(U[F]) && (F = Xe(F, b) || F), E == null ? U.removeProperty && U.removeProperty(F.replace(/([A-Z])/g, "-$1").toLowerCase()) : U[F] = E)
            },
            zt = function(b) {
                return Z.getComputedStyle(b instanceof Element ? b : b.host || (b.parentNode || {}).host || b)
            },
            k = {},
            _ = function(b) {
                if (b === Z) return k.left = k.top = 0, k.width = k.right = Se.clientWidth || b.innerWidth || Me.clientWidth || 0, k.height = k.bottom = (b.innerHeight || 0) - 20 < Se.clientHeight ? Se.clientHeight : b.innerHeight || Me.clientHeight || 0, k;
                var F = b.ownerDocument || le,
                    E = At(b.pageX) ? !b.nodeType && !At(b.left) && !At(b.top) ? b : tt(b)[0].getBoundingClientRect() : {
                        left: b.pageX - Ke(F),
                        top: b.pageY - ht(F),
                        right: b.pageX - Ke(F) + 1,
                        bottom: b.pageY - ht(F) + 1
                    };
                return At(E.right) && !At(E.width) ? (E.right = E.left + E.width, E.bottom = E.top + E.height) : At(E.width) && (E = {
                    width: E.right - E.left,
                    height: E.bottom - E.top,
                    right: E.right,
                    left: E.left,
                    bottom: E.bottom,
                    top: E.top
                }), E
            },
            D = function(b, F, E) {
                var U = b.vars,
                    ie = U[E],
                    de = b._listeners[F],
                    se;
                return pt(ie) && (se = ie.apply(U.callbackScope || b, U[E + "Params"] || [b.pointerEvent])), de && b.dispatchEvent(F) === !1 && (se = !1), se
            },
            $ = function(b, F) {
                var E = tt(b)[0],
                    U, ie, de;
                return !E.nodeType && E !== Z ? At(b.left) ? (ie = b.min || b.minX || b.minRotation || 0, U = b.min || b.minY || 0, {
                    left: ie,
                    top: U,
                    width: (b.max || b.maxX || b.maxRotation || 0) - ie,
                    height: (b.max || b.maxY || 0) - U
                }) : (de = {
                    x: 0,
                    y: 0
                }, {
                    left: b.left - de.x,
                    top: b.top - de.y,
                    width: b.width,
                    height: b.height
                }) : N(E, F)
            },
            A = {},
            N = function(b, F) {
                F = tt(F)[0];
                var E = b.getBBox && b.ownerSVGElement,
                    U = b.ownerDocument || le,
                    ie, de, se, ye, ue, Pe, We, Ze, S, st, Et, on, Zt;
                if (b === Z) se = ht(U), ie = Ke(U), de = ie + (U.documentElement.clientWidth || b.innerWidth || U.body.clientWidth || 0), ye = se + ((b.innerHeight || 0) - 20 < U.documentElement.clientHeight ? U.documentElement.clientHeight : b.innerHeight || U.body.clientHeight || 0);
                else {
                    if (F === Z || At(F)) return b.getBoundingClientRect();
                    ie = se = 0, E ? (st = b.getBBox(), Et = st.width, on = st.height) : (b.viewBox && (st = b.viewBox.baseVal) && (ie = st.x || 0, se = st.y || 0, Et = st.width, on = st.height), Et || (Zt = zt(b), st = Zt.boxSizing === "border-box", Et = (parseFloat(Zt.width) || b.clientWidth || 0) + (st ? 0 : parseFloat(Zt.borderLeftWidth) + parseFloat(Zt.borderRightWidth)), on = (parseFloat(Zt.height) || b.clientHeight || 0) + (st ? 0 : parseFloat(Zt.borderTopWidth) + parseFloat(Zt.borderBottomWidth)))), de = Et, ye = on
                }
                return b === F ? {
                    left: ie,
                    top: se,
                    width: de - ie,
                    height: ye - se
                } : (ue = X(F, !0).multiply(X(b)), Pe = ue.apply({
                    x: ie,
                    y: se
                }), We = ue.apply({
                    x: de,
                    y: se
                }), Ze = ue.apply({
                    x: de,
                    y: ye
                }), S = ue.apply({
                    x: ie,
                    y: ye
                }), ie = Math.min(Pe.x, We.x, Ze.x, S.x), se = Math.min(Pe.y, We.y, Ze.y, S.y), {
                    left: ie,
                    top: se,
                    width: Math.max(Pe.x, We.x, Ze.x, S.x) - ie,
                    height: Math.max(Pe.y, We.y, Ze.y, S.y) - se
                })
            },
            G = function(b, F, E, U, ie, de) {
                var se = {},
                    ye, ue, Pe;
                if (F)
                    if (ie !== 1 && F instanceof Array) {
                        if (se.end = ye = [], Pe = F.length, It(F[0]))
                            for (ue = 0; ue < Pe; ue++) ye[ue] = Ae(F[ue], ie);
                        else
                            for (ue = 0; ue < Pe; ue++) ye[ue] = F[ue] * ie;
                        E += 1.1, U -= 1.1
                    } else pt(F) ? se.end = function(We) {
                        var Ze = F.call(b, We),
                            S, st;
                        if (ie !== 1)
                            if (It(Ze)) {
                                S = {};
                                for (st in Ze) S[st] = Ze[st] * ie;
                                Ze = S
                            } else Ze *= ie;
                        return Ze
                    } : se.end = F;
                return (E || E === 0) && (se.max = E), (U || U === 0) && (se.min = U), de && (se.velocity = 0), se
            },
            Q = function ne(b) {
                var F;
                return !b || !b.getAttribute || b === Me ? !1 : (F = b.getAttribute("data-clickable")) === "true" || F !== "false" && (ce.test(b.nodeName + "") || b.getAttribute("contentEditable") === "true") ? !0 : ne(b.parentNode)
            },
            J = function(b, F) {
                for (var E = b.length, U; E--;) U = b[E], U.ondragstart = U.onselectstart = F ? null : Je, q.set(U, {
                    lazy: !0,
                    userSelect: F ? "text" : "none"
                })
            },
            Y = function ne(b) {
                if (zt(b).position === "fixed") return !0;
                if (b = b.parentNode, b && b.nodeType === 1) return ne(b)
            },
            fe, K, me = function(b, F) {
                b = q.utils.toArray(b)[0], F = F || {};
                var E = document.createElement("div"),
                    U = E.style,
                    ie = b.firstChild,
                    de = 0,
                    se = 0,
                    ye = b.scrollTop,
                    ue = b.scrollLeft,
                    Pe = b.scrollWidth,
                    We = b.scrollHeight,
                    Ze = 0,
                    S = 0,
                    st = 0,
                    Et, on, Zt, $r, ri, ii;
                fe && F.force3D !== !1 ? (ri = "translate3d(", ii = "px,0px)") : fn && (ri = "translate(", ii = "px)"), this.scrollTop = function(Tt, qn) {
                    if (!arguments.length) return -this.top();
                    this.top(-Tt, qn)
                }, this.scrollLeft = function(Tt, qn) {
                    if (!arguments.length) return -this.left();
                    this.left(-Tt, qn)
                }, this.left = function(Tt, qn) {
                    if (!arguments.length) return -(b.scrollLeft + se);
                    var Vt = b.scrollLeft - ue,
                        kt = se;
                    if ((Vt > 2 || Vt < -2) && !qn) {
                        ue = b.scrollLeft, q.killTweensOf(this, {
                            left: 1,
                            scrollLeft: 1
                        }), this.left(-ue), F.onKill && F.onKill();
                        return
                    }
                    Tt = -Tt, Tt < 0 ? (se = Tt - .5 | 0, Tt = 0) : Tt > S ? (se = Tt - S | 0, Tt = S) : se = 0, (se || kt) && (this._skip || (U[fn] = ri + -se + "px," + -de + ii), se + Ze >= 0 && (U.paddingRight = se + Ze + "px")), b.scrollLeft = Tt | 0, ue = b.scrollLeft
                }, this.top = function(Tt, qn) {
                    if (!arguments.length) return -(b.scrollTop + de);
                    var Vt = b.scrollTop - ye,
                        kt = de;
                    if ((Vt > 2 || Vt < -2) && !qn) {
                        ye = b.scrollTop, q.killTweensOf(this, {
                            top: 1,
                            scrollTop: 1
                        }), this.top(-ye), F.onKill && F.onKill();
                        return
                    }
                    Tt = -Tt, Tt < 0 ? (de = Tt - .5 | 0, Tt = 0) : Tt > st ? (de = Tt - st | 0, Tt = st) : de = 0, (de || kt) && (this._skip || (U[fn] = ri + -se + "px," + -de + ii)), b.scrollTop = Tt | 0, ye = b.scrollTop
                }, this.maxScrollTop = function() {
                    return st
                }, this.maxScrollLeft = function() {
                    return S
                }, this.disable = function() {
                    for (ie = E.firstChild; ie;) $r = ie.nextSibling, b.appendChild(ie), ie = $r;
                    b === E.parentNode && b.removeChild(E)
                }, this.enable = function() {
                    if (ie = b.firstChild, ie !== E) {
                        for (; ie;) $r = ie.nextSibling, E.appendChild(ie), ie = $r;
                        b.appendChild(E), this.calibrate()
                    }
                }, this.calibrate = function(Tt) {
                    var qn = b.clientWidth === Et,
                        Vt, kt, mr;
                    ye = b.scrollTop, ue = b.scrollLeft, !(qn && b.clientHeight === on && E.offsetHeight === Zt && Pe === b.scrollWidth && We === b.scrollHeight && !Tt) && ((de || se) && (kt = this.left(), mr = this.top(), this.left(-b.scrollLeft), this.top(-b.scrollTop)), Vt = zt(b), (!qn || Tt) && (U.display = "block", U.width = "auto", U.paddingRight = "0px", Ze = Math.max(0, b.scrollWidth - b.clientWidth), Ze && (Ze += parseFloat(Vt.paddingLeft) + (K ? parseFloat(Vt.paddingRight) : 0))), U.display = "inline-block", U.position = "relative", U.overflow = "visible", U.verticalAlign = "top", U.boxSizing = "content-box", U.width = "100%", U.paddingRight = Ze + "px", K && (U.paddingBottom = Vt.paddingBottom), Et = b.clientWidth, on = b.clientHeight, Pe = b.scrollWidth, We = b.scrollHeight, S = b.scrollWidth - Et, st = b.scrollHeight - on, Zt = E.offsetHeight, U.display = "block", (kt || mr) && (this.left(kt), this.top(mr)))
                }, this.content = E, this.element = b, this._skip = !1, this.enable()
            },
            De = function(b) {
                if (gt() && document.body) {
                    var F = window && window.navigator;
                    Z = window, le = document, Se = le.documentElement, Me = le.body, z = qe("div"), Lt = !!window.PointerEvent, ge = qe("div"), ge.style.cssText = "visibility:hidden;height:1px;top:-1px;pointer-events:none;position:relative;clear:both;cursor:grab", lt = ge.style.cursor === "grab" ? "grab" : "move", rt = F && F.userAgent.toLowerCase().indexOf("android") !== -1, Ue = "ontouchstart" in Se && "orientation" in Z || F && (F.MaxTouchPoints > 0 || F.msMaxTouchPoints > 0), K = function() {
                        var E = qe("div"),
                            U = qe("div"),
                            ie = U.style,
                            de = Me,
                            se;
                        return ie.display = "inline-block", ie.position = "relative", E.style.cssText = "width:90px;height:40px;padding:10px;overflow:auto;visibility:hidden", E.appendChild(U), de.appendChild(E), se = U.offsetHeight + 18 > E.scrollHeight, de.removeChild(E), se
                    }(), Ye = function(E) {
                        for (var U = E.split(","), ie = ("onpointerdown" in z ? "pointerdown,pointermove,pointerup,pointercancel" : "onmspointerdown" in z ? "MSPointerDown,MSPointerMove,MSPointerUp,MSPointerCancel" : E).split(","), de = {}, se = 4; --se > -1;) de[U[se]] = ie[se], de[ie[se]] = U[se];
                        try {
                            Se.addEventListener("test", null, Object.defineProperty({}, "passive", {
                                get: function() {
                                    wt = 1
                                }
                            }))
                        } catch {}
                        return de
                    }("touchstart,touchmove,touchend,touchcancel"), Ft(le, "touchcancel", Je), Ft(Z, "touchmove", Je), Me && Me.addEventListener("touchstart", Je), Ft(le, "contextmenu", function() {
                        for (var E in C) C[E].isPressed && C[E].endDrag()
                    }), q = $e = re()
                }
                q ? (it = q.plugins.inertia, Ne = q.core.context || function() {}, Xe = q.utils.checkPrefix, fn = Xe(fn), Ce = Xe(Ce), tt = q.utils.toArray, ct = q.core.getStyleSaver, fe = !!Xe("perspective")) : b && console.warn("Please gsap.registerPlugin(Draggable)")
            },
            Te = function() {
                function ne(F) {
                    this._listeners = {}, this.target = F || this
                }
                var b = ne.prototype;
                return b.addEventListener = function(E, U) {
                    var ie = this._listeners[E] || (this._listeners[E] = []);
                    ~ie.indexOf(U) || ie.push(U)
                }, b.removeEventListener = function(E, U) {
                    var ie = this._listeners[E],
                        de = ie && ie.indexOf(U);
                    de >= 0 && ie.splice(de, 1)
                }, b.dispatchEvent = function(E) {
                    var U = this,
                        ie;
                    return (this._listeners[E] || []).forEach(function(de) {
                        return de.call(U, {
                            type: E,
                            target: U.target
                        }) === !1 && (ie = !1)
                    }), ie
                }, ne
            }(),
            xe = function(ne) {
                r(b, ne);

                function b(F, E) {
                    var U;
                    U = ne.call(this) || this, $e || De(1), F = tt(F)[0], U.styles = ct && ct(F, "transform,left,top"), it || (it = q.plugins.inertia), U.vars = E = Ae(E || {}), U.target = F, U.x = U.y = U.rotation = 0, U.dragResistance = parseFloat(E.dragResistance) || 0, U.edgeResistance = isNaN(E.edgeResistance) ? 1 : parseFloat(E.edgeResistance) || 0, U.lockAxis = E.lockAxis, U.autoScroll = E.autoScroll || 0, U.lockedAxis = null, U.allowEventDefault = !!E.allowEventDefault, q.getProperty(F, "x");
                    var ie = (E.type || "x,y").toLowerCase(),
                        de = ~ie.indexOf("x") || ~ie.indexOf("y"),
                        se = ie.indexOf("rotation") !== -1,
                        ye = se ? "rotation" : de ? "x" : "left",
                        ue = de ? "y" : "top",
                        Pe = !!(~ie.indexOf("x") || ~ie.indexOf("left") || ie === "scroll"),
                        We = !!(~ie.indexOf("y") || ~ie.indexOf("top") || ie === "scroll"),
                        Ze = E.minimumMovement || 2,
                        S = i(U),
                        st = tt(E.trigger || E.handle || F),
                        Et = {},
                        on = 0,
                        Zt = !1,
                        $r = E.autoScrollMarginTop || 40,
                        ri = E.autoScrollMarginRight || 40,
                        ii = E.autoScrollMarginBottom || 40,
                        Tt = E.autoScrollMarginLeft || 40,
                        qn = E.clickableTest || Q,
                        Vt = 0,
                        kt = F._gsap || q.core.getCache(F),
                        mr = Y(F),
                        Li = function(H, be) {
                            return parseFloat(kt.get(F, H, be))
                        },
                        Ut = F.ownerDocument || le,
                        Yr, _t, mn, mi, Wn, Sn, ro, sd, ad, bn, gn, Mn, Cn, Ma, Ar, ws, On, dc, Ni, zi, io, _s, Vn, qt, ld, Fr, Xr, pc, hc, cd, _r, ud, $a, fd = function(H) {
                            return ze(H), H.stopImmediatePropagation && H.stopImmediatePropagation(), !1
                        },
                        oi = function et(H) {
                            if (S.autoScroll && S.isDragging && (Zt || On)) {
                                var be = F,
                                    ae = S.autoScroll * 15,
                                    we, Re, Le, Pt, Qe, Qt, jt, Jt;
                                for (Zt = !1, Ee.scrollTop = Z.pageYOffset != null ? Z.pageYOffset : Ut.documentElement.scrollTop != null ? Ut.documentElement.scrollTop : Ut.body.scrollTop, Ee.scrollLeft = Z.pageXOffset != null ? Z.pageXOffset : Ut.documentElement.scrollLeft != null ? Ut.documentElement.scrollLeft : Ut.body.scrollLeft, Pt = S.pointerX - Ee.scrollLeft, Qe = S.pointerY - Ee.scrollTop; be && !Re;) Re = mt(be.parentNode), we = Re ? Ee : be.parentNode, Le = Re ? {
                                    bottom: Math.max(Se.clientHeight, Z.innerHeight || 0),
                                    right: Math.max(Se.clientWidth, Z.innerWidth || 0),
                                    left: 0,
                                    top: 0
                                } : we.getBoundingClientRect(), Qt = jt = 0, We && (Jt = we._gsMaxScrollY - we.scrollTop, Jt < 0 ? jt = Jt : Qe > Le.bottom - ii && Jt ? (Zt = !0, jt = Math.min(Jt, ae * (1 - Math.max(0, Le.bottom - Qe) / ii) | 0)) : Qe < Le.top + $r && we.scrollTop && (Zt = !0, jt = -Math.min(we.scrollTop, ae * (1 - Math.max(0, Qe - Le.top) / $r) | 0)), jt && (we.scrollTop += jt)), Pe && (Jt = we._gsMaxScrollX - we.scrollLeft, Jt < 0 ? Qt = Jt : Pt > Le.right - ri && Jt ? (Zt = !0, Qt = Math.min(Jt, ae * (1 - Math.max(0, Le.right - Pt) / ri) | 0)) : Pt < Le.left + Tt && we.scrollLeft && (Zt = !0, Qt = -Math.min(we.scrollLeft, ae * (1 - Math.max(0, Pt - Le.left) / Tt) | 0)), Qt && (we.scrollLeft += Qt)), Re && (Qt || jt) && (Z.scrollTo(we.scrollLeft, we.scrollTop), Cs(S.pointerX + Qt, S.pointerY + jt)), be = we
                            }
                            if (On) {
                                var _n = S.x,
                                    Kn = S.y;
                                se ? (S.deltaX = _n - parseFloat(kt.rotation), S.rotation = _n, kt.rotation = _n + "deg", kt.renderTransform(1, kt)) : _t ? (We && (S.deltaY = Kn - _t.top(), _t.top(Kn)), Pe && (S.deltaX = _n - _t.left(), _t.left(_n))) : de ? (We && (S.deltaY = Kn - parseFloat(kt.y), kt.y = Kn + "px"), Pe && (S.deltaX = _n - parseFloat(kt.x), kt.x = _n + "px"), kt.renderTransform(1, kt)) : (We && (S.deltaY = Kn - parseFloat(F.style.top || 0), F.style.top = Kn + "px"), Pe && (S.deltaX = _n - parseFloat(F.style.left || 0), F.style.left = _n + "px")), sd && !H && !pc && (pc = !0, D(S, "drag", "onDrag") === !1 && (Pe && (S.x -= S.deltaX), We && (S.y -= S.deltaY), et(!0)), pc = !1)
                            }
                            On = !1
                        },
                        oo = function(H, be) {
                            var ae = S.x,
                                we = S.y,
                                Re, Le;
                            F._gsap || (kt = q.core.getCache(F)), kt.uncache && q.getProperty(F, "x"), de ? (S.x = parseFloat(kt.x), S.y = parseFloat(kt.y)) : se ? S.x = S.rotation = parseFloat(kt.rotation) : _t ? (S.y = _t.top(), S.x = _t.left()) : (S.y = parseFloat(F.style.top || (Le = zt(F)) && Le.top) || 0, S.x = parseFloat(F.style.left || (Le || {}).left) || 0), (Ni || zi || io) && !be && (S.isDragging || S.isThrowing) && (io && (ve.x = S.x, ve.y = S.y, Re = io(ve), Re.x !== S.x && (S.x = Re.x, On = !0), Re.y !== S.y && (S.y = Re.y, On = !0)), Ni && (Re = Ni(S.x), Re !== S.x && (S.x = Re, se && (S.rotation = Re), On = !0)), zi && (Re = zi(S.y), Re !== S.y && (S.y = Re), On = !0)), On && oi(!0), H || (S.deltaX = S.x - ae, S.deltaY = S.y - we, D(S, "throwupdate", "onThrowUpdate"))
                        },
                        mc = function(H, be, ae, we) {
                            return be == null && (be = -Mt), ae == null && (ae = Mt), pt(H) ? function(Re) {
                                var Le = S.isPressed ? 1 - S.edgeResistance : 1;
                                return H.call(S, (Re > ae ? ae + (Re - ae) * Le : Re < be ? be + (Re - be) * Le : Re) * we) * we
                            } : Ve(H) ? function(Re) {
                                for (var Le = H.length, Pt = 0, Qe = Mt, Qt, jt; --Le > -1;) Qt = H[Le], jt = Qt - Re, jt < 0 && (jt = -jt), jt < Qe && Qt >= be && Qt <= ae && (Pt = Le, Qe = jt);
                                return H[Pt]
                            } : isNaN(H) ? function(Re) {
                                return Re
                            } : function() {
                                return H * we
                            }
                        },
                        Kg = function(H, be, ae, we, Re, Le, Pt) {
                            return Le = Le && Le < Mt ? Le * Le : Mt, pt(H) ? function(Qe) {
                                var Qt = S.isPressed ? 1 - S.edgeResistance : 1,
                                    jt = Qe.x,
                                    Jt = Qe.y,
                                    _n, Kn, gi;
                                return Qe.x = jt = jt > ae ? ae + (jt - ae) * Qt : jt < be ? be + (jt - be) * Qt : jt, Qe.y = Jt = Jt > Re ? Re + (Jt - Re) * Qt : Jt < we ? we + (Jt - we) * Qt : Jt, _n = H.call(S, Qe), _n !== Qe && (Qe.x = _n.x, Qe.y = _n.y), Pt !== 1 && (Qe.x *= Pt, Qe.y *= Pt), Le < Mt && (Kn = Qe.x - jt, gi = Qe.y - Jt, Kn * Kn + gi * gi > Le && (Qe.x = jt, Qe.y = Jt)), Qe
                            } : Ve(H) ? function(Qe) {
                                for (var Qt = H.length, jt = 0, Jt = Mt, _n, Kn, gi, kr; --Qt > -1;) gi = H[Qt], _n = gi.x - Qe.x, Kn = gi.y - Qe.y, kr = _n * _n + Kn * Kn, kr < Jt && (jt = Qt, Jt = kr);
                                return Jt <= Le ? H[jt] : Qe
                            } : function(Qe) {
                                return Qe
                            }
                        },
                        gc = function() {
                            var H, be, ae, we;
                            ro = !1, _t ? (_t.calibrate(), S.minX = gn = -_t.maxScrollLeft(), S.minY = Cn = -_t.maxScrollTop(), S.maxX = bn = S.maxY = Mn = 0, ro = !0) : E.bounds && (H = $(E.bounds, F.parentNode), se ? (S.minX = gn = H.left, S.maxX = bn = H.left + H.width, S.minY = Cn = S.maxY = Mn = 0) : !At(E.bounds.maxX) || !At(E.bounds.maxY) ? (H = E.bounds, S.minX = gn = H.minX, S.minY = Cn = H.minY, S.maxX = bn = H.maxX, S.maxY = Mn = H.maxY) : (be = $(F, F.parentNode), S.minX = gn = Math.round(Li(ye, "px") + H.left - be.left), S.minY = Cn = Math.round(Li(ue, "px") + H.top - be.top), S.maxX = bn = Math.round(gn + (H.width - be.width)), S.maxY = Mn = Math.round(Cn + (H.height - be.height))), gn > bn && (S.minX = bn, S.maxX = bn = gn, gn = S.minX), Cn > Mn && (S.minY = Mn, S.maxY = Mn = Cn, Cn = S.minY), se && (S.minRotation = gn, S.maxRotation = bn), ro = !0), E.liveSnap && (ae = E.liveSnap === !0 ? E.snap || {} : E.liveSnap, we = Ve(ae) || pt(ae), se ? (Ni = mc(we ? ae : ae.rotation, gn, bn, 1), zi = null) : ae.points ? io = Kg(we ? ae : ae.points, gn, bn, Cn, Mn, ae.radius, _t ? -1 : 1) : (Pe && (Ni = mc(we ? ae : ae.x || ae.left || ae.scrollLeft, gn, bn, _t ? -1 : 1)), We && (zi = mc(we ? ae : ae.y || ae.top || ae.scrollTop, Cn, Mn, _t ? -1 : 1))))
                        },
                        Zg = function() {
                            S.isThrowing = !1, D(S, "throwcomplete", "onThrowComplete")
                        },
                        Qg = function() {
                            S.isThrowing = !1
                        },
                        vc = function(H, be) {
                            var ae, we, Re, Le;
                            H && it ? (H === !0 && (ae = E.snap || E.liveSnap || {}, we = Ve(ae) || pt(ae), H = {
                                resistance: (E.throwResistance || E.resistance || 1e3) / (se ? 10 : 1)
                            }, se ? H.rotation = G(S, we ? ae : ae.rotation, bn, gn, 1, be) : (Pe && (H[ye] = G(S, we ? ae : ae.points || ae.x || ae.left, bn, gn, _t ? -1 : 1, be || S.lockedAxis === "x")), We && (H[ue] = G(S, we ? ae : ae.points || ae.y || ae.top, Mn, Cn, _t ? -1 : 1, be || S.lockedAxis === "y")), (ae.points || Ve(ae) && It(ae[0])) && (H.linkedProps = ye + "," + ue, H.radius = ae.radius))), S.isThrowing = !0, Le = isNaN(E.overshootTolerance) ? E.edgeResistance === 1 ? 0 : 1 - S.edgeResistance + .2 : E.overshootTolerance, H.duration || (H.duration = {
                                max: Math.max(E.minDuration || 0, "maxDuration" in E ? E.maxDuration : 2),
                                min: isNaN(E.minDuration) ? Le === 0 || It(H) && H.resistance > 1e3 ? 0 : .5 : E.minDuration,
                                overshoot: Le
                            }), S.tween = Re = q.to(_t || F, {
                                inertia: H,
                                data: "_draggable",
                                onComplete: Zg,
                                onInterrupt: Qg,
                                onUpdate: E.fastMode ? D : oo,
                                onUpdateParams: E.fastMode ? [S, "onthrowupdate", "onThrowUpdate"] : ae && ae.radius ? [!1, !0] : []
                            }), E.fastMode || (_t && (_t._skip = !0), Re.render(1e9, !0, !0), oo(!0, !0), S.endX = S.x, S.endY = S.y, se && (S.endRotation = S.x), Re.play(0), oo(!0, !0), _t && (_t._skip = !1))) : ro && S.applyBounds()
                        },
                        dd = function(H) {
                            var be = qt,
                                ae;
                            qt = X(F.parentNode, !0), H && S.isPressed && !qt.equals(be || new I) && (ae = be.inverse().apply({
                                x: mn,
                                y: mi
                            }), qt.apply(ae, ae), mn = ae.x, mi = ae.y), qt.equals(Bt) && (qt = null)
                        },
                        Aa = function() {
                            var H = 1 - S.edgeResistance,
                                be = mr ? Ke(Ut) : 0,
                                ae = mr ? ht(Ut) : 0,
                                we, Re, Le;
                            de && (kt.x = Li(ye, "px") + "px", kt.y = Li(ue, "px") + "px", kt.renderTransform()), dd(!1), A.x = S.pointerX - be, A.y = S.pointerY - ae, qt && qt.apply(A, A), mn = A.x, mi = A.y, On && (Cs(S.pointerX, S.pointerY), oi(!0)), ud = X(F), _t ? (gc(), Sn = _t.top(), Wn = _t.left()) : (Ds() ? (oo(!0, !0), gc()) : S.applyBounds(), se ? (we = F.ownerSVGElement ? [kt.xOrigin - F.getBBox().x, kt.yOrigin - F.getBBox().y] : (zt(F)[Ce] || "0 0").split(" "), ws = S.rotationOrigin = X(F).apply({
                                x: parseFloat(we[0]) || 0,
                                y: parseFloat(we[1]) || 0
                            }), oo(!0, !0), Re = S.pointerX - ws.x - be, Le = ws.y - S.pointerY + ae, Wn = S.x, Sn = S.y = Math.atan2(Le, Re) * pe) : (Sn = Li(ue, "px"), Wn = Li(ye, "px"))), ro && H && (Wn > bn ? Wn = bn + (Wn - bn) / H : Wn < gn && (Wn = gn - (gn - Wn) / H), se || (Sn > Mn ? Sn = Mn + (Sn - Mn) / H : Sn < Cn && (Sn = Cn - (Cn - Sn) / H))), S.startX = Wn = _e(Wn), S.startY = Sn = _e(Sn)
                        },
                        Ds = function() {
                            return S.tween && S.tween.isActive()
                        },
                        Jg = function() {
                            ge.parentNode && !Ds() && !S.isDragging && ge.parentNode.removeChild(ge)
                        },
                        Ss = function(H, be) {
                            var ae;
                            if (!Yr || S.isPressed || !H || (H.type === "mousedown" || H.type === "pointerdown") && !be && vt() - Vt < 30 && Ye[S.pointerEvent.type]) {
                                _r && H && Yr && ze(H);
                                return
                            }
                            if (ld = Ds(), $a = !1, S.pointerEvent = H, Ye[H.type] ? (Vn = ~H.type.indexOf("touch") ? H.currentTarget || H.target : Ut, Ft(Vn, "touchend", qr), Ft(Vn, "touchmove", so), Ft(Vn, "touchcancel", qr), Ft(Ut, "touchstart", Fe)) : (Vn = null, Ft(Ut, "mousemove", so)), Xr = null, (!Lt || !Vn) && (Ft(Ut, "mouseup", qr), H && H.target && Ft(H.target, "mouseup", qr)), _s = qn.call(S, H.target) && E.dragClickables === !1 && !be, _s) {
                                Ft(H.target, "change", qr), D(S, "pressInit", "onPressInit"), D(S, "press", "onPress"), J(st, !0), _r = !1;
                                return
                            }
                            if (Fr = !Vn || Pe === We || S.vars.allowNativeTouchScrolling === !1 || S.vars.allowContextMenu && H && (H.ctrlKey || H.which > 2) ? !1 : Pe ? "y" : "x", _r = !Fr && !S.allowEventDefault, _r && (ze(H), Ft(Z, "touchforcechange", ze)), H.changedTouches ? (H = Ma = H.changedTouches[0], Ar = H.identifier) : H.pointerId ? Ar = H.pointerId : Ma = Ar = null, ot++, ut(oi), mi = S.pointerY = H.pageY, mn = S.pointerX = H.pageX, D(S, "pressInit", "onPressInit"), (Fr || S.autoScroll) && pn(F.parentNode), F.parentNode && S.autoScroll && !_t && !se && F.parentNode._gsMaxScrollX && !ge.parentNode && !F.getBBox && (ge.style.width = F.parentNode.scrollWidth + "px", F.parentNode.appendChild(ge)), Aa(), S.tween && S.tween.kill(), S.isThrowing = !1, q.killTweensOf(_t || F, Et, !0), _t && q.killTweensOf(F, {
                                    scrollTo: 1
                                }, !0), S.tween = S.lockedAxis = null, (E.zIndexBoost || !se && !_t && E.zIndexBoost !== !1) && (F.style.zIndex = b.zIndex++), S.isPressed = !0, sd = !!(E.onDrag || S._listeners.drag), ad = !!(E.onMove || S._listeners.move), E.cursor !== !1 || E.activeCursor)
                                for (ae = st.length; --ae > -1;) q.set(st[ae], {
                                    cursor: E.activeCursor || E.cursor || (lt === "grab" ? "grabbing" : lt)
                                });
                            D(S, "press", "onPress")
                        },
                        so = function(H) {
                            var be = H,
                                ae, we, Re, Le, Pt, Qe;
                            if (!Yr || Ge || !S.isPressed || !H) {
                                _r && H && Yr && ze(H);
                                return
                            }
                            if (S.pointerEvent = H, ae = H.changedTouches, ae) {
                                if (H = ae[0], H !== Ma && H.identifier !== Ar) {
                                    for (Le = ae.length; --Le > -1 && (H = ae[Le]).identifier !== Ar && H.target !== F;);
                                    if (Le < 0) return
                                }
                            } else if (H.pointerId && Ar && H.pointerId !== Ar) return;
                            if (Vn && Fr && !Xr && (A.x = H.pageX - (mr ? Ke(Ut) : 0), A.y = H.pageY - (mr ? ht(Ut) : 0), qt && qt.apply(A, A), we = A.x, Re = A.y, Pt = Math.abs(we - mn), Qe = Math.abs(Re - mi), (Pt !== Qe && (Pt > Ze || Qe > Ze) || rt && Fr === Xr) && (Xr = Pt > Qe && Pe ? "x" : "y", Fr && Xr !== Fr && Ft(Z, "touchforcechange", ze), S.vars.lockAxisOnTouchScroll !== !1 && Pe && We && (S.lockedAxis = Xr === "x" ? "y" : "x", pt(S.vars.onLockAxis) && S.vars.onLockAxis.call(S, be)), rt && Fr === Xr))) {
                                qr(be);
                                return
                            }!S.allowEventDefault && (!Fr || Xr && Fr !== Xr) && be.cancelable !== !1 ? (ze(be), _r = !0) : _r && (_r = !1), S.autoScroll && (Zt = !0), Cs(H.pageX, H.pageY, ad)
                        },
                        Cs = function(H, be, ae) {
                            var we = 1 - S.dragResistance,
                                Re = 1 - S.edgeResistance,
                                Le = S.pointerX,
                                Pt = S.pointerY,
                                Qe = Sn,
                                Qt = S.x,
                                jt = S.y,
                                Jt = S.endX,
                                _n = S.endY,
                                Kn = S.endRotation,
                                gi = On,
                                kr, Ii, Un, Dn, yc, Kr;
                            S.pointerX = H, S.pointerY = be, mr && (H -= Ke(Ut), be -= ht(Ut)), se ? (Dn = Math.atan2(ws.y - be, H - ws.x) * pe, yc = S.y - Dn, yc > 180 ? (Sn -= 360, S.y = Dn) : yc < -180 && (Sn += 360, S.y = Dn), S.x !== Wn || Math.abs(Sn - Dn) > Ze ? (S.y = Dn, Un = Wn + (Sn - Dn) * we) : Un = Wn) : (qt && (Kr = H * qt.a + be * qt.c + qt.e, be = H * qt.b + be * qt.d + qt.f, H = Kr), Ii = be - mi, kr = H - mn, Ii < Ze && Ii > -Ze && (Ii = 0), kr < Ze && kr > -Ze && (kr = 0), (S.lockAxis || S.lockedAxis) && (kr || Ii) && (Kr = S.lockedAxis, Kr || (S.lockedAxis = Kr = Pe && Math.abs(kr) > Math.abs(Ii) ? "y" : We ? "x" : null, Kr && pt(S.vars.onLockAxis) && S.vars.onLockAxis.call(S, S.pointerEvent)), Kr === "y" ? Ii = 0 : Kr === "x" && (kr = 0)), Un = _e(Wn + kr * we), Dn = _e(Sn + Ii * we)), (Ni || zi || io) && (S.x !== Un || S.y !== Dn && !se) && (io && (ve.x = Un, ve.y = Dn, Kr = io(ve), Un = _e(Kr.x), Dn = _e(Kr.y)), Ni && (Un = _e(Ni(Un))), zi && (Dn = _e(zi(Dn)))), ro && (Un > bn ? Un = bn + Math.round((Un - bn) * Re) : Un < gn && (Un = gn + Math.round((Un - gn) * Re)), se || (Dn > Mn ? Dn = Math.round(Mn + (Dn - Mn) * Re) : Dn < Cn && (Dn = Math.round(Cn + (Dn - Cn) * Re)))), (S.x !== Un || S.y !== Dn && !se) && (se ? (S.endRotation = S.x = S.endX = Un, On = !0) : (We && (S.y = S.endY = Dn, On = !0), Pe && (S.x = S.endX = Un, On = !0)), !ae || D(S, "move", "onMove") !== !1 ? !S.isDragging && S.isPressed && (S.isDragging = $a = !0, D(S, "dragstart", "onDragStart")) : (S.pointerX = Le, S.pointerY = Pt, Sn = Qe, S.x = Qt, S.y = jt, S.endX = Jt, S.endY = _n, S.endRotation = Kn, On = gi))
                        },
                        qr = function et(H, be) {
                            if (!Yr || !S.isPressed || H && Ar != null && !be && (H.pointerId && H.pointerId !== Ar && H.target !== F || H.changedTouches && !Ct(H.changedTouches, Ar))) {
                                _r && H && Yr && ze(H);
                                return
                            }
                            S.isPressed = !1;
                            var ae = H,
                                we = S.isDragging,
                                Re = S.vars.allowContextMenu && H && (H.ctrlKey || H.which > 2),
                                Le = q.delayedCall(.001, Jg),
                                Pt, Qe, Qt, jt, Jt;
                            if (Vn ? (je(Vn, "touchend", et), je(Vn, "touchmove", so), je(Vn, "touchcancel", et), je(Ut, "touchstart", Fe)) : je(Ut, "mousemove", so), je(Z, "touchforcechange", ze), (!Lt || !Vn) && (je(Ut, "mouseup", et), H && H.target && je(H.target, "mouseup", et)), On = !1, we && (on = oe = vt(), S.isDragging = !1), Xt(oi), _s && !Re) {
                                H && (je(H.target, "change", et), S.pointerEvent = ae), J(st, !1), D(S, "release", "onRelease"), D(S, "click", "onClick"), _s = !1;
                                return
                            }
                            for (Qe = st.length; --Qe > -1;) hn(st[Qe], "cursor", E.cursor || (E.cursor !== !1 ? lt : null));
                            if (ot--, H) {
                                if (Pt = H.changedTouches, Pt && (H = Pt[0], H !== Ma && H.identifier !== Ar)) {
                                    for (Qe = Pt.length; --Qe > -1 && (H = Pt[Qe]).identifier !== Ar && H.target !== F;);
                                    if (Qe < 0 && !be) return
                                }
                                S.pointerEvent = ae, S.pointerX = H.pageX, S.pointerY = H.pageY
                            }
                            return Re && ae ? (ze(ae), _r = !0, D(S, "release", "onRelease")) : ae && !we ? (_r = !1, ld && (E.snap || E.bounds) && vc(E.inertia || E.throwProps), D(S, "release", "onRelease"), (!rt || ae.type !== "touchmove") && ae.type.indexOf("cancel") === -1 && (D(S, "click", "onClick"), vt() - Vt < 300 && D(S, "doubleclick", "onDoubleClick"), jt = ae.target || F, Vt = vt(), Jt = function() {
                                Vt !== hc && S.enabled() && !S.isPressed && !ae.defaultPrevented && (jt.click ? jt.click() : Ut.createEvent && (Qt = Ut.createEvent("MouseEvents"), Qt.initMouseEvent("click", !0, !0, Z, 1, S.pointerEvent.screenX, S.pointerEvent.screenY, S.pointerX, S.pointerY, !1, !1, !1, !1, 0, null), jt.dispatchEvent(Qt)))
                            }, !rt && !ae.defaultPrevented && q.delayedCall(.05, Jt))) : (vc(E.inertia || E.throwProps), !S.allowEventDefault && ae && (E.dragClickables !== !1 || !qn.call(S, ae.target)) && we && (!Fr || Xr && Fr === Xr) && ae.cancelable !== !1 ? (_r = !0, ze(ae)) : _r = !1, D(S, "release", "onRelease")), Ds() && Le.duration(S.tween.duration()), we && D(S, "dragend", "onDragEnd"), !0
                        },
                        Fa = function(H) {
                            if (H && S.isDragging && !_t) {
                                var be = H.target || F.parentNode,
                                    ae = be.scrollLeft - be._gsScrollX,
                                    we = be.scrollTop - be._gsScrollY;
                                (ae || we) && (qt ? (mn -= ae * qt.a + we * qt.c, mi -= we * qt.d + ae * qt.b) : (mn -= ae, mi -= we), be._gsScrollX += ae, be._gsScrollY += we, Cs(S.pointerX, S.pointerY))
                            }
                        },
                        pd = function(H) {
                            var be = vt(),
                                ae = be - Vt < 100,
                                we = be - on < 50,
                                Re = ae && hc === Vt,
                                Le = S.pointerEvent && S.pointerEvent.defaultPrevented,
                                Pt = ae && cd === Vt,
                                Qe = H.isTrusted || H.isTrusted == null && ae && Re;
                            if ((Re || we && S.vars.suppressClickOnDrag !== !1) && H.stopImmediatePropagation && H.stopImmediatePropagation(), ae && !(S.pointerEvent && S.pointerEvent.defaultPrevented) && (!Re || Qe && !Pt)) {
                                Qe && Re && (cd = Vt), hc = Vt;
                                return
                            }(S.isPressed || we || ae) && (!Qe || !H.detail || !ae || Le) && ze(H), !ae && !we && !$a && (H && H.target && (S.pointerEvent = H), D(S, "click", "onClick"))
                        },
                        hd = function(H) {
                            return qt ? {
                                x: H.x * qt.a + H.y * qt.c + qt.e,
                                y: H.x * qt.b + H.y * qt.d + qt.f
                            } : {
                                x: H.x,
                                y: H.y
                            }
                        };
                    return dc = b.get(F), dc && dc.kill(), U.startDrag = function(et, H) {
                        var be, ae, we, Re;
                        Ss(et || S.pointerEvent, !0), H && !S.hitTest(et || S.pointerEvent) && (be = _(et || S.pointerEvent), ae = _(F), we = hd({
                            x: be.left + be.width / 2,
                            y: be.top + be.height / 2
                        }), Re = hd({
                            x: ae.left + ae.width / 2,
                            y: ae.top + ae.height / 2
                        }), mn -= we.x - Re.x, mi -= we.y - Re.y), S.isDragging || (S.isDragging = $a = !0, D(S, "dragstart", "onDragStart"))
                    }, U.drag = so, U.endDrag = function(et) {
                        return qr(et || S.pointerEvent, !0)
                    }, U.timeSinceDrag = function() {
                        return S.isDragging ? 0 : (vt() - on) / 1e3
                    }, U.timeSinceClick = function() {
                        return (vt() - Vt) / 1e3
                    }, U.hitTest = function(et, H) {
                        return b.hitTest(S.target, et, H)
                    }, U.getDirection = function(et, H) {
                        var be = et === "velocity" && it ? et : It(et) && !se ? "element" : "start",
                            ae, we, Re, Le, Pt, Qe;
                        return be === "element" && (Pt = _(S.target), Qe = _(et)), ae = be === "start" ? S.x - Wn : be === "velocity" ? it.getVelocity(F, ye) : Pt.left + Pt.width / 2 - (Qe.left + Qe.width / 2), se ? ae < 0 ? "counter-clockwise" : "clockwise" : (H = H || 2, we = be === "start" ? S.y - Sn : be === "velocity" ? it.getVelocity(F, ue) : Pt.top + Pt.height / 2 - (Qe.top + Qe.height / 2), Re = Math.abs(ae / we), Le = Re < 1 / H ? "" : ae < 0 ? "left" : "right", Re < H && (Le !== "" && (Le += "-"), Le += we < 0 ? "up" : "down"), Le)
                    }, U.applyBounds = function(et, H) {
                        var be, ae, we, Re, Le, Pt;
                        if (et && E.bounds !== et) return E.bounds = et, S.update(!0, H);
                        if (oo(!0), gc(), ro && !Ds()) {
                            if (be = S.x, ae = S.y, be > bn ? be = bn : be < gn && (be = gn), ae > Mn ? ae = Mn : ae < Cn && (ae = Cn), (S.x !== be || S.y !== ae) && (we = !0, S.x = S.endX = be, se ? S.endRotation = be : S.y = S.endY = ae, On = !0, oi(!0), S.autoScroll && !S.isDragging))
                                for (pn(F.parentNode), Re = F, Ee.scrollTop = Z.pageYOffset != null ? Z.pageYOffset : Ut.documentElement.scrollTop != null ? Ut.documentElement.scrollTop : Ut.body.scrollTop, Ee.scrollLeft = Z.pageXOffset != null ? Z.pageXOffset : Ut.documentElement.scrollLeft != null ? Ut.documentElement.scrollLeft : Ut.body.scrollLeft; Re && !Pt;) Pt = mt(Re.parentNode), Le = Pt ? Ee : Re.parentNode, We && Le.scrollTop > Le._gsMaxScrollY && (Le.scrollTop = Le._gsMaxScrollY), Pe && Le.scrollLeft > Le._gsMaxScrollX && (Le.scrollLeft = Le._gsMaxScrollX), Re = Le;
                            S.isThrowing && (we || S.endX > bn || S.endX < gn || S.endY > Mn || S.endY < Cn) && vc(E.inertia || E.throwProps, we)
                        }
                        return S
                    }, U.update = function(et, H, be) {
                        if (H && S.isPressed) {
                            var ae = X(F),
                                we = ud.apply({
                                    x: S.x - Wn,
                                    y: S.y - Sn
                                }),
                                Re = X(F.parentNode, !0);
                            Re.apply({
                                x: ae.e - we.x,
                                y: ae.f - we.y
                            }, we), S.x -= we.x - Re.e, S.y -= we.y - Re.f, oi(!0), Aa()
                        }
                        var Le = S.x,
                            Pt = S.y;
                        return dd(!H), et ? S.applyBounds() : (On && be && oi(!0), oo(!0)), H && (Cs(S.pointerX, S.pointerY), On && oi(!0)), S.isPressed && !H && (Pe && Math.abs(Le - S.x) > .01 || We && Math.abs(Pt - S.y) > .01 && !se) && Aa(), S.autoScroll && (pn(F.parentNode, S.isDragging), Zt = S.isDragging, oi(!0), dn(F, Fa), xt(F, Fa)), S
                    }, U.enable = function(et) {
                        var H = {
                                lazy: !0
                            },
                            be, ae, we;
                        if (E.cursor !== !1 && (H.cursor = E.cursor || lt), q.utils.checkPrefix("touchCallout") && (H.touchCallout = "none"), et !== "soft") {
                            for (yt(st, Pe === We ? "none" : E.allowNativeTouchScrolling && F.scrollHeight === F.clientHeight == (F.scrollWidth === F.clientHeight) || E.allowEventDefault ? "manipulation" : Pe ? "pan-y" : "pan-x"), ae = st.length; --ae > -1;) we = st[ae], Lt || Ft(we, "mousedown", Ss), Ft(we, "touchstart", Ss), Ft(we, "click", pd, !0), q.set(we, H), we.getBBox && we.ownerSVGElement && Pe !== We && q.set(we.ownerSVGElement, {
                                touchAction: E.allowNativeTouchScrolling || E.allowEventDefault ? "manipulation" : Pe ? "pan-y" : "pan-x"
                            }), E.allowContextMenu || Ft(we, "contextmenu", fd);
                            J(st, !1)
                        }
                        return xt(F, Fa), Yr = !0, it && et !== "soft" && it.track(_t || F, de ? "x,y" : se ? "rotation" : "top,left"), F._gsDragID = be = "d" + L++, C[be] = S, _t && (_t.enable(), _t.element._gsDragID = be), (E.bounds || se) && Aa(), E.bounds && S.applyBounds(), S
                    }, U.disable = function(et) {
                        for (var H = S.isDragging, be = st.length, ae; --be > -1;) hn(st[be], "cursor", null);
                        if (et !== "soft") {
                            for (yt(st, null), be = st.length; --be > -1;) ae = st[be], hn(ae, "touchCallout", null), je(ae, "mousedown", Ss), je(ae, "touchstart", Ss), je(ae, "click", pd, !0), je(ae, "contextmenu", fd);
                            J(st, !0), Vn && (je(Vn, "touchcancel", qr), je(Vn, "touchend", qr), je(Vn, "touchmove", so)), je(Ut, "mouseup", qr), je(Ut, "mousemove", so)
                        }
                        return dn(F, Fa), Yr = !1, it && et !== "soft" && (it.untrack(_t || F, de ? "x,y" : se ? "rotation" : "top,left"), S.tween && S.tween.kill()), _t && _t.disable(), Xt(oi), S.isDragging = S.isPressed = _s = !1, H && D(S, "dragend", "onDragEnd"), S
                    }, U.enabled = function(et, H) {
                        return arguments.length ? et ? S.enable(H) : S.disable(H) : Yr
                    }, U.kill = function() {
                        return S.isThrowing = !1, S.tween && S.tween.kill(), S.disable(), q.set(st, {
                            clearProps: "userSelect"
                        }), delete C[F._gsDragID], S
                    }, U.revert = function() {
                        this.kill(), this.styles && this.styles.revert()
                    }, ~ie.indexOf("scroll") && (_t = U.scrollProxy = new me(F, Oe({
                        onKill: function() {
                            S.isPressed && qr(null)
                        }
                    }, E)), F.style.overflowY = We && !Ue ? "auto" : "hidden", F.style.overflowX = Pe && !Ue ? "auto" : "hidden", F = _t.content), se ? Et.rotation = 1 : (Pe && (Et[ye] = 1), We && (Et[ue] = 1)), kt.force3D = "force3D" in E ? E.force3D : !0, Ne(i(U)), U.enable(), U
                }
                return b.register = function(E) {
                    q = E, De()
                }, b.create = function(E, U) {
                    return $e || De(!0), tt(E).map(function(ie) {
                        return new b(ie, U)
                    })
                }, b.get = function(E) {
                    return C[(tt(E)[0] || {})._gsDragID]
                }, b.timeSinceDrag = function() {
                    return (vt() - oe) / 1e3
                }, b.hitTest = function(E, U, ie) {
                    if (E === U) return !1;
                    var de = _(E),
                        se = _(U),
                        ye = de.top,
                        ue = de.left,
                        Pe = de.right,
                        We = de.bottom,
                        Ze = de.width,
                        S = de.height,
                        st = se.left > Pe || se.right < ue || se.top > We || se.bottom < ye,
                        Et, on, Zt;
                    return st || !ie ? !st : (Zt = (ie + "").indexOf("%") !== -1, ie = parseFloat(ie) || 0, Et = {
                        left: Math.max(ue, se.left),
                        top: Math.max(ye, se.top)
                    }, Et.width = Math.min(Pe, se.right) - Et.left, Et.height = Math.min(We, se.bottom) - Et.top, Et.width < 0 || Et.height < 0 ? !1 : Zt ? (ie *= .01, on = Et.width * Et.height, on >= Ze * S * ie || on >= se.width * se.height * ie) : Et.width > ie && Et.height > ie)
                }, b
            }(Te);
        Rn(xe.prototype, {
            pointerX: 0,
            pointerY: 0,
            startX: 0,
            startY: 0,
            deltaX: 0,
            deltaY: 0,
            isDragging: !1,
            isPressed: !1
        }), xe.zIndex = 1e3, xe.version = "3.12.2", re() && q.registerPlugin(xe), n.Draggable = xe, n.default = xe, typeof window > "u" || window !== n ? Object.defineProperty(n, "__esModule", {
            value: !0
        }) : delete window.default
    })
})(af, af.exports);
var AE = af.exports;
const Dh = cs(AE),
    FE = u.forwardRef(({
        uuid: t,
        contents: e,
        builder: n,
        onClose: r
    }, i) => {
        u.useMemo(() => he.registerPlugin(Dh), []);
        const {
            locale: o
        } = nr(), s = u.useRef(null), a = u.useRef(null), l = u.useRef(null), c = u.useRef(!1), d = u.useRef(null), f = u.useRef(he.timeline({
            paused: !0
        })), h = If(p => p.setState);
        return u.useLayoutEffect(() => {
            const p = he.context(m => {
                const g = m.selector || he.utils.selector,
                    y = g("[data-gsap-hero-title]")[0];
                if (y === void 0) return;
                const x = new In(y, {
                    type: "lines",
                    linesClass: "line"
                });
                new In(y, {
                    type: "lines",
                    linesClass: "line-wrap"
                });
                const w = g("[data-gsap-hero-description]")[0],
                    M = new In(w, {
                        type: "lines",
                        linesClass: "line"
                    });
                new In(w, {
                    type: "lines",
                    linesClass: "line-wrap"
                });
                const T = g("[data-gsap-hero-infos]")[0],
                    O = g("[data-gsap-hero-poster]")[0],
                    R = g("[data-gsap-hero-poster-mask]")[0],
                    P = g("[data-gsap-hero-poster-white]")[0],
                    B = g("[data-gsap-hero-poster-primary]")[0],
                    te = g("[data-gsap-builder-line-root]")[0],
                    W = g("[data-gsap-builder-link-label]")[0],
                    ee = g("[data-gsap-builder-link-line]")[0],
                    V = g("[data-gsap-builder-close-line1-primary]")[0],
                    I = g("[data-gsap-builder-close-line1-white]")[0],
                    X = g("[data-gsap-builder-close-line2-primary]")[0],
                    q = g("[data-gsap-builder-close-line2-white]")[0];
                f.current.add(he.timeline({
                    defaults: {
                        duration: .6,
                        ease: "power2.out"
                    }
                }).fromTo(x.lines, {
                    yPercent: 120
                }, {
                    yPercent: 0
                }).fromTo(T, {
                    yPercent: 120
                }, {
                    yPercent: 0
                }, "<+.2").fromTo(M.lines, {
                    yPercent: 120
                }, {
                    yPercent: 0,
                    stagger: {
                        amount: .1
                    }
                }, "<+.1")).add(he.timeline().add(he.timeline({
                    defaults: {
                        duration: .8,
                        ease: "power2.out"
                    }
                }).fromTo([B, P], {
                    yPercent: 120
                }, {
                    yPercent: 0,
                    stagger: {
                        amount: .1
                    }
                })).add(he.timeline({
                    defaults: {
                        duration: .8,
                        ease: "power2.out"
                    }
                }).fromTo(R, {
                    yPercent: 120
                }, {
                    yPercent: 0
                }).fromTo(O, {
                    yPercent: -100
                }, {
                    yPercent: 0
                }, "<"), "<+.2").set([B, P], {
                    opacity: 0
                }), "<+.1").add(he.timeline().add(he.timeline({
                    defaults: {
                        duration: .6,
                        ease: "power2.inOut"
                    }
                }).fromTo(te, {
                    scaleX: 0
                }, {
                    scaleX: 1
                }, "<"), "<").add(he.timeline({
                    defaults: {
                        duration: 1,
                        ease: "power3.out"
                    }
                }).fromTo(W, {
                    yPercent: 180,
                    skewY: 25
                }, {
                    yPercent: 0,
                    skewY: 0
                }).fromTo(ee, {
                    x: -20,
                    scaleX: 0
                }, {
                    x: 0,
                    scaleX: 1,
                    transformOrigin: "left center"
                }, "<+.2"), "<").add(he.timeline({
                    defaults: {
                        duration: .6,
                        ease: "power3.inOut"
                    }
                }).fromTo([V, I], {
                    xPercent: 100,
                    scaleX: 0
                }, {
                    xPercent: 0,
                    scaleX: 1,
                    stagger: {
                        amount: .1
                    }
                }).fromTo([X, q], {
                    xPercent: 100,
                    scaleX: 0
                }, {
                    xPercent: 0,
                    scaleX: 1,
                    stagger: {
                        amount: .1
                    }
                }, "<+.1"), "<"), "<+.1")
            }, l.current);
            return () => {
                p.revert()
            }
        }, []), u.useLayoutEffect(() => {
            const p = he.context(() => {
                he.to("[data-gsap-builder-line]", {
                    motionPath: {
                        fromCurrent: !1,
                        path: [{
                            scaleX: 0,
                            xPercent: 50
                        }, {
                            scaleX: 1,
                            xPercent: 0
                        }, {
                            scaleX: 0,
                            xPercent: -100
                        }]
                    },
                    transformOrigin: "right center",
                    ease: "power2.inOut",
                    duration: 1.5,
                    repeat: -1
                })
            });
            return () => {
                p.revert()
            }
        }, []), u.useEffect(() => {
            d.current = new yE({
                lerp: .1,
                smoothWheel: !0,
                wrapper: s.current,
                content: a.current,
                eventsTarget: s.current,
                gestureOrientation: "both",
                orientation: "horizontal"
            });
            let p;
            const m = y => {
                p = requestAnimationFrame(m), c.current && d.current.raf(y)
            };
            p = requestAnimationFrame(m);
            const g = ({
                scroll: y,
                velocity: x
            }) => {
                h({
                    scroll: y,
                    velocity: x
                })
            };
            return d.current.on("scroll", g), () => {
                cancelAnimationFrame(p), d.current.off("scroll", g), d.current.destroy()
            }
        }, [t, h]), u.useEffect(() => {
            new Dh(s.current, {
                type: "scrollLeft",
                bounds: s.current,
                dragClickables: !0,
                cursor: "default",
                inertia: !0
            })
        }, []), u.useImperativeHandle(i, () => ({
            timeline: f,
            disable: () => {
                c.current = !1
            },
            enable: () => {
                c.current = !0, d.current.scrollTo(0, {
                    immediate: !0
                })
            }
        }), []), bt("Builder"), v.jsxs("div", {
            ref: l,
            className: "relative w-full h-full",
            children: [v.jsx("div", {
                ref: s,
                className: "relative w-full h-full overflow-auto bg-dark/0 [&>div]:h-full",
                children: v.jsx("div", {
                    ref: a,
                    className: "flex w-auto h-full flex-nowrap",
                    children: n == null ? void 0 : n.map(({
                        type: p,
                        ...m
                    }, g) => {
                        const y = $E[p];
                        return v.jsx(u.Fragment, {
                            children: y && v.jsx(y, { ...m,
                                ...e
                            })
                        }, g)
                    })
                })
            }), v.jsx("div", {
                className: "absolute left-0 top-0 w-full z-20",
                children: v.jsx(ki, {
                    children: v.jsx("div", {
                        className: "position relative translate-y-[calc(1.9rem+2.5rem)] md:translate-y-[calc(3.2rem+5rem)]",
                        children: v.jsx("div", {
                            className: "absolute top-0 right-0 -translate-y-1/2",
                            children: v.jsxs("button", {
                                className: "group block w-[4.4rem] h-[4.4rem] translate-x-[1.5rem] translate-y-[0.5rem]",
                                onClick: r,
                                "aria-label": "close",
                                children: [v.jsxs("span", {
                                    className: "absolute top-1/2 left-1/2 w-[1.8rem] h-[.2rem] -translate-x-1/2 -translate-y-1/2 rotate-45 origin-center",
                                    children: [v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full bg-primary",
                                        "data-gsap-builder-close-line1-primary": !0
                                    }), v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full overflow-hidden",
                                        "data-gsap-builder-close-line1-white": !0,
                                        children: v.jsx("span", {
                                            className: "absolute top-0 left-0 w-full h-full bg-white group-hover:-translate-x-full transition-transform duration-300 ease-out"
                                        })
                                    })]
                                }), v.jsxs("span", {
                                    className: "absolute top-1/2 left-1/2 w-[1.8rem] h-[.2rem] -translate-x-1/2 -translate-y-1/2 -rotate-45 origin-center",
                                    children: [v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full bg-primary",
                                        "data-gsap-builder-close-line2-primary": !0
                                    }), v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full overflow-hidden",
                                        "data-gsap-builder-close-line2-white": !0,
                                        children: v.jsx("span", {
                                            className: "absolute top-0 left-0 w-full h-full bg-white delay-100 group-hover:-translate-x-full transition-transform duration-300 ease-out"
                                        })
                                    })]
                                })]
                            })
                        })
                    })
                })
            }), v.jsx("div", {
                className: "absolute left-0 w-full bottom-[5.9rem] md:bottom-[5.25rem] mb-10 md:mb-16 xl:mb-20",
                children: v.jsx(ki, {
                    children: v.jsxs("div", {
                        className: "relative -translate-y-10 md:-translate-y-20",
                        children: [v.jsx("div", {
                            className: "absolute left-0 bottom-0",
                            children: v.jsx("div", {
                                className: "absolute w-[8.4rem] md:w-[10.4rem] bottom-0 left-0 h-[.2rem] bg-primary-dark overflow-hidden",
                                "data-gsap-builder-line-root": !0,
                                children: v.jsx("div", {
                                    className: "absolute top-0 left-0 w-full h-full bg-primary",
                                    "data-gsap-builder-line": !0
                                })
                            })
                        }), v.jsx("div", {
                            className: "absolute right-0 bottom-0",
                            children: v.jsxs("a", {
                                href: e == null ? void 0 : e.link,
                                target: "_blank",
                                className: "relative block px-[2.4rem] py-[1.6rem] group",
                                children: [v.jsx("span", {
                                    className: "relative block overflow-hidden",
                                    children: v.jsx("span", {
                                        className: "relative block overflow-hidden",
                                        "data-gsap-builder-link-label": !0,
                                        children: v.jsx("span", {
                                            className: "relative block",
                                            children: v.jsx("span", {
                                                "data-label": o.shared.cta_website,
                                                className: "font-condensed text-regular md:text-regular-lg block transition-transform duration-500 ease-in-out after:content-[attr(data-label)] after:absolute after:top-0 after:left-0 after:translate-y-full group-hover:-translate-y-full",
                                                children: o.shared.cta_website
                                            })
                                        })
                                    })
                                }), v.jsxs("span", {
                                    className: "absolute left-0 right-0 bottom-0 md:-bottom-0 h-[.2rem]",
                                    "data-gsap-builder-link-line": !0,
                                    children: [v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full origin-top-right transition-transform duration-300 ease-out delay-100 bg-white group-hover:delay-0 group-hover:ease-in-out group-hover:translate-x-[1rem] group-hover:scale-x-0"
                                    }), v.jsx("span", {
                                        className: "absolute top-0 left-0 w-full h-full origin-top-left -translate-x-[1rem] scale-x-0 transition-transform duration-300 ease-out bg-white group-hover:ease-in-out group-hover:delay-100 group-hover:translate-x-0 group-hover:scale-100"
                                    })]
                                })]
                            })
                        })]
                    })
                })
            })]
        })
    }),
    kE = () => {
        const {
            scenes: t
        } = nr(), e = Bn(h => h.leaf), n = u.useRef(null), r = u.useRef(null), i = u.useRef(null), o = Gr(), s = Bn(h => h.setCurrentLeaf), a = u.useCallback(() => {
            var h;
            return (h = i.current) == null ? void 0 : h.timeline.current
        }, []), l = () => {
            he.timeline().set(n.current, {
                yPercent: -120
            }).set(r.current, {
                yPercent: 60
            })
        }, c = () => {}, d = u.useCallback(h => {
            if (!n.current) return;
            const p = h.value;
            he.timeline().set(n.current, {
                yPercent: -120 * (1 - p)
            }).set(r.current, {
                yPercent: 60 * (1 - p)
            }, "<")
        }, []), f = u.useCallback(h => {
            var p, m;
            i.current && (h.value ? (p = i.current) == null || p.enable() : (m = i.current) == null || m.disable(), he.delayedCall(1, () => {
                var g, y;
                h.value && he.set(n.current, {
                    pointerEvents: "auto"
                }), h.value ? (g = a()) == null || g.restart() : (y = a()) == null || y.reverse()
            }))
        }, [a]);
        return u.useEffect(() => (o.leafMotionValue.addEventListener("start", f), o.leafMotionValue.addEventListener("update", d), () => {
            o.leafMotionValue.removeEventListener("start", f), o.leafMotionValue.removeEventListener("update", d)
        }), [o, f, d]), bt("Cases"), t.map(h => v.jsx(_v, { in: e === h.uuid,
            appear: !0,
            timeout: 1e3,
            unmountOnExit: !0,
            onEnter: l,
            onExit: c,
            children: v.jsx("section", {
                ref: n,
                className: "absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none",
                children: v.jsx("div", {
                    ref: r,
                    className: "absolute top-0 left-0 w-full h-full",
                    children: v.jsx(FE, {
                        ref: i,
                        ...h,
                        onClose: () => s(null)
                    })
                })
            })
        }, `builder-${h.uuid}`))
    };
var Pa = {},
    OE = {},
    pa = u;

function jE(t) {
    return t && typeof t == "object" && "default" in t ? t : {
        default: t
    }
}
var Gl = jE(pa);

function Sh(t, e) {
    for (var n = 0; n < e.length; n++) {
        var r = e[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
    }
}

function LE(t, e, n) {
    return e && Sh(t.prototype, e), n && Sh(t, n), t
}
var ol = typeof process < "u" && OE && !0,
    Hc = function(t) {
        return Object.prototype.toString.call(t) === "[object String]"
    },
    NE = function() {
        function t(n) {
            var r = n === void 0 ? {} : n,
                i = r.name,
                o = i === void 0 ? "stylesheet" : i,
                s = r.optimizeForSpeed,
                a = s === void 0 ? ol : s;
            yi(Hc(o), "`name` must be a string"), this._name = o, this._deletedRulePlaceholder = "#" + o + "-deleted-rule____{}", yi(typeof a == "boolean", "`optimizeForSpeed` must be a boolean"), this._optimizeForSpeed = a, this._serverSheet = void 0, this._tags = [], this._injected = !1, this._rulesCount = 0;
            var l = typeof window < "u" && document.querySelector('meta[property="csp-nonce"]');
            this._nonce = l ? l.getAttribute("content") : null
        }
        var e = t.prototype;
        return e.setOptimizeForSpeed = function(r) {
            yi(typeof r == "boolean", "`setOptimizeForSpeed` accepts a boolean"), yi(this._rulesCount === 0, "optimizeForSpeed cannot be when rules have already been inserted"), this.flush(), this._optimizeForSpeed = r, this.inject()
        }, e.isOptimizeForSpeed = function() {
            return this._optimizeForSpeed
        }, e.inject = function() {
            var r = this;
            if (yi(!this._injected, "sheet already injected"), this._injected = !0, typeof window < "u" && this._optimizeForSpeed) {
                this._tags[0] = this.makeStyleTag(this._name), this._optimizeForSpeed = "insertRule" in this.getSheet(), this._optimizeForSpeed || (ol || console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."), this.flush(), this._injected = !0);
                return
            }
            this._serverSheet = {
                cssRules: [],
                insertRule: function(i, o) {
                    return typeof o == "number" ? r._serverSheet.cssRules[o] = {
                        cssText: i
                    } : r._serverSheet.cssRules.push({
                        cssText: i
                    }), o
                },
                deleteRule: function(i) {
                    r._serverSheet.cssRules[i] = null
                }
            }
        }, e.getSheetForTag = function(r) {
            if (r.sheet) return r.sheet;
            for (var i = 0; i < document.styleSheets.length; i++)
                if (document.styleSheets[i].ownerNode === r) return document.styleSheets[i]
        }, e.getSheet = function() {
            return this.getSheetForTag(this._tags[this._tags.length - 1])
        }, e.insertRule = function(r, i) {
            if (yi(Hc(r), "`insertRule` accepts only strings"), typeof window > "u") return typeof i != "number" && (i = this._serverSheet.cssRules.length), this._serverSheet.insertRule(r, i), this._rulesCount++;
            if (this._optimizeForSpeed) {
                var o = this.getSheet();
                typeof i != "number" && (i = o.cssRules.length);
                try {
                    o.insertRule(r, i)
                } catch {
                    return ol || console.warn(`StyleSheet: illegal rule: 

` + r + `

See https://stackoverflow.com/q/20007992 for more info`), -1
                }
            } else {
                var s = this._tags[i];
                this._tags.push(this.makeStyleTag(this._name, r, s))
            }
            return this._rulesCount++
        }, e.replaceRule = function(r, i) {
            if (this._optimizeForSpeed || typeof window > "u") {
                var o = typeof window < "u" ? this.getSheet() : this._serverSheet;
                if (i.trim() || (i = this._deletedRulePlaceholder), !o.cssRules[r]) return r;
                o.deleteRule(r);
                try {
                    o.insertRule(i, r)
                } catch {
                    ol || console.warn(`StyleSheet: illegal rule: 

` + i + `

See https://stackoverflow.com/q/20007992 for more info`), o.insertRule(this._deletedRulePlaceholder, r)
                }
            } else {
                var s = this._tags[r];
                yi(s, "old rule at index `" + r + "` not found"), s.textContent = i
            }
            return r
        }, e.deleteRule = function(r) {
            if (typeof window > "u") {
                this._serverSheet.deleteRule(r);
                return
            }
            if (this._optimizeForSpeed) this.replaceRule(r, "");
            else {
                var i = this._tags[r];
                yi(i, "rule at index `" + r + "` not found"), i.parentNode.removeChild(i), this._tags[r] = null
            }
        }, e.flush = function() {
            this._injected = !1, this._rulesCount = 0, typeof window < "u" ? (this._tags.forEach(function(r) {
                return r && r.parentNode.removeChild(r)
            }), this._tags = []) : this._serverSheet.cssRules = []
        }, e.cssRules = function() {
            var r = this;
            return typeof window > "u" ? this._serverSheet.cssRules : this._tags.reduce(function(i, o) {
                return o ? i = i.concat(Array.prototype.map.call(r.getSheetForTag(o).cssRules, function(s) {
                    return s.cssText === r._deletedRulePlaceholder ? null : s
                })) : i.push(null), i
            }, [])
        }, e.makeStyleTag = function(r, i, o) {
            i && yi(Hc(i), "makeStyleTag accepts only strings as second parameter");
            var s = document.createElement("style");
            this._nonce && s.setAttribute("nonce", this._nonce), s.type = "text/css", s.setAttribute("data-" + r, ""), i && s.appendChild(document.createTextNode(i));
            var a = document.head || document.getElementsByTagName("head")[0];
            return o ? a.insertBefore(s, o) : a.appendChild(s), s
        }, LE(t, [{
            key: "length",
            get: function() {
                return this._rulesCount
            }
        }]), t
    }();

function yi(t, e) {
    if (!t) throw new Error("StyleSheet: " + e + ".")
}

function zE(t) {
    for (var e = 5381, n = t.length; n;) e = e * 33 ^ t.charCodeAt(--n);
    return e >>> 0
}
var IE = zE,
    BE = function(t) {
        return t.replace(/\/style/gi, "\\/style")
    },
    ts = {};

function lf(t, e) {
    if (!e) return "jsx-" + t;
    var n = String(e),
        r = t + n;
    return ts[r] || (ts[r] = "jsx-" + IE(t + "-" + n)), ts[r]
}

function Ch(t, e) {
    var n = /__jsx-style-dynamic-selector/g;
    typeof window > "u" && (e = BE(e));
    var r = t + e;
    return ts[r] || (ts[r] = e.replace(n, t)), ts[r]
}

function WE(t, e) {
    return e === void 0 && (e = {}), t.map(function(n) {
        var r = n[0],
            i = n[1];
        return Gl.default.createElement("style", {
            id: "__" + r,
            key: "__" + r,
            nonce: e.nonce ? e.nonce : void 0,
            dangerouslySetInnerHTML: {
                __html: i
            }
        })
    })
}
var VE = function() {
    function t(n) {
        var r = n === void 0 ? {} : n,
            i = r.styleSheet,
            o = i === void 0 ? null : i,
            s = r.optimizeForSpeed,
            a = s === void 0 ? !1 : s;
        this._sheet = o || new NE({
            name: "styled-jsx",
            optimizeForSpeed: a
        }), this._sheet.inject(), o && typeof a == "boolean" && (this._sheet.setOptimizeForSpeed(a), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
    }
    var e = t.prototype;
    return e.add = function(r) {
        var i = this;
        this._optimizeForSpeed === void 0 && (this._optimizeForSpeed = Array.isArray(r.children), this._sheet.setOptimizeForSpeed(this._optimizeForSpeed), this._optimizeForSpeed = this._sheet.isOptimizeForSpeed()), typeof window < "u" && !this._fromServer && (this._fromServer = this.selectFromServer(), this._instancesCounts = Object.keys(this._fromServer).reduce(function(c, d) {
            return c[d] = 0, c
        }, {}));
        var o = this.getIdAndRules(r),
            s = o.styleId,
            a = o.rules;
        if (s in this._instancesCounts) {
            this._instancesCounts[s] += 1;
            return
        }
        var l = a.map(function(c) {
            return i._sheet.insertRule(c)
        }).filter(function(c) {
            return c !== -1
        });
        this._indices[s] = l, this._instancesCounts[s] = 1
    }, e.remove = function(r) {
        var i = this,
            o = this.getIdAndRules(r).styleId;
        if (UE(o in this._instancesCounts, "styleId: `" + o + "` not found"), this._instancesCounts[o] -= 1, this._instancesCounts[o] < 1) {
            var s = this._fromServer && this._fromServer[o];
            s ? (s.parentNode.removeChild(s), delete this._fromServer[o]) : (this._indices[o].forEach(function(a) {
                return i._sheet.deleteRule(a)
            }), delete this._indices[o]), delete this._instancesCounts[o]
        }
    }, e.update = function(r, i) {
        this.add(i), this.remove(r)
    }, e.flush = function() {
        this._sheet.flush(), this._sheet.inject(), this._fromServer = void 0, this._indices = {}, this._instancesCounts = {}
    }, e.cssRules = function() {
        var r = this,
            i = this._fromServer ? Object.keys(this._fromServer).map(function(s) {
                return [s, r._fromServer[s]]
            }) : [],
            o = this._sheet.cssRules();
        return i.concat(Object.keys(this._indices).map(function(s) {
            return [s, r._indices[s].map(function(a) {
                return o[a].cssText
            }).join(r._optimizeForSpeed ? "" : `
`)]
        }).filter(function(s) {
            return !!s[1]
        }))
    }, e.styles = function(r) {
        return WE(this.cssRules(), r)
    }, e.getIdAndRules = function(r) {
        var i = r.children,
            o = r.dynamic,
            s = r.id;
        if (o) {
            var a = lf(s, o);
            return {
                styleId: a,
                rules: Array.isArray(i) ? i.map(function(l) {
                    return Ch(a, l)
                }) : [Ch(a, i)]
            }
        }
        return {
            styleId: lf(s),
            rules: Array.isArray(i) ? i : [i]
        }
    }, e.selectFromServer = function() {
        var r = Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]'));
        return r.reduce(function(i, o) {
            var s = o.id.slice(2);
            return i[s] = o, i
        }, {})
    }, t
}();

function UE(t, e) {
    if (!t) throw new Error("StyleSheetRegistry: " + e + ".")
}
var Yl = pa.createContext(null);
Yl.displayName = "StyleSheetContext";

function od() {
    return new VE
}

function HE(t) {
    var e = t.registry,
        n = t.children,
        r = pa.useContext(Yl),
        i = pa.useState(function() {
            return r || e || od()
        }),
        o = i[0];
    return Gl.default.createElement(Yl.Provider, {
        value: o
    }, n)
}

function Ng() {
    return pa.useContext(Yl)
}
var GE = Gl.default.useInsertionEffect || Gl.default.useLayoutEffect,
    Eh = typeof window < "u" ? od() : void 0;

function zg(t) {
    var e = Eh || Ng();
    return e ? typeof window > "u" ? (e.add(t), null) : (GE(function() {
        return e.add(t),
            function() {
                e.remove(t)
            }
    }, [t.id, String(t.dynamic)]), null) : null
}
zg.dynamic = function(t) {
    return t.map(function(e) {
        var n = e[0],
            r = e[1];
        return lf(n, r)
    }).join(" ")
};
Pa.StyleRegistry = HE;
Pa.createStyleRegistry = od;
Pa.style = zg;
Pa.useStyleRegistry = Ng;
var YE = Pa.style;
const XE = cs(YE),
    qE = () => (u.useLayoutEffect(() => {
        const t = () => {
            const e = window.innerWidth,
                n = e > 1023 ? 60 : e > 767 ? 40 : 20,
                r = e > 1023 ? 30 : e > 767 ? 25 : 20,
                i = e > 1023 ? 12 - 1 : e > 767 ? 6 - 1 : 4 - 1,
                o = window.innerHeight * .01,
                s = window.innerWidth - n * 2 - r * i,
                a = window.innerHeight / window.innerWidth / (e < 768 ? 2 : 2.4);
            document.documentElement.style.setProperty("--ratio", `${Math.ceil(a*100)}%`), document.documentElement.style.setProperty("--vh", `${Math.round(o*100)/100}px`), document.documentElement.style.setProperty("--gw", `${s}px`)
        };
        return window.addEventListener("resize", t), t(), () => {
            window.removeEventListener("resize", t)
        }
    }, []), v.jsx(XE, {
        id: "3376554734",
        children: [":root{--cols:4;--gap:2rem;--cp:2rem;--col:calc(1 / var(--cols) * var(--gw));}", "@media (min-width:768px){:root{--cols:6;--gap:2.5rem;--cp:4rem;}}", "@media (min-width:1024px){:root{--cols:12;--gap:3rem;--cp:6rem;}}"]
    })),
    KE = ({
        children: t
    }) => v.jsxs(v.Fragment, {
        children: [v.jsx(qE, {}), v.jsx(tC, {}), v.jsxs("main", {
            className: "absolute top-0 left-0 right-0 bottom-0 overflow-hidden",
            children: [t, v.jsx(hE, {}), v.jsx(kE, {})]
        }), v.jsx(VC, {}), v.jsx(QS, {})]
    }),
    ZE = ({
        children: t
    }) => {
        const {
            visible: e
        } = un("Layout", {
            Grid: at({
                visible: {
                    value: !1
                }
            })
        });
        return v.jsxs(v.Fragment, {
            children: [v.jsx(KE, {
                children: t
            }), e && v.jsx("div", {
                className: "absolute top-0 left-0 w-full h-full pointer-events-none z-50",
                children: v.jsx(ki, {
                    className: "h-full",
                    children: v.jsx(Xf, {
                        className: "h-full",
                        children: Array(12).fill(void 0).map((n, r) => v.jsx("div", {
                            className: "col-span-1 bg-[orange] h-full opacity-25"
                        }, r))
                    })
                })
            })]
        })
    },
    QE = () => {
        const t = Dv(),
            [e] = u.useState(t);
        return v.jsx(v.Fragment, {
            children: e
        })
    },
    JE = () => (bt("Root"), v.jsx(ZE, {
        children: v.jsx(QE, {})
    })),
    e3 = () => v.jsxs(v.Fragment, {
        children: [v.jsx(JE, {}), v.jsx(XS, {})]
    }),
    Ig = {
        NAVIGATION: "navigation",
        TRANSITION: "transition"
    },
    t3 = [{
        path: "home",
        element: v.jsx(KS, {})
    }, {
        path: "about",
        element: v.jsx(qS, {})
    }, {
        path: ":id",
        element: v.jsx(ZS, {})
    }],
    n3 = t => t === "home",
    r3 = async () => await Gn.getState().load(),
    Bg = Sv(Cv(v.jsx(xc, {
        id: "store",
        path: "/",
        loader: r3,
        element: v.jsx(e3, {}),
        children: t3.map(({
            path: t,
            element: e
        }) => n3(t) ? v.jsx(xc, {
            index: !0,
            element: e
        }, t) : v.jsx(xc, {
            path: t,
            element: e
        }, t))
    })), {
        basename: _a
    });
let Th = !0;
Bg.subscribe(({
    location: t
}) => {
    const {
        routes: e
    } = nr(), n = e.map(s => ({ ...s,
        path: s.path.replace("/", _a)
    })), r = Ev(n, t), i = r ? r[0].route : n[0], o = n.indexOf(i);
    Bn.getState().setCurrentRoute({
        index: o,
        initial: Th,
        ...t.state
    }), Bn.getState().setCurrentLeaf(null), Th = !1
});
const i3 = new Mv.Lethargy,
    o3 = () => {
        const [t, e, n, r] = fi(i => [i.setDragGestureState, i.setMoveGestureState, i.setWheelGestureState, i.setKeysGestureState]);
        return $v({
            onDrag: t,
            onMove: e,
            onWheel: i => {
                if (i.last) return !1;
                if (i3.check(i.event)) {
                    if (!i.memo) return n(i), !0
                } else return !1
            }
        }, {
            target: document.body,
            eventOptions: {
                passive: !1
            },
            drag: {
                threshold: 10
            }
        }), u.useEffect(() => {
            const i = o => {
                r({
                    key: o.key,
                    event: o
                })
            };
            return document.addEventListener("keydown", i), () => {
                document.removeEventListener("keydown", i)
            }
        }, [r]), null
    },
    s3 = () => {
        const t = Gn(i => i.progress),
            e = Gn(i => i.complete),
            n = u.useRef(null),
            r = u.useRef(he.timeline({
                paused: !0,
                delay: .3
            }));
        return u.useLayoutEffect(() => {
            const i = he.context(() => {
                r.current.to(["[data-gsap-line]", "[data-gsap-base]"], {
                    scaleY: 0,
                    duration: .8,
                    ease: "power2.inOut",
                    stagger: .2,
                    onComplete: e
                })
            }, n.current);
            return () => {
                i.clear()
            }
        }, [e]), u.useEffect(() => {
            t === 1 && r.current.play()
        }, [t]), v.jsxs("div", {
            ref: n,
            className: "static",
            children: [v.jsx("div", {
                className: "absolute top-1/2 left-1/2 w-[.1rem] h-[20rem] bg-white -translate-x-1/2 -translate-y-1/2 opacity-20 z-30",
                "data-gsap-base": !0
            }), v.jsx("div", {
                className: "absolute top-1/2 left-1/2 w-[.2rem] h-[20rem] -translate-x-1/2 -translate-y-1/2 z-30",
                "data-gsap-line": !0,
                children: v.jsx("div", {
                    className: Kt("w-full h-full bg-white scale-0 transition-transform duration-700 ease-out", {
                        "delay-300": t !== 1
                    }),
                    style: {
                        transform: `scale(1, ${t})`
                    }
                })
            })]
        })
    },
    a3 = () => {
        const {
            get: t
        } = hr(), {
            getDPR: e
        } = Da();
        return u.useLayoutEffect(() => {
            const n = () => {
                const r = e(),
                    i = t().size,
                    {
                        width: o,
                        height: s
                    } = Rm(i.width, i.height, r);
                t().setSize(o, s, !1)
            };
            return window.addEventListener("resize", n), n(), () => {
                window.removeEventListener("resize", n)
            }
        }, [t, e]), null
    },
    l3 = `
  varying vec2 vUv;

  void main() {
    gl_Position = vec4(position, 1.0); // projectionMatrix * modelViewMatrix * vec4(position, 1.0);

    vUv = uv;
  }
`,
    c3 = `
  uniform sampler2D uScene0;
  uniform sampler2D uScene1;
  uniform sampler2D uNoise;
  uniform sampler2D uPattern;

  uniform float uAspectRatio;
  uniform float uNoiseSpeed;
  uniform float uNoiseScale;
  uniform float uNoiseIntensity;
  uniform float uPatternScale;
  uniform float uPatternStretch;
  uniform float uPatternIntensity;
  uniform float uDisplacementScale;
  uniform float uDisplacementIntensity;
  uniform float uCameraTransition;
  uniform float uLeafTransition;
  uniform float uTransition;
  uniform float uVelocity;
  uniform float uOpacity;
  uniform float uOffset;
  uniform float uXAxis;
  uniform float uYAxis;
  uniform float uTime;

  varying vec2 vUv;

  float mapRange(float value, float inMin, float inMax, float outMin, float outMax) {
    return outMin + (value - inMin) * (outMax - outMin) / (inMax - inMin);
  }

  void main() {
    float time = uTime;
    float offset = uOffset;
    float opacity = uOpacity;
    float velocity = uVelocity;
    float transition = uTransition;
    float leafTransition = uLeafTransition;
    float cameraTransition = uCameraTransition;
    vec2 aspectRatio = vec2(uAspectRatio, 1.);
    
    // Noise
    vec2 noiseUv = vUv * aspectRatio * vec2(uPatternStretch, 1.);
    noiseUv *= uNoiseScale;
    noiseUv += time * uNoiseSpeed;
    vec2 noise = texture2D(uNoise, noiseUv).xy;
    
    // Pattern
    vec2 patternUv = vUv * aspectRatio;
    patternUv *= uPatternScale;
    patternUv += (-1.0 + noise * 2.0) * uNoiseIntensity;
    vec2 pattern = texture2D(uPattern, patternUv).xy;

    // Displacement
    vec2 displacement = texture2D(uNoise, vUv * uDisplacementScale).xy;
    float displacementTransition = abs(abs(clamp(cameraTransition, 0., 1.) * 2. - 1.) - 1.);
    displacementTransition *= uDisplacementIntensity;
    
    // Scenes
    vec2 uv0 = vUv;
    vec2 uv1 = vUv;
    vec2 uv2 = vUv;
    vec2 uv3 = vUv;

    float mapRangeTransitionX0 = mapRange(transition, 0.0, 1.0, 0.0, 1.0);
    float mapRangeTransitionX1 = mapRange(transition, 0.0, 1.0, 1.0, 0.0);
    
    float intensityX0 = uPatternIntensity * mapRangeTransitionX0;
    float intensityX1 = uPatternIntensity * mapRangeTransitionX1;

    uv0.x += mapRangeTransitionX1 * offset * uXAxis;
    uv0.x += (-1.0 + pattern.x * 2.0) * intensityX1 * uXAxis;

    uv1.x -= mapRangeTransitionX0 * offset * uXAxis;
    uv1.x -= (-1.0 + pattern.x * 2.0) * intensityX0 * uXAxis;

    uv0.y -= (-1.0 + displacement.x * 2.0) * displacementTransition * uYAxis;
    uv1.y += (-1.0 + displacement.x * 2.0) * displacementTransition * uYAxis;

    vec4 scene0 = texture2D(uScene0, uv0);
    vec4 scene1 = texture2D(uScene1, uv1);

    float skew = clamp(velocity, -2., 2.) * .1;
    float maskStep = uv2.x + uv2.y * skew;
    float mask = smoothstep(transition, transition + .000001, maskStep);
    
    float leafStep = 1. - uv3.y * 0.8;
    float leaf = smoothstep(leafTransition, leafTransition + .000001, leafStep);
    
    mask = uXAxis == 1. ? mask : uYAxis == -1. ? leaf : clamp(1. - floor(cameraTransition + .5) / 1., 0., 1.);
    
    vec4 color = mix(scene0, scene1, mask);

    gl_FragColor = color;
    
    #include <encodings_fragment>
  }
`,
    u3 = to({
        uScene0: null,
        uScene1: null,
        uAspectRatio: 1,
        uNoise: null,
        uNoiseSpeed: .02,
        uNoiseScale: 1.5,
        uNoiseIntensity: .1,
        uPattern: null,
        uPatternScale: 2.5,
        uPatternStretch: .8,
        uPatternIntensity: .2,
        uDisplacementScale: 2,
        uDisplacementIntensity: .2,
        uCameraTransition: 0,
        uCameraOffsetTransition: 0,
        uLeafTransition: 0,
        uTransition: 0,
        uVelocity: 0,
        uOpacity: 1,
        uOffset: .3,
        uXAxis: 1,
        uYAxis: 0,
        uTime: 0
    }, l3, c3);
Ur({
    TransitionShaderMaterial: u3
});
const f3 = u.forwardRef((t, e) => {
        const n = rn("noise"),
            r = rn("pattern"),
            i = u.useRef(null),
            o = wr([i, e]);
        return u.useLayoutEffect(() => {
            const s = i.current.material;
            s.uniforms.uDisplacementScale.value = window.innerWidth < 768 ? 1 : 2, s.uniforms.uDisplacementIntensity.value = window.innerWidth < 768 ? .1 : .2
        }, []), kn(({
            clock: s,
            size: a
        }) => {
            const l = i.current.material;
            l.uniforms.uTime.value = s.getElapsedTime(), l.uniforms.uAspectRatio.value = a.width / a.height
        }), bt("Transition"), v.jsxs("mesh", {
            ref: o,
            frustumCulled: !1,
            children: [v.jsx("planeGeometry", {
                args: [2, 2]
            }), v.jsx("transitionShaderMaterial", {
                uNoise: n,
                "uNoise-wrapS": Nn,
                "uNoise-wrapT": Nn,
                uPattern: r,
                "uPattern-wrapS": Nn,
                "uPattern-wrapT": Nn,
                ...t
            })]
        })
    }),
    d3 = u.forwardRef((t, e) => {
        const n = Gr(),
            r = u.useRef(null),
            i = wr([r, e]),
            o = u.useMemo(() => t.intensity, [t.intensity]),
            s = u.useMemo(() => t.intensityOffset, [t.intensityOffset]);
        return u.useEffect(() => {
            const a = l => {
                const c = Hf(l.value);
                r.current.intensity = o + s * c
            };
            return n.cameraMotionValue.addEventListener("update", a), () => {
                n.cameraMotionValue.removeEventListener("update", a)
            }
        }, [n, o, s]), u.useEffect(() => {
            const a = Bn.subscribe(l => l.route, l => {
                l.initial && n.needsUnderground() && (r.current.intensity = o + s)
            }, {
                fireImmediately: !0
            });
            return () => {
                a()
            }
        }, [n, o, s]), bt("Bloom"), v.jsx(rv, {
            mipmapBlur: !0,
            ref: i,
            width: md.AUTO_SIZE,
            height: md.AUTO_SIZE,
            kernelSize: iv.MEDIUM,
            ...t
        })
    }),
    p3 = t => {
        const e = u.useRef(null),
            n = Gr();
        return un("Postprocessing", {
            Bloom: at({
                intensity: {
                    value: t.intensity + (n.needsUnderground() ? t.intensityOffset : 0),
                    min: 0,
                    max: 10,
                    onChange: r => e.current.intensity = r
                },
                luminanceThreshold: {
                    value: t.luminanceThreshold,
                    min: 0,
                    max: 1,
                    onChange: r => e.current.luminanceMaterial.threshold = r
                },
                luminanceSmoothing: {
                    value: t.luminanceSmoothing,
                    min: 0,
                    max: 1,
                    onChange: r => e.current.luminanceMaterial.smoothing = r
                },
                enable: {
                    value: !0,
                    onChange: r => e.current.blendMode.blendFunction = r ? er.ADD : er.SKIP
                }
            })
        }), v.jsx(d3, {
            ref: e,
            ...t
        })
    };
class Ph extends xr {
    constructor(n = 0, r = 0) {
        super(n, r);
        ke(this, "isInit", !1)
    }
    setInit(n) {
        this.isInit = n
    }
}
const Gc = 2,
    Tn = {
        min: [0, 0],
        max: [0, 0]
    },
    Wg = t => {
        const e = t.length / Gc;
        Tn.min[0] = t[0], Tn.min[1] = t[1], Tn.max[0] = t[0], Tn.max[1] = t[1];
        for (let n = 0; n < e; n++) {
            const r = t[n * Gc + 0],
                i = t[n * Gc + 1];
            Tn.min[0] = Math.min(r, Tn.min[0]), Tn.min[1] = Math.min(i, Tn.min[1]), Tn.max[0] = Math.max(r, Tn.max[0]), Tn.max[1] = Math.max(i, Tn.max[1])
        }
    },
    h3 = (t, e) => {
        Wg(t), e.min.set(Tn.min[0], Tn.min[1], 0), e.max.set(Tn.max[0], Tn.max[1], 0)
    },
    m3 = (t, e) => {
        Wg(t);
        const n = Tn.min[0],
            r = Tn.min[1],
            i = Tn.max[0],
            o = Tn.max[1],
            s = i - n,
            a = o - r,
            l = Math.sqrt(s * s + a * a);
        e.center.set(n + s / 2, r + a / 2, 0), e.radius = l / 2
    };
class g3 extends jh {
    constructor() {
        super(), this.setAttribute("position", new Kc(new Float32Array([-1, -1, 3, -1, -1, 3]), 2)), this.setAttribute("uv", new Kc(new Float32Array([0, 0, 2, 0, 0, 2]), 2))
    }
    computeBoundingSphere() {
        this.boundingSphere === null && (this.boundingSphere = new zv);
        const e = this.attributes.position.array,
            n = this.attributes.position.itemSize;
        if (!e || !n || e.length < 2) {
            this.boundingSphere.radius = 0, this.boundingSphere.center.set(0, 0, 0);
            return
        }
        m3(e, this.boundingSphere), isNaN(this.boundingSphere.radius) && console.error(`
        THREE.BufferGeometry.computeBoundingSphere(): 
        Computed radius is NaN. The "position" attribute is likely to have NaN values.
      `)
    }
    computeBoundingBox() {
        this.boundingBox === null && (this.boundingBox = new ql);
        const e = this.boundingBox,
            n = this.attributes.position.array,
            r = this.attributes.position.itemSize;
        if (!n || !r || n.length < 2) {
            e.makeEmpty();
            return
        }
        h3(n, e)
    }
}
const Bi = `
  precision highp float;
  attribute vec2 position;
  attribute vec2 uv;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;
  uniform vec2 texelSize;
  void main () {
    vUv = uv;
    vL = vUv - vec2(texelSize.x, 0.0);
    vR = vUv + vec2(texelSize.x, 0.0);
    vT = vUv + vec2(0.0, texelSize.y);
    vB = vUv - vec2(0.0, texelSize.y);
    gl_Position = vec4(position, 0, 1);
  }
`,
    v3 = `
  precision mediump float;
  precision mediump sampler2D;
  varying highp vec2 vUv;
  uniform sampler2D uTexture;
  uniform float value;
  void main () {
    gl_FragColor = value * texture2D(uTexture, vUv);
  }
`,
    y3 = `
  precision highp float;
  precision highp sampler2D;
  varying vec2 vUv;
  uniform sampler2D uTarget;
  uniform float aspectRatio;
  uniform vec3 color;
  uniform vec2 point;
  uniform float radius;
  void main () {
    vec2 p = vUv - point.xy;
    p.x *= aspectRatio;
    vec3 splat = exp(-dot(p, p) / radius) * color;
    vec3 base = texture2D(uTarget, vUv).xyz;
    gl_FragColor = vec4(base + splat, 1.0);
  }
`,
    x3 = `
  precision highp float;
  precision highp sampler2D;
  varying vec2 vUv;
  uniform sampler2D uVelocity;
  uniform sampler2D uSource;
  uniform vec2 texelSize;
  uniform vec2 dyeTexelSize;
  uniform float dt;
  uniform float dissipation;
  vec4 bilerp (sampler2D sam, vec2 uv, vec2 tsize) {
    vec2 st = uv / tsize - 0.5;
    vec2 iuv = floor(st);
    vec2 fuv = fract(st);
    vec4 a = texture2D(sam, (iuv + vec2(0.5, 0.5)) * tsize);
    vec4 b = texture2D(sam, (iuv + vec2(1.5, 0.5)) * tsize);
    vec4 c = texture2D(sam, (iuv + vec2(0.5, 1.5)) * tsize);
    vec4 d = texture2D(sam, (iuv + vec2(1.5, 1.5)) * tsize);
    return mix(mix(a, b, fuv.x), mix(c, d, fuv.x), fuv.y);
  }
  void main () {
    vec2 coord = vUv - dt * bilerp(uVelocity, vUv, texelSize).xy * texelSize;
    gl_FragColor = dissipation * bilerp(uSource, coord, dyeTexelSize);
    gl_FragColor.a = 1.0;
  }
`,
    b3 = `
  precision highp float;
  precision highp sampler2D;
  varying vec2 vUv;
  uniform sampler2D uVelocity;
  uniform sampler2D uSource;
  uniform vec2 texelSize;
  uniform float dt;
  uniform float dissipation;
  void main () {
    vec2 coord = vUv - dt * texture2D(uVelocity, vUv).xy * texelSize;
    gl_FragColor = dissipation * texture2D(uSource, coord);
    gl_FragColor.a = 1.0;
  }
`,
    w3 = `
  precision mediump float;
  precision mediump sampler2D;
  varying highp vec2 vUv;
  varying highp vec2 vL;
  varying highp vec2 vR;
  varying highp vec2 vT;
  varying highp vec2 vB;
  uniform sampler2D uVelocity;
  void main () {
    float L = texture2D(uVelocity, vL).x;
    float R = texture2D(uVelocity, vR).x;
    float T = texture2D(uVelocity, vT).y;
    float B = texture2D(uVelocity, vB).y;
    vec2 C = texture2D(uVelocity, vUv).xy;
    if (vL.x < 0.0) { L = -C.x; }
    if (vR.x > 1.0) { R = -C.x; }
    if (vT.y > 1.0) { T = -C.y; }
    if (vB.y < 0.0) { B = -C.y; }
    float div = 0.5 * (R - L + T - B);
    gl_FragColor = vec4(div, 0.0, 0.0, 1.0);
  }
`,
    _3 = `
  precision mediump float;
  precision mediump sampler2D;
  varying highp vec2 vUv;
  varying highp vec2 vL;
  varying highp vec2 vR;
  varying highp vec2 vT;
  varying highp vec2 vB;
  uniform sampler2D uVelocity;
  void main () {
    float L = texture2D(uVelocity, vL).y;
    float R = texture2D(uVelocity, vR).y;
    float T = texture2D(uVelocity, vT).x;
    float B = texture2D(uVelocity, vB).x;
    float vorticity = R - L - T + B;
    gl_FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);
  }
`,
    D3 = `
  precision highp float;
  precision highp sampler2D;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;
  uniform sampler2D uVelocity;
  uniform sampler2D uCurl;
  uniform float curl;
  uniform float dt;
  void main () {
    float L = texture2D(uCurl, vL).x;
    float R = texture2D(uCurl, vR).x;
    float T = texture2D(uCurl, vT).x;
    float B = texture2D(uCurl, vB).x;
    float C = texture2D(uCurl, vUv).x;
    vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));
    force /= length(force) + 0.0001;
    force *= curl * C;
    force.y *= -1.0;
    vec2 vel = texture2D(uVelocity, vUv).xy;
    gl_FragColor = vec4(vel + force * dt, 0.0, 1.0);
  }
`,
    S3 = `
  precision mediump float;
  precision mediump sampler2D;
  varying highp vec2 vUv;
  varying highp vec2 vL;
  varying highp vec2 vR;
  varying highp vec2 vT;
  varying highp vec2 vB;
  uniform sampler2D uPressure;
  uniform sampler2D uDivergence;
  void main () {
    float L = texture2D(uPressure, vL).x;
    float R = texture2D(uPressure, vR).x;
    float T = texture2D(uPressure, vT).x;
    float B = texture2D(uPressure, vB).x;
    float C = texture2D(uPressure, vUv).x;
    float divergence = texture2D(uDivergence, vUv).x;
    float pressure = (L + R + B + T - divergence) * 0.25;
    gl_FragColor = vec4(pressure, 0.0, 0.0, 1.0);
  }
`,
    C3 = `
  precision mediump float;
  precision mediump sampler2D;
  varying highp vec2 vUv;
  varying highp vec2 vL;
  varying highp vec2 vR;
  varying highp vec2 vT;
  varying highp vec2 vB;
  uniform sampler2D uPressure;
  uniform sampler2D uVelocity;
  void main () {
    float L = texture2D(uPressure, vL).x;
    float R = texture2D(uPressure, vR).x;
    float T = texture2D(uPressure, vT).x;
    float B = texture2D(uPressure, vB).x;
    vec2 velocity = texture2D(uVelocity, vUv).xy;
    velocity.xy -= vec2(R - L, T - B);
    gl_FragColor = vec4(velocity, 0.0, 1.0);
  }
`;
var Xc;
let Vg = (Xc = class {
    constructor(e) {
        ke(this, "_renderer");
        ke(this, "_simRes");
        ke(this, "_dyeRes");
        ke(this, "_density");
        ke(this, "_velocity");
        ke(this, "_pressure");
        ke(this, "_divergence");
        ke(this, "_curl");
        ke(this, "_clearProgram");
        ke(this, "_splatProgram");
        ke(this, "_advectionProgram");
        ke(this, "_divergenceProgram");
        ke(this, "_curlProgram");
        ke(this, "_vorticityProgram");
        ke(this, "_pressureProgram");
        ke(this, "_gradienSubtractProgram");
        ke(this, "iterations", 5);
        ke(this, "densityDissipation", .97);
        ke(this, "velocityDissipation", .98);
        ke(this, "pressureDissipation", .8);
        ke(this, "curlStrength", 30);
        ke(this, "radius", .25);
        ke(this, "_splats", []);
        ke(this, "_pointer", new Ph);
        ke(this, "_lastPointer", new Ph);
        ke(this, "_viewport", new xr);
        ke(this, "_triangle", new g3);
        ke(this, "_camera", new Iv(-1, 1, 1, -1, 0, 1));
        ke(this, "_updateMouse", this.updateMouse.bind(this));
        ke(this, "_updateSize", this.updateSize.bind(this));
        this._renderer = e, this._simRes = 128, this._dyeRes = 512;
        const n = {
                value: new xr().setScalar(1 / this._simRes)
            },
            r = e.extensions.get(`OES_texture_${e.capabilities.isWebGL2&&gr.os!=="ios"?"":"half_"}float_linear`),
            i = e.capabilities.isWebGL2 && gr.os !== "ios" ? df : e.extensions.get("OES_texture_half_float").HALF_FLOAT_OES,
            o = r ? Ti : Ui;
        this._density = this.createDoubleFBO(this._dyeRes, this._dyeRes, {
            type: i,
            format: Zc,
            minFilter: o,
            depthBuffer: !1
        }), this._velocity = this.createDoubleFBO(this._simRes, this._simRes, {
            type: i,
            format: Bv,
            minFilter: o,
            depthBuffer: !1
        }), this._pressure = this.createDoubleFBO(this._simRes, this._simRes, {
            type: i,
            format: bc,
            minFilter: Ui,
            depthBuffer: !1
        }), this._divergence = new Di(this._simRes, this._simRes, {
            type: i,
            format: bc,
            minFilter: Ui,
            generateMipmaps: !1,
            depthBuffer: !1
        }), this._curl = new Di(this._simRes, this._simRes, {
            type: i,
            format: bc,
            minFilter: Ui,
            generateMipmaps: !1,
            depthBuffer: !1
        }), this._clearProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: v3,
            uniforms: {
                texelSize: n,
                uTexture: {
                    value: null
                },
                value: {
                    value: this.pressureDissipation
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._splatProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: y3,
            uniforms: {
                texelSize: n,
                uTarget: {
                    value: null
                },
                aspectRatio: {
                    value: 1
                },
                color: {
                    value: new dt
                },
                point: {
                    value: new xr
                },
                radius: {
                    value: 1
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._advectionProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: r ? b3 : x3,
            uniforms: {
                texelSize: n,
                dyeTexelSize: {
                    value: new xr(1 / this._dyeRes, 1 / this._dyeRes)
                },
                uVelocity: {
                    value: null
                },
                uSource: {
                    value: null
                },
                dt: {
                    value: .016
                },
                dissipation: {
                    value: 1
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._divergenceProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: w3,
            uniforms: {
                texelSize: n,
                uVelocity: {
                    value: null
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._curlProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: _3,
            uniforms: {
                texelSize: n,
                uVelocity: {
                    value: null
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._vorticityProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: D3,
            uniforms: {
                texelSize: n,
                uVelocity: {
                    value: null
                },
                uCurl: {
                    value: null
                },
                curl: {
                    value: this.curlStrength
                },
                dt: {
                    value: .016
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._pressureProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: S3,
            uniforms: {
                texelSize: n,
                uPressure: {
                    value: null
                },
                uDivergence: {
                    value: null
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), this._gradienSubtractProgram = new ai(this._triangle, new li({
            vertexShader: Bi,
            fragmentShader: C3,
            uniforms: {
                texelSize: n,
                uPressure: {
                    value: null
                },
                uVelocity: {
                    value: null
                }
            },
            depthTest: !1,
            depthWrite: !1
        })), "ontouchstart" in window ? (window.addEventListener("touchstart", this._updateMouse, !1), window.addEventListener("touchmove", this._updateMouse, !1)) : window.addEventListener("mousemove", this._updateMouse, !1), window.addEventListener("resize", this._updateSize, !1), this._updateSize()
    }
    updateSize() {
        this._viewport.set(window.innerWidth, window.innerHeight)
    }
    updateMouse(e) {
        window.TouchEvent && e instanceof TouchEvent && e.changedTouches && e.changedTouches.length && (this._pointer.setX(e.changedTouches[0].pageX), this._pointer.setY(e.changedTouches[0].pageY)), e instanceof MouseEvent && (this._pointer.setX(e.pageX), this._pointer.setY(e.pageY)), this._lastPointer.isInit || (this._lastPointer.setInit(!0), this._lastPointer.set(this._pointer.x, this._pointer.y));
        const n = this._pointer.x - this._lastPointer.x,
            r = this._pointer.y - this._lastPointer.y;
        this._lastPointer.set(this._pointer.x, this._pointer.y), (Math.abs(n) || Math.abs(r)) && this._splats.push({
            x: this._pointer.x / this._viewport.x,
            y: 1 - this._pointer.y / this._viewport.y,
            dx: n * 5,
            dy: r * -5
        })
    }
    splat({
        x: e,
        y: n,
        dx: r,
        dy: i
    }) {
        this._splatProgram.material.uniforms.uTarget.value = this._velocity.read.texture, this._splatProgram.material.uniforms.aspectRatio.value = this._viewport.x / this._viewport.y, this._splatProgram.material.uniforms.point.value.set(e, n), this._splatProgram.material.uniforms.color.value.set(r, i, 1), this._splatProgram.material.uniforms.radius.value = this.radius / 100, this._renderer.setRenderTarget(this._velocity.write), this._renderer.render(this._splatProgram, this._camera), this._renderer.setRenderTarget(null), this._velocity.swap(), this._splatProgram.material.uniforms.uTarget.value = this._density.read.texture, this._renderer.setRenderTarget(this._density.write), this._renderer.render(this._splatProgram, this._camera), this._renderer.setRenderTarget(null), this._density.swap()
    }
    update(e) {
        const n = e || this._renderer;
        n.autoClear = !1;
        for (let r = this._splats.length - 1; r >= 0; r--) this.splat(this._splats.splice(r, 1)[0]);
        this._curlProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, n.setRenderTarget(this._curl), n.render(this._curlProgram, this._camera), n.setRenderTarget(null), this._vorticityProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, this._vorticityProgram.material.uniforms.uCurl.value = this._curl.texture, n.setRenderTarget(this._velocity.write), n.render(this._vorticityProgram, this._camera), n.setRenderTarget(null), this._velocity.swap(), this._divergenceProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, n.setRenderTarget(this._divergence), n.render(this._divergenceProgram, this._camera), n.setRenderTarget(null), this._clearProgram.material.uniforms.uTexture.value = this._pressure.read.texture, this._clearProgram.material.uniforms.value.value = this.pressureDissipation, n.setRenderTarget(this._pressure.write), n.render(this._clearProgram, this._camera), n.setRenderTarget(null), this._pressure.swap(), this._pressureProgram.material.uniforms.uDivergence.value = this._divergence.texture;
        for (let r = 0; r < this.iterations; r++) this._pressureProgram.material.uniforms.uPressure.value = this._pressure.read.texture, n.setRenderTarget(this._pressure.write), n.render(this._pressureProgram, this._camera), n.setRenderTarget(null), this._pressure.swap();
        this._gradienSubtractProgram.material.uniforms.uPressure.value = this._pressure.read.texture, this._gradienSubtractProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, n.setRenderTarget(this._velocity.write), n.render(this._gradienSubtractProgram, this._camera), n.setRenderTarget(null), this._velocity.swap(), this._advectionProgram.material.uniforms.dyeTexelSize.value.set(1 / this._simRes), this._advectionProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, this._advectionProgram.material.uniforms.uSource.value = this._velocity.read.texture, this._advectionProgram.material.uniforms.dissipation.value = this.velocityDissipation, n.setRenderTarget(this._velocity.write), n.render(this._advectionProgram, this._camera), n.setRenderTarget(null), this._velocity.swap(), this._advectionProgram.material.uniforms.dyeTexelSize.value.set(1 / this._dyeRes), this._advectionProgram.material.uniforms.uVelocity.value = this._velocity.read.texture, this._advectionProgram.material.uniforms.uSource.value = this._density.read.texture, this._advectionProgram.material.uniforms.dissipation.value = this.densityDissipation, n.setRenderTarget(this._density.write), n.render(this._advectionProgram, this._camera), n.setRenderTarget(null), this._density.swap(), this._renderer.autoClear = !0
    }
    createDoubleFBO(e, n, {
        minFilter: r = Ti,
        magFilter: i = Ti,
        ...o
    }) {
        const s = {
                minFilter: r,
                magFilter: i,
                generateMipmaps: !1,
                ...o
            },
            a = {
                read: new Di(e, n, s),
                write: new Di(e, n, s),
                swap: () => {
                    const l = a.read;
                    a.read = a.write, a.write = l
                }
            };
        return a
    }
    get densityTexure() {
        return this._density.read.texture
    }
    static getInstance(e) {
        return this._instance || (this._instance = new this(e))
    }
}, ke(Xc, "_instance"), Xc);
const E3 = `
  uniform sampler2D tDiffuse;
  uniform sampler2D tFluid;
  uniform int debug;

  vec4 getRGB(sampler2D tDiffuse, vec2 uv, float angle, float amount) {
    vec2 offset = vec2(cos(angle), sin(angle)) * amount;
    vec4 r = texture2D(tDiffuse, uv + offset);
    vec4 g = texture2D(tDiffuse, uv);
    vec4 b = texture2D(tDiffuse, uv - offset);
    return vec4(r.r, g.g, b.b, g.a);
  }

  vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
  }

  vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
  }

  void mainUv(inout vec2 uv) {
    vec3 fluid = texture2D(tFluid, uv).rgb;
    uv -= fluid.rg * 0.0002;
  }

  void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
    vec3 fluid = texture2D(tFluid, vUv).rgb;
    if (debug > 0) {
      outputColor = vec4(fluid * 0.1 + 0.5, 1);
    } else {
      vec4 diffuse = texture2D(tDiffuse, uv);
      vec4 aberration = getRGB(tDiffuse, uv, PI / 4., .005);
      
      vec3 HSVaberration = rgb2hsv(aberration.rgb);
      float saturationFactor = 1.2;
      HSVaberration.y *= saturationFactor;

      vec4 RGBaberration = vec4(hsv2rgb(HSVaberration), aberration.a);
      vec4 color = mix(diffuse, RGBaberration, fluid.b);
      outputColor = inputColor; // color;
    }
  }
`;
class T3 extends Ah {
    constructor(n, {
        iterations: r,
        densityDissipation: i,
        velocityDissipation: o,
        pressureDissipation: s,
        curlStrength: a,
        radius: l,
        debug: c
    }) {
        super("FluidEffect", E3, {
            uniforms: new Map([
                ["tDiffuse", new al(null)],
                ["tFluid", new al(null)],
                ["debug", new al(~~c)]
            ])
        });
        ke(this, "_simulation");
        ke(this, "_debug", !1);
        this._simulation = Vg.getInstance(n), this.iterations = r, this.densityDissipation = i, this.velocityDissipation = o, this.pressureDissipation = s, this.curlStrength = a, this.radius = l, this.debug = c
    }
    update(n, r) {
        this._simulation.update(n), this.uniforms.get("tDiffuse").value = r.texture, this.uniforms.get("tFluid").value = this._simulation.densityTexure, this.uniforms.get("debug").value = ~~this._debug
    }
    set iterations(n) {
        this._simulation.iterations = n
    }
    set densityDissipation(n) {
        this._simulation.densityDissipation = n
    }
    set velocityDissipation(n) {
        this._simulation.velocityDissipation = n
    }
    set pressureDissipation(n) {
        this._simulation.pressureDissipation = n
    }
    set curlStrength(n) {
        this._simulation.curlStrength = n
    }
    set radius(n) {
        this._simulation.radius = n
    }
    set debug(n) {
        this._debug = n
    }
}
const P3 = u.forwardRef((t, e) => {
        const {
            gl: n
        } = hr(), r = u.useMemo(() => new T3(n, t), [n, t]);
        return v.jsx("primitive", {
            ref: e,
            object: r,
            dispose: null
        })
    }),
    R3 = u.forwardRef((t, e) => (bt("Fluid"), v.jsx(P3, {
        ref: e,
        ...t
    }))),
    M3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            Fluid: at({
                densityDissipation: {
                    value: t.densityDissipation,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.densityDissipation = n
                },
                velocityDissipation: {
                    value: t.velocityDissipation,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.velocityDissipation = n
                },
                pressureDissipation: {
                    value: t.pressureDissipation,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.pressureDissipation = n
                },
                curlStrength: {
                    value: t.curlStrength,
                    min: 0,
                    max: 50,
                    onChange: n => e.current.curlStrength = n
                },
                radius: {
                    value: t.radius,
                    min: 0,
                    max: 5,
                    onChange: n => e.current.radius = n * .1
                },
                debug: {
                    value: t.debug,
                    onChange: n => e.current.debug = n
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx(R3, {
            ref: e,
            ...t
        })
    },
    $3 = u.forwardRef((t, e) => {
        const n = rn(t.texture);
        return bt("LUT"), v.jsx(ov, {
            ref: e,
            lut: n
        })
    }),
    A3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            LUT: at({
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx($3, {
            ref: e,
            ...t
        })
    },
    F3 = u.forwardRef((t, e) => (bt("Noise"), v.jsx(sv, {
        ref: e,
        ...t
    }))),
    k3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            Noise: at({
                opacity: {
                    value: t.opacity,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.blendMode.opacity.value = n
                },
                premultiply: {
                    value: t.premultiply,
                    onChange: n => e.current.premultiply = n
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.ADD : er.SKIP
                }
            })
        }), v.jsx(F3, {
            ref: e,
            ...t
        })
    },
    O3 = `
  uniform float intensity;

  vec4 splitRGB(sampler2D tDiffuse, vec2 uv, float angle, float amount) {
    vec2 offset = vec2(cos(angle), sin(angle)) * amount;
    vec4 r = texture2D(tDiffuse, uv + offset);
    vec4 g = texture2D(tDiffuse, uv);
    vec4 b = texture2D(tDiffuse, uv - offset);
    return vec4(r.r, g.g, b.b, g.a);
  }

  void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
    outputColor = splitRGB(inputBuffer, uv, PI / 4., intensity);
  }
`;
class j3 extends Ah {
    constructor({
        intensity: n = 1
    } = {}) {
        super("RGBSplitEffect", O3, {
            uniforms: new Map([
                ["intensity", new al(n)]
            ])
        });
        ke(this, "intensity");
        this.intensity = n
    }
    update() {
        this.uniforms.get("intensity").value = this.intensity
    }
}
const Ug = .01,
    L3 = u.forwardRef((t, e) => {
        const n = u.useMemo(() => new j3(t), [t]);
        return v.jsx("primitive", {
            ref: e,
            object: n,
            dispose: null
        })
    }),
    N3 = u.forwardRef((t, e) => (bt("RGBSplit"), v.jsx(L3, {
        ref: e,
        intensity: t.intensity * Ug
    }))),
    z3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            RGBSplit: at({
                intensity: {
                    value: t.intensity,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.intensity = n * Ug
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx(N3, {
            ref: e,
            ...t
        })
    },
    I3 = u.forwardRef((t, e) => (bt("Vignette"), v.jsx(av, {
        ref: e,
        ...t
    }))),
    B3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            Vignette: at({
                offset: {
                    value: t.offset,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.offset = n
                },
                darkness: {
                    value: t.darkness,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.darkness = n
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx(I3, {
            ref: e,
            ...t
        })
    },
    W3 = u.forwardRef((t, e) => (bt("ToneMapping"), v.jsx(lv, {
        ref: e,
        resolution: 512,
        ...t
    }))),
    V3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            ToneMapping: at({
                middleGrey: {
                    value: t.middleGrey,
                    min: 0,
                    max: 1,
                    onChange: n => e.current.middleGrey = n
                },
                adaptive: {
                    value: t.adaptive,
                    onChange: n => e.current.adaptive = n
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx(W3, {
            ref: e,
            ...t
        })
    },
    U3 = u.forwardRef((t, e) => {
        u.useMemo(() => he.registerPlugin(bs), []);
        const n = u.useRef(null),
            r = wr([n, e]);
        return Vf(i => {
            n.current.hue = i.effects.colorCorrection.hue
        }), bt("ColorCorrection"), v.jsx(cv, {
            ref: r,
            ...t
        })
    }),
    H3 = t => {
        const e = u.useRef(null);
        return un("Postprocessing", {
            ColorCorrection: at({
                hue: {
                    value: t.hue,
                    min: -Math.PI,
                    max: Math.PI,
                    onChange: n => e.current.hue = n
                },
                saturation: {
                    value: t.saturation,
                    min: -1,
                    max: 1,
                    onChange: n => e.current.saturation = n
                },
                enable: {
                    value: !0,
                    onChange: n => e.current.blendMode.blendFunction = n ? er.NORMAL : er.SKIP
                }
            })
        }), v.jsx(U3, {
            ref: e,
            ...t
        })
    },
    G3 = u.forwardRef(({
        bloom: t,
        colorCorrection: e,
        fluid: n,
        lut: r,
        noise: i,
        rgbSplit: o,
        toneMapping: s,
        vignette: a
    }, l) => {
        const c = u.useRef(null),
            {
                getSamples: d,
                needsPosprocessing: f
            } = Da();
        return u.useImperativeHandle(l, () => ({
            render: h => {
                const p = c.current.passes[0];
                p.scene = h
            }
        })), bt("Effects"), v.jsxs(uv, {
            ref: c,
            multisampling: d(),
            disableNormalPass: !0,
            children: [v.jsx(z3, { ...o
            }), f() ? v.jsx(M3, { ...n
            }) : v.jsx(u.Fragment, {}), v.jsx(p3, { ...t
            }), v.jsx(B3, { ...a
            }), v.jsx(V3, { ...s
            }), v.jsx(H3, { ...e
            }), v.jsx(k3, { ...i
            }), f() ? v.jsx(A3, { ...r
            }) : v.jsx(u.Fragment, {})]
        })
    }),
    Y3 = u.forwardRef((t, e) => {
        const n = u.useRef(null),
            r = wr([n, e]);
        return Wf(i => {
            n.current.near = t.near * i.fog.near, n.current.far = t.far * i.fog.far
        }), v.jsx("fog", {
            ref: r,
            attach: "fog",
            ...t
        })
    }),
    X3 = ({
        uuid: t,
        color: e,
        near: n,
        far: r,
        ...i
    }) => {
        const o = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Fog: at({
                    color: {
                        value: e
                    },
                    near: {
                        value: n,
                        min: 0,
                        max: 10
                    },
                    far: {
                        value: r,
                        min: 0,
                        max: 10
                    }
                })
            })
        });
        return v.jsx(Y3, {
            uuid: t,
            ...o,
            ...i
        })
    },
    Hg = u.forwardRef(({
        mixBlur: t = 0,
        mixStrength: e = 1,
        resolution: n = 256,
        blur: r = [0, 0],
        minDepthThreshold: i = .9,
        maxDepthThreshold: o = 1,
        depthScale: s = 0,
        depthToBlurRatioBias: a = .25,
        mirror: l = 0,
        distortion: c = 1,
        mixContrast: d = 1,
        distortionMap: f,
        reflectorOffset: h = 0,
        ...p
    }, m) => {
        u.useMemo(() => Ur({
            MeshReflectorMaterialImpl: fv
        }), []);
        const g = hr(({
                gl: ge
            }) => ge),
            y = hr(({
                camera: ge
            }) => ge),
            x = hr(({
                scene: ge
            }) => ge);
        r = Array.isArray(r) ? r : [r, r];
        const w = r[0] + r[1] > 0,
            M = u.useRef(null),
            [T] = u.useState(() => new Wv),
            [O] = u.useState(() => new dt),
            [R] = u.useState(() => new dt),
            [P] = u.useState(() => new dt),
            [B] = u.useState(() => new qc),
            [te] = u.useState(() => new dt(0, 0, -1)),
            [W] = u.useState(() => new yl),
            [ee] = u.useState(() => new dt),
            [V] = u.useState(() => new dt),
            [I] = u.useState(() => new yl),
            [X] = u.useState(() => new qc),
            [q] = u.useState(() => new Vv),
            Z = u.useCallback(() => {
                var Xe;
                const ge = M.current.parent || ((Xe = M.current) == null ? void 0 : Xe.__r3f.parent);
                if (!ge || (R.setFromMatrixPosition(ge.matrixWorld), P.setFromMatrixPosition(y.matrixWorld), B.extractRotation(ge.matrixWorld), O.set(0, 0, 1), O.applyMatrix4(B), R.addScaledVector(O, h), ee.subVectors(R, P), ee.dot(O) > 0)) return;
                ee.reflect(O).negate(), ee.add(R), B.extractRotation(y.matrixWorld), te.set(0, 0, -1), te.applyMatrix4(B), te.add(P), V.subVectors(R, te), V.reflect(O).negate(), V.add(R), q.position.copy(ee), q.up.set(0, 1, 0), q.up.applyMatrix4(B), q.up.reflect(O), q.lookAt(V), q.far = y.far, q.updateMatrixWorld(), q.projectionMatrix.copy(y.projectionMatrix), X.set(.5, 0, 0, .5, 0, .5, 0, .5, 0, 0, .5, .5, 0, 0, 0, 1), X.multiply(q.projectionMatrix), X.multiply(q.matrixWorldInverse), X.multiply(ge.matrixWorld), T.setFromNormalAndCoplanarPoint(O, R), T.applyMatrix4(q.matrixWorldInverse), W.set(T.normal.x, T.normal.y, T.normal.z, T.constant);
                const $e = q.projectionMatrix;
                I.x = (Math.sign(W.x) + $e.elements[8]) / $e.elements[0], I.y = (Math.sign(W.y) + $e.elements[9]) / $e.elements[5], I.z = -1, I.w = (1 + $e.elements[10]) / $e.elements[14], W.multiplyScalar(2 / W.dot(I)), $e.elements[2] = W.x, $e.elements[6] = W.y, $e.elements[10] = W.z + 1, $e.elements[14] = W.w
            }, [y, h]),
            [le, Se, Me, z] = u.useMemo(() => {
                const ge = {
                        minFilter: Ti,
                        magFilter: Ti,
                        type: df
                    },
                    $e = new Di(n, n, ge);
                $e.depthBuffer = !0, $e.depthTexture = new Uv(n, n), $e.depthTexture.format = Hv, $e.depthTexture.type = Gv;
                const Xe = new Di(n, n, ge),
                    tt = new dv({
                        gl: g,
                        resolution: n,
                        width: r[0],
                        height: r[1],
                        minDepthThreshold: i,
                        maxDepthThreshold: o,
                        depthScale: s,
                        depthToBlurRatioBias: a
                    }),
                    wt = {
                        mirror: l,
                        textureMatrix: X,
                        mixBlur: t,
                        tDiffuse: $e.texture,
                        tDepth: $e.depthTexture,
                        tDiffuseBlur: Xe.texture,
                        hasBlur: w,
                        mixStrength: e,
                        minDepthThreshold: i,
                        maxDepthThreshold: o,
                        depthScale: s,
                        depthToBlurRatioBias: a,
                        distortion: c,
                        distortionMap: f,
                        mixContrast: d,
                        "defines-USE_BLUR": w ? "" : void 0,
                        "defines-USE_DEPTH": s > 0 ? "" : void 0,
                        "defines-USE_DISTORTION": f ? "" : void 0
                    };
                return [$e, Xe, tt, wt]
            }, [g, r, X, n, l, w, t, e, i, o, s, a, c, f, d]);
        return kn(() => {
            var tt;
            const ge = M.current.parent || ((tt = M.current) == null ? void 0 : tt.__r3f.parent);
            if (!ge || !ge.userData.active) return;
            ge.visible = !1;
            const $e = g.xr.enabled,
                Xe = g.shadowMap.autoUpdate;
            Z(), g.xr.enabled = !1, g.shadowMap.autoUpdate = !1, g.setRenderTarget(le), g.state.buffers.depth.setMask(!0), g.autoClear || g.clear(), g.render(x, q), w && Me.render(g, le, Se), g.xr.enabled = $e, g.shadowMap.autoUpdate = Xe, ge.visible = !0, g.setRenderTarget(null)
        }), v.jsx("meshReflectorMaterialImpl", {
            attach: "material",
            ref: wr([M, m]),
            ...z,
            ...p
        }, "key" + z["defines-USE_BLUR"] + z["defines-USE_DEPTH"] + z["defines-USE_DISTORTION"])
    }),
    q3 = u.forwardRef(({
        geometry: t,
        normal: e,
        color: n,
        mirror: r,
        metalness: i,
        repeat: o,
        roughness: s,
        mixContrast: a,
        mixStrength: l,
        normalScale: c
    }, d) => {
        const f = rn(e),
            h = u.useMemo(() => new xr().setScalar(c), [c]),
            p = u.useRef(null),
            m = no(t),
            g = u.useRef(null),
            y = wr([g, d]),
            x = u.useRef(0);
        return kn((w, M) => {
            x.current += M, g.current.userData.active && (p.current.normalMap.offset.x = .2 * Math.cos(x.current * .1), p.current.normalMap.offset.y = .1 * Math.sin(x.current * .2))
        }), bt("Ground"), v.jsxs("mesh", {
            ref: y,
            name: "Reflector",
            position: m.position,
            rotation: [-Math.PI / 2, 0, 0],
            children: [v.jsx("planeGeometry", {
                args: [10, 10]
            }), v.jsx(Hg, {
                ref: p,
                blur: [0, 0],
                color: n,
                mirror: r,
                resolution: 512,
                metalness: i,
                roughness: s,
                mixStrength: l,
                mixContrast: a,
                normalMap: f,
                "normalMap-wrapS": Nn,
                "normalMap-wrapT": Nn,
                "normalMap-repeat": [o, o],
                normalScale: h
            })]
        })
    }),
    K3 = ({
        uuid: t,
        ...e
    }) => {
        const n = u.useRef(null),
            {
                color: r,
                mirror: i,
                metalness: o,
                roughness: s,
                mixStrength: a,
                mixContrast: l,
                normalScale: c,
                repeat: d
            } = e;
        return un("Scenes", {
            [Gt.capitalize(t)]: at({
                Ground: at({
                    color: {
                        value: r,
                        onChange: f => n.current.material.color.set(f)
                    },
                    mirror: {
                        value: i,
                        min: 0,
                        max: 1,
                        onChange: f => n.current.material.mirror = f
                    },
                    metalness: {
                        value: o,
                        min: 0,
                        max: 1,
                        onChange: f => n.current.material.metalness = f
                    },
                    roughness: {
                        value: s,
                        min: 0,
                        max: 1,
                        onChange: f => n.current.material.roughness = f
                    },
                    mixStrength: {
                        value: a,
                        min: 0,
                        max: 100,
                        onChange: f => n.current.material.mixStrength = f
                    },
                    mixContrast: {
                        value: l,
                        min: 0,
                        max: 1,
                        onChange: f => n.current.material.mixContrast = f
                    },
                    normalScale: {
                        value: c,
                        min: 0,
                        max: 1,
                        onChange: f => n.current.material.normalScale.set(f, f)
                    },
                    repeat: {
                        value: d,
                        min: 0,
                        max: 50,
                        step: 1,
                        onChange: f => n.current.material.normalMap.repeat.set(f, f)
                    }
                })
            })
        }), v.jsx(q3, {
            ref: n,
            uuid: t,
            ...e
        })
    },
    Z3 = `
  attribute vec2 delayDuration;
  attribute vec3 startPosition;
  attribute vec3 controlPosition0;
  attribute vec3 controlPosition1;
  attribute vec3 endPosition;
  attribute vec4 axisAngle;
  attribute float size;

  uniform float uReveal;

  varying float vProgress;

  vec4 cubicBezier(vec4 p0, vec4 c0, vec4 c1, vec4 p1, float t) {
    float tn = 1.0 - t;
  
    return tn * tn * tn * p0 + 3.0 * tn * tn * t * c0 + 3.0 * tn * t * t * c1 + t * t * t * p1;
  }
  
  vec3 cubicBezier(vec3 p0, vec3 c0, vec3 c1, vec3 p1, float t) {
    float tn = 1.0 - t;
  
    return tn * tn * tn * p0 + 3.0 * tn * tn * t * c0 + 3.0 * tn * t * t * c1 + t * t * t * p1;
  }
  
  vec2 cubicBezier(vec2 p0, vec2 c0, vec2 c1, vec2 p1, float t) {
    float tn = 1.0 - t;
  
    return tn * tn * tn * p0 + 3.0 * tn * tn * t * c0 + 3.0 * tn * t * t * c1 + t * t * t * p1;
  }

  float easeCubicOut(float t) {
    float f = t - 1.0;
    return f * f * f + 1.0;
  }
  
  float easeCubicOut(float t, float b, float c, float d) {
    return b + easeCubicOut(t / d) * c;
  }

  vec4 quatFromAxisAngle(vec3 axis, float angle) {
    float halfAngle = angle * 0.5;
    return vec4(axis.xyz * sin(halfAngle), cos(halfAngle));
  }

  vec3 rotateVector(vec4 q, vec3 v) {
    return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
  }

  void main () {
    float tDelay = delayDuration.x; 
    float tDuration = delayDuration.y; 
    float tTime = clamp(uReveal - tDelay, 0., tDuration); 
    float tProgress = easeCubicOut(tTime, 0., 1., tDuration);
    float angle = axisAngle.w * tProgress;
    float scl = tProgress * 2.0 - 1.0;

    vec4 quaternion = quatFromAxisAngle(axisAngle.xyz, angle);

    vec4 transformed = vec4(position, 1.);
    transformed.xyz = rotateVector(quaternion, transformed.xyz);

    transformed.xyz += cubicBezier(startPosition, controlPosition0, controlPosition1, endPosition, tProgress);

    vec4 mvPosition = modelViewMatrix * transformed;

    float progress = 1.0 - scl * scl;
    
    gl_Position = projectionMatrix * mvPosition;

    gl_PointSize = size * progress;
    gl_PointSize *= (4.3 / - mvPosition.z);

    vProgress = progress;
  }
`,
    Q3 = `
  uniform sampler2D map;

  varying float vProgress;

  void main () {
    vec4 texel = vec4(texture2D(map, gl_PointCoord));
    vec4 color = texel * vec4(1., 1., 1., 1.);

    gl_FragColor = color * 3.;
    gl_FragColor.a *= vProgress;

    #include <tonemapping_fragment>
    #include <encodings_fragment>
  }
`,
    J3 = to({
        map: null,
        uReveal: 0
    }, Z3, Q3),
    eT = ({
        uuid: t,
        bounds: e
    }) => {
        u.useMemo(() => Ur({
            ParticlesShaderMaterial: J3
        }), []);
        const n = rn("spark"),
            r = u.useMemo(() => tT(e), [e]),
            i = u.useRef(null);
        return Vf((o, s) => {
            s.uuid === t && (i.current.material.uniforms.uReveal.value = o.portal.particles.reveal)
        }), v.jsxs("points", {
            ref: i,
            children: [v.jsxs("bufferGeometry", {
                children: [v.jsx("bufferAttribute", {
                    attach: "attributes-position",
                    args: [r.positions, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-startPosition",
                    args: [r.startPositions, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-controlPosition0",
                    args: [r.controlPositions0, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-controlPosition1",
                    args: [r.controlPositions1, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-endPosition",
                    args: [r.endPositions, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-delayDuration",
                    args: [r.delayDurations, 2]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-axisAngles",
                    args: [r.axisAngles, 4]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-size",
                    args: [r.sizes, 1]
                })]
            }), v.jsx("particlesShaderMaterial", {
                map: n,
                blending: Kl,
                depthTest: !1,
                depthWrite: !1,
                toneMapped: !1
            })]
        })
    },
    tT = t => {
        const e = [],
            n = [],
            r = [],
            i = [],
            o = [],
            s = [],
            a = [],
            l = [],
            c = new dt;
        return Gt.forEach(t, d => {
            const f = new ql;
            f.setFromObject(d);
            const h = f.max.x - f.min.x,
                p = f.max.y - f.min.y,
                m = Math.round(h * p * 150);
            for (let g = m - 1; g >= 0; --g) {
                e.push(0, 0, 0);
                const y = d.position.x + Math.random() * h - h / 2,
                    x = d.position.y + Math.random() * p,
                    w = d.position.z;
                n.push(y, x, w);
                const M = y + He.randFloat(-.2, .2),
                    T = x + He.randFloat(0, 0),
                    O = w + 1;
                r.push(M, T, O);
                const R = y + He.randFloat(-.6, .6),
                    P = x + He.randFloat(-.2, .2),
                    B = w + 0;
                i.push(R, P, B);
                const te = y + He.randFloat(0, 0),
                    W = x + He.randFloat(-.3, .3),
                    ee = w + 1;
                o.push(te, W, ee), l.push(He.randFloat(3, 4)), c.x = 0, c.y = 0, c.z = 0, c.normalize();
                const V = Math.PI * He.randInt(2, 3);
                s.push(c.x, c.y, c.z, V);
                const I = g / (m - 1) * .5,
                    X = He.randFloat(2, 3);
                a.push(I, X)
            }
        }), {
            positions: new Float32Array(e),
            startPositions: new Float32Array(n),
            controlPositions0: new Float32Array(r),
            controlPositions1: new Float32Array(i),
            endPositions: new Float32Array(o),
            delayDurations: new Float32Array(a),
            axisAngles: new Float32Array(s),
            sizes: new Float32Array(l)
        }
    },
    nT = ({
        uuid: t,
        geometry: e,
        color: n,
        emissive: r,
        emissiveIntensity: i,
        intensity: o,
        toneMapped: s
    }) => {
        u.useMemo(() => he.registerPlugin(bs), []);
        const a = no(e),
            l = u.useRef([]),
            c = u.useMemo(() => a instanceof ai ? [a] : a.children, [a]),
            d = u.useRef(null),
            f = u.useMemo(() => {
                const h = new ql;
                h.setFromObject(a);
                const p = h.max.x - h.min.x,
                    m = h.max.y - h.min.y,
                    g = new dt;
                return g.setX(Gt.max([Gt.min(c.map(y => y.position.x)) || 0, 0]) || 0), g.setY(m / 2 + c[0].position.y), {
                    width: p,
                    height: m,
                    position: g
                }
            }, [a, c]);
        return Wf(h => {
            Gt.forEach(l.current, p => {
                p.emissiveIntensity = h.portal.emissiveIntensity, p.emissive.set(h.portal.emissive)
            })
        }), Vf((h, p) => {
            p.uuid === t && Gt.forEach(l.current, m => {
                m.emissiveIntensity = h.portal.emissive
            })
        }), bt("Portal"), v.jsxs("group", {
            children: [v.jsx("rectAreaLight", {
                ref: d,
                color: n,
                intensity: o,
                rotation: [0, -Math.PI, 0],
                ...f
            }), c.map((h, p) => v.jsx("mesh", {
                geometry: h.geometry,
                position: h.position,
                children: v.jsx("meshStandardMaterial", {
                    ref: m => l.current[p] = m,
                    color: n,
                    emissive: r,
                    emissiveIntensity: i,
                    toneMapped: s
                })
            }, `${t}-portal-${p}`)), t !== "uprising" && v.jsx(eT, {
                uuid: t,
                bounds: c
            })]
        })
    },
    rT = ({
        uuid: t,
        color: e,
        emissive: n,
        emissiveIntensity: r,
        intensity: i,
        toneMapped: o,
        ...s
    }) => {
        const a = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Portal: at({
                    color: {
                        value: e
                    },
                    emissive: {
                        value: n
                    },
                    emissiveIntensity: {
                        value: r,
                        min: 0,
                        max: 5
                    },
                    intensity: {
                        value: i,
                        min: 0,
                        max: 10
                    },
                    toneMapped: {
                        value: o
                    }
                })
            })
        });
        return v.jsx(nT, {
            uuid: t,
            ...a,
            ...s
        })
    },
    iT = `
  #include <fog_pars_vertex>

  attribute vec3 translate;
  attribute vec3 rotation;
  attribute float opacity;
  attribute float direction;
  attribute float speed;
  attribute float scale;
  attribute vec3 noise;
  attribute vec3 color;

  uniform float time;

  varying vec2 vUv;
  varying vec3 vColor;
  varying float vSpeed;
  varying float vOpacity;

  mat4 translateMatrix (vec3 v) {
    return mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,1.0,0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(v.x,v.y,v.z,1.0) );
  }

  mat4 rotateMatrix (vec3 v) {
    mat4 rx = mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,cos(v.x),-sin(v.x),0.0), vec4(0.0,sin(v.x),cos(v.x),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 ry = mat4( vec4(cos(v.y),0.0,sin(v.y),0.0), vec4(0.0,1.0,0.0,0.0), vec4(-sin(v.y),0.0,cos(v.y),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 rz = mat4( vec4(cos(v.z),-sin(v.z),0.0,0.0), vec4(sin(v.z),cos(v.z),0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(0.0,0.0,0.0,1.0) );
    return rx * rz * ry;
  }

  mat4 scaleMatrix (vec3 v) {
    return mat4( vec4(v.x,0.0,0.0,0.0), vec4(0.0,v.y,0.0,0.0), vec4(0.0,0.0,v.z,0.0), vec4(0.0,0.0,0.0,1.0) );
  }

  mat4 transformMatrix (vec3 t, vec3 r, vec3 s) {
    mat4 ms = scaleMatrix(s);
    mat4 mt = translateMatrix(t);
    mat4 mr = rotateMatrix(r);
    return mt * mr * ms;
  }

  void main() {
    float s = time * speed * 2.;
    
    vec3 transformPosition = translate + noise;
    vec3 transformRotation = rotation + vec3(0., 0., noise.z + s * direction);
    vec3 transformScale = vec3(scale);

    mat4 transform = transformMatrix(transformPosition, transformRotation, transformScale);

    vec3 transformed = vec4(transform * vec4(position, 1.)).xyz;
    
    #include <project_vertex>
    #include <fog_vertex>

    vUv = uv;
    vSpeed = s;
    vColor = color;
    vOpacity = opacity;
  }
`,
    oT = `
  #include <fog_pars_fragment>

  uniform sampler2D map;
  uniform sampler2D noiseMap;

  uniform float noiseIntensity;

  varying vec2 vUv;
  varying vec3 vColor;
  varying float vSpeed;
  varying float vOpacity;

  void main() {  
    vec2 uv = vUv;
    vec2 nUv = vUv;
    
    nUv.x += cos(vSpeed * .5);
    nUv.y += sin(vSpeed * .5);

    vec2 n = texture2D(noiseMap, nUv * 2.).xy;
    uv += (-1.0 + n * 2.0) * noiseIntensity;

    vec4 texel = texture2D(map, uv);
    vec4 color = vec4(vColor, 1.);

    gl_FragColor = texel * color * vOpacity;

    #include <tonemapping_fragment>
    #include <encodings_fragment>
    #include <fog_fragment>
  }
`,
    sT = to(ha.merge([ns.fog, {
        map: null,
        noiseMap: null,
        time: 0,
        noiseIntensity: 0
    }]), iT, oT, t => {
        t && (t.fog = !0)
    }),
    aT = u.forwardRef(({
        texture: t,
        displacement: e,
        ...n
    }, r) => {
        u.useMemo(() => Ur({
            SmokeShaderMaterial: sT
        }), []);
        const i = rn(t),
            o = rn(e),
            s = u.useRef(null),
            a = wr([s, r]),
            l = u.useRef(null),
            c = u.useMemo(() => cT(n), [n]),
            [d] = u.useState(() => new hf(1, 1, 1, 1)),
            [f] = u.useState(() => Math.random() * 1e3);
        return kn(({
            camera: h,
            clock: p
        }) => {
            s.current.userData.active && (l.current.uniforms.time.value = f + p.getElapsedTime(), s.current.lookAt(h.position))
        }), bt("Smoke"), v.jsx(v.Fragment, {
            children: v.jsxs("mesh", {
                ref: a,
                children: [v.jsxs("instancedBufferGeometry", {
                    instanceCount: n.count,
                    index: d.index,
                    "attributes-uv": d.attributes.uv,
                    "attributes-position": d.attributes.position,
                    children: [v.jsx("instancedBufferAttribute", {
                        attach: "attributes-translate",
                        args: [c.translates, 3]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-rotation",
                        args: [c.rotations, 3]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-opacity",
                        args: [c.opacities, 1]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-direction",
                        args: [c.directions, 1]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-scale",
                        args: [c.scales, 1]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-noise",
                        args: [c.noises, 3]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-scale",
                        args: [c.scales, 1]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-speed",
                        args: [c.speeds, 1]
                    }), v.jsx("instancedBufferAttribute", {
                        attach: "attributes-color",
                        args: [c.colors, 3]
                    })]
                }, n.count), v.jsx("smokeShaderMaterial", {
                    ref: l,
                    map: i,
                    noiseMap: o,
                    "noiseMap-wrapS": Nn,
                    "noiseMap-wrapT": Nn,
                    noiseIntensity: n.noiseIntensity,
                    blending: Kl,
                    depthWrite: !1,
                    vertexColor: !0
                })]
            })
        })
    }),
    lT = ({
        uuid: t,
        count: e,
        color: n,
        opacity: r,
        radius: i,
        scale: o,
        speed: s,
        noise: a,
        noiseIntensity: l,
        offset: c,
        position: d,
        ...f
    }) => {
        const h = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Smoke: at({
                    color: {
                        value: n
                    },
                    count: {
                        value: e,
                        min: 0,
                        max: 500,
                        step: 1
                    },
                    opacity: {
                        value: r,
                        min: 0,
                        max: 1
                    },
                    radius: {
                        value: i,
                        min: 0,
                        max: 5
                    },
                    scale: {
                        value: o,
                        min: 0,
                        max: 5
                    },
                    speed: {
                        value: s,
                        min: 0,
                        max: 1
                    },
                    noise: {
                        value: a,
                        min: 0,
                        max: 1
                    },
                    noiseIntensity: {
                        value: l,
                        min: 0,
                        max: 1
                    },
                    offset: c,
                    position: d
                })
            })
        });
        return v.jsx(aT, {
            uuid: t,
            ...h,
            ...f
        })
    },
    cT = ({
        count: t,
        color: e,
        opacity: n,
        radius: r,
        scale: i,
        speed: o,
        noise: s,
        offset: a,
        position: l
    }) => {
        const c = [],
            d = [],
            f = [],
            h = [],
            p = [],
            m = [],
            g = [],
            y = [],
            x = new ma(e);
        for (let w = t - 1; w >= 0; --w) {
            const M = w % 2,
                T = l.x + (M === 0 ? -a.x * r : a.x * r),
                O = l.y + He.randFloatSpread(a.y),
                R = l.z + He.randFloatSpread(a.z);
            c.push(T, O, R);
            const P = 0,
                B = 0,
                te = He.randFloat(-Math.PI, Math.PI);
            d.push(P, B, te);
            const W = He.randFloatSpread(s),
                ee = He.randFloatSpread(s),
                V = He.randFloatSpread(s);
            p.push(W, ee, V), g.push(o * He.randFloat(1, 2) * .25), m.push(i * He.randFloat(2, 3)), f.push(n * He.randFloat(.5, 1)), h.push(M === 0 ? 1 : -1), y.push(...x.toArray())
        }
        return {
            translates: new Float32Array(c),
            rotations: new Float32Array(d),
            opacities: new Float32Array(f),
            directions: new Float32Array(h),
            noises: new Float32Array(p),
            scales: new Float32Array(m),
            speeds: new Float32Array(g),
            colors: new Float32Array(y)
        }
    },
    uT = `
  #include <fog_pars_vertex>

  attribute vec3 velocity;
  attribute vec3 offset;
  attribute vec2 params;
  attribute vec3 color;
  attribute vec2 wiggle;
  attribute float radius;

  varying vec4 vColor;
  varying vec2 vUv;

  mat4 translateMatrix (vec3 v) {
    return mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,1.0,0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(v.x,v.y,v.z,1.0) );
  }

  mat4 scaleMatrix (vec3 v) {
    return mat4( vec4(v.x,0.0,0.0,0.0), vec4(0.0,v.y,0.0,0.0), vec4(0.0,0.0,v.z,0.0), vec4(0.0,0.0,0.0,1.0) );
  }

  mat4 rotateMatrix (vec3 v) {
    mat4 rx = mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,cos(v.x),-sin(v.x),0.0), vec4(0.0,sin(v.x),cos(v.x),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 ry = mat4( vec4(cos(v.y),0.0,sin(v.y),0.0), vec4(0.0,1.0,0.0,0.0), vec4(-sin(v.y),0.0,cos(v.y),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 rz = mat4( vec4(cos(v.z),-sin(v.z),0.0,0.0), vec4(sin(v.z),cos(v.z),0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(0.0,0.0,0.0,1.0) );
    return rx * rz * ry;
  }


  mat4 transformMatrix (vec3 t, vec3 r, vec3 s) {
    mat4 ms = scaleMatrix(s);
    mat4 mt = translateMatrix(t);
    mat4 mr = rotateMatrix(r);
    return mt * mr * ms;
  }

  vec4 quatFromAxisAngle(vec3 axis, float angle) {
    float halfAngle = angle * 0.5;
    return vec4(axis.xyz * sin(halfAngle), cos(halfAngle));
  }

  vec3 rotateVector(vec4 q, vec3 v) {
    return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
  }

  void main() {
    float maxAge = params.y;
    float age = clamp(params.x, 0., maxAge);
    float positionInTime = (age / maxAge);
    float positionInTimeInverted = 1. - positionInTime;
    float positionInTimeMap = positionInTime * 2.0 - 1.0;
    float progress = 1. - pow(positionInTimeMap, 2.);
    float dist = pow(length(uv - 0.5), 2.0) - .2;

    vec4 transform = transformMatrix(vec3(0.,0.,progress * dist * .15), vec3(0.), vec3(progress * .075)) * vec4(position, 1.);

    vec4 quaternionY = quatFromAxisAngle(vec3(0.,1.,0.), age * velocity.y * 10.);
    vec4 quaternionX = quatFromAxisAngle(vec3(1.,0.,0.), age * velocity.x);
    vec4 quaternionZ = quatFromAxisAngle(vec3(0.,0.,1.), age * velocity.z);
    transform.xyz = rotateVector(quaternionX, transform.xyz);
    transform.xyz = rotateVector(quaternionY, transform.xyz);
    transform.xyz = rotateVector(quaternionZ, transform.xyz);
    
    transform.y += cos(wiggle.x * age) * wiggle.y;
    transform.x += sin(wiggle.x * age) * wiggle.y;
    transform.z += sin(wiggle.x * age) * wiggle.y;
    
    transform.y += offset.y + velocity.y * age * .9;
    transform.x += offset.x + cos(age) * radius * clamp(positionInTimeInverted, .5, 1.);
    transform.z += offset.z + sin(age) * radius * clamp(positionInTimeInverted, .5, 1.);

    vec3 transformed = transform.xyz;

    #include <project_vertex>
    #include <fog_vertex>

    vColor = vec4(color, progress);
    vUv = uv;
  }
`,
    fT = `
  #include <fog_pars_fragment>

  uniform sampler2D map;

  varying vec4 vColor;
  varying vec2 vUv;

  void main() {
    vec2 uv = vUv;
    vec4 color = vColor;
    vec4 texture = texture2D( map, uv );

    gl_FragColor = color * texture;

    #include <tonemapping_fragment>
    #include <encodings_fragment>
    #include <fog_fragment>
  }
`,
    dT = to(ha.merge([ns.fog, {
        map: null
    }]), uT, fT, t => {
        t && (t.fog = !0)
    }),
    pT = u.forwardRef(({
        texture: t,
        ...e
    }, n) => {
        u.useMemo(() => Ur({
            LeafShaderMaterial: dT
        }), []);
        const r = rn(t),
            i = u.useRef(null),
            o = wr([i, n]),
            s = hr(h => h.clock),
            a = u.useRef(null),
            l = u.useRef(null),
            c = Bf(),
            d = u.useMemo(() => mT(e), [e]),
            [f] = u.useState(() => new hf(1, 1, 16, 16));
        return u.useEffect(() => c ? s.stop() : s.start(), [s, c]), kn((h, p) => {
            if (!i.current.userData.active) return;
            const m = a.current.attributes.params;
            for (let g = e.count - 1, y, x, w; g >= 0; --g) y = g * 2, x = m.array[y], w = m.array[y + 1], x < w ? x += p : x = 0, m.array[y] = x;
            m.needsUpdate = !0
        }), bt("Leafs"), v.jsxs("mesh", {
            ref: o,
            children: [v.jsxs("instancedBufferGeometry", {
                ref: a,
                instanceCount: e.count,
                index: f.index,
                "attributes-uv": f.attributes.uv,
                "attributes-position": f.attributes.position,
                children: [v.jsx("instancedBufferAttribute", {
                    attach: "attributes-velocity",
                    args: [d.velocities, 3]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-offset",
                    args: [d.offsets, 3]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-wiggle",
                    args: [d.wiggles, 2]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-params",
                    args: [d.params, 2]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-radius",
                    args: [d.radius, 1]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-color",
                    args: [d.colors, 3]
                })]
            }, e.count), v.jsx("leafShaderMaterial", {
                ref: l,
                map: r,
                side: Yv,
                transparent: !0,
                depthWrite: !1
            })]
        })
    }),
    hT = ({
        uuid: t,
        count: e,
        color: n,
        ...r
    }) => {
        const i = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Leafs: at({
                    color: {
                        value: n
                    },
                    count: {
                        value: e,
                        min: 0,
                        max: 500,
                        step: 1
                    }
                })
            })
        });
        return v.jsx(pT, {
            uuid: t,
            ...i,
            ...r
        })
    };

function mT({
    count: t,
    color: e
}) {
    const n = [],
        r = [],
        i = [],
        o = [],
        s = [],
        a = [],
        l = new ma(e);
    for (let c = t - 1; c >= 0; --c) {
        const d = c / (t - 1),
            f = 0,
            h = -.5,
            p = 0;
        r.push(f, h, p);
        const m = He.randFloat(1, 2),
            g = He.randFloat(.1, .2),
            y = He.randFloat(1, 2);
        n.push(m, g, y);
        const x = He.randFloat(2, 5),
            w = He.randFloat(.01, .03);
        a.push(x, w);
        const M = Math.PI * 4 * d,
            T = Math.PI * 4;
        i.push(M, T), s.push(He.randFloat(.4, .8)), o.push(...l.toArray())
    }
    return {
        velocities: new Float32Array(n),
        offsets: new Float32Array(r),
        wiggles: new Float32Array(a),
        params: new Float32Array(i),
        radius: new Float32Array(s),
        colors: new Float32Array(o)
    }
}
const gT = ({
        points: t,
        transformEnabled: e,
        ...n
    }) => {
        const r = u.useRef(null),
            i = u.useRef(null),
            o = hS(m => m.setActive),
            [s] = u.useState(() => new dt),
            [a] = u.useState(() => new dt),
            [l] = u.useState(() => new Xv(t[0].clone(), t[1], t[2])),
            c = u.useMemo(() => ["lime", "orange", "red"], []),
            [d, f] = u.useState([]),
            h = d[0],
            p = u.useCallback(m => {
                const g = m.target.object,
                    y = g.parent.children.indexOf(g);
                t[y].copy(g.position)
            }, [h]);
        return u.useEffect(() => {
            const m = i.current,
                g = y => o(y.value);
            return m && m.addEventListener("dragging-changed", g), () => m && m.removeEventListener("dragging-changed", g)
        }, [h]), kn(() => {
            const m = r.current.parent;
            if (!m || !m.userData.active) return;
            const y = m.parent.getObjectByName("model"),
                x = a ? y.getWorldPosition(a) : s;
            l.v0.addVectors(x, t[0]), l.v1.copy(t[1]), l.v2.copy(t[2]);
            const w = l.getPoints(20).map(P => P.toArray()).flat(),
                M = w.length - 3,
                R = r.current.geometry.attributes.instanceStart;
            for (let P = 0; P < M; P += 3) R.data.array[2 * P + 0] = w[P + 0], R.data.array[2 * P + 1] = w[P + 1], R.data.array[2 * P + 2] = w[P + 2], R.data.array[2 * P + 3] = w[P + 3], R.data.array[2 * P + 4] = w[P + 4], R.data.array[2 * P + 5] = w[P + 5];
            R.needsUpdate = !0
        }), v.jsxs(v.Fragment, {
            children: [v.jsx(pv, {
                ref: r,
                start: t[0],
                mid: t[1],
                end: t[2],
                ...n
            }), e && v.jsxs(v.Fragment, {
                children: [h && v.jsx(hv, {
                    ref: i,
                    object: h,
                    mode: "translate",
                    onObjectChange: p
                }), v.jsx(mv, {
                    box: !0,
                    onChange: f,
                    children: t.map((m, g) => v.jsxs("mesh", {
                        position: m,
                        children: [v.jsx("sphereGeometry", {
                            args: [.02, 8, 4]
                        }), v.jsx("meshBasicMaterial", {
                            color: c[g]
                        })]
                    }, g))
                })]
            })]
        })
    },
    vT = ({
        lineWidth: t,
        ...e
    }) => {
        const {
            mobile: n
        } = lc(), r = n ? t.mobile : t.desktop, i = u.useMemo(() => [
            [new dt(-.1263591151129111, -.10707066040717314, .11329420042450986), new dt(-1.2838407072178395, -.6590652910280085, .1558212148932599), new dt(-1.9009660952454892, .933245714781793, .19862473940144987)],
            [new dt(.16130047687945953, -.29009764652754483, .15746716635008184), new dt(.6728350393102536, -.6926233994162598, 1.2855322043075885), new dt(.8065483337117852, 1.3975308923470338, 1.51974644725738)],
            [new dt(.2, -.21461141341141116, .12120835066330593), new dt(1.61355930149791, -.8472818584331315, .6953598603019042), new dt(2.07521559115208, 1.1643951124419707, .8900292743217832)]
        ], []);
        return bt("Cables"), v.jsx("group", {
            children: i.map((o, s) => v.jsx(gT, {
                points: o,
                lineWidth: r,
                ...e
            }, s))
        })
    },
    yT = ({
        uuid: t,
        color: e,
        lineWidth: n,
        ...r
    }) => {
        const {
            lineWidthMobile: i,
            lineWidthDesktop: o,
            ...s
        } = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Cables: at({
                    color: {
                        value: e
                    },
                    lineWidth: at({
                        lineWidthMobile: {
                            value: n.mobile,
                            min: 0,
                            max: 10
                        },
                        lineWidthDesktop: {
                            value: n.desktop,
                            min: 0,
                            max: 10
                        }
                    }),
                    transformEnabled: {
                        value: !1
                    }
                })
            })
        });
        return v.jsx(vT, {
            uuid: t,
            lineWidth: {
                mobile: i,
                desktop: o
            },
            ...s,
            ...r
        })
    };
class xT extends mf {
    constructor(n) {
        super(n);
        ke(this, "_time");
        this._time = {
            value: 0
        }
    }
    onBeforeCompile(n) {
        n.uniforms.time = this._time, n.vertexShader = `
      attribute vec3 translate;
      uniform float time;

      mat4 translateMatrix (vec3 v) {
        return mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,1.0,0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(v.x,v.y,v.z,1.0) );
      }
    
      mat4 rotateMatrix (vec3 v) {
        mat4 rx = mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,cos(v.x),-sin(v.x),0.0), vec4(0.0,sin(v.x),cos(v.x),0.0), vec4(0.0,0.0,0.0,1.0) );
        mat4 ry = mat4( vec4(cos(v.y),0.0,sin(v.y),0.0), vec4(0.0,1.0,0.0,0.0), vec4(-sin(v.y),0.0,cos(v.y),0.0), vec4(0.0,0.0,0.0,1.0) );
        mat4 rz = mat4( vec4(cos(v.z),-sin(v.z),0.0,0.0), vec4(sin(v.z),cos(v.z),0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(0.0,0.0,0.0,1.0) );
        return rx * rz * ry;
      }
    
      mat4 scaleMatrix (vec3 v) {
        return mat4( vec4(v.x,0.0,0.0,0.0), vec4(0.0,v.y,0.0,0.0), vec4(0.0,0.0,v.z,0.0), vec4(0.0,0.0,0.0,1.0) );
      }
    
      mat4 transformMatrix (vec3 t, vec3 r, vec3 s) {
        mat4 ms = scaleMatrix(s);
        mat4 mt = translateMatrix(t);
        mat4 mr = rotateMatrix(r);
        return mt * mr * ms;
      }

      ${n.vertexShader}
    `, n.vertexShader = n.vertexShader.replace("#include <begin_vertex>", `
        vec3 transformed = (transformMatrix(translate, vec3(0.), vec3(.07)) * vec4(position, 1.)).xyz;
      `)
    }
    get time() {
        return this._time.value
    }
    set time(n) {
        this._time.value = n
    }
}
const bT = ({
        envMapRef: t,
        ...e
    }) => {
        u.useMemo(() => Ur({
            SphereMaterial: xT
        }), []);
        const n = rn(t),
            r = u.useMemo(() => wT(e), [e]),
            [i] = u.useState(() => new Lh(1, 32, 32)),
            [o] = u.useState(() => Math.random() * 1e3),
            [s] = u.useState(() => new dt(0, 0, 1)),
            [a] = u.useState(() => new dt(0, 0, 1)),
            [l] = u.useState(() => new dt(0, 0, 0)),
            c = u.useRef(null),
            d = u.useRef(null);
        return kn(({
            clock: f
        }, h) => {
            if (!d.current.userData.active) return;
            c.current.time = o + f.getElapsedTime();
            const p = a.distanceTo(s) > .7 ? .2 : 1.2,
                m = a.distanceTo(s) > .7 ? .02 : .3;
            l.y = He.lerp(l.y, p, .08), l.z = He.lerp(l.z, m, .03), d.current.rotation.y += l.y * h, d.current.rotation.z = Math.cos(f.getElapsedTime() * 2) * l.z
        }), u.useEffect(() => {
            const f = fi.subscribe(h => h.moveState, h => {
                const p = h.xy[0] / window.innerWidth * 2 - 1,
                    m = -(h.xy[1] / window.innerHeight) * 2 + 1;
                a.set(p, -m, 1)
            });
            return () => {
                f()
            }
        }, [a]), bt("Spheres"), v.jsxs("mesh", {
            ref: d,
            position: [0, .1, .33877140283584595],
            children: [v.jsx("instancedBufferGeometry", {
                instanceCount: e.count,
                index: i.index,
                "attributes-uv": i.attributes.uv,
                "attributes-normal": i.attributes.normal,
                "attributes-position": i.attributes.position,
                children: v.jsx("instancedBufferAttribute", {
                    attach: "attributes-translate",
                    args: [r.translates, 3]
                })
            }), v.jsx("sphereMaterial", {
                ref: c,
                envMap: n,
                ...e
            })]
        })
    },
    wT = ({
        count: t = 1
    }) => {
        const e = [],
            n = Math.PI * 2 / t;
        for (let r = t - 1; r >= 0; --r) {
            const i = Math.cos(n * r) * .925,
                o = 0,
                s = Math.sin(n * r) * .925;
            e.push(i, o, s)
        }
        return {
            translates: new Float32Array(e)
        }
    },
    _T = ({
        uuid: t,
        ...e
    }) => v.jsx(bT, {
        uuid: t,
        ...e
    }),
    DT = `
  #include <fog_pars_vertex>

  uniform float pixelRatio;
  uniform float time;

  attribute float opacity;
  attribute float speed;
  attribute float size;
  attribute float glow;
  attribute vec3 noise;
  attribute vec3 color;

  varying vec3 vColor;
  varying float vGlow;
  varying float vOpacity;

  void main() {
    vec4 transform = vec4(position, 1.);
    transform.x += cos(time * speed * noise.x) * 1.;
    transform.y += sin(time * speed * noise.y) * 1.;
    transform.z += cos(time * speed * noise.z) * 1.;

    vec3 transformed = transform.xyz;

    #include <project_vertex>

    gl_PointSize = size * 25. * pixelRatio;

    #include <fog_vertex>

    vGlow = glow;
    vColor = color;
    vOpacity = opacity;
  }
`,
    ST = `
  #include <fog_pars_fragment>

  uniform sampler2D map;
    
  varying vec3 vColor;
  varying float vGlow;
  varying float vOpacity;

  void main() {
    vec4 texel = vec4(texture2D(map, gl_PointCoord));
    vec4 color = texel * vec4(vColor, 1.);
    gl_FragColor = color + color * vGlow;
    gl_FragColor.a *= vOpacity;

    #include <tonemapping_fragment>
    #include <encodings_fragment>
    #include <fog_fragment>
  } 
`,
    CT = to(ha.merge([ns.fog, {
        map: null,
        time: 0,
        pixelRatio: 1,
        vertexColor: !0
    }]), DT, ST, t => {
        t && (t.fog = !0)
    }),
    ET = u.forwardRef(({
        texture: t,
        ...e
    }, n) => {
        u.useMemo(() => Ur({
            SparklesShaderMaterial: CT
        }), []);
        const r = rn(t),
            i = 1,
            o = u.useRef(null),
            s = wr([o, n]),
            a = u.useRef(null),
            l = u.useMemo(() => Math.random() * 1e3, []),
            c = u.useMemo(() => PT(e), [e]);
        return kn(({
            clock: d
        }) => {
            o.current.userData.active && (a.current.uniforms.time.value = l + d.getElapsedTime())
        }), bt("Sparkles"), v.jsxs("points", {
            ref: s,
            frustumCulled: !1,
            children: [v.jsxs("bufferGeometry", {
                children: [v.jsx("bufferAttribute", {
                    attach: "attributes-position",
                    args: [c.positions, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-opacity",
                    args: [c.opacities, 1]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-size",
                    args: [c.sizes, 1]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-speed",
                    args: [c.speeds, 1]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-noise",
                    args: [c.noises, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-color",
                    args: [c.colors, 3]
                }), v.jsx("bufferAttribute", {
                    attach: "attributes-glow",
                    args: [c.glows, 1]
                })]
            }), v.jsx("sparklesShaderMaterial", {
                ref: a,
                map: r,
                blending: Kl,
                depthWrite: !1,
                pixelRatio: i,
                vertexColor: !0
            })]
        })
    }),
    TT = ({
        uuid: t,
        color: e,
        count: n,
        opacity: r,
        scale: i,
        size: o,
        glow: s,
        speed: a,
        noise: l,
        position: c,
        ...d
    }) => {
        const f = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Sparkles: at({
                    color: {
                        value: e
                    },
                    count: {
                        value: n,
                        min: 0,
                        max: 500,
                        step: 1
                    },
                    opacity: {
                        value: r,
                        min: 0,
                        max: 1
                    },
                    scale: {
                        value: i,
                        min: 0,
                        max: 10
                    },
                    size: {
                        value: o,
                        min: 0,
                        max: 1
                    },
                    glow: {
                        value: s,
                        min: 0,
                        max: 5
                    },
                    speed: {
                        value: a,
                        min: 0,
                        max: 5
                    },
                    noise: {
                        value: l,
                        min: 0,
                        max: 10
                    },
                    position: c
                })
            })
        });
        return v.jsx(ET, {
            uuid: t,
            ...f,
            ...d
        })
    },
    PT = ({
        count: t,
        color: e,
        opacity: n,
        scale: r,
        size: i,
        glow: o,
        speed: s,
        noise: a,
        position: l
    }) => {
        const c = [],
            d = [],
            f = [],
            h = [],
            p = [],
            m = [],
            g = [],
            y = new ma(e);
        for (let x = t - 1; x >= 0; --x) {
            const w = l.x + He.randFloatSpread(r),
                M = l.y + He.randFloatSpread(r),
                T = l.z + He.randFloatSpread(r / 1.5);
            c.push(w, M, T);
            const O = He.randFloatSpread(a),
                R = He.randFloatSpread(a),
                P = He.randFloatSpread(a);
            f.push(O, R, P), p.push(...y.toArray()), d.push(n), h.push(s), m.push(He.randFloat(0, i)), g.push(o)
        }
        return {
            positions: new Float32Array(c),
            opacities: new Float32Array(d),
            noises: new Float32Array(f),
            speeds: new Float32Array(h),
            colors: new Float32Array(p),
            sizes: new Float32Array(m),
            glows: new Float32Array(g)
        }
    },
    RT = ({
        geometry: t,
        envMapRef: e,
        aoMapRef: n,
        bumpMapRef: r,
        normalMapRef: i,
        roughnessMapRef: o,
        fogColor: s,
        fogNear: a,
        fogFar: l,
        lightColor: c,
        lightIntensity: d,
        panelsColor: f,
        panelsEmissive: h,
        panelsEmissiveIntensity: p,
        boxesColor: m,
        boxesEmissive: g,
        boxesBumpMapScale: y,
        boxesAoMapIntensity: x,
        boxesRoughness: w,
        boxesMetalness: M
    }) => {
        const {
            scene: T
        } = rn(t), O = rn(e), R = rn(n), P = rn(r), B = rn(i), te = rn(o), W = An("logo", T), ee = An("cubes", T), V = An("cables", T), I = An("connectors", T), X = An("white-panels", T), q = Gr(), Z = u.useRef(null), le = u.useRef(null), Se = u.useRef(null), Me = u.useMemo(() => {
            const $e = new ql;
            $e.setFromObject(X);
            const Xe = $e.max.x - $e.min.x,
                tt = $e.max.y - $e.min.y,
                wt = new dt;
            return wt.setY(-tt / 2 + X.position.y), {
                width: Xe,
                height: tt,
                position: wt
            }
        }, [X]), z = u.useRef(0), ge = () => {
            const $e = q.cameraMotionValue.get();
            Z.current.near = a - $e * .2, Z.current.far = l - $e * .2
        };
        return kn(($e, Xe) => {
            z.current += Xe, le.current.userData.active && (Se.current.normalMap.offset.x = .2 * Math.cos(z.current * .1), Se.current.normalMap.offset.y = .1 * Math.sin(z.current * .2), ge())
        }), bt("Underground"), v.jsxs(v.Fragment, {
            children: [v.jsx("fog", {
                ref: Z,
                attach: "fog",
                color: s,
                near: a,
                far: l
            }), v.jsxs("mesh", {
                ref: le,
                name: "Reflector",
                position: [0, -.39, 0],
                rotation: [Math.PI / 2, 0, 0],
                children: [v.jsx("planeGeometry", {
                    args: [10, 10]
                }), v.jsx(Hg, {
                    ref: Se,
                    mirror: .92,
                    mixBlur: 0,
                    blur: [0, 0],
                    resolution: 512,
                    normalMap: B,
                    "normalMap-repeat": [8, 8],
                    "normalMap-wrapS": Nn,
                    "normalMap-wrapT": Nn,
                    normalScale: new xr(.08, .08),
                    color: "#ffffff",
                    metalness: .98,
                    roughness: .98,
                    mixStrength: 18,
                    mixContrast: .98
                })]
            }), v.jsxs("group", {
                children: [v.jsx("rectAreaLight", {
                    color: c,
                    intensity: d,
                    rotation: [0, -Math.PI, 0],
                    ...Me
                }), v.jsx("mesh", {
                    geometry: X.geometry,
                    position: X.position,
                    rotation: X.rotation,
                    scale: X.scale,
                    children: v.jsx("meshStandardMaterial", {
                        color: f,
                        emissive: h,
                        emissiveIntensity: p,
                        roughness: 1,
                        metalness: 1,
                        toneMapped: !1
                    })
                })]
            }), v.jsxs("mesh", {
                position: ee.position,
                rotation: ee.rotation,
                scale: ee.scale,
                children: [v.jsx("bufferGeometry", {
                    index: ee.geometry.index,
                    "attributes-uv": ee.geometry.attributes.uv,
                    "attributes-uv2": ee.geometry.attributes.uv.clone(),
                    "attributes-normal": ee.geometry.attributes.normal,
                    "attributes-position": ee.geometry.attributes.position
                }), v.jsx("meshStandardMaterial", {
                    color: m,
                    emissive: g,
                    roughness: w,
                    metalness: M,
                    aoMap: R,
                    aoMapIntensity: x,
                    envMap: O,
                    bumpMap: P,
                    bumpScale: y,
                    "bumpMap-repeat": [2, 2],
                    "bumpMap-wrapS": Nn,
                    "bumpMap-wrapT": Nn,
                    roughnessMap: te,
                    "roughnessMap-wrapS": Nn,
                    "roughnessMap-wrapT": Nn,
                    "roughnessMap-repeat": [2, 2]
                })]
            }), v.jsxs("mesh", {
                position: I.position,
                rotation: I.rotation,
                scale: I.scale,
                children: [v.jsx("bufferGeometry", {
                    index: I.geometry.index,
                    "attributes-uv": I.geometry.attributes.uv,
                    "attributes-uv2": I.geometry.attributes.uv.clone(),
                    "attributes-normal": I.geometry.attributes.normal,
                    "attributes-position": I.geometry.attributes.position
                }), v.jsx("meshStandardMaterial", {
                    color: m,
                    emissive: g,
                    roughness: w,
                    metalness: M,
                    aoMap: R,
                    aoMapIntensity: x,
                    envMap: O,
                    bumpMap: P,
                    bumpScale: y,
                    "bumpMap-repeat": [1, 1],
                    "bumpMap-wrapS": Nn,
                    "bumpMap-wrapT": Nn,
                    roughnessMap: te,
                    "roughnessMap-wrapS": Nn,
                    "roughnessMap-wrapT": Nn,
                    "roughnessMap-repeat": [1, 1]
                })]
            }), v.jsx("mesh", {
                geometry: V.geometry,
                position: V.position,
                rotation: V.rotation,
                scale: V.scale,
                children: v.jsx("meshStandardMaterial", {
                    color: "#ffffff",
                    emissive: "#000000",
                    emissiveIntensity: 1,
                    roughness: .5,
                    metalness: 0
                })
            }), v.jsx("mesh", {
                geometry: W.geometry,
                position: W.position,
                rotation: W.rotation,
                scale: W.scale,
                children: v.jsx("meshStandardMaterial", {
                    color: "#000000",
                    emissive: "#000000",
                    roughness: 1,
                    metalness: 1
                })
            })]
        })
    },
    MT = ({
        uuid: t,
        fogColor: e,
        fogNear: n,
        fogFar: r,
        lightColor: i,
        lightIntensity: o,
        panelsColor: s,
        panelsEmissive: a,
        panelsEmissiveIntensity: l,
        boxesColor: c,
        boxesEmissive: d,
        boxesAoMapIntensity: f,
        boxesBumpMapScale: h,
        boxesMetalness: p,
        boxesRoughness: m,
        ...g
    }) => {
        const y = un("Scenes", {
            Underground: at({
                Fog: at({
                    fogColor: {
                        value: e
                    },
                    fogNear: {
                        value: n,
                        min: 0,
                        max: 10
                    },
                    fogFar: {
                        value: r,
                        min: 0,
                        max: 10
                    }
                }),
                Light: at({
                    lightColor: {
                        value: i
                    },
                    lightIntensity: {
                        value: o,
                        min: 0,
                        max: 10
                    }
                }),
                Panels: at({
                    panelsColor: {
                        value: s
                    },
                    panelsEmissive: {
                        value: a
                    },
                    panelsEmissiveIntensity: {
                        value: l,
                        min: 0,
                        max: 5
                    }
                }),
                Boxes: at({
                    boxesColor: {
                        value: c
                    },
                    boxesEmissive: {
                        value: d
                    },
                    boxesBumpMapScale: {
                        value: h,
                        min: -2,
                        max: 2
                    },
                    boxesAoMapIntensity: {
                        value: f,
                        min: -2,
                        max: 2
                    },
                    boxesRoughness: {
                        value: m,
                        min: -2,
                        max: 2
                    },
                    boxesMetalness: {
                        value: p,
                        min: -2,
                        max: 2
                    }
                })
            })
        });
        return v.jsx(RT, {
            uuid: t,
            ...y,
            ...g
        })
    },
    $T = () => {
        const t = hr(({
                gl: n
            }) => n),
            [e] = u.useState(() => Vg.getInstance(t));
        return e
    },
    AT = `
  varying vec2 vUv;

  void main() {
    gl_Position = vec4(position, 1.0);

    vUv = uv;
  }
`,
    FT = `
  uniform sampler2D tFluidDensity;

  varying vec2 vUv;

  vec3 adjustSaturation(vec3 color, float value) {
    // https://www.w3.org/TR/WCAG21/#dfn-relative-luminance
    const vec3 luminosityFactor = vec3(0.2126, 0.7152, 0.0722);
    vec3 grayscale = vec3(dot(color, luminosityFactor));
  
    return mix(grayscale, color, 1.0 + value);
  }

  void main() {
    vec3 fluidDensity = texture2D(tFluidDensity, vUv).rgb;
    float fluidMask = smoothstep(0.0, 1.0, fluidDensity.b);
    float fluidPush = pow(abs(fluidDensity.x) * 0.01, 2.0);
    float fluidEdge = fluidPush * smoothstep(0.2, 0.0, abs(fluidMask-0.5));

    vec3 fluidColor = vec3(228.0/255.0, 103.0/255.0, 103.0/255.0);
    vec3 fluid = vec3(fluidColor * clamp(fluidEdge, 0.0, 1.0));

    vec3 color = vec3(16./255.) + fluid;
    
    color = adjustSaturation(color, 0.6);

    gl_FragColor = vec4(color, 1.0);

    #include <tonemapping_fragment>
    #include <encodings_fragment>
  }
`,
    kT = to({
        tFluidDensity: null
    }, AT, FT),
    OT = () => {
        u.useMemo(() => Ur({
            BackgroundShaderMaterial: kT
        }), []);
        const t = u.useRef(null),
            e = $T();
        return kn(() => {
            if (!t.current.userData.active) return;
            const n = t.current.material;
            n.uniforms.tFluidDensity.value = e.densityTexure
        }), bt("Upperground"), v.jsxs(v.Fragment, {
            children: [v.jsxs("mesh", {
                ref: t,
                children: [v.jsx("planeGeometry", {
                    args: [2, 2]
                }), v.jsx("backgroundShaderMaterial", {
                    toneMapped: !1,
                    depthTest: !1,
                    depthWrite: !1
                })]
            }), v.jsx(DE, {})]
        })
    },
    Gg = ({
        geometry: t,
        envMapRef: e,
        ...n
    }) => {
        const r = no(t),
            i = rn(e),
            o = u.useRef(null);
        return Wf(s => {
            o.current.emissiveIntensity = s.model.emissiveIntensity
        }), bt("BaseModel"), v.jsx("mesh", {
            name: "model",
            geometry: r.geometry,
            children: v.jsx("meshStandardMaterial", {
                ref: o,
                envMap: i,
                ...n
            })
        })
    },
    jT = ({
        uuid: t,
        color: e,
        emissive: n,
        emissiveIntensity: r,
        metalness: i,
        roughness: o,
        toneMapped: s,
        ...a
    }) => {
        const l = un("Scenes", {
            [Gt.capitalize(t)]: at({
                Model: at({
                    Material: at({
                        color: {
                            value: e
                        },
                        emissive: {
                            value: n
                        },
                        emissiveIntensity: {
                            value: r,
                            min: 0,
                            max: 5
                        },
                        metalness: {
                            value: i,
                            min: 0,
                            max: 1
                        },
                        roughness: {
                            value: o,
                            min: 0,
                            max: 1
                        },
                        toneMapped: {
                            value: s
                        }
                    })
                })
            })
        });
        return v.jsx(Gg, {
            uuid: t,
            ...l,
            ...a
        })
    },
    LT = ({
        speed: t,
        rotationIntensity: e,
        floatIntensity: n,
        floatingRangeMin: r,
        floatingRangeMax: i,
        ...o
    }) => (bt("FloatModel"), v.jsx(gv, {
        speed: t,
        rotationIntensity: e,
        floatIntensity: n,
        floatingRange: [r, i],
        children: v.jsx(Gg, { ...o
        })
    })),
    NT = ({
        uuid: t,
        color: e,
        emissive: n,
        emissiveIntensity: r,
        metalness: i,
        roughness: o,
        toneMapped: s,
        speed: a,
        floatIntensity: l,
        rotationIntensity: c,
        floatingRangeMin: d,
        floatingRangeMax: f,
        ...h
    }) => {
        const p = un("Scenes", {
                [Gt.capitalize(t)]: at({
                    Model: at({
                        Material: at({
                            color: {
                                value: e
                            },
                            emissive: {
                                value: n
                            },
                            emissiveIntensity: {
                                value: r,
                                min: 0,
                                max: 5
                            },
                            metalness: {
                                value: i,
                                min: 0,
                                max: 1
                            },
                            roughness: {
                                value: o,
                                min: 0,
                                max: 1
                            },
                            toneMapped: {
                                value: s
                            }
                        })
                    })
                })
            }),
            m = un("Scenes", {
                [Gt.capitalize(t)]: at({
                    Model: at({
                        Float: at({
                            speed: {
                                value: a,
                                min: 0,
                                max: 5
                            },
                            floatIntensity: {
                                value: l,
                                min: 0,
                                max: 5
                            },
                            rotationIntensity: {
                                value: c,
                                min: 0,
                                max: 5
                            },
                            floatingRangeMin: {
                                value: d,
                                min: 0,
                                max: 5
                            },
                            floatingRangeMax: {
                                value: f,
                                min: 0,
                                max: 5
                            }
                        })
                    })
                })
            });
        return v.jsx(LT, {
            uuid: t,
            ...p,
            ...m,
            ...h
        })
    },
    zT = ({
        animation: t,
        geometry: e,
        envMapRef: n,
        ...r
    }) => {
        const i = u.useRef(null),
            o = rn(n),
            {
                scene: s,
                animations: a
            } = rn(e),
            {
                actions: l
            } = vv(a, i),
            c = no(e),
            d = Pm(e),
            f = An("Body", d),
            h = An("Shirt", d),
            p = An("Shorts", d),
            m = An("Socks", d),
            g = An("Shoes", d),
            y = An("mixamorig5Hips", d),
            x = An("stand", s),
            w = An("ball", s);
        return u.useEffect(() => {
            var M;
            (M = l == null ? void 0 : l[t]) == null || M.play()
        }, [l, t]), bt("AnimatedModel"), v.jsxs("group", {
            ref: i,
            dispose: null,
            children: [v.jsx("group", {
                position: c.position,
                rotation: c.rotation,
                scale: c.scale,
                children: v.jsxs("group", {
                    name: "Player",
                    position: d.position,
                    children: [v.jsx("skinnedMesh", {
                        geometry: f.geometry,
                        skeleton: f.skeleton,
                        children: v.jsx("meshStandardMaterial", {
                            envMap: o,
                            ...r
                        })
                    }), v.jsx("skinnedMesh", {
                        geometry: h.geometry,
                        skeleton: h.skeleton,
                        children: v.jsx("meshStandardMaterial", {
                            envMap: o,
                            ...r
                        })
                    }), v.jsx("skinnedMesh", {
                        geometry: g.geometry,
                        skeleton: g.skeleton,
                        children: v.jsx("meshStandardMaterial", {
                            envMap: o,
                            ...r
                        })
                    }), v.jsx("skinnedMesh", {
                        geometry: p.geometry,
                        skeleton: p.skeleton,
                        children: v.jsx("meshStandardMaterial", {
                            envMap: o,
                            ...r
                        })
                    }), v.jsx("skinnedMesh", {
                        geometry: m.geometry,
                        skeleton: m.skeleton,
                        children: v.jsx("meshStandardMaterial", {
                            envMap: o,
                            ...r
                        })
                    }), v.jsx("primitive", {
                        object: y
                    })]
                })
            }), v.jsx("mesh", {
                geometry: w.geometry,
                position: w.position,
                rotation: w.rotation,
                scale: w.scale,
                children: v.jsx("meshStandardMaterial", {
                    envMap: o,
                    ...r
                })
            }), v.jsx("mesh", {
                geometry: x.geometry,
                position: x.position,
                rotation: x.rotation,
                scale: x.scale,
                children: v.jsx("meshStandardMaterial", {
                    envMap: o,
                    ...r,
                    roughness: 1
                })
            })]
        })
    },
    IT = ({
        uuid: t,
        ...e
    }) => v.jsx(zT, {
        uuid: t,
        ...e
    }),
    BT = `
  #include <fog_pars_vertex>

  attribute vec3 velocity;
  attribute vec3 offset;
  attribute vec2 params;
  attribute vec3 color;
  attribute vec2 wiggle;
  attribute float radius;

  varying vec4 vColor;
  varying vec2 vUv;

  mat4 translateMatrix (vec3 v) {
    return mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,1.0,0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(v.x,v.y,v.z,1.0) );
  }

  mat4 scaleMatrix (vec3 v) {
    return mat4( vec4(v.x,0.0,0.0,0.0), vec4(0.0,v.y,0.0,0.0), vec4(0.0,0.0,v.z,0.0), vec4(0.0,0.0,0.0,1.0) );
  }

  mat4 rotateMatrix (vec3 v) {
    mat4 rx = mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,cos(v.x),-sin(v.x),0.0), vec4(0.0,sin(v.x),cos(v.x),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 ry = mat4( vec4(cos(v.y),0.0,sin(v.y),0.0), vec4(0.0,1.0,0.0,0.0), vec4(-sin(v.y),0.0,cos(v.y),0.0), vec4(0.0,0.0,0.0,1.0) );
    mat4 rz = mat4( vec4(cos(v.z),-sin(v.z),0.0,0.0), vec4(sin(v.z),cos(v.z),0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(0.0,0.0,0.0,1.0) );
    return rx * rz * ry;
  }


  mat4 transformMatrix (vec3 t, vec3 r, vec3 s) {
    mat4 ms = scaleMatrix(s);
    mat4 mt = translateMatrix(t);
    mat4 mr = rotateMatrix(r);
    return mt * mr * ms;
  }

  vec4 quatFromAxisAngle(vec3 axis, float angle) {
    float halfAngle = angle * 0.5;
    return vec4(axis.xyz * sin(halfAngle), cos(halfAngle));
  }

  vec3 rotateVector(vec4 q, vec3 v) {
    return v + 2.0 * cross(q.xyz, cross(q.xyz, v) + q.w * v);
  }

  void main() {
    float maxAge = params.y;
    float age = clamp(params.x, 0., maxAge);
    float positionInTime = (age / maxAge);
    float positionInTimeInverted = 1. - positionInTime;
    float positionInTimeMap = positionInTime * 2.0 - 1.0;
    float progress = 1. - pow(positionInTimeMap, 2.);
    float dist = pow(length(uv - 0.5), 2.0) - .2;

    vec4 transform = transformMatrix(vec3(0.,0.,0.), vec3(0.), vec3(positionInTimeInverted * .1)) * vec4(position, 1.);

    vec4 quaternionY = quatFromAxisAngle(vec3(0.,1.,0.), age * velocity.y * 10.);
    vec4 quaternionX = quatFromAxisAngle(vec3(1.,0.,0.), age * velocity.x);
    vec4 quaternionZ = quatFromAxisAngle(vec3(0.,0.,1.), age * velocity.z);
    transform.xyz = rotateVector(quaternionX, transform.xyz);
    transform.xyz = rotateVector(quaternionY, transform.xyz);
    transform.xyz = rotateVector(quaternionZ, transform.xyz);
    
    transform.y += cos(wiggle.x * age) * wiggle.y;
    transform.x += sin(wiggle.x * age) * wiggle.y;
    transform.z += sin(wiggle.x * age) * wiggle.y;
    
    transform.y += offset.y + velocity.y * age * .9;
    transform.x += offset.x + cos(age) * radius * clamp(positionInTimeInverted, .5, 1.);
    transform.z += offset.z + sin(age) * radius * clamp(positionInTimeInverted, .5, 1.);

    vec3 transformed = transform.xyz;

    #include <project_vertex>
    #include <fog_vertex>

    vColor = vec4(color, progress);
    vUv = uv;
  }
`,
    WT = `
  #include <fog_pars_fragment>

  // uniform sampler2D map;

  varying vec4 vColor;
  varying vec2 vUv;

  void main() {
    vec2 uv = vUv;
    vec4 color = vColor;
    // vec4 texture = texture2D( map, uv );

    gl_FragColor = color; // * texture;

    #include <tonemapping_fragment>
    #include <encodings_fragment>
    #include <fog_fragment>
  }
`,
    VT = to(ha.merge([ns.fog, {
        map: null
    }]), BT, WT, t => {
        t && (t.fog = !0)
    }),
    Rh = u.forwardRef(({
        count: t = 150,
        color: e = "#ffffff"
    }, n) => {
        u.useMemo(() => Ur({
            NectarShaderMaterial: VT
        }), []);
        const r = u.useRef(null),
            i = wr([r, n]),
            o = hr(f => f.clock),
            s = u.useRef(null),
            a = u.useRef(null),
            l = Bf(),
            c = u.useMemo(() => UT({
                count: t,
                color: e
            }), [t, e]),
            [d] = u.useState(() => new Lh(.08, 16, 16));
        return u.useEffect(() => l ? o.stop() : o.start(), [o, l]), kn((f, h) => {
            var m;
            if (!((m = r.current.parent) != null && m.userData.active)) return;
            const p = s.current.attributes.params;
            for (let g = t - 1, y, x, w; g >= 0; --g) y = g * 2, x = p.array[y], w = p.array[y + 1], x < w ? x += h : x = 0, p.array[y] = x;
            p.needsUpdate = !0
        }), bt("Nectar"), v.jsxs("mesh", {
            ref: i,
            children: [v.jsxs("instancedBufferGeometry", {
                ref: s,
                instanceCount: t,
                index: d.index,
                "attributes-uv": d.attributes.uv,
                "attributes-position": d.attributes.position,
                children: [v.jsx("instancedBufferAttribute", {
                    attach: "attributes-velocity",
                    args: [c.velocities, 3]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-offset",
                    args: [c.offsets, 3]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-wiggle",
                    args: [c.wiggles, 2]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-params",
                    args: [c.params, 2]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-radius",
                    args: [c.radius, 1]
                }), v.jsx("instancedBufferAttribute", {
                    attach: "attributes-color",
                    args: [c.colors, 3]
                })]
            }, t), v.jsx("nectarShaderMaterial", {
                ref: a,
                transparent: !0,
                toneMapped: !1
            })]
        })
    });

function UT({
    count: t = 100,
    color: e
}) {
    const n = [],
        r = [],
        i = [],
        o = [],
        s = [],
        a = [],
        l = new ma(e);
    for (let c = t - 1; c >= 0; --c) {
        const d = c / (t - 1),
            f = 0,
            h = -.1,
            p = 0;
        r.push(f, h, p);
        const m = He.randFloat(.05, .1),
            g = He.randFloat(.04, .08),
            y = He.randFloat(.05, .1);
        n.push(m, g, y);
        const x = He.randFloat(.04, .08),
            w = He.randFloat(.02, .04);
        a.push(x, w);
        const M = Math.PI * 4 * d,
            T = Math.PI * 4;
        i.push(M, T), s.push(He.randFloat(.04, .08)), o.push(...l.toArray())
    }
    return {
        velocities: new Float32Array(n),
        offsets: new Float32Array(r),
        wiggles: new Float32Array(a),
        params: new Float32Array(i),
        radius: new Float32Array(s),
        colors: new Float32Array(o)
    }
}
const HT = ({
        geometry: t,
        envMapRef: e,
        ...n
    }) => {
        const {
            scene: r
        } = rn(t), i = rn(e), o = u.useRef(null), s = u.useRef(null), a = u.useRef(null), l = An("Main_Flower", r), c = An("Small_Flower", r), d = l.children[0], f = c.children[0];
        return kn(({
            clock: h
        }, p) => {
            if (o.current.userData.active = a.current.userData.active, s.current.userData.active = a.current.userData.active, !a.current.userData.active) return;
            const m = h.getElapsedTime();
            o.current.position.y = .489 + Math.sin(m * .5) * .05, s.current.position.y = -.072 + Math.cos(m * .5) * .05, o.current.rotation.y += p * .15, s.current.rotation.y += p * .2
        }), bt("FlowersModel"), v.jsxs("group", {
            ref: a,
            position: r.position,
            children: [v.jsxs("mesh", {
                ref: o,
                geometry: c.geometry,
                position: c.position,
                rotation: c.rotation,
                children: [v.jsx("meshStandardMaterial", {
                    envMap: i,
                    ...n
                }), v.jsx("mesh", {
                    geometry: f.geometry,
                    position: f.position,
                    rotation: f.rotation,
                    children: v.jsx("meshStandardMaterial", {
                        emissive: "white",
                        envMap: i,
                        toneMapped: !1
                    })
                }), v.jsx(Rh, {})]
            }), v.jsxs("mesh", {
                ref: s,
                geometry: l.geometry,
                position: l.position,
                rotation: l.rotation,
                children: [v.jsx("meshStandardMaterial", {
                    envMap: i,
                    ...n
                }), v.jsx("mesh", {
                    geometry: d.geometry,
                    position: d.position,
                    rotation: d.rotation,
                    children: v.jsx("meshStandardMaterial", {
                        emissive: "white",
                        envMap: i,
                        toneMapped: !1
                    })
                }), v.jsx(Rh, {})]
            })]
        })
    },
    GT = ({
        uuid: t,
        ...e
    }) => v.jsx(HT, {
        uuid: t,
        ...e
    }),
    zo = 128,
    Io = 128,
    Yc = zo * Io,
    Mh = `
  precision highp float;

  attribute vec3 position;

  void main() {
    gl_Position = vec4( position, 1.0 );
  }
`,
    YT = `
  precision highp float;

  uniform vec2 resolution;
  uniform sampler2D texture;

  void main() {
    vec2 uv = gl_FragCoord.xy / resolution.xy;
    gl_FragColor = texture2D( texture, uv );
  }
`,
    XT = `
  precision highp float;

  uniform sampler2D texturePosition;
  uniform sampler2D textureDefaultPosition;
  uniform vec2 resolution;
  uniform vec3 mouse3d;
  uniform float speed;
  uniform float dieSpeed;
  uniform float curlSize;
  uniform float attraction;
  uniform float radius;
  uniform float delta;
  uniform float time;

  vec4 mod289(vec4 x) {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
  }

  float mod289(float x) {
    return x - floor(x * (1.0 / 289.0)) * 289.0;
  }

  vec4 permute(vec4 x) {
    return mod289(((x*34.0)+1.0)*x);
  }

  float permute(float x) {
    return mod289(((x*34.0)+1.0)*x);
  }

  vec4 taylorInvSqrt(vec4 r) {
    return 1.79284291400159 - 0.85373472095314 * r;
  }

  float taylorInvSqrt(float r) {
    return 1.79284291400159 - 0.85373472095314 * r;
  }

  vec4 grad4(float j, vec4 ip) {
    const vec4 ones = vec4(1.0, 1.0, 1.0, -1.0);
    vec4 p,s;

    p.xyz = floor( fract (vec3(j) * ip.xyz) * 7.0) * ip.z - 1.0;
    p.w = 1.5 - dot(abs(p.xyz), ones.xyz);
    s = vec4(lessThan(p, vec4(0.0)));
    p.xyz = p.xyz + (s.xyz*2.0 - 1.0) * s.www;

    return p;
  }

  #define F4 0.309016994374947451

  vec4 snoise4 (vec4 v) { // simplexNoiseDerivatives
    const vec4  C = vec4( 0.138196601125011,0.276393202250021,0.414589803375032,-0.447213595499958);

    vec4 i  = floor(v + dot(v, vec4(F4)) );
    vec4 x0 = v -   i + dot(i, C.xxxx);

    vec4 i0;
    vec3 isX = step( x0.yzw, x0.xxx );
    vec3 isYZ = step( x0.zww, x0.yyz );
    i0.x = isX.x + isX.y + isX.z;
    i0.yzw = 1.0 - isX;
    i0.y += isYZ.x + isYZ.y;
    i0.zw += 1.0 - isYZ.xy;
    i0.z += isYZ.z;
    i0.w += 1.0 - isYZ.z;

    vec4 i3 = clamp( i0, 0.0, 1.0 );
    vec4 i2 = clamp( i0-1.0, 0.0, 1.0 );
    vec4 i1 = clamp( i0-2.0, 0.0, 1.0 );

    vec4 x1 = x0 - i1 + C.xxxx;
    vec4 x2 = x0 - i2 + C.yyyy;
    vec4 x3 = x0 - i3 + C.zzzz;
    vec4 x4 = x0 + C.wwww;

    i = mod289(i);
    float j0 = permute( permute( permute( permute(i.w) + i.z) + i.y) + i.x);
    vec4 j1 = permute( permute( permute( permute (
              i.w + vec4(i1.w, i2.w, i3.w, 1.0 ))
            + i.z + vec4(i1.z, i2.z, i3.z, 1.0 ))
            + i.y + vec4(i1.y, i2.y, i3.y, 1.0 ))
            + i.x + vec4(i1.x, i2.x, i3.x, 1.0 ));


    vec4 ip = vec4(1.0/294.0, 1.0/49.0, 1.0/7.0, 0.0) ;

    vec4 p0 = grad4(j0,   ip);
    vec4 p1 = grad4(j1.x, ip);
    vec4 p2 = grad4(j1.y, ip);
    vec4 p3 = grad4(j1.z, ip);
    vec4 p4 = grad4(j1.w, ip);

    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    p4 *= taylorInvSqrt(dot(p4,p4));

    vec3 values0 = vec3(dot(p0, x0), dot(p1, x1), dot(p2, x2)); //value of contributions from each corner at point
    vec2 values1 = vec2(dot(p3, x3), dot(p4, x4));

    vec3 m0 = max(0.5 - vec3(dot(x0,x0), dot(x1,x1), dot(x2,x2)), 0.0); //(0.5 - x^2) where x is the distance
    vec2 m1 = max(0.5 - vec2(dot(x3,x3), dot(x4,x4)), 0.0);

    vec3 temp0 = -6.0 * m0 * m0 * values0;
    vec2 temp1 = -6.0 * m1 * m1 * values1;

    vec3 mmm0 = m0 * m0 * m0;
    vec2 mmm1 = m1 * m1 * m1;

    float dx = temp0[0] * x0.x + temp0[1] * x1.x + temp0[2] * x2.x + temp1[0] * x3.x + temp1[1] * x4.x + mmm0[0] * p0.x + mmm0[1] * p1.x + mmm0[2] * p2.x + mmm1[0] * p3.x + mmm1[1] * p4.x;
    float dy = temp0[0] * x0.y + temp0[1] * x1.y + temp0[2] * x2.y + temp1[0] * x3.y + temp1[1] * x4.y + mmm0[0] * p0.y + mmm0[1] * p1.y + mmm0[2] * p2.y + mmm1[0] * p3.y + mmm1[1] * p4.y;
    float dz = temp0[0] * x0.z + temp0[1] * x1.z + temp0[2] * x2.z + temp1[0] * x3.z + temp1[1] * x4.z + mmm0[0] * p0.z + mmm0[1] * p1.z + mmm0[2] * p2.z + mmm1[0] * p3.z + mmm1[1] * p4.z;
    float dw = temp0[0] * x0.w + temp0[1] * x1.w + temp0[2] * x2.w + temp1[0] * x3.w + temp1[1] * x4.w + mmm0[0] * p0.w + mmm0[1] * p1.w + mmm0[2] * p2.w + mmm1[0] * p3.w + mmm1[1] * p4.w;

    return vec4(dx, dy, dz, dw) * 49.0;
  }

  vec3 curl( in vec3 p, in float noiseTime, in float persistence ) {
    vec4 xNoisePotentialDerivatives = vec4(0.0);
    vec4 yNoisePotentialDerivatives = vec4(0.0);
    vec4 zNoisePotentialDerivatives = vec4(0.0);

    for (int i = 0; i < 3; ++i) {
      float twoPowI = pow(2.0, float(i));
      float scale = 0.5 * twoPowI * pow(persistence, float(i));

      xNoisePotentialDerivatives += snoise4(vec4(p * twoPowI, noiseTime)) * scale;
      yNoisePotentialDerivatives += snoise4(vec4((p + vec3(123.4, 129845.6, -1239.1)) * twoPowI, noiseTime)) * scale;
      zNoisePotentialDerivatives += snoise4(vec4((p + vec3(-9519.0, 9051.0, -123.0)) * twoPowI, noiseTime)) * scale;
    }

    return vec3(
      zNoisePotentialDerivatives[1] - yNoisePotentialDerivatives[2],
      xNoisePotentialDerivatives[2] - zNoisePotentialDerivatives[0],
      yNoisePotentialDerivatives[0] - xNoisePotentialDerivatives[1]
    );
  }

  void main() {
    vec2 uv = gl_FragCoord.xy / resolution.xy;

    vec4 positionInfo = texture2D( texturePosition, uv );
    vec3 position = positionInfo.xyz; // mix(vec3(0.0, -200.0, 0.0), positionInfo.xyz, smoothstep(0.0, 0.3, initAnimation));
    float life = positionInfo.a - dieSpeed;

    vec3 followPosition = mouse3d / 0.1; // mix(vec3(0.0, -(1.0 - initAnimation) * 200.0, 0.0), mouse3d, smoothstep(0.2, 0.7, initAnimation));

    if(life < 0.0) {
      positionInfo = texture2D( textureDefaultPosition, uv );
      // position = positionInfo.xyz * (1.0 + sin(time * 15.0) * 0.2 + (1.0 - initAnimation)) * 0.4 * radius;
      position = positionInfo.xyz * (1.0 + sin(time * 15.0) * 0.2) * 2. * radius;
      position += followPosition;
      life = 0.5 + fract(positionInfo.w * 21.4131 + time);

      /* position = vec3(0.0);
      life = 0.; */
    } else {
      vec3 offset = followPosition - position;
      position += offset * (0.005 + life * 0.01) * attraction * (1.0 - smoothstep(50.0, 300.0, length(offset))) * speed;
      position += curl(position * curlSize, time, 0.1 + (1.0 - life) * 0.1) * speed;
      position.x -= length(offset) * delta * 2.5; // 0.01; // @TODO update 0.01 with time delta value
    }

    gl_FragColor = vec4(position, life);
  }
`;
class Yg {
    constructor(e) {
        ke(this, "_renderer");
        ke(this, "_camera");
        ke(this, "_scene");
        ke(this, "_mesh");
        ke(this, "_position");
        ke(this, "_copyShader");
        ke(this, "_positionShader");
        ke(this, "_defaultPositionTexture");
        ke(this, "_mouse3d", new dt);
        ke(this, "_clearColor");
        this._renderer = e, this._scene = new Nh, this._camera = new Oh, this._camera.position.z = 1, this._copyShader = new li({
            uniforms: {
                resolution: {
                    value: new xr(zo, Io)
                },
                texture: {
                    value: null
                }
            },
            vertexShader: Mh,
            fragmentShader: YT
        }), this._positionShader = new li({
            uniforms: {
                resolution: {
                    value: new xr(zo, Io)
                },
                texturePosition: {
                    value: null
                },
                textureDefaultPosition: {
                    value: null
                },
                mouse3d: {
                    value: new dt
                },
                delta: {
                    value: 0
                },
                speed: {
                    value: 1
                },
                dieSpeed: {
                    value: 0
                },
                radius: {
                    value: 0
                },
                curlSize: {
                    value: 0
                },
                attraction: {
                    value: 0
                },
                time: {
                    value: 0
                },
                initAnimation: {
                    value: 0
                }
            },
            vertexShader: Mh,
            fragmentShader: XT,
            blending: qv,
            transparent: !1,
            depthWrite: !1,
            depthTest: !1
        }), this._mesh = new ai(new hf(2, 2), this._copyShader), this._scene.add(this._mesh), this._position = this.createDoubleFBO(zo, Io, {
            wrapS: Qc,
            wrapT: Qc,
            minFilter: Ui,
            magFilter: Ui,
            format: Zc,
            type: vd,
            depthBuffer: !1,
            stencilBuffer: !1
        }), this.copyTexture(this.createPositionTexture(), this._position.read), this.copyTexture(this._position.read.texture, this._position.write), this._clearColor = new ma(0)
    }
    createPositionTexture() {
        const e = new Float32Array(Yc * 4);
        let n, r, i, o;
        for (let a = 0; a < Yc; a++) n = a * 4, r = (.5 + Math.random() * .5) * 25, i = (Math.random() - .5) * Math.PI, o = Math.random() * Math.PI * 2, e[n + 0] = r * Math.cos(o) * Math.cos(i), e[n + 1] = r * Math.sin(i), e[n + 2] = r * Math.sin(o) * Math.cos(i), e[n + 3] = Math.random();
        const s = new Kv(e, zo, Io, Zc, vd);
        return s.minFilter = Ui, s.magFilter = Ui, s.needsUpdate = !0, s.generateMipmaps = !1, s.flipY = !1, this._defaultPositionTexture = s, s
    }
    copyTexture(e, n) {
        this._mesh.material = this._copyShader, this._copyShader.uniforms.texture.value = e, this._renderer.setRenderTarget(n), this._renderer.render(this._scene, this._camera), this._renderer.setRenderTarget(null)
    }
    updatePosition(e) {
        this._mesh.material = this._positionShader, this._positionShader.uniforms.textureDefaultPosition.value = this._defaultPositionTexture, this._positionShader.uniforms.texturePosition.value = this._position.read.texture, this._positionShader.uniforms.time.value += e, this._renderer.setRenderTarget(this._position.write), this._renderer.render(this._scene, this._camera), this._renderer.setRenderTarget(null), this._position.swap()
    }
    update(e) {
        this._renderer.getClearColor(this._clearColor);
        const n = this._renderer.autoClearColor,
            r = this._clearColor.getHex(),
            i = this._renderer.getClearAlpha();
        this._renderer.autoClearColor = !1, this._positionShader.uniforms.delta.value = e, this._positionShader.uniforms.speed.value = 20 * e, this._positionShader.uniforms.dieSpeed.value = 1 * e, this._positionShader.uniforms.radius.value = .1, this._positionShader.uniforms.curlSize.value = .06, this._positionShader.uniforms.attraction.value = 2, this._positionShader.uniforms.mouse3d.value.lerp(this._mouse3d, 5 * e), this.updatePosition(e), this._renderer.setClearColor(r, i), this._renderer.autoClearColor = n
    }
    createDoubleFBO(e, n, {
        minFilter: r = Ti,
        magFilter: i = Ti,
        ...o
    }) {
        const s = {
                minFilter: r,
                magFilter: i,
                generateMipmaps: !1,
                ...o
            },
            a = {
                read: new Di(e, n, s),
                write: new Di(e, n, s),
                swap: () => {
                    const l = a.read;
                    a.read = a.write, a.write = l
                }
            };
        return a
    }
    get dataTextureWidth() {
        return zo
    }
    get dataTextureHeight() {
        return Io
    }
    get dataTextureAmount() {
        return Yc
    }
    get defaultPositionTexture() {
        return this._defaultPositionTexture
    }
    get positionTexture() {
        return this._position.read.texture
    }
    get mouse3d() {
        return this._mouse3d
    }
    static getInstance(e) {
        return this._instance || (this._instance = new this(e))
    }
}
ke(Yg, "_instance");
const qT = () => {
        const t = hr(({
                gl: n
            }) => n),
            [e] = u.useState(() => Yg.getInstance(t));
        return e
    },
    KT = u.forwardRef((t, e) => {
        const n = qT(),
            r = u.useRef(null),
            i = u.useMemo(() => {
                const s = new jh,
                    a = new Float32Array(n.dataTextureAmount * 3);
                for (let l = 0; l < n.dataTextureAmount; l++) a[l * 3 + 0] = l % n.dataTextureWidth / n.dataTextureWidth, a[l * 3 + 1] = ~~(l / n.dataTextureWidth) / n.dataTextureHeight, a[l * 3 + 2] = 0;
                return s.setAttribute("position", new Kc(a, 3)), s
            }, [n]),
            o = u.useMemo(() => new Zv({
                uniforms: ha.merge([ns.lights.pointLights, ns.fog, {
                    texturePosition: {
                        value: null
                    },
                    tDiffuse: {
                        value: new ff().load(`${or}spark.jpg`)
                    }
                }]),
                vertexShader: `
          #include <common>
          #include <fog_pars_vertex>
          #include <morphtarget_pars_vertex>
          #include <skinning_pars_vertex>
          #include <logdepthbuf_pars_vertex>
          #include <shadowmap_pars_vertex>

          uniform sampler2D texturePosition;

          varying float vLife;
          varying vec3 vWorldPosition;
          
          void main() {
            #include <beginnormal_vertex>
            #include <morphnormal_vertex>
            #include <skinbase_vertex>
            #include <skinnormal_vertex>
            #include <defaultnormal_vertex>

            #include <begin_vertex>
            #include <morphtarget_vertex>
            #include <skinning_vertex>
            // #include <project_vertex>

            vec4 positionInfo = texture2D( texturePosition, position.xy );
        
            vec4 worldPosition = modelMatrix * vec4( positionInfo.xyz, 1.0 );
            vec4 mvPosition = viewMatrix * worldPosition;
        
            vLife = positionInfo.w;
            gl_PointSize = 3. / length( mvPosition.xyz ) * smoothstep(0.0, 0.2, positionInfo.w);
        
            gl_Position = projectionMatrix * mvPosition;

            #include <logdepthbuf_vertex>

            // #include <worldpos_vertex>
            #include <shadowmap_vertex>
            #include <fog_vertex>
          
            vWorldPosition = worldPosition.xyz;
          
          }
        `,
                fragmentShader: `
          // chunk(common);
          // chunk(fog_pars_fragment);
          // chunk(shadowmap_pars_fragment);
          #include <common>
          #include <packing>
          #include <fog_pars_fragment>
          #include <bsdfs>
          #include <lights_pars_begin>
          #include <logdepthbuf_pars_fragment>
          #include <shadowmap_pars_fragment>
          #include <shadowmask_pars_fragment>

          varying float vLife;
          uniform vec3 color1;
          uniform vec3 color2;
          uniform sampler2D tDiffuse;
          varying vec3 vWorldPosition;

          vec4 pack1K ( float depth ) {
          
            depth /= 1000.0;
            const vec4 bitSh = vec4( 256.0 * 256.0 * 256.0, 256.0 * 256.0, 256.0, 1.0 );
            const vec4 bitMsk = vec4( 0.0, 1.0 / 256.0, 1.0 / 256.0, 1.0 / 256.0 );
            vec4 res = fract( depth * bitSh );
            res -= res.xxyz * bitMsk;
            return res;
          
          }

          void main() {
            #include <logdepthbuf_fragment>

            vec3 color1 = vec3(1., 1., 1.);
            // vec3 color2 = vec3(1., 1., 1.);
            vec3 color2 = vec3(18./255., 118./255., 170./255.);
            
            vec3 outgoingLight = mix(color2, color1, smoothstep(0.0, 1.0, vLife));

            float shadow = getShadowMask();
            vec3 shadowMask = vec3( 1.0 );
            shadowMask = shadowMask * vec3( 1.0 - getShadowMask() );

            // outgoingLight *= shadowMask;//pow(shadowMask, vec3(0.75));
            vec3 lightPos = vec3(0., 25., 0.);
            // outgoingLight = 50.-vec3(length( vWorldPosition.xyz- lightPos.xyz ));

            gl_FragColor = vec4( outgoingLight, 1. );

            #include <tonemapping_fragment>
            #include <encodings_fragment>
            #include <fog_fragment>
          }
        `,
                blending: Kl,
                transparent: !0,
                toneMapped: !1,
                fog: !0
            }), []);
        return u.useImperativeHandle(e, () => ({
            render: s => {
                n.update(s * .25);
                const a = r.current.material;
                a.uniforms.texturePosition.value = n.positionTexture
            }
        })), v.jsx("points", {
            ref: r,
            geometry: i,
            material: o,
            position: [.08, 0, 0],
            scale: .015
        })
    }),
    ZT = ({
        geometry: t,
        envMapRef: e,
        ...n
    }) => {
        const r = no(t),
            i = rn(e),
            o = u.useRef(null),
            [s] = u.useState(() => new dt(0, 0, 1)),
            [a] = u.useState(() => new dt(0, 0, 1)),
            l = u.useRef(null),
            c = u.useRef(null);
        return kn(({
            clock: d
        }, f) => {
            if (!l.current.userData.active) return;
            const h = d.getElapsedTime();
            l.current.position.x = 0 + Math.cos(h * .25) * .015, l.current.position.y = .036 + Math.sin(h * .5) * .03, s.lerp(a, f * 2), l.current.lookAt(s), c.current.render(f)
        }), u.useEffect(() => {
            const d = fi.subscribe(f => f.moveState, f => {
                const h = f.xy[0] / window.innerWidth * 2 - 1,
                    p = -(f.xy[1] / window.innerHeight) * 2 + 1;
                a.set(h * .1, p * .1, 1)
            });
            return () => {
                d()
            }
        }, [a]), bt("WatchModel"), v.jsx("group", {
            ref: l,
            position: [0, .1, 0],
            children: v.jsxs("group", {
                position: r.position,
                rotation: [-.212, .608, .132],
                children: [v.jsx("mesh", {
                    geometry: r.geometry,
                    scale: r.scale,
                    children: v.jsx("meshStandardMaterial", {
                        ref: o,
                        envMap: i,
                        ...n
                    })
                }), v.jsx(KT, {
                    ref: c
                })]
            })
        })
    },
    QT = ({
        uuid: t,
        ...e
    }) => v.jsx(ZT, {
        uuid: t,
        ...e
    }),
    JT = ({
        geometry: t,
        envMapRef: e,
        glowColor: n,
        glowEmissive: r,
        glowEmissiveIntensity: i,
        glowMetalness: o,
        glowRoughness: s,
        glowToneMapped: a,
        ...l
    }) => {
        const c = rn(e),
            d = no(t),
            [f] = u.useState(() => new dt(0, 0, 1)),
            [h] = u.useState(() => new dt(0, 0, 1)),
            [p] = u.useState(() => new dt(0, 0, 1)),
            m = u.useRef(null),
            g = u.useRef(null),
            y = An("Base", d),
            x = An("Webcam-rotation", d),
            w = An("Lens", x),
            M = An("White_Mat_Glass", x);
        return kn(() => {
            m.current.userData.active && (p.lerp(f, .1), g.current.lookAt(p))
        }), u.useEffect(() => {
            const T = fi.subscribe(O => O.moveState, O => {
                const R = O.xy[0] / window.innerWidth * 2 - 1,
                    P = -(O.xy[1] / window.innerHeight) * 2 + 1;
                f.set(R, P, 1), f.distanceTo(h) > .7 && f.set(0, 0, 1)
            });
            return () => {
                T()
            }
        }, [f, h]), bt("CameraModel"), v.jsxs("group", {
            ref: m,
            position: d.position,
            children: [v.jsx("mesh", {
                geometry: y.geometry,
                children: v.jsx("meshStandardMaterial", {
                    envMap: c,
                    ...l
                })
            }), v.jsxs("group", {
                ref: g,
                position: x.position,
                children: [v.jsx("mesh", {
                    geometry: x.geometry,
                    children: v.jsx("meshStandardMaterial", {
                        envMap: c,
                        ...l
                    })
                }), v.jsx("mesh", {
                    geometry: w.geometry,
                    position: w.position,
                    children: v.jsx("meshStandardMaterial", {
                        envMap: c,
                        ...l
                    })
                }), v.jsx("mesh", {
                    geometry: M.geometry,
                    position: M.position,
                    children: v.jsx("meshStandardMaterial", {
                        envMap: c,
                        color: n,
                        emissive: r,
                        emissiveIntensity: i,
                        metalness: o,
                        roughness: s,
                        toneMapped: a
                    })
                })]
            })]
        })
    },
    eP = ({
        uuid: t,
        color: e,
        emissive: n,
        emissiveIntensity: r,
        metalness: i,
        roughness: o,
        toneMapped: s,
        glowColor: a,
        glowEmissive: l,
        glowEmissiveIntensity: c,
        glowMetalness: d,
        glowRoughness: f,
        glowToneMapped: h,
        ...p
    }) => {
        const m = un("Scenes", {
                [Gt.capitalize(t)]: at({
                    Model: at({
                        Material: at({
                            color: {
                                value: e
                            },
                            emissive: {
                                value: n
                            },
                            emissiveIntensity: {
                                value: r,
                                min: 0,
                                max: 5
                            },
                            metalness: {
                                value: i,
                                min: 0,
                                max: 1
                            },
                            roughness: {
                                value: o,
                                min: 0,
                                max: 1
                            },
                            toneMapped: {
                                value: s
                            }
                        })
                    })
                })
            }),
            g = un("Scenes", {
                [Gt.capitalize(t)]: at({
                    Model: at({
                        LensMaterial: at({
                            glowColor: {
                                value: a
                            },
                            glowEmissive: {
                                value: l
                            },
                            glowEmissiveIntensity: {
                                value: c,
                                min: 0,
                                max: 5
                            },
                            glowMetalness: {
                                value: d,
                                min: 0,
                                max: 1
                            },
                            glowRoughness: {
                                value: f,
                                min: 0,
                                max: 1
                            },
                            glowToneMapped: {
                                value: h
                            }
                        })
                    })
                })
            });
        return v.jsx(JT, {
            uuid: t,
            ...m,
            ...g,
            ...p
        })
    };
class tP extends mf {
    constructor(n) {
        super(n);
        ke(this, "_time");
        ke(this, "_mouse");
        ke(this, "_noise");
        ke(this, "_disp");
        this._time = {
            value: 0
        }, this._mouse = {
            value: new dt
        }, this._noise = {
            value: new yl
        }, this._disp = {
            value: new dt
        }
    }
    onBeforeCompile(n) {
        n.uniforms.time = this._time, n.uniforms.mouse = this._mouse, n.uniforms.noise = this._noise, n.uniforms.disp = this._disp, n.vertexShader = `
      attribute vec3 offset;
      attribute float indx;

      uniform vec3 mouse;
      uniform vec4 noise;
      uniform vec3 disp;

      uniform float time;

      //	Simplex 3D Noise 
      //	by Ian McEwan, Ashima Arts
      //
      vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
      vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}

      float snoise(vec3 v){ 
        const vec2  C = vec2(1.0/6.0, 1.0/3.0) ;
        const vec4  D = vec4(0.0, 0.5, 1.0, 2.0);

        // First corner
        vec3 i  = floor(v + dot(v, C.yyy) );
        vec3 x0 =   v - i + dot(i, C.xxx) ;

        // Other corners
        vec3 g = step(x0.yzx, x0.xyz);
        vec3 l = 1.0 - g;
        vec3 i1 = min( g.xyz, l.zxy );
        vec3 i2 = max( g.xyz, l.zxy );

        //  x0 = x0 - 0. + 0.0 * C 
        vec3 x1 = x0 - i1 + 1.0 * C.xxx;
        vec3 x2 = x0 - i2 + 2.0 * C.xxx;
        vec3 x3 = x0 - 1. + 3.0 * C.xxx;

        // Permutations
        i = mod(i, 289.0 ); 
        vec4 p = permute( permute( permute( 
                  i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
                + i.y + vec4(0.0, i1.y, i2.y, 1.0 )) 
                + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));

        // Gradients
        // ( N*N points uniformly over a square, mapped onto an octahedron.)
        float n_ = 1.0/7.0; // N=7
        vec3  ns = n_ * D.wyz - D.xzx;

        vec4 j = p - 49.0 * floor(p * ns.z *ns.z);  //  mod(p,N*N)

        vec4 x_ = floor(j * ns.z);
        vec4 y_ = floor(j - 7.0 * x_ );    // mod(j,N)

        vec4 x = x_ *ns.x + ns.yyyy;
        vec4 y = y_ *ns.x + ns.yyyy;
        vec4 h = 1.0 - abs(x) - abs(y);

        vec4 b0 = vec4( x.xy, y.xy );
        vec4 b1 = vec4( x.zw, y.zw );

        vec4 s0 = floor(b0)*2.0 + 1.0;
        vec4 s1 = floor(b1)*2.0 + 1.0;
        vec4 sh = -step(h, vec4(0.0));

        vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy ;
        vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww ;

        vec3 p0 = vec3(a0.xy,h.x);
        vec3 p1 = vec3(a0.zw,h.y);
        vec3 p2 = vec3(a1.xy,h.z);
        vec3 p3 = vec3(a1.zw,h.w);

        //Normalise gradients
        vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
        p0 *= norm.x;
        p1 *= norm.y;
        p2 *= norm.z;
        p3 *= norm.w;

        // Mix final noise value
        vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
        m = m * m;
        return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1), 
                                      dot(p2,x2), dot(p3,x3) ) );
      }

      vec3 snoiseVec3( vec3 x ){
        float s  = snoise(vec3( x ));
        float s1 = snoise(vec3( x.y - 19.1 , x.z + 33.4 , x.x + 47.2 ));
        float s2 = snoise(vec3( x.z + 74.2 , x.x - 124.5 , x.y + 99.4 ));
        vec3 c = vec3( s , s1 , s2 );
        return c;
      }
      
      ${n.vertexShader}
    `, n.vertexShader = n.vertexShader.replace("#include <begin_vertex>", `
        vec3 pos = position;

        float dist = length(pos.xy - mouse.xy);

        float threshold = disp.x;
        float strength = dist / disp.y;
        float displacement = mix(0.0, strength, smoothstep(threshold, threshold + disp.z, dist));

        float vx = noise.x;
        float vy = noise.y;
        float vz = noise.z * .1;
        float vw = noise.w * displacement;

        pos += snoiseVec3(pos * vx + (time + indx * vy) * vz) * vw;
        
        vec3 transformed = pos;
      `)
    }
    get time() {
        return this._time.value
    }
    set time(n) {
        this._time.value = n
    }
    get mouse() {
        return this._mouse.value
    }
    set mouse(n) {
        this._mouse.value = n
    }
    get noise() {
        return this._noise.value
    }
    set noise(n) {
        this._noise.value = n
    }
    get disp() {
        return this._disp.value
    }
    set disp(n) {
        this._disp.value = n
    }
}
const nP = u.forwardRef(({
        geometry: t,
        envMapRef: e,
        ...n
    }, r) => {
        u.useMemo(() => Ur({
            DisplaceMaterial: tP
        }), []);
        const i = rn(e),
            o = no(t),
            s = o.geometry.attributes.position.count,
            a = u.useRef(null),
            l = wr([a, r]),
            c = u.useRef(null),
            [d] = u.useState(() => new dt(0, 0, 0)),
            [f] = u.useState(() => new dt(0, 0, .45)),
            [h] = u.useState(() => Math.random() * 1e3),
            [p] = u.useState(() => new dt(0, 0, 0)),
            m = u.useMemo(() => iP({
                count: s
            }), [s]),
            g = u.useRef(null);
        return kn(({
            camera: y,
            clock: x
        }) => {
            var O;
            if (!a.current.userData.active) return;
            d.copy(p), d.unproject(y);
            const w = d.sub(y.position).normalize(),
                M = (f.z - y.position.z) / w.z,
                T = y.position.clone().add(w.multiplyScalar(M));
            c.current.time = h + x.getElapsedTime(), c.current.mouse.lerp(T, .05), (O = g.current) == null || O.position.lerp(T, .05)
        }), u.useEffect(() => {
            const y = fi.subscribe(x => x.moveState, x => {
                const w = x.xy[0] / window.innerWidth * 2 - 1,
                    M = -(x.xy[1] / window.innerHeight) * 2 + 1;
                p.set(w, M, 0)
            });
            return () => {
                y()
            }
        }, [p]), bt("DisplaceModel"), v.jsx(v.Fragment, {
            children: v.jsxs("mesh", {
                ref: l,
                name: "model",
                children: [v.jsxs("bufferGeometry", {
                    index: o.geometry.index,
                    "attributes-normal": o.geometry.attributes.normal,
                    "attributes-position": o.geometry.attributes.position,
                    children: [v.jsx("bufferAttribute", {
                        attach: "attributes-offset",
                        args: [m.offsets, 3]
                    }), v.jsx("bufferAttribute", {
                        attach: "attributes-indx",
                        args: [m.indices, 1]
                    })]
                }), v.jsx("displaceMaterial", {
                    ref: c,
                    envMap: i,
                    ...n
                })]
            })
        })
    }),
    rP = ({
        uuid: t,
        ...e
    }) => {
        const n = u.useRef(null);
        return un("Scenes", {
            [Gt.capitalize(t)]: at({
                Model: at({
                    Noise: at({
                        vx: {
                            value: 3,
                            min: 0,
                            max: 5,
                            step: .01,
                            onChange: r => n.current.material.noise.setX(r)
                        },
                        vy: {
                            value: 3,
                            min: 0,
                            max: 5,
                            step: .01,
                            onChange: r => n.current.material.noise.setY(r)
                        },
                        vz: {
                            value: 3,
                            min: 0,
                            max: 5,
                            step: .01,
                            onChange: r => n.current.material.noise.setZ(r)
                        },
                        vw: {
                            value: 1,
                            min: 0,
                            max: 5,
                            step: .01,
                            onChange: r => n.current.material.noise.setW(r)
                        }
                    }),
                    Displacement: at({
                        threshold: {
                            value: .15,
                            min: 0,
                            max: 1,
                            step: .01,
                            onChange: r => n.current.material.disp.setX(r)
                        },
                        strength: {
                            value: 50,
                            min: 0,
                            max: 100,
                            step: 1,
                            onChange: r => n.current.material.disp.setY(r)
                        },
                        offset: {
                            value: .05,
                            min: 0,
                            max: 1,
                            step: .01,
                            onChange: r => n.current.material.disp.setZ(r)
                        }
                    })
                })
            })
        }), v.jsx(nP, {
            ref: n,
            uuid: t,
            ...e
        })
    };

function iP({
    count: t
}) {
    const e = [],
        n = [];
    for (let r = t - 1; r >= 0; --r) {
        const i = He.randFloatSpread(1);
        e.push(i, i, i), n.push(He.randFloat(0, 1))
    }
    return {
        offsets: new Float32Array(e),
        indices: new Float32Array(n)
    }
}
class oP extends mf {
    constructor(n) {
        super(n);
        ke(this, "_time");
        ke(this, "_mouse");
        this._time = {
            value: 0
        }, this._mouse = {
            value: new dt
        }
    }
    onBeforeCompile(n) {
        n.uniforms.time = this._time, n.uniforms.mouse = this._mouse, n.vertexShader = `
      attribute vec3 translate;

      uniform vec3 mouse;
      uniform float time;

      mat4 translateMatrix (vec3 v) {
        return mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,1.0,0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(v.x,v.y,v.z,1.0) );
      }
    
      mat4 rotateMatrix (vec3 v) {
        mat4 rx = mat4( vec4(1.0,0.0,0.0,0.0), vec4(0.0,cos(v.x),-sin(v.x),0.0), vec4(0.0,sin(v.x),cos(v.x),0.0), vec4(0.0,0.0,0.0,1.0) );
        mat4 ry = mat4( vec4(cos(v.y),0.0,sin(v.y),0.0), vec4(0.0,1.0,0.0,0.0), vec4(-sin(v.y),0.0,cos(v.y),0.0), vec4(0.0,0.0,0.0,1.0) );
        mat4 rz = mat4( vec4(cos(v.z),-sin(v.z),0.0,0.0), vec4(sin(v.z),cos(v.z),0.0,0.0), vec4(0.0,0.0,1.0,0.0), vec4(0.0,0.0,0.0,1.0) );
        return rx * rz * ry;
      }
    
      mat4 scaleMatrix (vec3 v) {
        return mat4( vec4(v.x,0.0,0.0,0.0), vec4(0.0,v.y,0.0,0.0), vec4(0.0,0.0,v.z,0.0), vec4(0.0,0.0,0.0,1.0) );
      }
    
      mat4 transformMatrix (vec3 t, vec3 r, vec3 s) {
        mat4 ms = scaleMatrix(s);
        mat4 mt = translateMatrix(t);
        mat4 mr = rotateMatrix(r);
        return mt * mr * ms;
      }

      ${n.vertexShader}
    `, n.vertexShader = n.vertexShader.replace("#include <begin_vertex>", `
        float tx = time * .15;
        float ty = 0.;//time * -.05;
        float tz = time * .15;

        vec4 cameraLocalPosition = vec4(cameraPosition, 1) * rotateMatrix(vec3(tx,ty,tz));
        vec3 cameraVector = cameraLocalPosition.xyz - translate;
        vec3 localUpVector = vec3(0, 1, 0);

        vec3 zaxis = normalize(cameraVector);
        vec3 xaxis = normalize(cross(localUpVector, zaxis));
        vec3 yaxis = cross(zaxis, xaxis);

        mat3 lookAtMatrix = mat3(xaxis, yaxis, zaxis);

        vec3 transformed = lookAtMatrix * position + translate;
      `), n.vertexShader = n.vertexShader.replace("#include <project_vertex>", `
      mat4 transformedMatrix = transformMatrix(vec3(0.,.25,.6), vec3(tx,ty,tz), vec3(1.));
      vec4 mvPosition = transformedMatrix * vec4( transformed, 1.0 );

      #ifdef USE_INSTANCING

        mvPosition = instanceMatrix * mvPosition;

      #endif

      mvPosition = modelViewMatrix * mvPosition;

      gl_Position = projectionMatrix * mvPosition;
      `)
    }
    get time() {
        return this._time.value
    }
    set time(n) {
        this._time.value = n
    }
    get mouse() {
        return this._mouse.value
    }
    set mouse(n) {
        this._mouse.value = n
    }
}
const sP = ({
        geometry: t,
        envMapRef: e,
        ...n
    }) => {
        u.useMemo(() => Ur({
            InstancedMaterial: oP
        }), []);
        const r = Pm(t),
            i = rn(e),
            o = u.useRef(null),
            s = u.useRef(null),
            [a] = u.useState(() => 5),
            [l] = u.useState(() => new dt),
            [c] = u.useState(() => Math.random() * 1e3),
            d = u.useMemo(() => Math.pow(a, 3), [a]),
            f = u.useMemo(() => lP({
                count: d
            }), [d]);
        return kn(({
            clock: h
        }) => {
            o.current.userData.active && (s.current.time = c + h.getElapsedTime(), s.current.mouse.set(l.x, l.y, 0))
        }), u.useEffect(() => {
            const h = fi.subscribe(p => p.moveState, p => {
                const m = p.xy[0] / window.innerWidth * 2 - 1,
                    g = -(p.xy[1] / window.innerHeight) * 2 + 1;
                l.set(m, g + .2, -.163)
            });
            return () => {
                h()
            }
        }, [l]), bt("InstancedModel"), v.jsxs("mesh", {
            ref: o,
            children: [v.jsx("instancedBufferGeometry", {
                instanceCount: d,
                index: r.geometry.index,
                "attributes-uv": r.geometry.attributes.uv,
                "attributes-normal": r.geometry.attributes.normal,
                "attributes-position": r.geometry.attributes.position,
                children: v.jsx("instancedBufferAttribute", {
                    attach: "attributes-translate",
                    args: [f.translates, 3]
                })
            }), v.jsx("instancedMaterial", {
                ref: s,
                envMap: i,
                ...n
            })]
        })
    },
    aP = ({
        uuid: t,
        ...e
    }) => v.jsx(sP, {
        uuid: t,
        ...e
    }),
    lP = ({
        count: t = 1
    }) => {
        const e = [];
        for (let i = t - 1; i >= 0; --i) {
            const o = Math.floor(i / 25),
                s = Math.floor(i % (5 * 5) / 5),
                a = i % 5,
                l = (s - (5 - 1) / 2) * .158,
                c = (a - (5 - 1) / 2) * .158,
                d = (o - (5 - 1) / 2) * .158;
            e.push(l, c, d)
        }
        return {
            translates: new Float32Array(e)
        }
    },
    cP = Object.freeze(Object.defineProperty({
        __proto__: null,
        AnimatedModel: IT,
        BaseModel: jT,
        Cables: yT,
        CameraModel: eP,
        DisplaceModel: rP,
        FloatModel: NT,
        FlowersModel: GT,
        Fog: X3,
        Ground: K3,
        InstancedModel: aP,
        Leafs: hT,
        Portal: rT,
        Smoke: lT,
        Sparkles: TT,
        Spheres: _T,
        Underground: MT,
        Upperground: OT,
        WatchModel: QT
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    uP = ({
        scenes: t,
        onCompiled: e
    }) => {
        const n = hr(({
                gl: i
            }) => i),
            r = hr(({
                camera: i
            }) => i);
        return u.useLayoutEffect(() => {
            console.time("compile"), Gt.forEach(t, i => Gt.forEach(i.children, o => {
                o.userData.active = !0
            })), console.time("compile::scenes"), Gt.forEach(t, i => n.compile(i, r)), console.timeEnd("compile::scenes"), console.timeEnd("compile"), he.delayedCall(.3, e)
        }, []), null
    },
    fP = ({
        uuid: t,
        components: e
    }) => v.jsx(v.Fragment, {
        children: e.map(({
            name: n,
            ...r
        }) => {
            const i = cP[n];
            return v.jsx(u.Fragment, {
                children: i && v.jsx(i, {
                    uuid: t,
                    ...r
                })
            }, n)
        })
    }),
    dP = () => {
        u.useMemo(() => he.registerPlugin(bs), []);
        const {
            scenes: t,
            settings: e
        } = nr(), n = u.useMemo(() => Array.from({
            length: t.length
        }).map(() => new Nh), [t]), r = u.useRef(null), {
            getSamples: i
        } = Da(), o = u.useRef(0), s = u.useRef(0), a = Gr(), l = u.useRef(null), c = u.useRef(null), d = u.useMemo(() => Sa(), []), f = u.useMemo(() => ({
            wrapT: Qv,
            wrapS: Qc,
            generateMipmaps: !1,
            samples: i()
        }), [i]), h = u.useRef(!0), p = u.useRef(!1), m = Lp(f), g = Lp(f), y = u.useRef(!1), x = Gn(P => P.compile), w = u.useCallback(P => {
            const B = (P % 1 + 1) % 1,
                te = He.clamp(1 - B, 0, 1),
                W = c.current.material;
            W.uniforms.uTransition.value = te
        }, []), M = u.useCallback(P => {
            const B = P,
                te = c.current.material;
            te.uniforms.uLeafTransition.value = B
        }, []), T = u.useCallback(P => {
            const B = c.current.material,
                te = He.mapLinear(P, d.y, -1, -0, -1);
            B.uniforms.uCameraTransition.value = Math.abs(te)
        }, [d]), O = u.useCallback((P, B) => {
            const te = c.current.material;
            te.uniforms.uXAxis.value = P, te.uniforms.uYAxis.value = B
        }, []), R = u.useCallback(([P, B]) => {
            const te = P !== void 0 && B !== void 0;
            Gt.forEach(n, (W, ee) => Gt.forEach(W.children, V => {
                V.userData.active = te ? ee === P || ee === B : ee === P
            }))
        }, [n]);
        return kn(({
            gl: P,
            camera: B
        }, te) => {
            if (!y.current) return;
            const W = a.motionValue.get(),
                ee = a.getNextMotionIndex(W),
                V = a.getPrevMotionIndex(W),
                I = n[ee],
                X = n[V];
            if (a.needsUnderground() && !a.cameraMotionValue.isAnimating() || a.needsUpperground() && !a.leafMotionValue.isAnimating()) r.current.render(X);
            else if (ee === V) r.current.render(I);
            else {
                const q = h.current ? X : I,
                    Z = h.current ? m : g,
                    le = a.getDirection();
                ee !== o.current || V !== s.current || p.current ? (p.current = !1, R([ee, V]), (a.needsUnderground() || a.needsUpperground()) && le < 0 || !a.needsUnderground() && !a.needsUpperground() && le > 0 ? (P.setRenderTarget(m), P.clear(), P.render(X, B)) : (P.setRenderTarget(g), P.clear(), P.render(I, B))) : (P.setRenderTarget(Z), P.clear(), P.render(q, B)), P.setRenderTarget(null), h.current = !h.current, c.current.material.uniforms.uScene0.value = m.texture, c.current.material.uniforms.uScene1.value = g.texture, c.current.material.uniforms.uVelocity.value = He.lerp(c.current.material.uniforms.uVelocity.value, a.motionValue.getVelocity(), te * 10), r.current.render(l.current)
            }
            o.current = ee, s.current = V
        }), u.useEffect(() => {
            const P = () => {
                    O(1, 0)
                },
                B = W => {
                    w(W.value)
                },
                te = W => {
                    R([W.value])
                };
            return a.motionValue.addEventListener("start", P), a.motionValue.addEventListener("update", B), a.motionValue.addEventListener("complete", te), () => {
                a.motionValue.removeEventListener("start", P), a.motionValue.removeEventListener("update", B), a.motionValue.removeEventListener("complete", te)
            }
        }, [a, R, w, O]), u.useEffect(() => {
            const P = W => {
                    O(0, 1), !(W.direction > 0) && (p.current = !0)
                },
                B = W => {
                    T(W.value)
                },
                te = W => {
                    R([W.value]), !(W.direction > 0) && O(1, 0)
                };
            return a.cameraMotionValue.addEventListener("start", P), a.cameraMotionValue.addEventListener("update", B), a.cameraMotionValue.addEventListener("complete", te), () => {
                a.cameraMotionValue.removeEventListener("start", P), a.cameraMotionValue.removeEventListener("update", B), a.cameraMotionValue.removeEventListener("complete", te)
            }
        }, [a, R, T, O]), u.useEffect(() => {
            const P = W => {
                    O(0, -1), !(W.direction > 0) && (p.current = !0)
                },
                B = W => {
                    M(W.value)
                },
                te = W => {
                    R([W.value]), !(W.direction > 0) && O(1, 0)
                };
            return a.leafMotionValue.addEventListener("start", P), a.leafMotionValue.addEventListener("update", B), a.leafMotionValue.addEventListener("complete", te), () => {
                a.leafMotionValue.removeEventListener("start", P), a.leafMotionValue.removeEventListener("update", B), a.leafMotionValue.removeEventListener("complete", te)
            }
        }, [a, R, M, O]), u.useEffect(() => {
            const P = Bn.subscribe(B => B.route, B => B.initial && R([B.index]), {
                fireImmediately: !0
            });
            return () => {
                P()
            }
        }, [R]), u.useEffect(() => {
            const P = Gn.subscribe(B => B.compiled, B => y.current = B);
            return () => {
                P()
            }
        }, []), bt("Composer"), v.jsxs(v.Fragment, {
            children: [n.map((P, B) => v.jsx(u.Fragment, {
                children: yv(v.jsx(fP, { ...t[B]
                }), P)
            }, `scene-${B}`)), v.jsx("scene", {}), v.jsx("scene", {
                ref: l,
                children: v.jsx(f3, {
                    ref: c
                })
            }), v.jsx(G3, {
                ref: r,
                ...e.effects
            }), v.jsx(uP, {
                scenes: n,
                onCompiled: x
            })]
        })
    },
    pP = () => {
        u.useMemo(() => ny.init(), []);
        const t = Gn(r => r.loaded),
            {
                getDPR: e,
                needsWebgl1: n
            } = Da();
        return bt("Stage"), v.jsxs(xv, {
            style: {
                position: "absolute",
                top: 0,
                left: 0,
                zIndex: 0
            },
            dpr: [1, e()],
            gl: n() ? r => new Jv({
                canvas: r,
                powerPreference: "default",
                antialias: !1,
                stencil: !1,
                depth: !1
            }) : {
                powerPreference: "default",
                autoClear: !1,
                antialias: !1,
                stencil: !1,
                depth: !1
            },
            children: [v.jsx("color", {
                attach: "background",
                args: ["#000000"]
            }), v.jsx(a3, {}), t && v.jsxs(v.Fragment, {
                children: [v.jsx(kS, {}), v.jsx(dP, {})]
            })]
        })
    },
    hP = () => v.jsx(TS, {
        children: v.jsx(jS, {
            children: v.jsxs(nC, {
                children: [v.jsx(pP, {}), v.jsx(s3, {}), v.jsx(o3, {}), v.jsx(Tv, {
                    router: Bg
                }), v.jsx(ym, {
                    hidden: !0,
                    collapsed: !0
                })]
            })
        })
    });
/*!
 * CustomEase 3.12.2
 * https://greensock.com
 *
 * @license Copyright 2008-2023, GreenSock. All rights reserved.
 * Subject to the terms at https://greensock.com/standard-license or for
 * Club GreenSock members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var yr, Xg, qg = function() {
        return yr || typeof window < "u" && (yr = window.gsap) && yr.registerPlugin && yr
    },
    $h = function() {
        yr = qg(), yr ? (yr.registerEase("_CE", Ra.create), Xg = 1) : console.warn("Please gsap.registerPlugin(CustomEase)")
    },
    mP = 1e20,
    sl = function(e) {
        return ~~(e * 1e3 + (e < 0 ? -.5 : .5)) / 1e3
    },
    gP = /[-+=\.]*\d+[\.e\-\+]*\d*[e\-\+]*\d*/gi,
    vP = /[cLlsSaAhHvVtTqQ]/g,
    yP = function(e) {
        var n = e.length,
            r = mP,
            i;
        for (i = 1; i < n; i += 6) + e[i] < r && (r = +e[i]);
        return r
    },
    xP = function(e, n, r) {
        !r && r !== 0 && (r = Math.max(+e[e.length - 1], +e[1]));
        var i = +e[0] * -1,
            o = -r,
            s = e.length,
            a = 1 / (+e[s - 2] + i),
            l = -n || (Math.abs(+e[s - 1] - +e[1]) < .01 * (+e[s - 2] - +e[0]) ? yP(e) + o : +e[s - 1] + o),
            c;
        for (l ? l = 1 / l : l = -a, c = 0; c < s; c += 2) e[c] = (+e[c] + i) * a, e[c + 1] = (+e[c + 1] + o) * l
    },
    bP = function t(e, n, r, i, o, s, a, l, c, d, f) {
        var h = (e + r) / 2,
            p = (n + i) / 2,
            m = (r + o) / 2,
            g = (i + s) / 2,
            y = (o + a) / 2,
            x = (s + l) / 2,
            w = (h + m) / 2,
            M = (p + g) / 2,
            T = (m + y) / 2,
            O = (g + x) / 2,
            R = (w + T) / 2,
            P = (M + O) / 2,
            B = a - e,
            te = l - n,
            W = Math.abs((r - a) * te - (i - l) * B),
            ee = Math.abs((o - a) * te - (s - l) * B),
            V;
        return d || (d = [{
            x: e,
            y: n
        }, {
            x: a,
            y: l
        }], f = 1), d.splice(f || d.length - 1, 0, {
            x: R,
            y: P
        }), (W + ee) * (W + ee) > c * (B * B + te * te) && (V = d.length, t(e, n, h, p, w, M, R, P, c, d, f), t(R, P, T, O, y, x, a, l, c, d, f + 1 + (d.length - V))), d
    },
    Ra = function() {
        function t(n, r, i) {
            Xg || $h(), this.id = n, this.setData(r, i)
        }
        var e = t.prototype;
        return e.setData = function(r, i) {
            i = i || {}, r = r || "0,0,1,1";
            var o = r.match(gP),
                s = 1,
                a = [],
                l = [],
                c = i.precision || 1,
                d = c <= 1,
                f, h, p, m, g, y, x, w, M;
            if (this.data = r, (vP.test(r) || ~r.indexOf("M") && r.indexOf("C") < 0) && (o = ua(r)[0]), f = o.length, f === 4) o.unshift(0, 0), o.push(1, 1), f = 8;
            else if ((f - 2) % 6) throw "Invalid CustomEase";
            for ((+o[0] != 0 || +o[f - 2] != 1) && xP(o, i.height, i.originY), this.segment = o, m = 2; m < f; m += 6) h = {
                x: +o[m - 2],
                y: +o[m - 1]
            }, p = {
                x: +o[m + 4],
                y: +o[m + 5]
            }, a.push(h, p), bP(h.x, h.y, +o[m], +o[m + 1], +o[m + 2], +o[m + 3], p.x, p.y, 1 / (c * 2e5), a, a.length - 1);
            for (f = a.length, m = 0; m < f; m++) x = a[m], w = a[m - 1] || x, (x.x > w.x || w.y !== x.y && w.x === x.x || x === w) && x.x <= 1 ? (w.cx = x.x - w.x, w.cy = x.y - w.y, w.n = x, w.nx = x.x, d && m > 1 && Math.abs(w.cy / w.cx - a[m - 2].cy / a[m - 2].cx) > 2 && (d = 0), w.cx < s && (w.cx ? s = w.cx : (w.cx = .001, m === f - 1 && (w.x -= .001, s = Math.min(s, .001), d = 0)))) : (a.splice(m--, 1), f--);
            if (f = 1 / s + 1 | 0, g = 1 / f, y = 0, x = a[0], d) {
                for (m = 0; m < f; m++) M = m * g, x.nx < M && (x = a[++y]), h = x.y + (M - x.x) / x.cx * x.cy, l[m] = {
                    x: M,
                    cx: g,
                    y: h,
                    cy: 0,
                    nx: 9
                }, m && (l[m - 1].cy = h - l[m - 1].y);
                l[f - 1].cy = a[a.length - 1].y - h
            } else {
                for (m = 0; m < f; m++) x.nx < m * g && (x = a[++y]), l[m] = x;
                y < a.length - 1 && (l[m - 1] = a[a.length - 2])
            }
            return this.ease = function(T) {
                var O = l[T * f | 0] || l[f - 1];
                return O.nx < T && (O = O.n), O.y + (T - O.x) / O.cx * O.cy
            }, this.ease.custom = this, this.id && yr && yr.registerEase(this.id, this.ease), this
        }, e.getSVGData = function(r) {
            return t.getSVGData(this, r)
        }, t.create = function(r, i, o) {
            return new t(r, i, o).ease
        }, t.register = function(r) {
            yr = r, $h()
        }, t.get = function(r) {
            return yr.parseEase(r)
        }, t.getSVGData = function(r, i) {
            i = i || {};
            var o = i.width || 100,
                s = i.height || 100,
                a = i.x || 0,
                l = (i.y || 0) + s,
                c = yr.utils.toArray(i.path)[0],
                d, f, h, p, m, g, y, x, w, M;
            if (i.invert && (s = -s, l = 0), typeof r == "string" && (r = yr.parseEase(r)), r.custom && (r = r.custom), r instanceof t) d = qf(Vo([r.segment], o, 0, 0, -s, a, l));
            else {
                for (d = [a, l], y = Math.max(5, (i.precision || 1) * 200), p = 1 / y, y += 2, x = 5 / y, w = sl(a + p * o), M = sl(l + r(p) * -s), f = (M - l) / (w - a), h = 2; h < y; h++) m = sl(a + h * p * o), g = sl(l + r(h * p) * -s), (Math.abs((g - M) / (m - w) - f) > x || h === y - 1) && (d.push(w, M), f = (g - M) / (m - w)), w = m, M = g;
                d = "M" + d.join(",")
            }
            return c && c.setAttribute("d", d), d
        }, t
    }();
qg() && yr.registerPlugin(Ra);
Ra.version = "3.12.2";
he.registerPlugin(Ra, Ea);
Ra.create("expoCurve.inOut", "M0,0,C0.25,0,0.294,0.023,0.335,0.05,0.428,0.11,0.466,0.292,0.498,0.502,0.532,0.73,0.586,0.88,0.64,0.928,0.679,0.962,0.698,1,1,1");
bv.createRoot(document.getElementById("root")).render(v.jsx(hP, {}));