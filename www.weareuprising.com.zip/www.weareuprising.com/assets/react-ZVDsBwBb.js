function ic(e, t) {
    for (var n = 0; n < t.length; n++) {
        const r = t[n];
        if (typeof r != "string" && !Array.isArray(r)) {
            for (const l in r)
                if (l !== "default" && !(l in e)) {
                    const i = Object.getOwnPropertyDescriptor(r, l);
                    i && Object.defineProperty(e, l, i.get ? i : {
                        enumerable: !0,
                        get: () => r[l]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }))
}
var qv = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function Eu(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var oc = {
        exports: {}
    },
    H = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var sl = Symbol.for("react.element"),
    np = Symbol.for("react.portal"),
    rp = Symbol.for("react.fragment"),
    lp = Symbol.for("react.strict_mode"),
    ip = Symbol.for("react.profiler"),
    op = Symbol.for("react.provider"),
    up = Symbol.for("react.context"),
    ap = Symbol.for("react.forward_ref"),
    sp = Symbol.for("react.suspense"),
    cp = Symbol.for("react.memo"),
    fp = Symbol.for("react.lazy"),
    Ta = Symbol.iterator;

function dp(e) {
    return e === null || typeof e != "object" ? null : (e = Ta && e[Ta] || e["@@iterator"], typeof e == "function" ? e : null)
}
var uc = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    ac = Object.assign,
    sc = {};

function ar(e, t, n) {
    this.props = e, this.context = t, this.refs = sc, this.updater = n || uc
}
ar.prototype.isReactComponent = {};
ar.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
ar.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function cc() {}
cc.prototype = ar.prototype;

function ku(e, t, n) {
    this.props = e, this.context = t, this.refs = sc, this.updater = n || uc
}
var xu = ku.prototype = new cc;
xu.constructor = ku;
ac(xu, ar.prototype);
xu.isPureReactComponent = !0;
var Na = Array.isArray,
    fc = Object.prototype.hasOwnProperty,
    Cu = {
        current: null
    },
    dc = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function pc(e, t, n) {
    var r, l = {},
        i = null,
        o = null;
    if (t != null)
        for (r in t.ref !== void 0 && (o = t.ref), t.key !== void 0 && (i = "" + t.key), t) fc.call(t, r) && !dc.hasOwnProperty(r) && (l[r] = t[r]);
    var u = arguments.length - 2;
    if (u === 1) l.children = n;
    else if (1 < u) {
        for (var a = Array(u), s = 0; s < u; s++) a[s] = arguments[s + 2];
        l.children = a
    }
    if (e && e.defaultProps)
        for (r in u = e.defaultProps, u) l[r] === void 0 && (l[r] = u[r]);
    return {
        $$typeof: sl,
        type: e,
        key: i,
        ref: o,
        props: l,
        _owner: Cu.current
    }
}

function pp(e, t) {
    return {
        $$typeof: sl,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function _u(e) {
    return typeof e == "object" && e !== null && e.$$typeof === sl
}

function hp(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var La = /\/+/g;

function Ki(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? hp("" + e.key) : t.toString(36)
}

function Ul(e, t, n, r, l) {
    var i = typeof e;
    (i === "undefined" || i === "boolean") && (e = null);
    var o = !1;
    if (e === null) o = !0;
    else switch (i) {
        case "string":
        case "number":
            o = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case sl:
                case np:
                    o = !0
            }
    }
    if (o) return o = e, l = l(o), e = r === "" ? "." + Ki(o, 0) : r, Na(l) ? (n = "", e != null && (n = e.replace(La, "$&/") + "/"), Ul(l, t, n, "", function(s) {
        return s
    })) : l != null && (_u(l) && (l = pp(l, n + (!l.key || o && o.key === l.key ? "" : ("" + l.key).replace(La, "$&/") + "/") + e)), t.push(l)), 1;
    if (o = 0, r = r === "" ? "." : r + ":", Na(e))
        for (var u = 0; u < e.length; u++) {
            i = e[u];
            var a = r + Ki(i, u);
            o += Ul(i, t, n, a, l)
        } else if (a = dp(e), typeof a == "function")
            for (e = a.call(e), u = 0; !(i = e.next()).done;) i = i.value, a = r + Ki(i, u++), o += Ul(i, t, n, a, l);
        else if (i === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return o
}

function Sl(e, t, n) {
    if (e == null) return e;
    var r = [],
        l = 0;
    return Ul(e, r, "", "", function(i) {
        return t.call(n, i, l++)
    }), r
}

function mp(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var Oe = {
        current: null
    },
    Al = {
        transition: null
    },
    vp = {
        ReactCurrentDispatcher: Oe,
        ReactCurrentBatchConfig: Al,
        ReactCurrentOwner: Cu
    };
H.Children = {
    map: Sl,
    forEach: function(e, t, n) {
        Sl(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return Sl(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return Sl(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!_u(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
H.Component = ar;
H.Fragment = rp;
H.Profiler = ip;
H.PureComponent = ku;
H.StrictMode = lp;
H.Suspense = sp;
H.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = vp;
H.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = ac({}, e.props),
        l = e.key,
        i = e.ref,
        o = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (i = t.ref, o = Cu.current), t.key !== void 0 && (l = "" + t.key), e.type && e.type.defaultProps) var u = e.type.defaultProps;
        for (a in t) fc.call(t, a) && !dc.hasOwnProperty(a) && (r[a] = t[a] === void 0 && u !== void 0 ? u[a] : t[a])
    }
    var a = arguments.length - 2;
    if (a === 1) r.children = n;
    else if (1 < a) {
        u = Array(a);
        for (var s = 0; s < a; s++) u[s] = arguments[s + 2];
        r.children = u
    }
    return {
        $$typeof: sl,
        type: e.type,
        key: l,
        ref: i,
        props: r,
        _owner: o
    }
};
H.createContext = function(e) {
    return e = {
        $$typeof: up,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: op,
        _context: e
    }, e.Consumer = e
};
H.createElement = pc;
H.createFactory = function(e) {
    var t = pc.bind(null, e);
    return t.type = e, t
};
H.createRef = function() {
    return {
        current: null
    }
};
H.forwardRef = function(e) {
    return {
        $$typeof: ap,
        render: e
    }
};
H.isValidElement = _u;
H.lazy = function(e) {
    return {
        $$typeof: fp,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: mp
    }
};
H.memo = function(e, t) {
    return {
        $$typeof: cp,
        type: e,
        compare: t === void 0 ? null : t
    }
};
H.startTransition = function(e) {
    var t = Al.transition;
    Al.transition = {};
    try {
        e()
    } finally {
        Al.transition = t
    }
};
H.unstable_act = function() {
    throw Error("act(...) is not supported in production builds of React.")
};
H.useCallback = function(e, t) {
    return Oe.current.useCallback(e, t)
};
H.useContext = function(e) {
    return Oe.current.useContext(e)
};
H.useDebugValue = function() {};
H.useDeferredValue = function(e) {
    return Oe.current.useDeferredValue(e)
};
H.useEffect = function(e, t) {
    return Oe.current.useEffect(e, t)
};
H.useId = function() {
    return Oe.current.useId()
};
H.useImperativeHandle = function(e, t, n) {
    return Oe.current.useImperativeHandle(e, t, n)
};
H.useInsertionEffect = function(e, t) {
    return Oe.current.useInsertionEffect(e, t)
};
H.useLayoutEffect = function(e, t) {
    return Oe.current.useLayoutEffect(e, t)
};
H.useMemo = function(e, t) {
    return Oe.current.useMemo(e, t)
};
H.useReducer = function(e, t, n) {
    return Oe.current.useReducer(e, t, n)
};
H.useRef = function(e) {
    return Oe.current.useRef(e)
};
H.useState = function(e) {
    return Oe.current.useState(e)
};
H.useSyncExternalStore = function(e, t, n) {
    return Oe.current.useSyncExternalStore(e, t, n)
};
H.useTransition = function() {
    return Oe.current.useTransition()
};
H.version = "18.2.0";
oc.exports = H;
var R = oc.exports;
const zn = Eu(R),
    yp = ic({
        __proto__: null,
        default: zn
    }, [R]);
var hc = {
        exports: {}
    },
    Xe = {},
    mc = {
        exports: {}
    },
    vc = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(D, U) {
        var B = D.length;
        D.push(U);
        e: for (; 0 < B;) {
            var X = B - 1 >>> 1,
                ee = D[X];
            if (0 < l(ee, U)) D[X] = U, D[B] = ee, B = X;
            else break e
        }
    }

    function n(D) {
        return D.length === 0 ? null : D[0]
    }

    function r(D) {
        if (D.length === 0) return null;
        var U = D[0],
            B = D.pop();
        if (B !== U) {
            D[0] = B;
            e: for (var X = 0, ee = D.length, pt = ee >>> 1; X < pt;) {
                var ke = 2 * (X + 1) - 1,
                    lt = D[ke],
                    De = ke + 1,
                    Mt = D[De];
                if (0 > l(lt, B)) De < ee && 0 > l(Mt, lt) ? (D[X] = Mt, D[De] = B, X = De) : (D[X] = lt, D[ke] = B, X = ke);
                else if (De < ee && 0 > l(Mt, B)) D[X] = Mt, D[De] = B, X = De;
                else break e
            }
        }
        return U
    }

    function l(D, U) {
        var B = D.sortIndex - U.sortIndex;
        return B !== 0 ? B : D.id - U.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var i = performance;
        e.unstable_now = function() {
            return i.now()
        }
    } else {
        var o = Date,
            u = o.now();
        e.unstable_now = function() {
            return o.now() - u
        }
    }
    var a = [],
        s = [],
        c = 1,
        p = null,
        m = 3,
        E = !1,
        S = !1,
        w = !1,
        C = typeof setTimeout == "function" ? setTimeout : null,
        d = typeof clearTimeout == "function" ? clearTimeout : null,
        f = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function h(D) {
        for (var U = n(s); U !== null;) {
            if (U.callback === null) r(s);
            else if (U.startTime <= D) r(s), U.sortIndex = U.expirationTime, t(a, U);
            else break;
            U = n(s)
        }
    }

    function x(D) {
        if (w = !1, h(D), !S)
            if (n(a) !== null) S = !0, Dt(T);
            else {
                var U = n(s);
                U !== null && re(x, U.startTime - D)
            }
    }

    function T(D, U) {
        S = !1, w && (w = !1, d(L), L = -1), E = !0;
        var B = m;
        try {
            for (h(U), p = n(a); p !== null && (!(p.expirationTime > U) || D && !Y());) {
                var X = p.callback;
                if (typeof X == "function") {
                    p.callback = null, m = p.priorityLevel;
                    var ee = X(p.expirationTime <= U);
                    U = e.unstable_now(), typeof ee == "function" ? p.callback = ee : p === n(a) && r(a), h(U)
                } else r(a);
                p = n(a)
            }
            if (p !== null) var pt = !0;
            else {
                var ke = n(s);
                ke !== null && re(x, ke.startTime - U), pt = !1
            }
            return pt
        } finally {
            p = null, m = B, E = !1
        }
    }
    var v = !1,
        _ = null,
        L = -1,
        O = 5,
        I = -1;

    function Y() {
        return !(e.unstable_now() - I < O)
    }

    function me() {
        if (_ !== null) {
            var D = e.unstable_now();
            I = D;
            var U = !0;
            try {
                U = _(!0, D)
            } finally {
                U ? pe() : (v = !1, _ = null)
            }
        } else v = !1
    }
    var pe;
    if (typeof f == "function") pe = function() {
        f(me)
    };
    else if (typeof MessageChannel < "u") {
        var Ze = new MessageChannel,
            Pn = Ze.port2;
        Ze.port1.onmessage = me, pe = function() {
            Pn.postMessage(null)
        }
    } else pe = function() {
        C(me, 0)
    };

    function Dt(D) {
        _ = D, v || (v = !0, pe())
    }

    function re(D, U) {
        L = C(function() {
            D(e.unstable_now())
        }, U)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(D) {
        D.callback = null
    }, e.unstable_continueExecution = function() {
        S || E || (S = !0, Dt(T))
    }, e.unstable_forceFrameRate = function(D) {
        0 > D || 125 < D ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : O = 0 < D ? Math.floor(1e3 / D) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return m
    }, e.unstable_getFirstCallbackNode = function() {
        return n(a)
    }, e.unstable_next = function(D) {
        switch (m) {
            case 1:
            case 2:
            case 3:
                var U = 3;
                break;
            default:
                U = m
        }
        var B = m;
        m = U;
        try {
            return D()
        } finally {
            m = B
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(D, U) {
        switch (D) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                D = 3
        }
        var B = m;
        m = D;
        try {
            return U()
        } finally {
            m = B
        }
    }, e.unstable_scheduleCallback = function(D, U, B) {
        var X = e.unstable_now();
        switch (typeof B == "object" && B !== null ? (B = B.delay, B = typeof B == "number" && 0 < B ? X + B : X) : B = X, D) {
            case 1:
                var ee = -1;
                break;
            case 2:
                ee = 250;
                break;
            case 5:
                ee = 1073741823;
                break;
            case 4:
                ee = 1e4;
                break;
            default:
                ee = 5e3
        }
        return ee = B + ee, D = {
            id: c++,
            callback: U,
            priorityLevel: D,
            startTime: B,
            expirationTime: ee,
            sortIndex: -1
        }, B > X ? (D.sortIndex = B, t(s, D), n(a) === null && D === n(s) && (w ? (d(L), L = -1) : w = !0, re(x, B - X))) : (D.sortIndex = ee, t(a, D), S || E || (S = !0, Dt(T))), D
    }, e.unstable_shouldYield = Y, e.unstable_wrapCallback = function(D) {
        var U = m;
        return function() {
            var B = m;
            m = U;
            try {
                return D.apply(this, arguments)
            } finally {
                m = B
            }
        }
    }
})(vc);
mc.exports = vc;
var gp = mc.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var yc = R,
    Ye = gp;

function P(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var gc = new Set,
    Hr = {};

function xn(e, t) {
    er(e, t), er(e + "Capture", t)
}

function er(e, t) {
    for (Hr[e] = t, e = 0; e < t.length; e++) gc.add(t[e])
}
var Ct = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    ko = Object.prototype.hasOwnProperty,
    wp = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    Da = {},
    Ma = {};

function Sp(e) {
    return ko.call(Ma, e) ? !0 : ko.call(Da, e) ? !1 : wp.test(e) ? Ma[e] = !0 : (Da[e] = !0, !1)
}

function Ep(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function kp(e, t, n, r) {
    if (t === null || typeof t > "u" || Ep(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function Fe(e, t, n, r, l, i, o) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = l, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = i, this.removeEmptyString = o
}
var Pe = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    Pe[e] = new Fe(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    Pe[t] = new Fe(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    Pe[e] = new Fe(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    Pe[e] = new Fe(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    Pe[e] = new Fe(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    Pe[e] = new Fe(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    Pe[e] = new Fe(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    Pe[e] = new Fe(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    Pe[e] = new Fe(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var Pu = /[\-:]([a-z])/g;

function Ru(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Pu, Ru);
    Pe[t] = new Fe(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Pu, Ru);
    Pe[t] = new Fe(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Pu, Ru);
    Pe[t] = new Fe(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    Pe[e] = new Fe(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
Pe.xlinkHref = new Fe("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    Pe[e] = new Fe(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function Tu(e, t, n, r) {
    var l = Pe.hasOwnProperty(t) ? Pe[t] : null;
    (l !== null ? l.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (kp(t, n, l, r) && (n = null), r || l === null ? Sp(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : l.mustUseProperty ? e[l.propertyName] = n === null ? l.type === 3 ? !1 : "" : n : (t = l.attributeName, r = l.attributeNamespace, n === null ? e.removeAttribute(t) : (l = l.type, n = l === 3 || l === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var Tt = yc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    El = Symbol.for("react.element"),
    On = Symbol.for("react.portal"),
    Fn = Symbol.for("react.fragment"),
    Nu = Symbol.for("react.strict_mode"),
    xo = Symbol.for("react.profiler"),
    wc = Symbol.for("react.provider"),
    Sc = Symbol.for("react.context"),
    Lu = Symbol.for("react.forward_ref"),
    Co = Symbol.for("react.suspense"),
    _o = Symbol.for("react.suspense_list"),
    Du = Symbol.for("react.memo"),
    Ut = Symbol.for("react.lazy"),
    Ec = Symbol.for("react.offscreen"),
    za = Symbol.iterator;

function mr(e) {
    return e === null || typeof e != "object" ? null : (e = za && e[za] || e["@@iterator"], typeof e == "function" ? e : null)
}
var ue = Object.assign,
    Yi;

function Tr(e) {
    if (Yi === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Yi = t && t[1] || ""
    }
    return `
` + Yi + e
}
var Xi = !1;

function Gi(e, t) {
    if (!e || Xi) return "";
    Xi = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (s) {
                    var r = s
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (s) {
                    r = s
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (s) {
                r = s
            }
            e()
        }
    } catch (s) {
        if (s && r && typeof s.stack == "string") {
            for (var l = s.stack.split(`
`), i = r.stack.split(`
`), o = l.length - 1, u = i.length - 1; 1 <= o && 0 <= u && l[o] !== i[u];) u--;
            for (; 1 <= o && 0 <= u; o--, u--)
                if (l[o] !== i[u]) {
                    if (o !== 1 || u !== 1)
                        do
                            if (o--, u--, 0 > u || l[o] !== i[u]) {
                                var a = `
` + l[o].replace(" at new ", " at ");
                                return e.displayName && a.includes("<anonymous>") && (a = a.replace("<anonymous>", e.displayName)), a
                            }
                    while (1 <= o && 0 <= u);
                    break
                }
        }
    } finally {
        Xi = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Tr(e) : ""
}

function xp(e) {
    switch (e.tag) {
        case 5:
            return Tr(e.type);
        case 16:
            return Tr("Lazy");
        case 13:
            return Tr("Suspense");
        case 19:
            return Tr("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Gi(e.type, !1), e;
        case 11:
            return e = Gi(e.type.render, !1), e;
        case 1:
            return e = Gi(e.type, !0), e;
        default:
            return ""
    }
}

function Po(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case Fn:
            return "Fragment";
        case On:
            return "Portal";
        case xo:
            return "Profiler";
        case Nu:
            return "StrictMode";
        case Co:
            return "Suspense";
        case _o:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case Sc:
            return (e.displayName || "Context") + ".Consumer";
        case wc:
            return (e._context.displayName || "Context") + ".Provider";
        case Lu:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Du:
            return t = e.displayName || null, t !== null ? t : Po(e.type) || "Memo";
        case Ut:
            t = e._payload, e = e._init;
            try {
                return Po(e(t))
            } catch {}
    }
    return null
}

function Cp(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return Po(t);
        case 8:
            return t === Nu ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function bt(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function kc(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function _p(e) {
    var t = kc(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var l = n.get,
            i = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return l.call(this)
            },
            set: function(o) {
                r = "" + o, i.call(this, o)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(o) {
                r = "" + o
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function kl(e) {
    e._valueTracker || (e._valueTracker = _p(e))
}

function xc(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = kc(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Zl(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function Ro(e, t) {
    var n = t.checked;
    return ue({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function Oa(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = bt(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function Cc(e, t) {
    t = t.checked, t != null && Tu(e, "checked", t, !1)
}

function To(e, t) {
    Cc(e, t);
    var n = bt(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? No(e, t.type, n) : t.hasOwnProperty("defaultValue") && No(e, t.type, bt(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function Fa(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function No(e, t, n) {
    (t !== "number" || Zl(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Nr = Array.isArray;

function Xn(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var l = 0; l < n.length; l++) t["$" + n[l]] = !0;
        for (n = 0; n < e.length; n++) l = t.hasOwnProperty("$" + e[n].value), e[n].selected !== l && (e[n].selected = l), l && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + bt(n), t = null, l = 0; l < e.length; l++) {
            if (e[l].value === n) {
                e[l].selected = !0, r && (e[l].defaultSelected = !0);
                return
            }
            t !== null || e[l].disabled || (t = e[l])
        }
        t !== null && (t.selected = !0)
    }
}

function Lo(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(P(91));
    return ue({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function Ia(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(P(92));
            if (Nr(n)) {
                if (1 < n.length) throw Error(P(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: bt(n)
    }
}

function _c(e, t) {
    var n = bt(t.value),
        r = bt(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function ja(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function Pc(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function Do(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? Pc(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var xl, Rc = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, l) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, l)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (xl = xl || document.createElement("div"), xl.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = xl.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function Qr(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var Or = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    Pp = ["Webkit", "ms", "Moz", "O"];
Object.keys(Or).forEach(function(e) {
    Pp.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), Or[t] = Or[e]
    })
});

function Tc(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Or.hasOwnProperty(e) && Or[e] ? ("" + t).trim() : t + "px"
}

function Nc(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                l = Tc(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, l) : e[n] = l
        }
}
var Rp = ue({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function Mo(e, t) {
    if (t) {
        if (Rp[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(P(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(P(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(P(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(P(62))
    }
}

function zo(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var Oo = null;

function Mu(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var Fo = null,
    Gn = null,
    Zn = null;

function Ua(e) {
    if (e = dl(e)) {
        if (typeof Fo != "function") throw Error(P(280));
        var t = e.stateNode;
        t && (t = Pi(t), Fo(e.stateNode, e.type, t))
    }
}

function Lc(e) {
    Gn ? Zn ? Zn.push(e) : Zn = [e] : Gn = e
}

function Dc() {
    if (Gn) {
        var e = Gn,
            t = Zn;
        if (Zn = Gn = null, Ua(e), t)
            for (e = 0; e < t.length; e++) Ua(t[e])
    }
}

function Mc(e, t) {
    return e(t)
}

function zc() {}
var Zi = !1;

function Oc(e, t, n) {
    if (Zi) return e(t, n);
    Zi = !0;
    try {
        return Mc(e, t, n)
    } finally {
        Zi = !1, (Gn !== null || Zn !== null) && (zc(), Dc())
    }
}

function Kr(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Pi(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(P(231, t, typeof n));
    return n
}
var Io = !1;
if (Ct) try {
    var vr = {};
    Object.defineProperty(vr, "passive", {
        get: function() {
            Io = !0
        }
    }), window.addEventListener("test", vr, vr), window.removeEventListener("test", vr, vr)
} catch {
    Io = !1
}

function Tp(e, t, n, r, l, i, o, u, a) {
    var s = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, s)
    } catch (c) {
        this.onError(c)
    }
}
var Fr = !1,
    Jl = null,
    ql = !1,
    jo = null,
    Np = {
        onError: function(e) {
            Fr = !0, Jl = e
        }
    };

function Lp(e, t, n, r, l, i, o, u, a) {
    Fr = !1, Jl = null, Tp.apply(Np, arguments)
}

function Dp(e, t, n, r, l, i, o, u, a) {
    if (Lp.apply(this, arguments), Fr) {
        if (Fr) {
            var s = Jl;
            Fr = !1, Jl = null
        } else throw Error(P(198));
        ql || (ql = !0, jo = s)
    }
}

function Cn(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function Fc(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function Aa(e) {
    if (Cn(e) !== e) throw Error(P(188))
}

function Mp(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Cn(e), t === null) throw Error(P(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var l = n.return;
        if (l === null) break;
        var i = l.alternate;
        if (i === null) {
            if (r = l.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (l.child === i.child) {
            for (i = l.child; i;) {
                if (i === n) return Aa(l), e;
                if (i === r) return Aa(l), t;
                i = i.sibling
            }
            throw Error(P(188))
        }
        if (n.return !== r.return) n = l, r = i;
        else {
            for (var o = !1, u = l.child; u;) {
                if (u === n) {
                    o = !0, n = l, r = i;
                    break
                }
                if (u === r) {
                    o = !0, r = l, n = i;
                    break
                }
                u = u.sibling
            }
            if (!o) {
                for (u = i.child; u;) {
                    if (u === n) {
                        o = !0, n = i, r = l;
                        break
                    }
                    if (u === r) {
                        o = !0, r = i, n = l;
                        break
                    }
                    u = u.sibling
                }
                if (!o) throw Error(P(189))
            }
        }
        if (n.alternate !== r) throw Error(P(190))
    }
    if (n.tag !== 3) throw Error(P(188));
    return n.stateNode.current === n ? e : t
}

function Ic(e) {
    return e = Mp(e), e !== null ? jc(e) : null
}

function jc(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = jc(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var Uc = Ye.unstable_scheduleCallback,
    Ba = Ye.unstable_cancelCallback,
    zp = Ye.unstable_shouldYield,
    Op = Ye.unstable_requestPaint,
    de = Ye.unstable_now,
    Fp = Ye.unstable_getCurrentPriorityLevel,
    zu = Ye.unstable_ImmediatePriority,
    Ac = Ye.unstable_UserBlockingPriority,
    bl = Ye.unstable_NormalPriority,
    Ip = Ye.unstable_LowPriority,
    Bc = Ye.unstable_IdlePriority,
    ki = null,
    yt = null;

function jp(e) {
    if (yt && typeof yt.onCommitFiberRoot == "function") try {
        yt.onCommitFiberRoot(ki, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var ct = Math.clz32 ? Math.clz32 : Bp,
    Up = Math.log,
    Ap = Math.LN2;

function Bp(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (Up(e) / Ap | 0) | 0
}
var Cl = 64,
    _l = 4194304;

function Lr(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function ei(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        l = e.suspendedLanes,
        i = e.pingedLanes,
        o = n & 268435455;
    if (o !== 0) {
        var u = o & ~l;
        u !== 0 ? r = Lr(u) : (i &= o, i !== 0 && (r = Lr(i)))
    } else o = n & ~l, o !== 0 ? r = Lr(o) : i !== 0 && (r = Lr(i));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & l) && (l = r & -r, i = t & -t, l >= i || l === 16 && (i & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - ct(t), l = 1 << n, r |= e[n], t &= ~l;
    return r
}

function $p(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function Vp(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, l = e.expirationTimes, i = e.pendingLanes; 0 < i;) {
        var o = 31 - ct(i),
            u = 1 << o,
            a = l[o];
        a === -1 ? (!(u & n) || u & r) && (l[o] = $p(u, t)) : a <= t && (e.expiredLanes |= u), i &= ~u
    }
}

function Uo(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function $c() {
    var e = Cl;
    return Cl <<= 1, !(Cl & 4194240) && (Cl = 64), e
}

function Ji(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function cl(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - ct(t), e[t] = n
}

function Wp(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var l = 31 - ct(n),
            i = 1 << l;
        t[l] = 0, r[l] = -1, e[l] = -1, n &= ~i
    }
}

function Ou(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - ct(n),
            l = 1 << r;
        l & t | e[r] & t && (e[r] |= t), n &= ~l
    }
}
var Z = 0;

function Vc(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var Wc, Fu, Hc, Qc, Kc, Ao = !1,
    Pl = [],
    Ht = null,
    Qt = null,
    Kt = null,
    Yr = new Map,
    Xr = new Map,
    Bt = [],
    Hp = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function $a(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Ht = null;
            break;
        case "dragenter":
        case "dragleave":
            Qt = null;
            break;
        case "mouseover":
        case "mouseout":
            Kt = null;
            break;
        case "pointerover":
        case "pointerout":
            Yr.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            Xr.delete(t.pointerId)
    }
}

function yr(e, t, n, r, l, i) {
    return e === null || e.nativeEvent !== i ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: i,
        targetContainers: [l]
    }, t !== null && (t = dl(t), t !== null && Fu(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, l !== null && t.indexOf(l) === -1 && t.push(l), e)
}

function Qp(e, t, n, r, l) {
    switch (t) {
        case "focusin":
            return Ht = yr(Ht, e, t, n, r, l), !0;
        case "dragenter":
            return Qt = yr(Qt, e, t, n, r, l), !0;
        case "mouseover":
            return Kt = yr(Kt, e, t, n, r, l), !0;
        case "pointerover":
            var i = l.pointerId;
            return Yr.set(i, yr(Yr.get(i) || null, e, t, n, r, l)), !0;
        case "gotpointercapture":
            return i = l.pointerId, Xr.set(i, yr(Xr.get(i) || null, e, t, n, r, l)), !0
    }
    return !1
}

function Yc(e) {
    var t = fn(e.target);
    if (t !== null) {
        var n = Cn(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = Fc(n), t !== null) {
                    e.blockedOn = t, Kc(e.priority, function() {
                        Hc(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function Bl(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = Bo(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            Oo = r, n.target.dispatchEvent(r), Oo = null
        } else return t = dl(n), t !== null && Fu(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function Va(e, t, n) {
    Bl(e) && n.delete(t)
}

function Kp() {
    Ao = !1, Ht !== null && Bl(Ht) && (Ht = null), Qt !== null && Bl(Qt) && (Qt = null), Kt !== null && Bl(Kt) && (Kt = null), Yr.forEach(Va), Xr.forEach(Va)
}

function gr(e, t) {
    e.blockedOn === t && (e.blockedOn = null, Ao || (Ao = !0, Ye.unstable_scheduleCallback(Ye.unstable_NormalPriority, Kp)))
}

function Gr(e) {
    function t(l) {
        return gr(l, e)
    }
    if (0 < Pl.length) {
        gr(Pl[0], e);
        for (var n = 1; n < Pl.length; n++) {
            var r = Pl[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Ht !== null && gr(Ht, e), Qt !== null && gr(Qt, e), Kt !== null && gr(Kt, e), Yr.forEach(t), Xr.forEach(t), n = 0; n < Bt.length; n++) r = Bt[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < Bt.length && (n = Bt[0], n.blockedOn === null);) Yc(n), n.blockedOn === null && Bt.shift()
}
var Jn = Tt.ReactCurrentBatchConfig,
    ti = !0;

function Yp(e, t, n, r) {
    var l = Z,
        i = Jn.transition;
    Jn.transition = null;
    try {
        Z = 1, Iu(e, t, n, r)
    } finally {
        Z = l, Jn.transition = i
    }
}

function Xp(e, t, n, r) {
    var l = Z,
        i = Jn.transition;
    Jn.transition = null;
    try {
        Z = 4, Iu(e, t, n, r)
    } finally {
        Z = l, Jn.transition = i
    }
}

function Iu(e, t, n, r) {
    if (ti) {
        var l = Bo(e, t, n, r);
        if (l === null) uo(e, t, r, ni, n), $a(e, r);
        else if (Qp(l, e, t, n, r)) r.stopPropagation();
        else if ($a(e, r), t & 4 && -1 < Hp.indexOf(e)) {
            for (; l !== null;) {
                var i = dl(l);
                if (i !== null && Wc(i), i = Bo(e, t, n, r), i === null && uo(e, t, r, ni, n), i === l) break;
                l = i
            }
            l !== null && r.stopPropagation()
        } else uo(e, t, r, null, n)
    }
}
var ni = null;

function Bo(e, t, n, r) {
    if (ni = null, e = Mu(r), e = fn(e), e !== null)
        if (t = Cn(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = Fc(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return ni = e, null
}

function Xc(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (Fp()) {
                case zu:
                    return 1;
                case Ac:
                    return 4;
                case bl:
                case Ip:
                    return 16;
                case Bc:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var Vt = null,
    ju = null,
    $l = null;

function Gc() {
    if ($l) return $l;
    var e, t = ju,
        n = t.length,
        r, l = "value" in Vt ? Vt.value : Vt.textContent,
        i = l.length;
    for (e = 0; e < n && t[e] === l[e]; e++);
    var o = n - e;
    for (r = 1; r <= o && t[n - r] === l[i - r]; r++);
    return $l = l.slice(e, 1 < r ? 1 - r : void 0)
}

function Vl(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function Rl() {
    return !0
}

function Wa() {
    return !1
}

function Ge(e) {
    function t(n, r, l, i, o) {
        this._reactName = n, this._targetInst = l, this.type = r, this.nativeEvent = i, this.target = o, this.currentTarget = null;
        for (var u in e) e.hasOwnProperty(u) && (n = e[u], this[u] = n ? n(i) : i[u]);
        return this.isDefaultPrevented = (i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === !1) ? Rl : Wa, this.isPropagationStopped = Wa, this
    }
    return ue(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Rl)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Rl)
        },
        persist: function() {},
        isPersistent: Rl
    }), t
}
var sr = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    Uu = Ge(sr),
    fl = ue({}, sr, {
        view: 0,
        detail: 0
    }),
    Gp = Ge(fl),
    qi, bi, wr, xi = ue({}, fl, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: Au,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== wr && (wr && e.type === "mousemove" ? (qi = e.screenX - wr.screenX, bi = e.screenY - wr.screenY) : bi = qi = 0, wr = e), qi)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : bi
        }
    }),
    Ha = Ge(xi),
    Zp = ue({}, xi, {
        dataTransfer: 0
    }),
    Jp = Ge(Zp),
    qp = ue({}, fl, {
        relatedTarget: 0
    }),
    eo = Ge(qp),
    bp = ue({}, sr, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    eh = Ge(bp),
    th = ue({}, sr, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    nh = Ge(th),
    rh = ue({}, sr, {
        data: 0
    }),
    Qa = Ge(rh),
    lh = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    ih = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    oh = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function uh(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = oh[e]) ? !!t[e] : !1
}

function Au() {
    return uh
}
var ah = ue({}, fl, {
        key: function(e) {
            if (e.key) {
                var t = lh[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = Vl(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? ih[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: Au,
        charCode: function(e) {
            return e.type === "keypress" ? Vl(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? Vl(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    sh = Ge(ah),
    ch = ue({}, xi, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    Ka = Ge(ch),
    fh = ue({}, fl, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: Au
    }),
    dh = Ge(fh),
    ph = ue({}, sr, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    hh = Ge(ph),
    mh = ue({}, xi, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    vh = Ge(mh),
    yh = [9, 13, 27, 32],
    Bu = Ct && "CompositionEvent" in window,
    Ir = null;
Ct && "documentMode" in document && (Ir = document.documentMode);
var gh = Ct && "TextEvent" in window && !Ir,
    Zc = Ct && (!Bu || Ir && 8 < Ir && 11 >= Ir),
    Ya = String.fromCharCode(32),
    Xa = !1;

function Jc(e, t) {
    switch (e) {
        case "keyup":
            return yh.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function qc(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var In = !1;

function wh(e, t) {
    switch (e) {
        case "compositionend":
            return qc(t);
        case "keypress":
            return t.which !== 32 ? null : (Xa = !0, Ya);
        case "textInput":
            return e = t.data, e === Ya && Xa ? null : e;
        default:
            return null
    }
}

function Sh(e, t) {
    if (In) return e === "compositionend" || !Bu && Jc(e, t) ? (e = Gc(), $l = ju = Vt = null, In = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return Zc && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var Eh = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function Ga(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Eh[e.type] : t === "textarea"
}

function bc(e, t, n, r) {
    Lc(r), t = ri(t, "onChange"), 0 < t.length && (n = new Uu("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var jr = null,
    Zr = null;

function kh(e) {
    ff(e, 0)
}

function Ci(e) {
    var t = An(e);
    if (xc(t)) return e
}

function xh(e, t) {
    if (e === "change") return t
}
var ef = !1;
if (Ct) {
    var to;
    if (Ct) {
        var no = "oninput" in document;
        if (!no) {
            var Za = document.createElement("div");
            Za.setAttribute("oninput", "return;"), no = typeof Za.oninput == "function"
        }
        to = no
    } else to = !1;
    ef = to && (!document.documentMode || 9 < document.documentMode)
}

function Ja() {
    jr && (jr.detachEvent("onpropertychange", tf), Zr = jr = null)
}

function tf(e) {
    if (e.propertyName === "value" && Ci(Zr)) {
        var t = [];
        bc(t, Zr, e, Mu(e)), Oc(kh, t)
    }
}

function Ch(e, t, n) {
    e === "focusin" ? (Ja(), jr = t, Zr = n, jr.attachEvent("onpropertychange", tf)) : e === "focusout" && Ja()
}

function _h(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return Ci(Zr)
}

function Ph(e, t) {
    if (e === "click") return Ci(t)
}

function Rh(e, t) {
    if (e === "input" || e === "change") return Ci(t)
}

function Th(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var dt = typeof Object.is == "function" ? Object.is : Th;

function Jr(e, t) {
    if (dt(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var l = n[r];
        if (!ko.call(t, l) || !dt(e[l], t[l])) return !1
    }
    return !0
}

function qa(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function ba(e, t) {
    var n = qa(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = qa(n)
    }
}

function nf(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? nf(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function rf() {
    for (var e = window, t = Zl(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Zl(e.document)
    }
    return t
}

function $u(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function Nh(e) {
    var t = rf(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && nf(n.ownerDocument.documentElement, n)) {
        if (r !== null && $u(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var l = n.textContent.length,
                    i = Math.min(r.start, l);
                r = r.end === void 0 ? i : Math.min(r.end, l), !e.extend && i > r && (l = r, r = i, i = l), l = ba(n, i);
                var o = ba(n, r);
                l && o && (e.rangeCount !== 1 || e.anchorNode !== l.node || e.anchorOffset !== l.offset || e.focusNode !== o.node || e.focusOffset !== o.offset) && (t = t.createRange(), t.setStart(l.node, l.offset), e.removeAllRanges(), i > r ? (e.addRange(t), e.extend(o.node, o.offset)) : (t.setEnd(o.node, o.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var Lh = Ct && "documentMode" in document && 11 >= document.documentMode,
    jn = null,
    $o = null,
    Ur = null,
    Vo = !1;

function es(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Vo || jn == null || jn !== Zl(r) || (r = jn, "selectionStart" in r && $u(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), Ur && Jr(Ur, r) || (Ur = r, r = ri($o, "onSelect"), 0 < r.length && (t = new Uu("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = jn)))
}

function Tl(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var Un = {
        animationend: Tl("Animation", "AnimationEnd"),
        animationiteration: Tl("Animation", "AnimationIteration"),
        animationstart: Tl("Animation", "AnimationStart"),
        transitionend: Tl("Transition", "TransitionEnd")
    },
    ro = {},
    lf = {};
Ct && (lf = document.createElement("div").style, "AnimationEvent" in window || (delete Un.animationend.animation, delete Un.animationiteration.animation, delete Un.animationstart.animation), "TransitionEvent" in window || delete Un.transitionend.transition);

function _i(e) {
    if (ro[e]) return ro[e];
    if (!Un[e]) return e;
    var t = Un[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in lf) return ro[e] = t[n];
    return e
}
var of = _i("animationend"), uf = _i("animationiteration"), af = _i("animationstart"), sf = _i("transitionend"), cf = new Map, ts = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function tn(e, t) {
    cf.set(e, t), xn(t, [e])
}
for (var lo = 0; lo < ts.length; lo++) {
    var io = ts[lo],
        Dh = io.toLowerCase(),
        Mh = io[0].toUpperCase() + io.slice(1);
    tn(Dh, "on" + Mh)
}
tn( of , "onAnimationEnd");
tn(uf, "onAnimationIteration");
tn(af, "onAnimationStart");
tn("dblclick", "onDoubleClick");
tn("focusin", "onFocus");
tn("focusout", "onBlur");
tn(sf, "onTransitionEnd");
er("onMouseEnter", ["mouseout", "mouseover"]);
er("onMouseLeave", ["mouseout", "mouseover"]);
er("onPointerEnter", ["pointerout", "pointerover"]);
er("onPointerLeave", ["pointerout", "pointerover"]);
xn("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
xn("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
xn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
xn("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
xn("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
xn("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Dr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    zh = new Set("cancel close invalid load scroll toggle".split(" ").concat(Dr));

function ns(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, Dp(r, t, void 0, e), e.currentTarget = null
}

function ff(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            l = r.event;
        r = r.listeners;
        e: {
            var i = void 0;
            if (t)
                for (var o = r.length - 1; 0 <= o; o--) {
                    var u = r[o],
                        a = u.instance,
                        s = u.currentTarget;
                    if (u = u.listener, a !== i && l.isPropagationStopped()) break e;
                    ns(l, u, s), i = a
                } else
                    for (o = 0; o < r.length; o++) {
                        if (u = r[o], a = u.instance, s = u.currentTarget, u = u.listener, a !== i && l.isPropagationStopped()) break e;
                        ns(l, u, s), i = a
                    }
        }
    }
    if (ql) throw e = jo, ql = !1, jo = null, e
}

function te(e, t) {
    var n = t[Yo];
    n === void 0 && (n = t[Yo] = new Set);
    var r = e + "__bubble";
    n.has(r) || (df(t, e, 2, !1), n.add(r))
}

function oo(e, t, n) {
    var r = 0;
    t && (r |= 4), df(n, e, r, t)
}
var Nl = "_reactListening" + Math.random().toString(36).slice(2);

function qr(e) {
    if (!e[Nl]) {
        e[Nl] = !0, gc.forEach(function(n) {
            n !== "selectionchange" && (zh.has(n) || oo(n, !1, e), oo(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[Nl] || (t[Nl] = !0, oo("selectionchange", !1, t))
    }
}

function df(e, t, n, r) {
    switch (Xc(t)) {
        case 1:
            var l = Yp;
            break;
        case 4:
            l = Xp;
            break;
        default:
            l = Iu
    }
    n = l.bind(null, t, n, e), l = void 0, !Io || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (l = !0), r ? l !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: l
    }) : e.addEventListener(t, n, !0) : l !== void 0 ? e.addEventListener(t, n, {
        passive: l
    }) : e.addEventListener(t, n, !1)
}

function uo(e, t, n, r, l) {
    var i = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var o = r.tag;
        if (o === 3 || o === 4) {
            var u = r.stateNode.containerInfo;
            if (u === l || u.nodeType === 8 && u.parentNode === l) break;
            if (o === 4)
                for (o = r.return; o !== null;) {
                    var a = o.tag;
                    if ((a === 3 || a === 4) && (a = o.stateNode.containerInfo, a === l || a.nodeType === 8 && a.parentNode === l)) return;
                    o = o.return
                }
            for (; u !== null;) {
                if (o = fn(u), o === null) return;
                if (a = o.tag, a === 5 || a === 6) {
                    r = i = o;
                    continue e
                }
                u = u.parentNode
            }
        }
        r = r.return
    }
    Oc(function() {
        var s = i,
            c = Mu(n),
            p = [];
        e: {
            var m = cf.get(e);
            if (m !== void 0) {
                var E = Uu,
                    S = e;
                switch (e) {
                    case "keypress":
                        if (Vl(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        E = sh;
                        break;
                    case "focusin":
                        S = "focus", E = eo;
                        break;
                    case "focusout":
                        S = "blur", E = eo;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        E = eo;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        E = Ha;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        E = Jp;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        E = dh;
                        break;
                    case of:
                    case uf:
                    case af:
                        E = eh;
                        break;
                    case sf:
                        E = hh;
                        break;
                    case "scroll":
                        E = Gp;
                        break;
                    case "wheel":
                        E = vh;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        E = nh;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        E = Ka
                }
                var w = (t & 4) !== 0,
                    C = !w && e === "scroll",
                    d = w ? m !== null ? m + "Capture" : null : m;
                w = [];
                for (var f = s, h; f !== null;) {
                    h = f;
                    var x = h.stateNode;
                    if (h.tag === 5 && x !== null && (h = x, d !== null && (x = Kr(f, d), x != null && w.push(br(f, x, h)))), C) break;
                    f = f.return
                }
                0 < w.length && (m = new E(m, S, null, n, c), p.push({
                    event: m,
                    listeners: w
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (m = e === "mouseover" || e === "pointerover", E = e === "mouseout" || e === "pointerout", m && n !== Oo && (S = n.relatedTarget || n.fromElement) && (fn(S) || S[_t])) break e;
                if ((E || m) && (m = c.window === c ? c : (m = c.ownerDocument) ? m.defaultView || m.parentWindow : window, E ? (S = n.relatedTarget || n.toElement, E = s, S = S ? fn(S) : null, S !== null && (C = Cn(S), S !== C || S.tag !== 5 && S.tag !== 6) && (S = null)) : (E = null, S = s), E !== S)) {
                    if (w = Ha, x = "onMouseLeave", d = "onMouseEnter", f = "mouse", (e === "pointerout" || e === "pointerover") && (w = Ka, x = "onPointerLeave", d = "onPointerEnter", f = "pointer"), C = E == null ? m : An(E), h = S == null ? m : An(S), m = new w(x, f + "leave", E, n, c), m.target = C, m.relatedTarget = h, x = null, fn(c) === s && (w = new w(d, f + "enter", S, n, c), w.target = h, w.relatedTarget = C, x = w), C = x, E && S) t: {
                        for (w = E, d = S, f = 0, h = w; h; h = Ln(h)) f++;
                        for (h = 0, x = d; x; x = Ln(x)) h++;
                        for (; 0 < f - h;) w = Ln(w),
                        f--;
                        for (; 0 < h - f;) d = Ln(d),
                        h--;
                        for (; f--;) {
                            if (w === d || d !== null && w === d.alternate) break t;
                            w = Ln(w), d = Ln(d)
                        }
                        w = null
                    }
                    else w = null;
                    E !== null && rs(p, m, E, w, !1), S !== null && C !== null && rs(p, C, S, w, !0)
                }
            }
            e: {
                if (m = s ? An(s) : window, E = m.nodeName && m.nodeName.toLowerCase(), E === "select" || E === "input" && m.type === "file") var T = xh;
                else if (Ga(m))
                    if (ef) T = Rh;
                    else {
                        T = _h;
                        var v = Ch
                    }
                else(E = m.nodeName) && E.toLowerCase() === "input" && (m.type === "checkbox" || m.type === "radio") && (T = Ph);
                if (T && (T = T(e, s))) {
                    bc(p, T, n, c);
                    break e
                }
                v && v(e, m, s),
                e === "focusout" && (v = m._wrapperState) && v.controlled && m.type === "number" && No(m, "number", m.value)
            }
            switch (v = s ? An(s) : window, e) {
                case "focusin":
                    (Ga(v) || v.contentEditable === "true") && (jn = v, $o = s, Ur = null);
                    break;
                case "focusout":
                    Ur = $o = jn = null;
                    break;
                case "mousedown":
                    Vo = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    Vo = !1, es(p, n, c);
                    break;
                case "selectionchange":
                    if (Lh) break;
                case "keydown":
                case "keyup":
                    es(p, n, c)
            }
            var _;
            if (Bu) e: {
                switch (e) {
                    case "compositionstart":
                        var L = "onCompositionStart";
                        break e;
                    case "compositionend":
                        L = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        L = "onCompositionUpdate";
                        break e
                }
                L = void 0
            }
            else In ? Jc(e, n) && (L = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (L = "onCompositionStart");L && (Zc && n.locale !== "ko" && (In || L !== "onCompositionStart" ? L === "onCompositionEnd" && In && (_ = Gc()) : (Vt = c, ju = "value" in Vt ? Vt.value : Vt.textContent, In = !0)), v = ri(s, L), 0 < v.length && (L = new Qa(L, e, null, n, c), p.push({
                event: L,
                listeners: v
            }), _ ? L.data = _ : (_ = qc(n), _ !== null && (L.data = _)))),
            (_ = gh ? wh(e, n) : Sh(e, n)) && (s = ri(s, "onBeforeInput"), 0 < s.length && (c = new Qa("onBeforeInput", "beforeinput", null, n, c), p.push({
                event: c,
                listeners: s
            }), c.data = _))
        }
        ff(p, t)
    })
}

function br(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function ri(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var l = e,
            i = l.stateNode;
        l.tag === 5 && i !== null && (l = i, i = Kr(e, n), i != null && r.unshift(br(e, i, l)), i = Kr(e, t), i != null && r.push(br(e, i, l))), e = e.return
    }
    return r
}

function Ln(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function rs(e, t, n, r, l) {
    for (var i = t._reactName, o = []; n !== null && n !== r;) {
        var u = n,
            a = u.alternate,
            s = u.stateNode;
        if (a !== null && a === r) break;
        u.tag === 5 && s !== null && (u = s, l ? (a = Kr(n, i), a != null && o.unshift(br(n, a, u))) : l || (a = Kr(n, i), a != null && o.push(br(n, a, u)))), n = n.return
    }
    o.length !== 0 && e.push({
        event: t,
        listeners: o
    })
}
var Oh = /\r\n?/g,
    Fh = /\u0000|\uFFFD/g;

function ls(e) {
    return (typeof e == "string" ? e : "" + e).replace(Oh, `
`).replace(Fh, "")
}

function Ll(e, t, n) {
    if (t = ls(t), ls(e) !== t && n) throw Error(P(425))
}

function li() {}
var Wo = null,
    Ho = null;

function Qo(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var Ko = typeof setTimeout == "function" ? setTimeout : void 0,
    Ih = typeof clearTimeout == "function" ? clearTimeout : void 0,
    is = typeof Promise == "function" ? Promise : void 0,
    jh = typeof queueMicrotask == "function" ? queueMicrotask : typeof is < "u" ? function(e) {
        return is.resolve(null).then(e).catch(Uh)
    } : Ko;

function Uh(e) {
    setTimeout(function() {
        throw e
    })
}

function ao(e, t) {
    var n = t,
        r = 0;
    do {
        var l = n.nextSibling;
        if (e.removeChild(n), l && l.nodeType === 8)
            if (n = l.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(l), Gr(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = l
    } while (n);
    Gr(t)
}

function Yt(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function os(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var cr = Math.random().toString(36).slice(2),
    vt = "__reactFiber$" + cr,
    el = "__reactProps$" + cr,
    _t = "__reactContainer$" + cr,
    Yo = "__reactEvents$" + cr,
    Ah = "__reactListeners$" + cr,
    Bh = "__reactHandles$" + cr;

function fn(e) {
    var t = e[vt];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[_t] || n[vt]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = os(e); e !== null;) {
                    if (n = e[vt]) return n;
                    e = os(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function dl(e) {
    return e = e[vt] || e[_t], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function An(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(P(33))
}

function Pi(e) {
    return e[el] || null
}
var Xo = [],
    Bn = -1;

function nn(e) {
    return {
        current: e
    }
}

function ne(e) {
    0 > Bn || (e.current = Xo[Bn], Xo[Bn] = null, Bn--)
}

function b(e, t) {
    Bn++, Xo[Bn] = e.current, e.current = t
}
var en = {},
    Le = nn(en),
    Ae = nn(!1),
    gn = en;

function tr(e, t) {
    var n = e.type.contextTypes;
    if (!n) return en;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var l = {},
        i;
    for (i in n) l[i] = t[i];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = l), l
}

function Be(e) {
    return e = e.childContextTypes, e != null
}

function ii() {
    ne(Ae), ne(Le)
}

function us(e, t, n) {
    if (Le.current !== en) throw Error(P(168));
    b(Le, t), b(Ae, n)
}

function pf(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var l in r)
        if (!(l in t)) throw Error(P(108, Cp(e) || "Unknown", l));
    return ue({}, n, r)
}

function oi(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || en, gn = Le.current, b(Le, e), b(Ae, Ae.current), !0
}

function as(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(P(169));
    n ? (e = pf(e, t, gn), r.__reactInternalMemoizedMergedChildContext = e, ne(Ae), ne(Le), b(Le, e)) : ne(Ae), b(Ae, n)
}
var St = null,
    Ri = !1,
    so = !1;

function hf(e) {
    St === null ? St = [e] : St.push(e)
}

function $h(e) {
    Ri = !0, hf(e)
}

function rn() {
    if (!so && St !== null) {
        so = !0;
        var e = 0,
            t = Z;
        try {
            var n = St;
            for (Z = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            St = null, Ri = !1
        } catch (l) {
            throw St !== null && (St = St.slice(e + 1)), Uc(zu, rn), l
        } finally {
            Z = t, so = !1
        }
    }
    return null
}
var $n = [],
    Vn = 0,
    ui = null,
    ai = 0,
    qe = [],
    be = 0,
    wn = null,
    Et = 1,
    kt = "";

function un(e, t) {
    $n[Vn++] = ai, $n[Vn++] = ui, ui = e, ai = t
}

function mf(e, t, n) {
    qe[be++] = Et, qe[be++] = kt, qe[be++] = wn, wn = e;
    var r = Et;
    e = kt;
    var l = 32 - ct(r) - 1;
    r &= ~(1 << l), n += 1;
    var i = 32 - ct(t) + l;
    if (30 < i) {
        var o = l - l % 5;
        i = (r & (1 << o) - 1).toString(32), r >>= o, l -= o, Et = 1 << 32 - ct(t) + l | n << l | r, kt = i + e
    } else Et = 1 << i | n << l | r, kt = e
}

function Vu(e) {
    e.return !== null && (un(e, 1), mf(e, 1, 0))
}

function Wu(e) {
    for (; e === ui;) ui = $n[--Vn], $n[Vn] = null, ai = $n[--Vn], $n[Vn] = null;
    for (; e === wn;) wn = qe[--be], qe[be] = null, kt = qe[--be], qe[be] = null, Et = qe[--be], qe[be] = null
}
var Ke = null,
    Qe = null,
    le = !1,
    st = null;

function vf(e, t) {
    var n = et(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function ss(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, Ke = e, Qe = Yt(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, Ke = e, Qe = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = wn !== null ? {
                id: Et,
                overflow: kt
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = et(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, Ke = e, Qe = null, !0) : !1;
        default:
            return !1
    }
}

function Go(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function Zo(e) {
    if (le) {
        var t = Qe;
        if (t) {
            var n = t;
            if (!ss(e, t)) {
                if (Go(e)) throw Error(P(418));
                t = Yt(n.nextSibling);
                var r = Ke;
                t && ss(e, t) ? vf(r, n) : (e.flags = e.flags & -4097 | 2, le = !1, Ke = e)
            }
        } else {
            if (Go(e)) throw Error(P(418));
            e.flags = e.flags & -4097 | 2, le = !1, Ke = e
        }
    }
}

function cs(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    Ke = e
}

function Dl(e) {
    if (e !== Ke) return !1;
    if (!le) return cs(e), le = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !Qo(e.type, e.memoizedProps)), t && (t = Qe)) {
        if (Go(e)) throw yf(), Error(P(418));
        for (; t;) vf(e, t), t = Yt(t.nextSibling)
    }
    if (cs(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(P(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            Qe = Yt(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            Qe = null
        }
    } else Qe = Ke ? Yt(e.stateNode.nextSibling) : null;
    return !0
}

function yf() {
    for (var e = Qe; e;) e = Yt(e.nextSibling)
}

function nr() {
    Qe = Ke = null, le = !1
}

function Hu(e) {
    st === null ? st = [e] : st.push(e)
}
var Vh = Tt.ReactCurrentBatchConfig;

function ot(e, t) {
    if (e && e.defaultProps) {
        t = ue({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}
var si = nn(null),
    ci = null,
    Wn = null,
    Qu = null;

function Ku() {
    Qu = Wn = ci = null
}

function Yu(e) {
    var t = si.current;
    ne(si), e._currentValue = t
}

function Jo(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function qn(e, t) {
    ci = e, Qu = Wn = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (Ue = !0), e.firstContext = null)
}

function nt(e) {
    var t = e._currentValue;
    if (Qu !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, Wn === null) {
            if (ci === null) throw Error(P(308));
            Wn = e, ci.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else Wn = Wn.next = e;
    return t
}
var dn = null;

function Xu(e) {
    dn === null ? dn = [e] : dn.push(e)
}

function gf(e, t, n, r) {
    var l = t.interleaved;
    return l === null ? (n.next = n, Xu(t)) : (n.next = l.next, l.next = n), t.interleaved = n, Pt(e, r)
}

function Pt(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var At = !1;

function Gu(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function wf(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function xt(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function Xt(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, K & 2) {
        var l = r.pending;
        return l === null ? t.next = t : (t.next = l.next, l.next = t), r.pending = t, Pt(e, n)
    }
    return l = r.interleaved, l === null ? (t.next = t, Xu(r)) : (t.next = l.next, l.next = t), r.interleaved = t, Pt(e, n)
}

function Wl(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Ou(e, n)
    }
}

function fs(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var l = null,
            i = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var o = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                i === null ? l = i = o : i = i.next = o, n = n.next
            } while (n !== null);
            i === null ? l = i = t : i = i.next = t
        } else l = i = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: l,
            lastBaseUpdate: i,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function fi(e, t, n, r) {
    var l = e.updateQueue;
    At = !1;
    var i = l.firstBaseUpdate,
        o = l.lastBaseUpdate,
        u = l.shared.pending;
    if (u !== null) {
        l.shared.pending = null;
        var a = u,
            s = a.next;
        a.next = null, o === null ? i = s : o.next = s, o = a;
        var c = e.alternate;
        c !== null && (c = c.updateQueue, u = c.lastBaseUpdate, u !== o && (u === null ? c.firstBaseUpdate = s : u.next = s, c.lastBaseUpdate = a))
    }
    if (i !== null) {
        var p = l.baseState;
        o = 0, c = s = a = null, u = i;
        do {
            var m = u.lane,
                E = u.eventTime;
            if ((r & m) === m) {
                c !== null && (c = c.next = {
                    eventTime: E,
                    lane: 0,
                    tag: u.tag,
                    payload: u.payload,
                    callback: u.callback,
                    next: null
                });
                e: {
                    var S = e,
                        w = u;
                    switch (m = t, E = n, w.tag) {
                        case 1:
                            if (S = w.payload, typeof S == "function") {
                                p = S.call(E, p, m);
                                break e
                            }
                            p = S;
                            break e;
                        case 3:
                            S.flags = S.flags & -65537 | 128;
                        case 0:
                            if (S = w.payload, m = typeof S == "function" ? S.call(E, p, m) : S, m == null) break e;
                            p = ue({}, p, m);
                            break e;
                        case 2:
                            At = !0
                    }
                }
                u.callback !== null && u.lane !== 0 && (e.flags |= 64, m = l.effects, m === null ? l.effects = [u] : m.push(u))
            } else E = {
                eventTime: E,
                lane: m,
                tag: u.tag,
                payload: u.payload,
                callback: u.callback,
                next: null
            }, c === null ? (s = c = E, a = p) : c = c.next = E, o |= m;
            if (u = u.next, u === null) {
                if (u = l.shared.pending, u === null) break;
                m = u, u = m.next, m.next = null, l.lastBaseUpdate = m, l.shared.pending = null
            }
        } while (1);
        if (c === null && (a = p), l.baseState = a, l.firstBaseUpdate = s, l.lastBaseUpdate = c, t = l.shared.interleaved, t !== null) {
            l = t;
            do o |= l.lane, l = l.next; while (l !== t)
        } else i === null && (l.shared.lanes = 0);
        En |= o, e.lanes = o, e.memoizedState = p
    }
}

function ds(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                l = r.callback;
            if (l !== null) {
                if (r.callback = null, r = n, typeof l != "function") throw Error(P(191, l));
                l.call(r)
            }
        }
}
var Sf = new yc.Component().refs;

function qo(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : ue({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var Ti = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Cn(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = ze(),
            l = Zt(e),
            i = xt(r, l);
        i.payload = t, n != null && (i.callback = n), t = Xt(e, i, l), t !== null && (ft(t, e, l, r), Wl(t, e, l))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = ze(),
            l = Zt(e),
            i = xt(r, l);
        i.tag = 1, i.payload = t, n != null && (i.callback = n), t = Xt(e, i, l), t !== null && (ft(t, e, l, r), Wl(t, e, l))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = ze(),
            r = Zt(e),
            l = xt(n, r);
        l.tag = 2, t != null && (l.callback = t), t = Xt(e, l, r), t !== null && (ft(t, e, r, n), Wl(t, e, r))
    }
};

function ps(e, t, n, r, l, i, o) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, i, o) : t.prototype && t.prototype.isPureReactComponent ? !Jr(n, r) || !Jr(l, i) : !0
}

function Ef(e, t, n) {
    var r = !1,
        l = en,
        i = t.contextType;
    return typeof i == "object" && i !== null ? i = nt(i) : (l = Be(t) ? gn : Le.current, r = t.contextTypes, i = (r = r != null) ? tr(e, l) : en), t = new t(n, i), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Ti, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = l, e.__reactInternalMemoizedMaskedChildContext = i), t
}

function hs(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ti.enqueueReplaceState(t, t.state, null)
}

function bo(e, t, n, r) {
    var l = e.stateNode;
    l.props = n, l.state = e.memoizedState, l.refs = Sf, Gu(e);
    var i = t.contextType;
    typeof i == "object" && i !== null ? l.context = nt(i) : (i = Be(t) ? gn : Le.current, l.context = tr(e, i)), l.state = e.memoizedState, i = t.getDerivedStateFromProps, typeof i == "function" && (qo(e, t, i, n), l.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof l.getSnapshotBeforeUpdate == "function" || typeof l.UNSAFE_componentWillMount != "function" && typeof l.componentWillMount != "function" || (t = l.state, typeof l.componentWillMount == "function" && l.componentWillMount(), typeof l.UNSAFE_componentWillMount == "function" && l.UNSAFE_componentWillMount(), t !== l.state && Ti.enqueueReplaceState(l, l.state, null), fi(e, n, l, r), l.state = e.memoizedState), typeof l.componentDidMount == "function" && (e.flags |= 4194308)
}

function Sr(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(P(309));
                var r = n.stateNode
            }
            if (!r) throw Error(P(147, e));
            var l = r,
                i = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === i ? t.ref : (t = function(o) {
                var u = l.refs;
                u === Sf && (u = l.refs = {}), o === null ? delete u[i] : u[i] = o
            }, t._stringRef = i, t)
        }
        if (typeof e != "string") throw Error(P(284));
        if (!n._owner) throw Error(P(290, e))
    }
    return e
}

function Ml(e, t) {
    throw e = Object.prototype.toString.call(t), Error(P(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function ms(e) {
    var t = e._init;
    return t(e._payload)
}

function kf(e) {
    function t(d, f) {
        if (e) {
            var h = d.deletions;
            h === null ? (d.deletions = [f], d.flags |= 16) : h.push(f)
        }
    }

    function n(d, f) {
        if (!e) return null;
        for (; f !== null;) t(d, f), f = f.sibling;
        return null
    }

    function r(d, f) {
        for (d = new Map; f !== null;) f.key !== null ? d.set(f.key, f) : d.set(f.index, f), f = f.sibling;
        return d
    }

    function l(d, f) {
        return d = Jt(d, f), d.index = 0, d.sibling = null, d
    }

    function i(d, f, h) {
        return d.index = h, e ? (h = d.alternate, h !== null ? (h = h.index, h < f ? (d.flags |= 2, f) : h) : (d.flags |= 2, f)) : (d.flags |= 1048576, f)
    }

    function o(d) {
        return e && d.alternate === null && (d.flags |= 2), d
    }

    function u(d, f, h, x) {
        return f === null || f.tag !== 6 ? (f = yo(h, d.mode, x), f.return = d, f) : (f = l(f, h), f.return = d, f)
    }

    function a(d, f, h, x) {
        var T = h.type;
        return T === Fn ? c(d, f, h.props.children, x, h.key) : f !== null && (f.elementType === T || typeof T == "object" && T !== null && T.$$typeof === Ut && ms(T) === f.type) ? (x = l(f, h.props), x.ref = Sr(d, f, h), x.return = d, x) : (x = Gl(h.type, h.key, h.props, null, d.mode, x), x.ref = Sr(d, f, h), x.return = d, x)
    }

    function s(d, f, h, x) {
        return f === null || f.tag !== 4 || f.stateNode.containerInfo !== h.containerInfo || f.stateNode.implementation !== h.implementation ? (f = go(h, d.mode, x), f.return = d, f) : (f = l(f, h.children || []), f.return = d, f)
    }

    function c(d, f, h, x, T) {
        return f === null || f.tag !== 7 ? (f = yn(h, d.mode, x, T), f.return = d, f) : (f = l(f, h), f.return = d, f)
    }

    function p(d, f, h) {
        if (typeof f == "string" && f !== "" || typeof f == "number") return f = yo("" + f, d.mode, h), f.return = d, f;
        if (typeof f == "object" && f !== null) {
            switch (f.$$typeof) {
                case El:
                    return h = Gl(f.type, f.key, f.props, null, d.mode, h), h.ref = Sr(d, null, f), h.return = d, h;
                case On:
                    return f = go(f, d.mode, h), f.return = d, f;
                case Ut:
                    var x = f._init;
                    return p(d, x(f._payload), h)
            }
            if (Nr(f) || mr(f)) return f = yn(f, d.mode, h, null), f.return = d, f;
            Ml(d, f)
        }
        return null
    }

    function m(d, f, h, x) {
        var T = f !== null ? f.key : null;
        if (typeof h == "string" && h !== "" || typeof h == "number") return T !== null ? null : u(d, f, "" + h, x);
        if (typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case El:
                    return h.key === T ? a(d, f, h, x) : null;
                case On:
                    return h.key === T ? s(d, f, h, x) : null;
                case Ut:
                    return T = h._init, m(d, f, T(h._payload), x)
            }
            if (Nr(h) || mr(h)) return T !== null ? null : c(d, f, h, x, null);
            Ml(d, h)
        }
        return null
    }

    function E(d, f, h, x, T) {
        if (typeof x == "string" && x !== "" || typeof x == "number") return d = d.get(h) || null, u(f, d, "" + x, T);
        if (typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case El:
                    return d = d.get(x.key === null ? h : x.key) || null, a(f, d, x, T);
                case On:
                    return d = d.get(x.key === null ? h : x.key) || null, s(f, d, x, T);
                case Ut:
                    var v = x._init;
                    return E(d, f, h, v(x._payload), T)
            }
            if (Nr(x) || mr(x)) return d = d.get(h) || null, c(f, d, x, T, null);
            Ml(f, x)
        }
        return null
    }

    function S(d, f, h, x) {
        for (var T = null, v = null, _ = f, L = f = 0, O = null; _ !== null && L < h.length; L++) {
            _.index > L ? (O = _, _ = null) : O = _.sibling;
            var I = m(d, _, h[L], x);
            if (I === null) {
                _ === null && (_ = O);
                break
            }
            e && _ && I.alternate === null && t(d, _), f = i(I, f, L), v === null ? T = I : v.sibling = I, v = I, _ = O
        }
        if (L === h.length) return n(d, _), le && un(d, L), T;
        if (_ === null) {
            for (; L < h.length; L++) _ = p(d, h[L], x), _ !== null && (f = i(_, f, L), v === null ? T = _ : v.sibling = _, v = _);
            return le && un(d, L), T
        }
        for (_ = r(d, _); L < h.length; L++) O = E(_, d, L, h[L], x), O !== null && (e && O.alternate !== null && _.delete(O.key === null ? L : O.key), f = i(O, f, L), v === null ? T = O : v.sibling = O, v = O);
        return e && _.forEach(function(Y) {
            return t(d, Y)
        }), le && un(d, L), T
    }

    function w(d, f, h, x) {
        var T = mr(h);
        if (typeof T != "function") throw Error(P(150));
        if (h = T.call(h), h == null) throw Error(P(151));
        for (var v = T = null, _ = f, L = f = 0, O = null, I = h.next(); _ !== null && !I.done; L++, I = h.next()) {
            _.index > L ? (O = _, _ = null) : O = _.sibling;
            var Y = m(d, _, I.value, x);
            if (Y === null) {
                _ === null && (_ = O);
                break
            }
            e && _ && Y.alternate === null && t(d, _), f = i(Y, f, L), v === null ? T = Y : v.sibling = Y, v = Y, _ = O
        }
        if (I.done) return n(d, _), le && un(d, L), T;
        if (_ === null) {
            for (; !I.done; L++, I = h.next()) I = p(d, I.value, x), I !== null && (f = i(I, f, L), v === null ? T = I : v.sibling = I, v = I);
            return le && un(d, L), T
        }
        for (_ = r(d, _); !I.done; L++, I = h.next()) I = E(_, d, L, I.value, x), I !== null && (e && I.alternate !== null && _.delete(I.key === null ? L : I.key), f = i(I, f, L), v === null ? T = I : v.sibling = I, v = I);
        return e && _.forEach(function(me) {
            return t(d, me)
        }), le && un(d, L), T
    }

    function C(d, f, h, x) {
        if (typeof h == "object" && h !== null && h.type === Fn && h.key === null && (h = h.props.children), typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case El:
                    e: {
                        for (var T = h.key, v = f; v !== null;) {
                            if (v.key === T) {
                                if (T = h.type, T === Fn) {
                                    if (v.tag === 7) {
                                        n(d, v.sibling), f = l(v, h.props.children), f.return = d, d = f;
                                        break e
                                    }
                                } else if (v.elementType === T || typeof T == "object" && T !== null && T.$$typeof === Ut && ms(T) === v.type) {
                                    n(d, v.sibling), f = l(v, h.props), f.ref = Sr(d, v, h), f.return = d, d = f;
                                    break e
                                }
                                n(d, v);
                                break
                            } else t(d, v);
                            v = v.sibling
                        }
                        h.type === Fn ? (f = yn(h.props.children, d.mode, x, h.key), f.return = d, d = f) : (x = Gl(h.type, h.key, h.props, null, d.mode, x), x.ref = Sr(d, f, h), x.return = d, d = x)
                    }
                    return o(d);
                case On:
                    e: {
                        for (v = h.key; f !== null;) {
                            if (f.key === v)
                                if (f.tag === 4 && f.stateNode.containerInfo === h.containerInfo && f.stateNode.implementation === h.implementation) {
                                    n(d, f.sibling), f = l(f, h.children || []), f.return = d, d = f;
                                    break e
                                } else {
                                    n(d, f);
                                    break
                                }
                            else t(d, f);
                            f = f.sibling
                        }
                        f = go(h, d.mode, x),
                        f.return = d,
                        d = f
                    }
                    return o(d);
                case Ut:
                    return v = h._init, C(d, f, v(h._payload), x)
            }
            if (Nr(h)) return S(d, f, h, x);
            if (mr(h)) return w(d, f, h, x);
            Ml(d, h)
        }
        return typeof h == "string" && h !== "" || typeof h == "number" ? (h = "" + h, f !== null && f.tag === 6 ? (n(d, f.sibling), f = l(f, h), f.return = d, d = f) : (n(d, f), f = yo(h, d.mode, x), f.return = d, d = f), o(d)) : n(d, f)
    }
    return C
}
var rr = kf(!0),
    xf = kf(!1),
    pl = {},
    gt = nn(pl),
    tl = nn(pl),
    nl = nn(pl);

function pn(e) {
    if (e === pl) throw Error(P(174));
    return e
}

function Zu(e, t) {
    switch (b(nl, t), b(tl, e), b(gt, pl), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : Do(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Do(t, e)
    }
    ne(gt), b(gt, t)
}

function lr() {
    ne(gt), ne(tl), ne(nl)
}

function Cf(e) {
    pn(nl.current);
    var t = pn(gt.current),
        n = Do(t, e.type);
    t !== n && (b(tl, e), b(gt, n))
}

function Ju(e) {
    tl.current === e && (ne(gt), ne(tl))
}
var ie = nn(0);

function di(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var co = [];

function qu() {
    for (var e = 0; e < co.length; e++) co[e]._workInProgressVersionPrimary = null;
    co.length = 0
}
var Hl = Tt.ReactCurrentDispatcher,
    fo = Tt.ReactCurrentBatchConfig,
    Sn = 0,
    oe = null,
    ve = null,
    Se = null,
    pi = !1,
    Ar = !1,
    rl = 0,
    Wh = 0;

function Re() {
    throw Error(P(321))
}

function bu(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!dt(e[n], t[n])) return !1;
    return !0
}

function ea(e, t, n, r, l, i) {
    if (Sn = i, oe = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, Hl.current = e === null || e.memoizedState === null ? Yh : Xh, e = n(r, l), Ar) {
        i = 0;
        do {
            if (Ar = !1, rl = 0, 25 <= i) throw Error(P(301));
            i += 1, Se = ve = null, t.updateQueue = null, Hl.current = Gh, e = n(r, l)
        } while (Ar)
    }
    if (Hl.current = hi, t = ve !== null && ve.next !== null, Sn = 0, Se = ve = oe = null, pi = !1, t) throw Error(P(300));
    return e
}

function ta() {
    var e = rl !== 0;
    return rl = 0, e
}

function mt() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return Se === null ? oe.memoizedState = Se = e : Se = Se.next = e, Se
}

function rt() {
    if (ve === null) {
        var e = oe.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = ve.next;
    var t = Se === null ? oe.memoizedState : Se.next;
    if (t !== null) Se = t, ve = e;
    else {
        if (e === null) throw Error(P(310));
        ve = e, e = {
            memoizedState: ve.memoizedState,
            baseState: ve.baseState,
            baseQueue: ve.baseQueue,
            queue: ve.queue,
            next: null
        }, Se === null ? oe.memoizedState = Se = e : Se = Se.next = e
    }
    return Se
}

function ll(e, t) {
    return typeof t == "function" ? t(e) : t
}

function po(e) {
    var t = rt(),
        n = t.queue;
    if (n === null) throw Error(P(311));
    n.lastRenderedReducer = e;
    var r = ve,
        l = r.baseQueue,
        i = n.pending;
    if (i !== null) {
        if (l !== null) {
            var o = l.next;
            l.next = i.next, i.next = o
        }
        r.baseQueue = l = i, n.pending = null
    }
    if (l !== null) {
        i = l.next, r = r.baseState;
        var u = o = null,
            a = null,
            s = i;
        do {
            var c = s.lane;
            if ((Sn & c) === c) a !== null && (a = a.next = {
                lane: 0,
                action: s.action,
                hasEagerState: s.hasEagerState,
                eagerState: s.eagerState,
                next: null
            }), r = s.hasEagerState ? s.eagerState : e(r, s.action);
            else {
                var p = {
                    lane: c,
                    action: s.action,
                    hasEagerState: s.hasEagerState,
                    eagerState: s.eagerState,
                    next: null
                };
                a === null ? (u = a = p, o = r) : a = a.next = p, oe.lanes |= c, En |= c
            }
            s = s.next
        } while (s !== null && s !== i);
        a === null ? o = r : a.next = u, dt(r, t.memoizedState) || (Ue = !0), t.memoizedState = r, t.baseState = o, t.baseQueue = a, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        l = e;
        do i = l.lane, oe.lanes |= i, En |= i, l = l.next; while (l !== e)
    } else l === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function ho(e) {
    var t = rt(),
        n = t.queue;
    if (n === null) throw Error(P(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        l = n.pending,
        i = t.memoizedState;
    if (l !== null) {
        n.pending = null;
        var o = l = l.next;
        do i = e(i, o.action), o = o.next; while (o !== l);
        dt(i, t.memoizedState) || (Ue = !0), t.memoizedState = i, t.baseQueue === null && (t.baseState = i), n.lastRenderedState = i
    }
    return [i, r]
}

function _f() {}

function Pf(e, t) {
    var n = oe,
        r = rt(),
        l = t(),
        i = !dt(r.memoizedState, l);
    if (i && (r.memoizedState = l, Ue = !0), r = r.queue, na(Nf.bind(null, n, r, e), [e]), r.getSnapshot !== t || i || Se !== null && Se.memoizedState.tag & 1) {
        if (n.flags |= 2048, il(9, Tf.bind(null, n, r, l, t), void 0, null), Ee === null) throw Error(P(349));
        Sn & 30 || Rf(n, t, l)
    }
    return l
}

function Rf(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = oe.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, oe.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function Tf(e, t, n, r) {
    t.value = n, t.getSnapshot = r, Lf(t) && Df(e)
}

function Nf(e, t, n) {
    return n(function() {
        Lf(t) && Df(e)
    })
}

function Lf(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !dt(e, n)
    } catch {
        return !0
    }
}

function Df(e) {
    var t = Pt(e, 1);
    t !== null && ft(t, e, 1, -1)
}

function vs(e) {
    var t = mt();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: ll,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = Kh.bind(null, oe, e), [t.memoizedState, e]
}

function il(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = oe.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, oe.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function Mf() {
    return rt().memoizedState
}

function Ql(e, t, n, r) {
    var l = mt();
    oe.flags |= e, l.memoizedState = il(1 | t, n, void 0, r === void 0 ? null : r)
}

function Ni(e, t, n, r) {
    var l = rt();
    r = r === void 0 ? null : r;
    var i = void 0;
    if (ve !== null) {
        var o = ve.memoizedState;
        if (i = o.destroy, r !== null && bu(r, o.deps)) {
            l.memoizedState = il(t, n, i, r);
            return
        }
    }
    oe.flags |= e, l.memoizedState = il(1 | t, n, i, r)
}

function ys(e, t) {
    return Ql(8390656, 8, e, t)
}

function na(e, t) {
    return Ni(2048, 8, e, t)
}

function zf(e, t) {
    return Ni(4, 2, e, t)
}

function Of(e, t) {
    return Ni(4, 4, e, t)
}

function Ff(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function If(e, t, n) {
    return n = n != null ? n.concat([e]) : null, Ni(4, 4, Ff.bind(null, t, e), n)
}

function ra() {}

function jf(e, t) {
    var n = rt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && bu(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function Uf(e, t) {
    var n = rt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && bu(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function Af(e, t, n) {
    return Sn & 21 ? (dt(n, t) || (n = $c(), oe.lanes |= n, En |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, Ue = !0), e.memoizedState = n)
}

function Hh(e, t) {
    var n = Z;
    Z = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = fo.transition;
    fo.transition = {};
    try {
        e(!1), t()
    } finally {
        Z = n, fo.transition = r
    }
}

function Bf() {
    return rt().memoizedState
}

function Qh(e, t, n) {
    var r = Zt(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, $f(e)) Vf(t, n);
    else if (n = gf(e, t, n, r), n !== null) {
        var l = ze();
        ft(n, e, r, l), Wf(n, t, r)
    }
}

function Kh(e, t, n) {
    var r = Zt(e),
        l = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if ($f(e)) Vf(t, l);
    else {
        var i = e.alternate;
        if (e.lanes === 0 && (i === null || i.lanes === 0) && (i = t.lastRenderedReducer, i !== null)) try {
            var o = t.lastRenderedState,
                u = i(o, n);
            if (l.hasEagerState = !0, l.eagerState = u, dt(u, o)) {
                var a = t.interleaved;
                a === null ? (l.next = l, Xu(t)) : (l.next = a.next, a.next = l), t.interleaved = l;
                return
            }
        } catch {} finally {}
        n = gf(e, t, l, r), n !== null && (l = ze(), ft(n, e, r, l), Wf(n, t, r))
    }
}

function $f(e) {
    var t = e.alternate;
    return e === oe || t !== null && t === oe
}

function Vf(e, t) {
    Ar = pi = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function Wf(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, Ou(e, n)
    }
}
var hi = {
        readContext: nt,
        useCallback: Re,
        useContext: Re,
        useEffect: Re,
        useImperativeHandle: Re,
        useInsertionEffect: Re,
        useLayoutEffect: Re,
        useMemo: Re,
        useReducer: Re,
        useRef: Re,
        useState: Re,
        useDebugValue: Re,
        useDeferredValue: Re,
        useTransition: Re,
        useMutableSource: Re,
        useSyncExternalStore: Re,
        useId: Re,
        unstable_isNewReconciler: !1
    },
    Yh = {
        readContext: nt,
        useCallback: function(e, t) {
            return mt().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: nt,
        useEffect: ys,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, Ql(4194308, 4, Ff.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return Ql(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return Ql(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = mt();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = mt();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = Qh.bind(null, oe, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = mt();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: vs,
        useDebugValue: ra,
        useDeferredValue: function(e) {
            return mt().memoizedState = e
        },
        useTransition: function() {
            var e = vs(!1),
                t = e[0];
            return e = Hh.bind(null, e[1]), mt().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = oe,
                l = mt();
            if (le) {
                if (n === void 0) throw Error(P(407));
                n = n()
            } else {
                if (n = t(), Ee === null) throw Error(P(349));
                Sn & 30 || Rf(r, t, n)
            }
            l.memoizedState = n;
            var i = {
                value: n,
                getSnapshot: t
            };
            return l.queue = i, ys(Nf.bind(null, r, i, e), [e]), r.flags |= 2048, il(9, Tf.bind(null, r, i, n, t), void 0, null), n
        },
        useId: function() {
            var e = mt(),
                t = Ee.identifierPrefix;
            if (le) {
                var n = kt,
                    r = Et;
                n = (r & ~(1 << 32 - ct(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = rl++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = Wh++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    Xh = {
        readContext: nt,
        useCallback: jf,
        useContext: nt,
        useEffect: na,
        useImperativeHandle: If,
        useInsertionEffect: zf,
        useLayoutEffect: Of,
        useMemo: Uf,
        useReducer: po,
        useRef: Mf,
        useState: function() {
            return po(ll)
        },
        useDebugValue: ra,
        useDeferredValue: function(e) {
            var t = rt();
            return Af(t, ve.memoizedState, e)
        },
        useTransition: function() {
            var e = po(ll)[0],
                t = rt().memoizedState;
            return [e, t]
        },
        useMutableSource: _f,
        useSyncExternalStore: Pf,
        useId: Bf,
        unstable_isNewReconciler: !1
    },
    Gh = {
        readContext: nt,
        useCallback: jf,
        useContext: nt,
        useEffect: na,
        useImperativeHandle: If,
        useInsertionEffect: zf,
        useLayoutEffect: Of,
        useMemo: Uf,
        useReducer: ho,
        useRef: Mf,
        useState: function() {
            return ho(ll)
        },
        useDebugValue: ra,
        useDeferredValue: function(e) {
            var t = rt();
            return ve === null ? t.memoizedState = e : Af(t, ve.memoizedState, e)
        },
        useTransition: function() {
            var e = ho(ll)[0],
                t = rt().memoizedState;
            return [e, t]
        },
        useMutableSource: _f,
        useSyncExternalStore: Pf,
        useId: Bf,
        unstable_isNewReconciler: !1
    };

function ir(e, t) {
    try {
        var n = "",
            r = t;
        do n += xp(r), r = r.return; while (r);
        var l = n
    } catch (i) {
        l = `
Error generating stack: ` + i.message + `
` + i.stack
    }
    return {
        value: e,
        source: t,
        stack: l,
        digest: null
    }
}

function mo(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function eu(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var Zh = typeof WeakMap == "function" ? WeakMap : Map;

function Hf(e, t, n) {
    n = xt(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        vi || (vi = !0, cu = r), eu(e, t)
    }, n
}

function Qf(e, t, n) {
    n = xt(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var l = t.value;
        n.payload = function() {
            return r(l)
        }, n.callback = function() {
            eu(e, t)
        }
    }
    var i = e.stateNode;
    return i !== null && typeof i.componentDidCatch == "function" && (n.callback = function() {
        eu(e, t), typeof r != "function" && (Gt === null ? Gt = new Set([this]) : Gt.add(this));
        var o = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: o !== null ? o : ""
        })
    }), n
}

function gs(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new Zh;
        var l = new Set;
        r.set(t, l)
    } else l = r.get(t), l === void 0 && (l = new Set, r.set(t, l));
    l.has(n) || (l.add(n), e = cm.bind(null, e, t, n), t.then(e, e))
}

function ws(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Ss(e, t, n, r, l) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = l, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = xt(-1, 1), t.tag = 2, Xt(n, t, 1))), n.lanes |= 1), e)
}
var Jh = Tt.ReactCurrentOwner,
    Ue = !1;

function Me(e, t, n, r) {
    t.child = e === null ? xf(t, null, n, r) : rr(t, e.child, n, r)
}

function Es(e, t, n, r, l) {
    n = n.render;
    var i = t.ref;
    return qn(t, l), r = ea(e, t, n, r, i, l), n = ta(), e !== null && !Ue ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Rt(e, t, l)) : (le && n && Vu(t), t.flags |= 1, Me(e, t, r, l), t.child)
}

function ks(e, t, n, r, l) {
    if (e === null) {
        var i = n.type;
        return typeof i == "function" && !fa(i) && i.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = i, Kf(e, t, i, r, l)) : (e = Gl(n.type, null, r, t, t.mode, l), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (i = e.child, !(e.lanes & l)) {
        var o = i.memoizedProps;
        if (n = n.compare, n = n !== null ? n : Jr, n(o, r) && e.ref === t.ref) return Rt(e, t, l)
    }
    return t.flags |= 1, e = Jt(i, r), e.ref = t.ref, e.return = t, t.child = e
}

function Kf(e, t, n, r, l) {
    if (e !== null) {
        var i = e.memoizedProps;
        if (Jr(i, r) && e.ref === t.ref)
            if (Ue = !1, t.pendingProps = r = i, (e.lanes & l) !== 0) e.flags & 131072 && (Ue = !0);
            else return t.lanes = e.lanes, Rt(e, t, l)
    }
    return tu(e, t, n, r, l)
}

function Yf(e, t, n) {
    var r = t.pendingProps,
        l = r.children,
        i = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, b(Qn, He), He |= n;
        else {
            if (!(n & 1073741824)) return e = i !== null ? i.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, b(Qn, He), He |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = i !== null ? i.baseLanes : n, b(Qn, He), He |= r
        }
    else i !== null ? (r = i.baseLanes | n, t.memoizedState = null) : r = n, b(Qn, He), He |= r;
    return Me(e, t, l, n), t.child
}

function Xf(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function tu(e, t, n, r, l) {
    var i = Be(n) ? gn : Le.current;
    return i = tr(t, i), qn(t, l), n = ea(e, t, n, r, i, l), r = ta(), e !== null && !Ue ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~l, Rt(e, t, l)) : (le && r && Vu(t), t.flags |= 1, Me(e, t, n, l), t.child)
}

function xs(e, t, n, r, l) {
    if (Be(n)) {
        var i = !0;
        oi(t)
    } else i = !1;
    if (qn(t, l), t.stateNode === null) Kl(e, t), Ef(t, n, r), bo(t, n, r, l), r = !0;
    else if (e === null) {
        var o = t.stateNode,
            u = t.memoizedProps;
        o.props = u;
        var a = o.context,
            s = n.contextType;
        typeof s == "object" && s !== null ? s = nt(s) : (s = Be(n) ? gn : Le.current, s = tr(t, s));
        var c = n.getDerivedStateFromProps,
            p = typeof c == "function" || typeof o.getSnapshotBeforeUpdate == "function";
        p || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (u !== r || a !== s) && hs(t, o, r, s), At = !1;
        var m = t.memoizedState;
        o.state = m, fi(t, r, o, l), a = t.memoizedState, u !== r || m !== a || Ae.current || At ? (typeof c == "function" && (qo(t, n, c, r), a = t.memoizedState), (u = At || ps(t, n, u, r, m, a, s)) ? (p || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount()), typeof o.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = a), o.props = r, o.state = a, o.context = s, r = u) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        o = t.stateNode, wf(e, t), u = t.memoizedProps, s = t.type === t.elementType ? u : ot(t.type, u), o.props = s, p = t.pendingProps, m = o.context, a = n.contextType, typeof a == "object" && a !== null ? a = nt(a) : (a = Be(n) ? gn : Le.current, a = tr(t, a));
        var E = n.getDerivedStateFromProps;
        (c = typeof E == "function" || typeof o.getSnapshotBeforeUpdate == "function") || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (u !== p || m !== a) && hs(t, o, r, a), At = !1, m = t.memoizedState, o.state = m, fi(t, r, o, l);
        var S = t.memoizedState;
        u !== p || m !== S || Ae.current || At ? (typeof E == "function" && (qo(t, n, E, r), S = t.memoizedState), (s = At || ps(t, n, s, r, m, S, a) || !1) ? (c || typeof o.UNSAFE_componentWillUpdate != "function" && typeof o.componentWillUpdate != "function" || (typeof o.componentWillUpdate == "function" && o.componentWillUpdate(r, S, a), typeof o.UNSAFE_componentWillUpdate == "function" && o.UNSAFE_componentWillUpdate(r, S, a)), typeof o.componentDidUpdate == "function" && (t.flags |= 4), typeof o.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof o.componentDidUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = S), o.props = r, o.state = S, o.context = a, r = s) : (typeof o.componentDidUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || u === e.memoizedProps && m === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return nu(e, t, n, r, i, l)
}

function nu(e, t, n, r, l, i) {
    Xf(e, t);
    var o = (t.flags & 128) !== 0;
    if (!r && !o) return l && as(t, n, !1), Rt(e, t, i);
    r = t.stateNode, Jh.current = t;
    var u = o && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && o ? (t.child = rr(t, e.child, null, i), t.child = rr(t, null, u, i)) : Me(e, t, u, i), t.memoizedState = r.state, l && as(t, n, !0), t.child
}

function Gf(e) {
    var t = e.stateNode;
    t.pendingContext ? us(e, t.pendingContext, t.pendingContext !== t.context) : t.context && us(e, t.context, !1), Zu(e, t.containerInfo)
}

function Cs(e, t, n, r, l) {
    return nr(), Hu(l), t.flags |= 256, Me(e, t, n, r), t.child
}
var ru = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function lu(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function Zf(e, t, n) {
    var r = t.pendingProps,
        l = ie.current,
        i = !1,
        o = (t.flags & 128) !== 0,
        u;
    if ((u = o) || (u = e !== null && e.memoizedState === null ? !1 : (l & 2) !== 0), u ? (i = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (l |= 1), b(ie, l & 1), e === null) return Zo(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (o = r.children, e = r.fallback, i ? (r = t.mode, i = t.child, o = {
        mode: "hidden",
        children: o
    }, !(r & 1) && i !== null ? (i.childLanes = 0, i.pendingProps = o) : i = Mi(o, r, 0, null), e = yn(e, r, n, null), i.return = t, e.return = t, i.sibling = e, t.child = i, t.child.memoizedState = lu(n), t.memoizedState = ru, e) : la(t, o));
    if (l = e.memoizedState, l !== null && (u = l.dehydrated, u !== null)) return qh(e, t, o, r, u, l, n);
    if (i) {
        i = r.fallback, o = t.mode, l = e.child, u = l.sibling;
        var a = {
            mode: "hidden",
            children: r.children
        };
        return !(o & 1) && t.child !== l ? (r = t.child, r.childLanes = 0, r.pendingProps = a, t.deletions = null) : (r = Jt(l, a), r.subtreeFlags = l.subtreeFlags & 14680064), u !== null ? i = Jt(u, i) : (i = yn(i, o, n, null), i.flags |= 2), i.return = t, r.return = t, r.sibling = i, t.child = r, r = i, i = t.child, o = e.child.memoizedState, o = o === null ? lu(n) : {
            baseLanes: o.baseLanes | n,
            cachePool: null,
            transitions: o.transitions
        }, i.memoizedState = o, i.childLanes = e.childLanes & ~n, t.memoizedState = ru, r
    }
    return i = e.child, e = i.sibling, r = Jt(i, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function la(e, t) {
    return t = Mi({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function zl(e, t, n, r) {
    return r !== null && Hu(r), rr(t, e.child, null, n), e = la(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function qh(e, t, n, r, l, i, o) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = mo(Error(P(422))), zl(e, t, o, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (i = r.fallback, l = t.mode, r = Mi({
        mode: "visible",
        children: r.children
    }, l, 0, null), i = yn(i, l, o, null), i.flags |= 2, r.return = t, i.return = t, r.sibling = i, t.child = r, t.mode & 1 && rr(t, e.child, null, o), t.child.memoizedState = lu(o), t.memoizedState = ru, i);
    if (!(t.mode & 1)) return zl(e, t, o, null);
    if (l.data === "$!") {
        if (r = l.nextSibling && l.nextSibling.dataset, r) var u = r.dgst;
        return r = u, i = Error(P(419)), r = mo(i, r, void 0), zl(e, t, o, r)
    }
    if (u = (o & e.childLanes) !== 0, Ue || u) {
        if (r = Ee, r !== null) {
            switch (o & -o) {
                case 4:
                    l = 2;
                    break;
                case 16:
                    l = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    l = 32;
                    break;
                case 536870912:
                    l = 268435456;
                    break;
                default:
                    l = 0
            }
            l = l & (r.suspendedLanes | o) ? 0 : l, l !== 0 && l !== i.retryLane && (i.retryLane = l, Pt(e, l), ft(r, e, l, -1))
        }
        return ca(), r = mo(Error(P(421))), zl(e, t, o, r)
    }
    return l.data === "$?" ? (t.flags |= 128, t.child = e.child, t = fm.bind(null, e), l._reactRetry = t, null) : (e = i.treeContext, Qe = Yt(l.nextSibling), Ke = t, le = !0, st = null, e !== null && (qe[be++] = Et, qe[be++] = kt, qe[be++] = wn, Et = e.id, kt = e.overflow, wn = t), t = la(t, r.children), t.flags |= 4096, t)
}

function _s(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), Jo(e.return, t, n)
}

function vo(e, t, n, r, l) {
    var i = e.memoizedState;
    i === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: l
    } : (i.isBackwards = t, i.rendering = null, i.renderingStartTime = 0, i.last = r, i.tail = n, i.tailMode = l)
}

function Jf(e, t, n) {
    var r = t.pendingProps,
        l = r.revealOrder,
        i = r.tail;
    if (Me(e, t, r.children, n), r = ie.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && _s(e, n, t);
            else if (e.tag === 19) _s(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (b(ie, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (l) {
        case "forwards":
            for (n = t.child, l = null; n !== null;) e = n.alternate, e !== null && di(e) === null && (l = n), n = n.sibling;
            n = l, n === null ? (l = t.child, t.child = null) : (l = n.sibling, n.sibling = null), vo(t, !1, l, n, i);
            break;
        case "backwards":
            for (n = null, l = t.child, t.child = null; l !== null;) {
                if (e = l.alternate, e !== null && di(e) === null) {
                    t.child = l;
                    break
                }
                e = l.sibling, l.sibling = n, n = l, l = e
            }
            vo(t, !0, n, null, i);
            break;
        case "together":
            vo(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Kl(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function Rt(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), En |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(P(153));
    if (t.child !== null) {
        for (e = t.child, n = Jt(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = Jt(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function bh(e, t, n) {
    switch (t.tag) {
        case 3:
            Gf(t), nr();
            break;
        case 5:
            Cf(t);
            break;
        case 1:
            Be(t.type) && oi(t);
            break;
        case 4:
            Zu(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                l = t.memoizedProps.value;
            b(si, r._currentValue), r._currentValue = l;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (b(ie, ie.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Zf(e, t, n) : (b(ie, ie.current & 1), e = Rt(e, t, n), e !== null ? e.sibling : null);
            b(ie, ie.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return Jf(e, t, n);
                t.flags |= 128
            }
            if (l = t.memoizedState, l !== null && (l.rendering = null, l.tail = null, l.lastEffect = null), b(ie, ie.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, Yf(e, t, n)
    }
    return Rt(e, t, n)
}
var qf, iu, bf, ed;
qf = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
iu = function() {};
bf = function(e, t, n, r) {
    var l = e.memoizedProps;
    if (l !== r) {
        e = t.stateNode, pn(gt.current);
        var i = null;
        switch (n) {
            case "input":
                l = Ro(e, l), r = Ro(e, r), i = [];
                break;
            case "select":
                l = ue({}, l, {
                    value: void 0
                }), r = ue({}, r, {
                    value: void 0
                }), i = [];
                break;
            case "textarea":
                l = Lo(e, l), r = Lo(e, r), i = [];
                break;
            default:
                typeof l.onClick != "function" && typeof r.onClick == "function" && (e.onclick = li)
        }
        Mo(n, r);
        var o;
        n = null;
        for (s in l)
            if (!r.hasOwnProperty(s) && l.hasOwnProperty(s) && l[s] != null)
                if (s === "style") {
                    var u = l[s];
                    for (o in u) u.hasOwnProperty(o) && (n || (n = {}), n[o] = "")
                } else s !== "dangerouslySetInnerHTML" && s !== "children" && s !== "suppressContentEditableWarning" && s !== "suppressHydrationWarning" && s !== "autoFocus" && (Hr.hasOwnProperty(s) ? i || (i = []) : (i = i || []).push(s, null));
        for (s in r) {
            var a = r[s];
            if (u = l != null ? l[s] : void 0, r.hasOwnProperty(s) && a !== u && (a != null || u != null))
                if (s === "style")
                    if (u) {
                        for (o in u) !u.hasOwnProperty(o) || a && a.hasOwnProperty(o) || (n || (n = {}), n[o] = "");
                        for (o in a) a.hasOwnProperty(o) && u[o] !== a[o] && (n || (n = {}), n[o] = a[o])
                    } else n || (i || (i = []), i.push(s, n)), n = a;
            else s === "dangerouslySetInnerHTML" ? (a = a ? a.__html : void 0, u = u ? u.__html : void 0, a != null && u !== a && (i = i || []).push(s, a)) : s === "children" ? typeof a != "string" && typeof a != "number" || (i = i || []).push(s, "" + a) : s !== "suppressContentEditableWarning" && s !== "suppressHydrationWarning" && (Hr.hasOwnProperty(s) ? (a != null && s === "onScroll" && te("scroll", e), i || u === a || (i = [])) : (i = i || []).push(s, a))
        }
        n && (i = i || []).push("style", n);
        var s = i;
        (t.updateQueue = s) && (t.flags |= 4)
    }
};
ed = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function Er(e, t) {
    if (!le) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function Te(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var l = e.child; l !== null;) n |= l.lanes | l.childLanes, r |= l.subtreeFlags & 14680064, r |= l.flags & 14680064, l.return = e, l = l.sibling;
    else
        for (l = e.child; l !== null;) n |= l.lanes | l.childLanes, r |= l.subtreeFlags, r |= l.flags, l.return = e, l = l.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function em(e, t, n) {
    var r = t.pendingProps;
    switch (Wu(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return Te(t), null;
        case 1:
            return Be(t.type) && ii(), Te(t), null;
        case 3:
            return r = t.stateNode, lr(), ne(Ae), ne(Le), qu(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (Dl(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, st !== null && (pu(st), st = null))), iu(e, t), Te(t), null;
        case 5:
            Ju(t);
            var l = pn(nl.current);
            if (n = t.type, e !== null && t.stateNode != null) bf(e, t, n, r, l), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(P(166));
                    return Te(t), null
                }
                if (e = pn(gt.current), Dl(t)) {
                    r = t.stateNode, n = t.type;
                    var i = t.memoizedProps;
                    switch (r[vt] = t, r[el] = i, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            te("cancel", r), te("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            te("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (l = 0; l < Dr.length; l++) te(Dr[l], r);
                            break;
                        case "source":
                            te("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            te("error", r), te("load", r);
                            break;
                        case "details":
                            te("toggle", r);
                            break;
                        case "input":
                            Oa(r, i), te("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!i.multiple
                            }, te("invalid", r);
                            break;
                        case "textarea":
                            Ia(r, i), te("invalid", r)
                    }
                    Mo(n, i), l = null;
                    for (var o in i)
                        if (i.hasOwnProperty(o)) {
                            var u = i[o];
                            o === "children" ? typeof u == "string" ? r.textContent !== u && (i.suppressHydrationWarning !== !0 && Ll(r.textContent, u, e), l = ["children", u]) : typeof u == "number" && r.textContent !== "" + u && (i.suppressHydrationWarning !== !0 && Ll(r.textContent, u, e), l = ["children", "" + u]) : Hr.hasOwnProperty(o) && u != null && o === "onScroll" && te("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            kl(r), Fa(r, i, !0);
                            break;
                        case "textarea":
                            kl(r), ja(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof i.onClick == "function" && (r.onclick = li)
                    }
                    r = l, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    o = l.nodeType === 9 ? l : l.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = Pc(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = o.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = o.createElement(n, {
                        is: r.is
                    }) : (e = o.createElement(n), n === "select" && (o = e, r.multiple ? o.multiple = !0 : r.size && (o.size = r.size))) : e = o.createElementNS(e, n), e[vt] = t, e[el] = r, qf(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (o = zo(n, r), n) {
                            case "dialog":
                                te("cancel", e), te("close", e), l = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                te("load", e), l = r;
                                break;
                            case "video":
                            case "audio":
                                for (l = 0; l < Dr.length; l++) te(Dr[l], e);
                                l = r;
                                break;
                            case "source":
                                te("error", e), l = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                te("error", e), te("load", e), l = r;
                                break;
                            case "details":
                                te("toggle", e), l = r;
                                break;
                            case "input":
                                Oa(e, r), l = Ro(e, r), te("invalid", e);
                                break;
                            case "option":
                                l = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, l = ue({}, r, {
                                    value: void 0
                                }), te("invalid", e);
                                break;
                            case "textarea":
                                Ia(e, r), l = Lo(e, r), te("invalid", e);
                                break;
                            default:
                                l = r
                        }
                        Mo(n, l),
                        u = l;
                        for (i in u)
                            if (u.hasOwnProperty(i)) {
                                var a = u[i];
                                i === "style" ? Nc(e, a) : i === "dangerouslySetInnerHTML" ? (a = a ? a.__html : void 0, a != null && Rc(e, a)) : i === "children" ? typeof a == "string" ? (n !== "textarea" || a !== "") && Qr(e, a) : typeof a == "number" && Qr(e, "" + a) : i !== "suppressContentEditableWarning" && i !== "suppressHydrationWarning" && i !== "autoFocus" && (Hr.hasOwnProperty(i) ? a != null && i === "onScroll" && te("scroll", e) : a != null && Tu(e, i, a, o))
                            }
                        switch (n) {
                            case "input":
                                kl(e), Fa(e, r, !1);
                                break;
                            case "textarea":
                                kl(e), ja(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + bt(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, i = r.value, i != null ? Xn(e, !!r.multiple, i, !1) : r.defaultValue != null && Xn(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof l.onClick == "function" && (e.onclick = li)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return Te(t), null;
        case 6:
            if (e && t.stateNode != null) ed(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(P(166));
                if (n = pn(nl.current), pn(gt.current), Dl(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[vt] = t, (i = r.nodeValue !== n) && (e = Ke, e !== null)) switch (e.tag) {
                        case 3:
                            Ll(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && Ll(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    i && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[vt] = t, t.stateNode = r
            }
            return Te(t), null;
        case 13:
            if (ne(ie), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (le && Qe !== null && t.mode & 1 && !(t.flags & 128)) yf(), nr(), t.flags |= 98560, i = !1;
                else if (i = Dl(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!i) throw Error(P(318));
                        if (i = t.memoizedState, i = i !== null ? i.dehydrated : null, !i) throw Error(P(317));
                        i[vt] = t
                    } else nr(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    Te(t), i = !1
                } else st !== null && (pu(st), st = null), i = !0;
                if (!i) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || ie.current & 1 ? ye === 0 && (ye = 3) : ca())), t.updateQueue !== null && (t.flags |= 4), Te(t), null);
        case 4:
            return lr(), iu(e, t), e === null && qr(t.stateNode.containerInfo), Te(t), null;
        case 10:
            return Yu(t.type._context), Te(t), null;
        case 17:
            return Be(t.type) && ii(), Te(t), null;
        case 19:
            if (ne(ie), i = t.memoizedState, i === null) return Te(t), null;
            if (r = (t.flags & 128) !== 0, o = i.rendering, o === null)
                if (r) Er(i, !1);
                else {
                    if (ye !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (o = di(e), o !== null) {
                                for (t.flags |= 128, Er(i, !1), r = o.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) i = n, e = r, i.flags &= 14680066, o = i.alternate, o === null ? (i.childLanes = 0, i.lanes = e, i.child = null, i.subtreeFlags = 0, i.memoizedProps = null, i.memoizedState = null, i.updateQueue = null, i.dependencies = null, i.stateNode = null) : (i.childLanes = o.childLanes, i.lanes = o.lanes, i.child = o.child, i.subtreeFlags = 0, i.deletions = null, i.memoizedProps = o.memoizedProps, i.memoizedState = o.memoizedState, i.updateQueue = o.updateQueue, i.type = o.type, e = o.dependencies, i.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return b(ie, ie.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    i.tail !== null && de() > or && (t.flags |= 128, r = !0, Er(i, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = di(o), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Er(i, !0), i.tail === null && i.tailMode === "hidden" && !o.alternate && !le) return Te(t), null
                    } else 2 * de() - i.renderingStartTime > or && n !== 1073741824 && (t.flags |= 128, r = !0, Er(i, !1), t.lanes = 4194304);
                i.isBackwards ? (o.sibling = t.child, t.child = o) : (n = i.last, n !== null ? n.sibling = o : t.child = o, i.last = o)
            }
            return i.tail !== null ? (t = i.tail, i.rendering = t, i.tail = t.sibling, i.renderingStartTime = de(), t.sibling = null, n = ie.current, b(ie, r ? n & 1 | 2 : n & 1), t) : (Te(t), null);
        case 22:
        case 23:
            return sa(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? He & 1073741824 && (Te(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Te(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(P(156, t.tag))
}

function tm(e, t) {
    switch (Wu(t), t.tag) {
        case 1:
            return Be(t.type) && ii(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return lr(), ne(Ae), ne(Le), qu(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return Ju(t), null;
        case 13:
            if (ne(ie), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(P(340));
                nr()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return ne(ie), null;
        case 4:
            return lr(), null;
        case 10:
            return Yu(t.type._context), null;
        case 22:
        case 23:
            return sa(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var Ol = !1,
    Ne = !1,
    nm = typeof WeakSet == "function" ? WeakSet : Set,
    M = null;

function Hn(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            se(e, t, r)
        } else n.current = null
}

function ou(e, t, n) {
    try {
        n()
    } catch (r) {
        se(e, t, r)
    }
}
var Ps = !1;

function rm(e, t) {
    if (Wo = ti, e = rf(), $u(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var l = r.anchorOffset,
                    i = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, i.nodeType
                } catch {
                    n = null;
                    break e
                }
                var o = 0,
                    u = -1,
                    a = -1,
                    s = 0,
                    c = 0,
                    p = e,
                    m = null;
                t: for (;;) {
                    for (var E; p !== n || l !== 0 && p.nodeType !== 3 || (u = o + l), p !== i || r !== 0 && p.nodeType !== 3 || (a = o + r), p.nodeType === 3 && (o += p.nodeValue.length), (E = p.firstChild) !== null;) m = p, p = E;
                    for (;;) {
                        if (p === e) break t;
                        if (m === n && ++s === l && (u = o), m === i && ++c === r && (a = o), (E = p.nextSibling) !== null) break;
                        p = m, m = p.parentNode
                    }
                    p = E
                }
                n = u === -1 || a === -1 ? null : {
                    start: u,
                    end: a
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (Ho = {
            focusedElem: e,
            selectionRange: n
        }, ti = !1, M = t; M !== null;)
        if (t = M, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, M = e;
        else
            for (; M !== null;) {
                t = M;
                try {
                    var S = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (S !== null) {
                                var w = S.memoizedProps,
                                    C = S.memoizedState,
                                    d = t.stateNode,
                                    f = d.getSnapshotBeforeUpdate(t.elementType === t.type ? w : ot(t.type, w), C);
                                d.__reactInternalSnapshotBeforeUpdate = f
                            }
                            break;
                        case 3:
                            var h = t.stateNode.containerInfo;
                            h.nodeType === 1 ? h.textContent = "" : h.nodeType === 9 && h.documentElement && h.removeChild(h.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(P(163))
                    }
                } catch (x) {
                    se(t, t.return, x)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, M = e;
                    break
                }
                M = t.return
            }
    return S = Ps, Ps = !1, S
}

function Br(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var l = r = r.next;
        do {
            if ((l.tag & e) === e) {
                var i = l.destroy;
                l.destroy = void 0, i !== void 0 && ou(t, n, i)
            }
            l = l.next
        } while (l !== r)
    }
}

function Li(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function uu(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function td(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, td(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[vt], delete t[el], delete t[Yo], delete t[Ah], delete t[Bh])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function nd(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Rs(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || nd(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function au(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = li));
    else if (r !== 4 && (e = e.child, e !== null))
        for (au(e, t, n), e = e.sibling; e !== null;) au(e, t, n), e = e.sibling
}

function su(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (su(e, t, n), e = e.sibling; e !== null;) su(e, t, n), e = e.sibling
}
var Ce = null,
    ut = !1;

function It(e, t, n) {
    for (n = n.child; n !== null;) rd(e, t, n), n = n.sibling
}

function rd(e, t, n) {
    if (yt && typeof yt.onCommitFiberUnmount == "function") try {
        yt.onCommitFiberUnmount(ki, n)
    } catch {}
    switch (n.tag) {
        case 5:
            Ne || Hn(n, t);
        case 6:
            var r = Ce,
                l = ut;
            Ce = null, It(e, t, n), Ce = r, ut = l, Ce !== null && (ut ? (e = Ce, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : Ce.removeChild(n.stateNode));
            break;
        case 18:
            Ce !== null && (ut ? (e = Ce, n = n.stateNode, e.nodeType === 8 ? ao(e.parentNode, n) : e.nodeType === 1 && ao(e, n), Gr(e)) : ao(Ce, n.stateNode));
            break;
        case 4:
            r = Ce, l = ut, Ce = n.stateNode.containerInfo, ut = !0, It(e, t, n), Ce = r, ut = l;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!Ne && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                l = r = r.next;
                do {
                    var i = l,
                        o = i.destroy;
                    i = i.tag, o !== void 0 && (i & 2 || i & 4) && ou(n, t, o), l = l.next
                } while (l !== r)
            }
            It(e, t, n);
            break;
        case 1:
            if (!Ne && (Hn(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (u) {
                se(n, t, u)
            }
            It(e, t, n);
            break;
        case 21:
            It(e, t, n);
            break;
        case 22:
            n.mode & 1 ? (Ne = (r = Ne) || n.memoizedState !== null, It(e, t, n), Ne = r) : It(e, t, n);
            break;
        default:
            It(e, t, n)
    }
}

function Ts(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new nm), t.forEach(function(r) {
            var l = dm.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(l, l))
        })
    }
}

function it(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var l = n[r];
            try {
                var i = e,
                    o = t,
                    u = o;
                e: for (; u !== null;) {
                    switch (u.tag) {
                        case 5:
                            Ce = u.stateNode, ut = !1;
                            break e;
                        case 3:
                            Ce = u.stateNode.containerInfo, ut = !0;
                            break e;
                        case 4:
                            Ce = u.stateNode.containerInfo, ut = !0;
                            break e
                    }
                    u = u.return
                }
                if (Ce === null) throw Error(P(160));
                rd(i, o, l), Ce = null, ut = !1;
                var a = l.alternate;
                a !== null && (a.return = null), l.return = null
            } catch (s) {
                se(l, t, s)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) ld(t, e), t = t.sibling
}

function ld(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (it(t, e), ht(e), r & 4) {
                try {
                    Br(3, e, e.return), Li(3, e)
                } catch (w) {
                    se(e, e.return, w)
                }
                try {
                    Br(5, e, e.return)
                } catch (w) {
                    se(e, e.return, w)
                }
            }
            break;
        case 1:
            it(t, e), ht(e), r & 512 && n !== null && Hn(n, n.return);
            break;
        case 5:
            if (it(t, e), ht(e), r & 512 && n !== null && Hn(n, n.return), e.flags & 32) {
                var l = e.stateNode;
                try {
                    Qr(l, "")
                } catch (w) {
                    se(e, e.return, w)
                }
            }
            if (r & 4 && (l = e.stateNode, l != null)) {
                var i = e.memoizedProps,
                    o = n !== null ? n.memoizedProps : i,
                    u = e.type,
                    a = e.updateQueue;
                if (e.updateQueue = null, a !== null) try {
                    u === "input" && i.type === "radio" && i.name != null && Cc(l, i), zo(u, o);
                    var s = zo(u, i);
                    for (o = 0; o < a.length; o += 2) {
                        var c = a[o],
                            p = a[o + 1];
                        c === "style" ? Nc(l, p) : c === "dangerouslySetInnerHTML" ? Rc(l, p) : c === "children" ? Qr(l, p) : Tu(l, c, p, s)
                    }
                    switch (u) {
                        case "input":
                            To(l, i);
                            break;
                        case "textarea":
                            _c(l, i);
                            break;
                        case "select":
                            var m = l._wrapperState.wasMultiple;
                            l._wrapperState.wasMultiple = !!i.multiple;
                            var E = i.value;
                            E != null ? Xn(l, !!i.multiple, E, !1) : m !== !!i.multiple && (i.defaultValue != null ? Xn(l, !!i.multiple, i.defaultValue, !0) : Xn(l, !!i.multiple, i.multiple ? [] : "", !1))
                    }
                    l[el] = i
                } catch (w) {
                    se(e, e.return, w)
                }
            }
            break;
        case 6:
            if (it(t, e), ht(e), r & 4) {
                if (e.stateNode === null) throw Error(P(162));
                l = e.stateNode, i = e.memoizedProps;
                try {
                    l.nodeValue = i
                } catch (w) {
                    se(e, e.return, w)
                }
            }
            break;
        case 3:
            if (it(t, e), ht(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                Gr(t.containerInfo)
            } catch (w) {
                se(e, e.return, w)
            }
            break;
        case 4:
            it(t, e), ht(e);
            break;
        case 13:
            it(t, e), ht(e), l = e.child, l.flags & 8192 && (i = l.memoizedState !== null, l.stateNode.isHidden = i, !i || l.alternate !== null && l.alternate.memoizedState !== null || (ua = de())), r & 4 && Ts(e);
            break;
        case 22:
            if (c = n !== null && n.memoizedState !== null, e.mode & 1 ? (Ne = (s = Ne) || c, it(t, e), Ne = s) : it(t, e), ht(e), r & 8192) {
                if (s = e.memoizedState !== null, (e.stateNode.isHidden = s) && !c && e.mode & 1)
                    for (M = e, c = e.child; c !== null;) {
                        for (p = M = c; M !== null;) {
                            switch (m = M, E = m.child, m.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    Br(4, m, m.return);
                                    break;
                                case 1:
                                    Hn(m, m.return);
                                    var S = m.stateNode;
                                    if (typeof S.componentWillUnmount == "function") {
                                        r = m, n = m.return;
                                        try {
                                            t = r, S.props = t.memoizedProps, S.state = t.memoizedState, S.componentWillUnmount()
                                        } catch (w) {
                                            se(r, n, w)
                                        }
                                    }
                                    break;
                                case 5:
                                    Hn(m, m.return);
                                    break;
                                case 22:
                                    if (m.memoizedState !== null) {
                                        Ls(p);
                                        continue
                                    }
                            }
                            E !== null ? (E.return = m, M = E) : Ls(p)
                        }
                        c = c.sibling
                    }
                e: for (c = null, p = e;;) {
                    if (p.tag === 5) {
                        if (c === null) {
                            c = p;
                            try {
                                l = p.stateNode, s ? (i = l.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none") : (u = p.stateNode, a = p.memoizedProps.style, o = a != null && a.hasOwnProperty("display") ? a.display : null, u.style.display = Tc("display", o))
                            } catch (w) {
                                se(e, e.return, w)
                            }
                        }
                    } else if (p.tag === 6) {
                        if (c === null) try {
                            p.stateNode.nodeValue = s ? "" : p.memoizedProps
                        } catch (w) {
                            se(e, e.return, w)
                        }
                    } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === e) && p.child !== null) {
                        p.child.return = p, p = p.child;
                        continue
                    }
                    if (p === e) break e;
                    for (; p.sibling === null;) {
                        if (p.return === null || p.return === e) break e;
                        c === p && (c = null), p = p.return
                    }
                    c === p && (c = null), p.sibling.return = p.return, p = p.sibling
                }
            }
            break;
        case 19:
            it(t, e), ht(e), r & 4 && Ts(e);
            break;
        case 21:
            break;
        default:
            it(t, e), ht(e)
    }
}

function ht(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (nd(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(P(160))
            }
            switch (r.tag) {
                case 5:
                    var l = r.stateNode;
                    r.flags & 32 && (Qr(l, ""), r.flags &= -33);
                    var i = Rs(e);
                    su(e, i, l);
                    break;
                case 3:
                case 4:
                    var o = r.stateNode.containerInfo,
                        u = Rs(e);
                    au(e, u, o);
                    break;
                default:
                    throw Error(P(161))
            }
        }
        catch (a) {
            se(e, e.return, a)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function lm(e, t, n) {
    M = e, id(e)
}

function id(e, t, n) {
    for (var r = (e.mode & 1) !== 0; M !== null;) {
        var l = M,
            i = l.child;
        if (l.tag === 22 && r) {
            var o = l.memoizedState !== null || Ol;
            if (!o) {
                var u = l.alternate,
                    a = u !== null && u.memoizedState !== null || Ne;
                u = Ol;
                var s = Ne;
                if (Ol = o, (Ne = a) && !s)
                    for (M = l; M !== null;) o = M, a = o.child, o.tag === 22 && o.memoizedState !== null ? Ds(l) : a !== null ? (a.return = o, M = a) : Ds(l);
                for (; i !== null;) M = i, id(i), i = i.sibling;
                M = l, Ol = u, Ne = s
            }
            Ns(e)
        } else l.subtreeFlags & 8772 && i !== null ? (i.return = l, M = i) : Ns(e)
    }
}

function Ns(e) {
    for (; M !== null;) {
        var t = M;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Ne || Li(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !Ne)
                            if (n === null) r.componentDidMount();
                            else {
                                var l = t.elementType === t.type ? n.memoizedProps : ot(t.type, n.memoizedProps);
                                r.componentDidUpdate(l, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var i = t.updateQueue;
                        i !== null && ds(t, i, r);
                        break;
                    case 3:
                        var o = t.updateQueue;
                        if (o !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            ds(t, o, n)
                        }
                        break;
                    case 5:
                        var u = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = u;
                            var a = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    a.autoFocus && n.focus();
                                    break;
                                case "img":
                                    a.src && (n.src = a.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var s = t.alternate;
                            if (s !== null) {
                                var c = s.memoizedState;
                                if (c !== null) {
                                    var p = c.dehydrated;
                                    p !== null && Gr(p)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(P(163))
                }
                Ne || t.flags & 512 && uu(t)
            } catch (m) {
                se(t, t.return, m)
            }
        }
        if (t === e) {
            M = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, M = n;
            break
        }
        M = t.return
    }
}

function Ls(e) {
    for (; M !== null;) {
        var t = M;
        if (t === e) {
            M = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, M = n;
            break
        }
        M = t.return
    }
}

function Ds(e) {
    for (; M !== null;) {
        var t = M;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        Li(4, t)
                    } catch (a) {
                        se(t, n, a)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var l = t.return;
                        try {
                            r.componentDidMount()
                        } catch (a) {
                            se(t, l, a)
                        }
                    }
                    var i = t.return;
                    try {
                        uu(t)
                    } catch (a) {
                        se(t, i, a)
                    }
                    break;
                case 5:
                    var o = t.return;
                    try {
                        uu(t)
                    } catch (a) {
                        se(t, o, a)
                    }
            }
        } catch (a) {
            se(t, t.return, a)
        }
        if (t === e) {
            M = null;
            break
        }
        var u = t.sibling;
        if (u !== null) {
            u.return = t.return, M = u;
            break
        }
        M = t.return
    }
}
var im = Math.ceil,
    mi = Tt.ReactCurrentDispatcher,
    ia = Tt.ReactCurrentOwner,
    tt = Tt.ReactCurrentBatchConfig,
    K = 0,
    Ee = null,
    he = null,
    _e = 0,
    He = 0,
    Qn = nn(0),
    ye = 0,
    ol = null,
    En = 0,
    Di = 0,
    oa = 0,
    $r = null,
    je = null,
    ua = 0,
    or = 1 / 0,
    wt = null,
    vi = !1,
    cu = null,
    Gt = null,
    Fl = !1,
    Wt = null,
    yi = 0,
    Vr = 0,
    fu = null,
    Yl = -1,
    Xl = 0;

function ze() {
    return K & 6 ? de() : Yl !== -1 ? Yl : Yl = de()
}

function Zt(e) {
    return e.mode & 1 ? K & 2 && _e !== 0 ? _e & -_e : Vh.transition !== null ? (Xl === 0 && (Xl = $c()), Xl) : (e = Z, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Xc(e.type)), e) : 1
}

function ft(e, t, n, r) {
    if (50 < Vr) throw Vr = 0, fu = null, Error(P(185));
    cl(e, n, r), (!(K & 2) || e !== Ee) && (e === Ee && (!(K & 2) && (Di |= n), ye === 4 && $t(e, _e)), $e(e, r), n === 1 && K === 0 && !(t.mode & 1) && (or = de() + 500, Ri && rn()))
}

function $e(e, t) {
    var n = e.callbackNode;
    Vp(e, t);
    var r = ei(e, e === Ee ? _e : 0);
    if (r === 0) n !== null && Ba(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && Ba(n), t === 1) e.tag === 0 ? $h(Ms.bind(null, e)) : hf(Ms.bind(null, e)), jh(function() {
            !(K & 6) && rn()
        }), n = null;
        else {
            switch (Vc(r)) {
                case 1:
                    n = zu;
                    break;
                case 4:
                    n = Ac;
                    break;
                case 16:
                    n = bl;
                    break;
                case 536870912:
                    n = Bc;
                    break;
                default:
                    n = bl
            }
            n = pd(n, od.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function od(e, t) {
    if (Yl = -1, Xl = 0, K & 6) throw Error(P(327));
    var n = e.callbackNode;
    if (bn() && e.callbackNode !== n) return null;
    var r = ei(e, e === Ee ? _e : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = gi(e, r);
    else {
        t = r;
        var l = K;
        K |= 2;
        var i = ad();
        (Ee !== e || _e !== t) && (wt = null, or = de() + 500, vn(e, t));
        do try {
            am();
            break
        } catch (u) {
            ud(e, u)
        }
        while (1);
        Ku(), mi.current = i, K = l, he !== null ? t = 0 : (Ee = null, _e = 0, t = ye)
    }
    if (t !== 0) {
        if (t === 2 && (l = Uo(e), l !== 0 && (r = l, t = du(e, l))), t === 1) throw n = ol, vn(e, 0), $t(e, r), $e(e, de()), n;
        if (t === 6) $t(e, r);
        else {
            if (l = e.current.alternate, !(r & 30) && !om(l) && (t = gi(e, r), t === 2 && (i = Uo(e), i !== 0 && (r = i, t = du(e, i))), t === 1)) throw n = ol, vn(e, 0), $t(e, r), $e(e, de()), n;
            switch (e.finishedWork = l, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(P(345));
                case 2:
                    an(e, je, wt);
                    break;
                case 3:
                    if ($t(e, r), (r & 130023424) === r && (t = ua + 500 - de(), 10 < t)) {
                        if (ei(e, 0) !== 0) break;
                        if (l = e.suspendedLanes, (l & r) !== r) {
                            ze(), e.pingedLanes |= e.suspendedLanes & l;
                            break
                        }
                        e.timeoutHandle = Ko(an.bind(null, e, je, wt), t);
                        break
                    }
                    an(e, je, wt);
                    break;
                case 4:
                    if ($t(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, l = -1; 0 < r;) {
                        var o = 31 - ct(r);
                        i = 1 << o, o = t[o], o > l && (l = o), r &= ~i
                    }
                    if (r = l, r = de() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * im(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = Ko(an.bind(null, e, je, wt), r);
                        break
                    }
                    an(e, je, wt);
                    break;
                case 5:
                    an(e, je, wt);
                    break;
                default:
                    throw Error(P(329))
            }
        }
    }
    return $e(e, de()), e.callbackNode === n ? od.bind(null, e) : null
}

function du(e, t) {
    var n = $r;
    return e.current.memoizedState.isDehydrated && (vn(e, t).flags |= 256), e = gi(e, t), e !== 2 && (t = je, je = n, t !== null && pu(t)), e
}

function pu(e) {
    je === null ? je = e : je.push.apply(je, e)
}

function om(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var l = n[r],
                        i = l.getSnapshot;
                    l = l.value;
                    try {
                        if (!dt(i(), l)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function $t(e, t) {
    for (t &= ~oa, t &= ~Di, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - ct(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function Ms(e) {
    if (K & 6) throw Error(P(327));
    bn();
    var t = ei(e, 0);
    if (!(t & 1)) return $e(e, de()), null;
    var n = gi(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = Uo(e);
        r !== 0 && (t = r, n = du(e, r))
    }
    if (n === 1) throw n = ol, vn(e, 0), $t(e, t), $e(e, de()), n;
    if (n === 6) throw Error(P(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, an(e, je, wt), $e(e, de()), null
}

function aa(e, t) {
    var n = K;
    K |= 1;
    try {
        return e(t)
    } finally {
        K = n, K === 0 && (or = de() + 500, Ri && rn())
    }
}

function kn(e) {
    Wt !== null && Wt.tag === 0 && !(K & 6) && bn();
    var t = K;
    K |= 1;
    var n = tt.transition,
        r = Z;
    try {
        if (tt.transition = null, Z = 1, e) return e()
    } finally {
        Z = r, tt.transition = n, K = t, !(K & 6) && rn()
    }
}

function sa() {
    He = Qn.current, ne(Qn)
}

function vn(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, Ih(n)), he !== null)
        for (n = he.return; n !== null;) {
            var r = n;
            switch (Wu(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && ii();
                    break;
                case 3:
                    lr(), ne(Ae), ne(Le), qu();
                    break;
                case 5:
                    Ju(r);
                    break;
                case 4:
                    lr();
                    break;
                case 13:
                    ne(ie);
                    break;
                case 19:
                    ne(ie);
                    break;
                case 10:
                    Yu(r.type._context);
                    break;
                case 22:
                case 23:
                    sa()
            }
            n = n.return
        }
    if (Ee = e, he = e = Jt(e.current, null), _e = He = t, ye = 0, ol = null, oa = Di = En = 0, je = $r = null, dn !== null) {
        for (t = 0; t < dn.length; t++)
            if (n = dn[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var l = r.next,
                    i = n.pending;
                if (i !== null) {
                    var o = i.next;
                    i.next = l, r.next = o
                }
                n.pending = r
            }
        dn = null
    }
    return e
}

function ud(e, t) {
    do {
        var n = he;
        try {
            if (Ku(), Hl.current = hi, pi) {
                for (var r = oe.memoizedState; r !== null;) {
                    var l = r.queue;
                    l !== null && (l.pending = null), r = r.next
                }
                pi = !1
            }
            if (Sn = 0, Se = ve = oe = null, Ar = !1, rl = 0, ia.current = null, n === null || n.return === null) {
                ye = 1, ol = t, he = null;
                break
            }
            e: {
                var i = e,
                    o = n.return,
                    u = n,
                    a = t;
                if (t = _e, u.flags |= 32768, a !== null && typeof a == "object" && typeof a.then == "function") {
                    var s = a,
                        c = u,
                        p = c.tag;
                    if (!(c.mode & 1) && (p === 0 || p === 11 || p === 15)) {
                        var m = c.alternate;
                        m ? (c.updateQueue = m.updateQueue, c.memoizedState = m.memoizedState, c.lanes = m.lanes) : (c.updateQueue = null, c.memoizedState = null)
                    }
                    var E = ws(o);
                    if (E !== null) {
                        E.flags &= -257, Ss(E, o, u, i, t), E.mode & 1 && gs(i, s, t), t = E, a = s;
                        var S = t.updateQueue;
                        if (S === null) {
                            var w = new Set;
                            w.add(a), t.updateQueue = w
                        } else S.add(a);
                        break e
                    } else {
                        if (!(t & 1)) {
                            gs(i, s, t), ca();
                            break e
                        }
                        a = Error(P(426))
                    }
                } else if (le && u.mode & 1) {
                    var C = ws(o);
                    if (C !== null) {
                        !(C.flags & 65536) && (C.flags |= 256), Ss(C, o, u, i, t), Hu(ir(a, u));
                        break e
                    }
                }
                i = a = ir(a, u),
                ye !== 4 && (ye = 2),
                $r === null ? $r = [i] : $r.push(i),
                i = o;do {
                    switch (i.tag) {
                        case 3:
                            i.flags |= 65536, t &= -t, i.lanes |= t;
                            var d = Hf(i, a, t);
                            fs(i, d);
                            break e;
                        case 1:
                            u = a;
                            var f = i.type,
                                h = i.stateNode;
                            if (!(i.flags & 128) && (typeof f.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (Gt === null || !Gt.has(h)))) {
                                i.flags |= 65536, t &= -t, i.lanes |= t;
                                var x = Qf(i, u, t);
                                fs(i, x);
                                break e
                            }
                    }
                    i = i.return
                } while (i !== null)
            }
            cd(n)
        } catch (T) {
            t = T, he === n && n !== null && (he = n = n.return);
            continue
        }
        break
    } while (1)
}

function ad() {
    var e = mi.current;
    return mi.current = hi, e === null ? hi : e
}

function ca() {
    (ye === 0 || ye === 3 || ye === 2) && (ye = 4), Ee === null || !(En & 268435455) && !(Di & 268435455) || $t(Ee, _e)
}

function gi(e, t) {
    var n = K;
    K |= 2;
    var r = ad();
    (Ee !== e || _e !== t) && (wt = null, vn(e, t));
    do try {
        um();
        break
    } catch (l) {
        ud(e, l)
    }
    while (1);
    if (Ku(), K = n, mi.current = r, he !== null) throw Error(P(261));
    return Ee = null, _e = 0, ye
}

function um() {
    for (; he !== null;) sd(he)
}

function am() {
    for (; he !== null && !zp();) sd(he)
}

function sd(e) {
    var t = dd(e.alternate, e, He);
    e.memoizedProps = e.pendingProps, t === null ? cd(e) : he = t, ia.current = null
}

function cd(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = tm(n, t), n !== null) {
                n.flags &= 32767, he = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                ye = 6, he = null;
                return
            }
        } else if (n = em(n, t, He), n !== null) {
            he = n;
            return
        }
        if (t = t.sibling, t !== null) {
            he = t;
            return
        }
        he = t = e
    } while (t !== null);
    ye === 0 && (ye = 5)
}

function an(e, t, n) {
    var r = Z,
        l = tt.transition;
    try {
        tt.transition = null, Z = 1, sm(e, t, n, r)
    } finally {
        tt.transition = l, Z = r
    }
    return null
}

function sm(e, t, n, r) {
    do bn(); while (Wt !== null);
    if (K & 6) throw Error(P(327));
    n = e.finishedWork;
    var l = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(P(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var i = n.lanes | n.childLanes;
    if (Wp(e, i), e === Ee && (he = Ee = null, _e = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || Fl || (Fl = !0, pd(bl, function() {
            return bn(), null
        })), i = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || i) {
        i = tt.transition, tt.transition = null;
        var o = Z;
        Z = 1;
        var u = K;
        K |= 4, ia.current = null, rm(e, n), ld(n, e), Nh(Ho), ti = !!Wo, Ho = Wo = null, e.current = n, lm(n), Op(), K = u, Z = o, tt.transition = i
    } else e.current = n;
    if (Fl && (Fl = !1, Wt = e, yi = l), i = e.pendingLanes, i === 0 && (Gt = null), jp(n.stateNode), $e(e, de()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) l = t[n], r(l.value, {
            componentStack: l.stack,
            digest: l.digest
        });
    if (vi) throw vi = !1, e = cu, cu = null, e;
    return yi & 1 && e.tag !== 0 && bn(), i = e.pendingLanes, i & 1 ? e === fu ? Vr++ : (Vr = 0, fu = e) : Vr = 0, rn(), null
}

function bn() {
    if (Wt !== null) {
        var e = Vc(yi),
            t = tt.transition,
            n = Z;
        try {
            if (tt.transition = null, Z = 16 > e ? 16 : e, Wt === null) var r = !1;
            else {
                if (e = Wt, Wt = null, yi = 0, K & 6) throw Error(P(331));
                var l = K;
                for (K |= 4, M = e.current; M !== null;) {
                    var i = M,
                        o = i.child;
                    if (M.flags & 16) {
                        var u = i.deletions;
                        if (u !== null) {
                            for (var a = 0; a < u.length; a++) {
                                var s = u[a];
                                for (M = s; M !== null;) {
                                    var c = M;
                                    switch (c.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            Br(8, c, i)
                                    }
                                    var p = c.child;
                                    if (p !== null) p.return = c, M = p;
                                    else
                                        for (; M !== null;) {
                                            c = M;
                                            var m = c.sibling,
                                                E = c.return;
                                            if (td(c), c === s) {
                                                M = null;
                                                break
                                            }
                                            if (m !== null) {
                                                m.return = E, M = m;
                                                break
                                            }
                                            M = E
                                        }
                                }
                            }
                            var S = i.alternate;
                            if (S !== null) {
                                var w = S.child;
                                if (w !== null) {
                                    S.child = null;
                                    do {
                                        var C = w.sibling;
                                        w.sibling = null, w = C
                                    } while (w !== null)
                                }
                            }
                            M = i
                        }
                    }
                    if (i.subtreeFlags & 2064 && o !== null) o.return = i, M = o;
                    else e: for (; M !== null;) {
                        if (i = M, i.flags & 2048) switch (i.tag) {
                            case 0:
                            case 11:
                            case 15:
                                Br(9, i, i.return)
                        }
                        var d = i.sibling;
                        if (d !== null) {
                            d.return = i.return, M = d;
                            break e
                        }
                        M = i.return
                    }
                }
                var f = e.current;
                for (M = f; M !== null;) {
                    o = M;
                    var h = o.child;
                    if (o.subtreeFlags & 2064 && h !== null) h.return = o, M = h;
                    else e: for (o = f; M !== null;) {
                        if (u = M, u.flags & 2048) try {
                            switch (u.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Li(9, u)
                            }
                        } catch (T) {
                            se(u, u.return, T)
                        }
                        if (u === o) {
                            M = null;
                            break e
                        }
                        var x = u.sibling;
                        if (x !== null) {
                            x.return = u.return, M = x;
                            break e
                        }
                        M = u.return
                    }
                }
                if (K = l, rn(), yt && typeof yt.onPostCommitFiberRoot == "function") try {
                    yt.onPostCommitFiberRoot(ki, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            Z = n, tt.transition = t
        }
    }
    return !1
}

function zs(e, t, n) {
    t = ir(n, t), t = Hf(e, t, 1), e = Xt(e, t, 1), t = ze(), e !== null && (cl(e, 1, t), $e(e, t))
}

function se(e, t, n) {
    if (e.tag === 3) zs(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                zs(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Gt === null || !Gt.has(r))) {
                    e = ir(n, e), e = Qf(t, e, 1), t = Xt(t, e, 1), e = ze(), t !== null && (cl(t, 1, e), $e(t, e));
                    break
                }
            }
            t = t.return
        }
}

function cm(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = ze(), e.pingedLanes |= e.suspendedLanes & n, Ee === e && (_e & n) === n && (ye === 4 || ye === 3 && (_e & 130023424) === _e && 500 > de() - ua ? vn(e, 0) : oa |= n), $e(e, t)
}

function fd(e, t) {
    t === 0 && (e.mode & 1 ? (t = _l, _l <<= 1, !(_l & 130023424) && (_l = 4194304)) : t = 1);
    var n = ze();
    e = Pt(e, t), e !== null && (cl(e, t, n), $e(e, n))
}

function fm(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), fd(e, n)
}

function dm(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                l = e.memoizedState;
            l !== null && (n = l.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(P(314))
    }
    r !== null && r.delete(t), fd(e, n)
}
var dd;
dd = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || Ae.current) Ue = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return Ue = !1, bh(e, t, n);
            Ue = !!(e.flags & 131072)
        }
    else Ue = !1, le && t.flags & 1048576 && mf(t, ai, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            Kl(e, t), e = t.pendingProps;
            var l = tr(t, Le.current);
            qn(t, n), l = ea(null, t, r, e, l, n);
            var i = ta();
            return t.flags |= 1, typeof l == "object" && l !== null && typeof l.render == "function" && l.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Be(r) ? (i = !0, oi(t)) : i = !1, t.memoizedState = l.state !== null && l.state !== void 0 ? l.state : null, Gu(t), l.updater = Ti, t.stateNode = l, l._reactInternals = t, bo(t, r, e, n), t = nu(null, t, r, !0, i, n)) : (t.tag = 0, le && i && Vu(t), Me(null, t, l, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (Kl(e, t), e = t.pendingProps, l = r._init, r = l(r._payload), t.type = r, l = t.tag = hm(r), e = ot(r, e), l) {
                    case 0:
                        t = tu(null, t, r, e, n);
                        break e;
                    case 1:
                        t = xs(null, t, r, e, n);
                        break e;
                    case 11:
                        t = Es(null, t, r, e, n);
                        break e;
                    case 14:
                        t = ks(null, t, r, ot(r.type, e), n);
                        break e
                }
                throw Error(P(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ot(r, l), tu(e, t, r, l, n);
        case 1:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ot(r, l), xs(e, t, r, l, n);
        case 3:
            e: {
                if (Gf(t), e === null) throw Error(P(387));r = t.pendingProps,
                i = t.memoizedState,
                l = i.element,
                wf(e, t),
                fi(t, r, null, n);
                var o = t.memoizedState;
                if (r = o.element, i.isDehydrated)
                    if (i = {
                            element: r,
                            isDehydrated: !1,
                            cache: o.cache,
                            pendingSuspenseBoundaries: o.pendingSuspenseBoundaries,
                            transitions: o.transitions
                        }, t.updateQueue.baseState = i, t.memoizedState = i, t.flags & 256) {
                        l = ir(Error(P(423)), t), t = Cs(e, t, r, n, l);
                        break e
                    } else if (r !== l) {
                    l = ir(Error(P(424)), t), t = Cs(e, t, r, n, l);
                    break e
                } else
                    for (Qe = Yt(t.stateNode.containerInfo.firstChild), Ke = t, le = !0, st = null, n = xf(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (nr(), r === l) {
                        t = Rt(e, t, n);
                        break e
                    }
                    Me(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return Cf(t), e === null && Zo(t), r = t.type, l = t.pendingProps, i = e !== null ? e.memoizedProps : null, o = l.children, Qo(r, l) ? o = null : i !== null && Qo(r, i) && (t.flags |= 32), Xf(e, t), Me(e, t, o, n), t.child;
        case 6:
            return e === null && Zo(t), null;
        case 13:
            return Zf(e, t, n);
        case 4:
            return Zu(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = rr(t, null, r, n) : Me(e, t, r, n), t.child;
        case 11:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ot(r, l), Es(e, t, r, l, n);
        case 7:
            return Me(e, t, t.pendingProps, n), t.child;
        case 8:
            return Me(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return Me(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, l = t.pendingProps, i = t.memoizedProps, o = l.value, b(si, r._currentValue), r._currentValue = o, i !== null)
                    if (dt(i.value, o)) {
                        if (i.children === l.children && !Ae.current) {
                            t = Rt(e, t, n);
                            break e
                        }
                    } else
                        for (i = t.child, i !== null && (i.return = t); i !== null;) {
                            var u = i.dependencies;
                            if (u !== null) {
                                o = i.child;
                                for (var a = u.firstContext; a !== null;) {
                                    if (a.context === r) {
                                        if (i.tag === 1) {
                                            a = xt(-1, n & -n), a.tag = 2;
                                            var s = i.updateQueue;
                                            if (s !== null) {
                                                s = s.shared;
                                                var c = s.pending;
                                                c === null ? a.next = a : (a.next = c.next, c.next = a), s.pending = a
                                            }
                                        }
                                        i.lanes |= n, a = i.alternate, a !== null && (a.lanes |= n), Jo(i.return, n, t), u.lanes |= n;
                                        break
                                    }
                                    a = a.next
                                }
                            } else if (i.tag === 10) o = i.type === t.type ? null : i.child;
                            else if (i.tag === 18) {
                                if (o = i.return, o === null) throw Error(P(341));
                                o.lanes |= n, u = o.alternate, u !== null && (u.lanes |= n), Jo(o, n, t), o = i.sibling
                            } else o = i.child;
                            if (o !== null) o.return = i;
                            else
                                for (o = i; o !== null;) {
                                    if (o === t) {
                                        o = null;
                                        break
                                    }
                                    if (i = o.sibling, i !== null) {
                                        i.return = o.return, o = i;
                                        break
                                    }
                                    o = o.return
                                }
                            i = o
                        }
                Me(e, t, l.children, n),
                t = t.child
            }
            return t;
        case 9:
            return l = t.type, r = t.pendingProps.children, qn(t, n), l = nt(l), r = r(l), t.flags |= 1, Me(e, t, r, n), t.child;
        case 14:
            return r = t.type, l = ot(r, t.pendingProps), l = ot(r.type, l), ks(e, t, r, l, n);
        case 15:
            return Kf(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, l = t.pendingProps, l = t.elementType === r ? l : ot(r, l), Kl(e, t), t.tag = 1, Be(r) ? (e = !0, oi(t)) : e = !1, qn(t, n), Ef(t, r, l), bo(t, r, l, n), nu(null, t, r, !0, e, n);
        case 19:
            return Jf(e, t, n);
        case 22:
            return Yf(e, t, n)
    }
    throw Error(P(156, t.tag))
};

function pd(e, t) {
    return Uc(e, t)
}

function pm(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function et(e, t, n, r) {
    return new pm(e, t, n, r)
}

function fa(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function hm(e) {
    if (typeof e == "function") return fa(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === Lu) return 11;
        if (e === Du) return 14
    }
    return 2
}

function Jt(e, t) {
    var n = e.alternate;
    return n === null ? (n = et(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function Gl(e, t, n, r, l, i) {
    var o = 2;
    if (r = e, typeof e == "function") fa(e) && (o = 1);
    else if (typeof e == "string") o = 5;
    else e: switch (e) {
        case Fn:
            return yn(n.children, l, i, t);
        case Nu:
            o = 8, l |= 8;
            break;
        case xo:
            return e = et(12, n, t, l | 2), e.elementType = xo, e.lanes = i, e;
        case Co:
            return e = et(13, n, t, l), e.elementType = Co, e.lanes = i, e;
        case _o:
            return e = et(19, n, t, l), e.elementType = _o, e.lanes = i, e;
        case Ec:
            return Mi(n, l, i, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case wc:
                    o = 10;
                    break e;
                case Sc:
                    o = 9;
                    break e;
                case Lu:
                    o = 11;
                    break e;
                case Du:
                    o = 14;
                    break e;
                case Ut:
                    o = 16, r = null;
                    break e
            }
            throw Error(P(130, e == null ? e : typeof e, ""))
    }
    return t = et(o, n, t, l), t.elementType = e, t.type = r, t.lanes = i, t
}

function yn(e, t, n, r) {
    return e = et(7, e, r, t), e.lanes = n, e
}

function Mi(e, t, n, r) {
    return e = et(22, e, r, t), e.elementType = Ec, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function yo(e, t, n) {
    return e = et(6, e, null, t), e.lanes = n, e
}

function go(e, t, n) {
    return t = et(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function mm(e, t, n, r, l) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Ji(0), this.expirationTimes = Ji(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Ji(0), this.identifierPrefix = r, this.onRecoverableError = l, this.mutableSourceEagerHydrationData = null
}

function da(e, t, n, r, l, i, o, u, a) {
    return e = new mm(e, t, n, u, a), t === 1 ? (t = 1, i === !0 && (t |= 8)) : t = 0, i = et(3, null, null, t), e.current = i, i.stateNode = e, i.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, Gu(i), e
}

function vm(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: On,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function hd(e) {
    if (!e) return en;
    e = e._reactInternals;
    e: {
        if (Cn(e) !== e || e.tag !== 1) throw Error(P(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (Be(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(P(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (Be(n)) return pf(e, n, t)
    }
    return t
}

function md(e, t, n, r, l, i, o, u, a) {
    return e = da(n, r, !0, e, l, i, o, u, a), e.context = hd(null), n = e.current, r = ze(), l = Zt(n), i = xt(r, l), i.callback = t ? ? null, Xt(n, i, l), e.current.lanes = l, cl(e, l, r), $e(e, r), e
}

function zi(e, t, n, r) {
    var l = t.current,
        i = ze(),
        o = Zt(l);
    return n = hd(n), t.context === null ? t.context = n : t.pendingContext = n, t = xt(i, o), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = Xt(l, t, o), e !== null && (ft(e, l, o, i), Wl(e, l, o)), o
}

function wi(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function Os(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function pa(e, t) {
    Os(e, t), (e = e.alternate) && Os(e, t)
}

function ym() {
    return null
}
var vd = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function ha(e) {
    this._internalRoot = e
}
Oi.prototype.render = ha.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(P(409));
    zi(e, t, null, null)
};
Oi.prototype.unmount = ha.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        kn(function() {
            zi(null, e, null, null)
        }), t[_t] = null
    }
};

function Oi(e) {
    this._internalRoot = e
}
Oi.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = Qc();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < Bt.length && t !== 0 && t < Bt[n].priority; n++);
        Bt.splice(n, 0, e), n === 0 && Yc(e)
    }
};

function ma(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function Fi(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function Fs() {}

function gm(e, t, n, r, l) {
    if (l) {
        if (typeof r == "function") {
            var i = r;
            r = function() {
                var s = wi(o);
                i.call(s)
            }
        }
        var o = md(t, r, e, 0, null, !1, !1, "", Fs);
        return e._reactRootContainer = o, e[_t] = o.current, qr(e.nodeType === 8 ? e.parentNode : e), kn(), o
    }
    for (; l = e.lastChild;) e.removeChild(l);
    if (typeof r == "function") {
        var u = r;
        r = function() {
            var s = wi(a);
            u.call(s)
        }
    }
    var a = da(e, 0, !1, null, null, !1, !1, "", Fs);
    return e._reactRootContainer = a, e[_t] = a.current, qr(e.nodeType === 8 ? e.parentNode : e), kn(function() {
        zi(t, a, n, r)
    }), a
}

function Ii(e, t, n, r, l) {
    var i = n._reactRootContainer;
    if (i) {
        var o = i;
        if (typeof l == "function") {
            var u = l;
            l = function() {
                var a = wi(o);
                u.call(a)
            }
        }
        zi(t, o, e, l)
    } else o = gm(n, t, e, l, r);
    return wi(o)
}
Wc = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = Lr(t.pendingLanes);
                n !== 0 && (Ou(t, n | 1), $e(t, de()), !(K & 6) && (or = de() + 500, rn()))
            }
            break;
        case 13:
            kn(function() {
                var r = Pt(e, 1);
                if (r !== null) {
                    var l = ze();
                    ft(r, e, 1, l)
                }
            }), pa(e, 1)
    }
};
Fu = function(e) {
    if (e.tag === 13) {
        var t = Pt(e, 134217728);
        if (t !== null) {
            var n = ze();
            ft(t, e, 134217728, n)
        }
        pa(e, 134217728)
    }
};
Hc = function(e) {
    if (e.tag === 13) {
        var t = Zt(e),
            n = Pt(e, t);
        if (n !== null) {
            var r = ze();
            ft(n, e, t, r)
        }
        pa(e, t)
    }
};
Qc = function() {
    return Z
};
Kc = function(e, t) {
    var n = Z;
    try {
        return Z = e, t()
    } finally {
        Z = n
    }
};
Fo = function(e, t, n) {
    switch (t) {
        case "input":
            if (To(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var l = Pi(r);
                        if (!l) throw Error(P(90));
                        xc(r), To(r, l)
                    }
                }
            }
            break;
        case "textarea":
            _c(e, n);
            break;
        case "select":
            t = n.value, t != null && Xn(e, !!n.multiple, t, !1)
    }
};
Mc = aa;
zc = kn;
var wm = {
        usingClientEntryPoint: !1,
        Events: [dl, An, Pi, Lc, Dc, aa]
    },
    kr = {
        findFiberByHostInstance: fn,
        bundleType: 0,
        version: "18.2.0",
        rendererPackageName: "react-dom"
    },
    Sm = {
        bundleType: kr.bundleType,
        version: kr.version,
        rendererPackageName: kr.rendererPackageName,
        rendererConfig: kr.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: Tt.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = Ic(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: kr.findFiberByHostInstance || ym,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.2.0-next-9e3b772b8-20220608"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Il = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Il.isDisabled && Il.supportsFiber) try {
        ki = Il.inject(Sm), yt = Il
    } catch {}
}
Xe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = wm;
Xe.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!ma(t)) throw Error(P(200));
    return vm(e, t, null, n)
};
Xe.createRoot = function(e, t) {
    if (!ma(e)) throw Error(P(299));
    var n = !1,
        r = "",
        l = vd;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (l = t.onRecoverableError)), t = da(e, 1, !1, null, null, n, !1, r, l), e[_t] = t.current, qr(e.nodeType === 8 ? e.parentNode : e), new ha(t)
};
Xe.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(P(188)) : (e = Object.keys(e).join(","), Error(P(268, e)));
    return e = Ic(t), e = e === null ? null : e.stateNode, e
};
Xe.flushSync = function(e) {
    return kn(e)
};
Xe.hydrate = function(e, t, n) {
    if (!Fi(t)) throw Error(P(200));
    return Ii(null, e, t, !0, n)
};
Xe.hydrateRoot = function(e, t, n) {
    if (!ma(e)) throw Error(P(405));
    var r = n != null && n.hydratedSources || null,
        l = !1,
        i = "",
        o = vd;
    if (n != null && (n.unstable_strictMode === !0 && (l = !0), n.identifierPrefix !== void 0 && (i = n.identifierPrefix), n.onRecoverableError !== void 0 && (o = n.onRecoverableError)), t = md(t, null, e, 1, n ? ? null, l, !1, i, o), e[_t] = t.current, qr(e), r)
        for (e = 0; e < r.length; e++) n = r[e], l = n._getVersion, l = l(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, l] : t.mutableSourceEagerHydrationData.push(n, l);
    return new Oi(t)
};
Xe.render = function(e, t, n) {
    if (!Fi(t)) throw Error(P(200));
    return Ii(null, e, t, !1, n)
};
Xe.unmountComponentAtNode = function(e) {
    if (!Fi(e)) throw Error(P(40));
    return e._reactRootContainer ? (kn(function() {
        Ii(null, null, e, !1, function() {
            e._reactRootContainer = null, e[_t] = null
        })
    }), !0) : !1
};
Xe.unstable_batchedUpdates = aa;
Xe.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!Fi(n)) throw Error(P(200));
    if (e == null || e._reactInternals === void 0) throw Error(P(38));
    return Ii(e, t, n, !1, r)
};
Xe.version = "18.2.0-next-9e3b772b8-20220608";

function yd() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(yd)
    } catch (e) {
        console.error(e)
    }
}
yd(), hc.exports = Xe;
var gd = hc.exports;
const Mr = Eu(gd),
    Em = ic({
        __proto__: null,
        default: Mr
    }, [gd]);

function Is() {
    return Is = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Is.apply(this, arguments)
}
var wd = {
        exports: {}
    },
    km = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED",
    xm = km,
    Cm = xm;

function Sd() {}

function Ed() {}
Ed.resetWarningCache = Sd;
var _m = function() {
    function e(r, l, i, o, u, a) {
        if (a !== Cm) {
            var s = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
            throw s.name = "Invariant Violation", s
        }
    }
    e.isRequired = e;

    function t() {
        return e
    }
    var n = {
        array: e,
        bigint: e,
        bool: e,
        func: e,
        number: e,
        object: e,
        string: e,
        symbol: e,
        any: e,
        arrayOf: t,
        element: e,
        elementType: e,
        instanceOf: t,
        node: e,
        objectOf: t,
        oneOf: t,
        oneOfType: t,
        shape: t,
        exact: t,
        checkPropTypes: Ed,
        resetWarningCache: Sd
    };
    return n.PropTypes = n, n
};
wd.exports = _m();
var Pm = wd.exports;
const bv = Eu(Pm);
/**
 * @remix-run/router v1.15.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function ce() {
    return ce = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, ce.apply(this, arguments)
}
var fe;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(fe || (fe = {}));
const js = "popstate";

function Rm(e) {
    e === void 0 && (e = {});

    function t(r, l) {
        let {
            pathname: i,
            search: o,
            hash: u
        } = r.location;
        return ul("", {
            pathname: i,
            search: o,
            hash: u
        }, l.state && l.state.usr || null, l.state && l.state.key || "default")
    }

    function n(r, l) {
        return typeof l == "string" ? l : hl(l)
    }
    return Nm(t, n, null, e)
}

function V(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function ur(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function Tm() {
    return Math.random().toString(36).substr(2, 8)
}

function Us(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function ul(e, t, n, r) {
    return n === void 0 && (n = null), ce({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? Nt(t) : t, {
        state: n,
        key: t && t.key || r || Tm()
    })
}

function hl(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function Nt(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Nm(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: l = document.defaultView,
        v5Compat: i = !1
    } = r, o = l.history, u = fe.Pop, a = null, s = c();
    s == null && (s = 0, o.replaceState(ce({}, o.state, {
        idx: s
    }), ""));

    function c() {
        return (o.state || {
            idx: null
        }).idx
    }

    function p() {
        u = fe.Pop;
        let C = c(),
            d = C == null ? null : C - s;
        s = C, a && a({
            action: u,
            location: w.location,
            delta: d
        })
    }

    function m(C, d) {
        u = fe.Push;
        let f = ul(w.location, C, d);
        n && n(f, C), s = c() + 1;
        let h = Us(f, s),
            x = w.createHref(f);
        try {
            o.pushState(h, "", x)
        } catch (T) {
            if (T instanceof DOMException && T.name === "DataCloneError") throw T;
            l.location.assign(x)
        }
        i && a && a({
            action: u,
            location: w.location,
            delta: 1
        })
    }

    function E(C, d) {
        u = fe.Replace;
        let f = ul(w.location, C, d);
        n && n(f, C), s = c();
        let h = Us(f, s),
            x = w.createHref(f);
        o.replaceState(h, "", x), i && a && a({
            action: u,
            location: w.location,
            delta: 0
        })
    }

    function S(C) {
        let d = l.location.origin !== "null" ? l.location.origin : l.location.href,
            f = typeof C == "string" ? C : hl(C);
        return f = f.replace(/ $/, "%20"), V(d, "No window.location.(origin|href) available to create URL for href: " + f), new URL(f, d)
    }
    let w = {
        get action() {
            return u
        },
        get location() {
            return e(l, o)
        },
        listen(C) {
            if (a) throw new Error("A history only accepts one active listener");
            return l.addEventListener(js, p), a = C, () => {
                l.removeEventListener(js, p), a = null
            }
        },
        createHref(C) {
            return t(l, C)
        },
        createURL: S,
        encodeLocation(C) {
            let d = S(C);
            return {
                pathname: d.pathname,
                search: d.search,
                hash: d.hash
            }
        },
        push: m,
        replace: E,
        go(C) {
            return o.go(C)
        }
    };
    return w
}
var ae;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(ae || (ae = {}));
const Lm = new Set(["lazy", "caseSensitive", "path", "id", "index", "children"]);

function Dm(e) {
    return e.index === !0
}

function hu(e, t, n, r) {
    return n === void 0 && (n = []), r === void 0 && (r = {}), e.map((l, i) => {
        let o = [...n, i],
            u = typeof l.id == "string" ? l.id : o.join("-");
        if (V(l.index !== !0 || !l.children, "Cannot specify children on an index route"), V(!r[u], 'Found a route id collision on id "' + u + `".  Route id's must be globally unique within Data Router usages`), Dm(l)) {
            let a = ce({}, l, t(l), {
                id: u
            });
            return r[u] = a, a
        } else {
            let a = ce({}, l, t(l), {
                id: u,
                children: void 0
            });
            return r[u] = a, l.children && (a.children = hu(l.children, t, o, r)), a
        }
    })
}

function Kn(e, t, n) {
    n === void 0 && (n = "/");
    let r = typeof t == "string" ? Nt(t) : t,
        l = ml(r.pathname || "/", n);
    if (l == null) return null;
    let i = kd(e);
    zm(i);
    let o = null;
    for (let u = 0; o == null && u < i.length; ++u) {
        let a = Qm(l);
        o = Vm(i[u], a)
    }
    return o
}

function Mm(e, t) {
    let {
        route: n,
        pathname: r,
        params: l
    } = e;
    return {
        id: n.id,
        pathname: r,
        params: l,
        data: t[n.id],
        handle: n.handle
    }
}

function kd(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let l = (i, o, u) => {
        let a = {
            relativePath: u === void 0 ? i.path || "" : u,
            caseSensitive: i.caseSensitive === !0,
            childrenIndex: o,
            route: i
        };
        a.relativePath.startsWith("/") && (V(a.relativePath.startsWith(r), 'Absolute route path "' + a.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), a.relativePath = a.relativePath.slice(r.length));
        let s = qt([r, a.relativePath]),
            c = n.concat(a);
        i.children && i.children.length > 0 && (V(i.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + s + '".')), kd(i.children, t, c, s)), !(i.path == null && !i.index) && t.push({
            path: s,
            score: Bm(s, i.index),
            routesMeta: c
        })
    };
    return e.forEach((i, o) => {
        var u;
        if (i.path === "" || !((u = i.path) != null && u.includes("?"))) l(i, o);
        else
            for (let a of xd(i.path)) l(i, o, a)
    }), t
}

function xd(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, l = n.endsWith("?"), i = n.replace(/\?$/, "");
    if (r.length === 0) return l ? [i, ""] : [i];
    let o = xd(r.join("/")),
        u = [];
    return u.push(...o.map(a => a === "" ? i : [i, a].join("/"))), l && u.push(...o), u.map(a => e.startsWith("/") && a === "" ? "/" : a)
}

function zm(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : $m(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const Om = /^:[\w-]+$/,
    Fm = 3,
    Im = 2,
    jm = 1,
    Um = 10,
    Am = -2,
    As = e => e === "*";

function Bm(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(As) && (r += Am), t && (r += Im), n.filter(l => !As(l)).reduce((l, i) => l + (Om.test(i) ? Fm : i === "" ? jm : Um), r)
}

function $m(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, l) => r === t[l]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function Vm(e, t) {
    let {
        routesMeta: n
    } = e, r = {}, l = "/", i = [];
    for (let o = 0; o < n.length; ++o) {
        let u = n[o],
            a = o === n.length - 1,
            s = l === "/" ? t : t.slice(l.length) || "/",
            c = Wm({
                path: u.relativePath,
                caseSensitive: u.caseSensitive,
                end: a
            }, s);
        if (!c) return null;
        Object.assign(r, c.params);
        let p = u.route;
        i.push({
            params: r,
            pathname: qt([l, c.pathname]),
            pathnameBase: Xm(qt([l, c.pathnameBase])),
            route: p
        }), c.pathnameBase !== "/" && (l = qt([l, c.pathnameBase]))
    }
    return i
}

function Wm(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = Hm(e.path, e.caseSensitive, e.end), l = t.match(n);
    if (!l) return null;
    let i = l[0],
        o = i.replace(/(.)\/+$/, "$1"),
        u = l.slice(1);
    return {
        params: r.reduce((s, c, p) => {
            let {
                paramName: m,
                isOptional: E
            } = c;
            if (m === "*") {
                let w = u[p] || "";
                o = i.slice(0, i.length - w.length).replace(/(.)\/+$/, "$1")
            }
            const S = u[p];
            return E && !S ? s[m] = void 0 : s[m] = (S || "").replace(/%2F/g, "/"), s
        }, {}),
        pathname: i,
        pathnameBase: o,
        pattern: e
    }
}

function Hm(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), ur(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        l = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (o, u, a) => (r.push({
            paramName: u,
            isOptional: a != null
        }), a ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), l += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? l += "\\/*$" : e !== "" && e !== "/" && (l += "(?:(?=\\/|$))"), [new RegExp(l, t ? void 0 : "i"), r]
}

function Qm(e) {
    try {
        return e.split("/").map(t => decodeURIComponent(t).replace(/\//g, "%2F")).join("/")
    } catch (t) {
        return ur(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function ml(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function Km(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: l = ""
    } = typeof e == "string" ? Nt(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : Ym(n, t) : t,
        search: Gm(r),
        hash: Zm(l)
    }
}

function Ym(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(l => {
        l === ".." ? n.length > 1 && n.pop() : l !== "." && n.push(l)
    }), n.length > 1 ? n.join("/") : "/"
}

function wo(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function Cd(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function _d(e, t) {
    let n = Cd(e);
    return t ? n.map((r, l) => l === e.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function Pd(e, t, n, r) {
    r === void 0 && (r = !1);
    let l;
    typeof e == "string" ? l = Nt(e) : (l = ce({}, e), V(!l.pathname || !l.pathname.includes("?"), wo("?", "pathname", "search", l)), V(!l.pathname || !l.pathname.includes("#"), wo("#", "pathname", "hash", l)), V(!l.search || !l.search.includes("#"), wo("#", "search", "hash", l)));
    let i = e === "" || l.pathname === "",
        o = i ? "/" : l.pathname,
        u;
    if (o == null) u = n;
    else {
        let p = t.length - 1;
        if (!r && o.startsWith("..")) {
            let m = o.split("/");
            for (; m[0] === "..";) m.shift(), p -= 1;
            l.pathname = m.join("/")
        }
        u = p >= 0 ? t[p] : "/"
    }
    let a = Km(l, u),
        s = o && o !== "/" && o.endsWith("/"),
        c = (i || o === ".") && n.endsWith("/");
    return !a.pathname.endsWith("/") && (s || c) && (a.pathname += "/"), a
}
const qt = e => e.join("/").replace(/\/\/+/g, "/"),
    Xm = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    Gm = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    Zm = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;
class va {
    constructor(t, n, r, l) {
        l === void 0 && (l = !1), this.status = t, this.statusText = n || "", this.internal = l, r instanceof Error ? (this.data = r.toString(), this.error = r) : this.data = r
    }
}

function Rd(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const Td = ["post", "put", "patch", "delete"],
    Jm = new Set(Td),
    qm = ["get", ...Td],
    bm = new Set(qm),
    ev = new Set([301, 302, 303, 307, 308]),
    tv = new Set([307, 308]),
    So = {
        state: "idle",
        location: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    nv = {
        state: "idle",
        data: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    xr = {
        state: "unblocked",
        proceed: void 0,
        reset: void 0,
        location: void 0
    },
    Nd = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    rv = e => ({
        hasErrorBoundary: !!e.hasErrorBoundary
    }),
    Ld = "remix-router-transitions";

function lv(e) {
    const t = e.window ? e.window : typeof window < "u" ? window : void 0,
        n = typeof t < "u" && typeof t.document < "u" && typeof t.document.createElement < "u",
        r = !n;
    V(e.routes.length > 0, "You must provide a non-empty routes array to createRouter");
    let l;
    if (e.mapRouteProperties) l = e.mapRouteProperties;
    else if (e.detectErrorBoundary) {
        let y = e.detectErrorBoundary;
        l = g => ({
            hasErrorBoundary: y(g)
        })
    } else l = rv;
    let i = {},
        o = hu(e.routes, l, void 0, i),
        u, a = e.basename || "/",
        s = ce({
            v7_fetcherPersist: !1,
            v7_normalizeFormMethod: !1,
            v7_partialHydration: !1,
            v7_prependBasename: !1,
            v7_relativeSplatPath: !1
        }, e.future),
        c = null,
        p = new Set,
        m = null,
        E = null,
        S = null,
        w = e.hydrationData != null,
        C = Kn(o, e.history.location, a),
        d = null;
    if (C == null) {
        let y = Je(404, {
                pathname: e.history.location.pathname
            }),
            {
                matches: g,
                route: k
            } = Ys(o);
        C = g, d = {
            [k.id]: y
        }
    }
    let f, h = C.some(y => y.route.lazy),
        x = C.some(y => y.route.loader);
    if (h) f = !1;
    else if (!x) f = !0;
    else if (s.v7_partialHydration) {
        let y = e.hydrationData ? e.hydrationData.loaderData : null,
            g = e.hydrationData ? e.hydrationData.errors : null,
            k = N => N.route.loader ? N.route.loader.hydrate === !0 ? !1 : y && y[N.route.id] !== void 0 || g && g[N.route.id] !== void 0 : !0;
        if (g) {
            let N = C.findIndex(z => g[z.route.id] !== void 0);
            f = C.slice(0, N + 1).every(k)
        } else f = C.every(k)
    } else f = e.hydrationData != null;
    let T, v = {
            historyAction: e.history.action,
            location: e.history.location,
            matches: C,
            initialized: f,
            navigation: So,
            restoreScrollPosition: e.hydrationData != null ? !1 : null,
            preventScrollReset: !1,
            revalidation: "idle",
            loaderData: e.hydrationData && e.hydrationData.loaderData || {},
            actionData: e.hydrationData && e.hydrationData.actionData || null,
            errors: e.hydrationData && e.hydrationData.errors || d,
            fetchers: new Map,
            blockers: new Map
        },
        _ = fe.Pop,
        L = !1,
        O, I = !1,
        Y = new Map,
        me = null,
        pe = !1,
        Ze = !1,
        Pn = [],
        Dt = [],
        re = new Map,
        D = 0,
        U = -1,
        B = new Map,
        X = new Set,
        ee = new Map,
        pt = new Map,
        ke = new Set,
        lt = new Map,
        De = new Map,
        Mt = !1;

    function $d() {
        if (c = e.history.listen(y => {
                let {
                    action: g,
                    location: k,
                    delta: N
                } = y;
                if (Mt) {
                    Mt = !1;
                    return
                }
                ur(De.size === 0 || N != null, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
                let z = _a({
                    currentLocation: v.location,
                    nextLocation: k,
                    historyAction: g
                });
                if (z && N != null) {
                    Mt = !0, e.history.go(N * -1), yl(z, {
                        state: "blocked",
                        location: k,
                        proceed() {
                            yl(z, {
                                state: "proceeding",
                                proceed: void 0,
                                reset: void 0,
                                location: k
                            }), e.history.go(N)
                        },
                        reset() {
                            let W = new Map(v.blockers);
                            W.set(z, xr), Ve({
                                blockers: W
                            })
                        }
                    });
                    return
                }
                return ln(g, k)
            }), n) {
            mv(t, Y);
            let y = () => vv(t, Y);
            t.addEventListener("pagehide", y), me = () => t.removeEventListener("pagehide", y)
        }
        return v.initialized || ln(fe.Pop, v.location, {
            initialHydration: !0
        }), T
    }

    function Vd() {
        c && c(), me && me(), p.clear(), O && O.abort(), v.fetchers.forEach((y, g) => vl(g)), v.blockers.forEach((y, g) => Ca(g))
    }

    function Wd(y) {
        return p.add(y), () => p.delete(y)
    }

    function Ve(y, g) {
        g === void 0 && (g = {}), v = ce({}, v, y);
        let k = [],
            N = [];
        s.v7_fetcherPersist && v.fetchers.forEach((z, W) => {
            z.state === "idle" && (ke.has(W) ? N.push(W) : k.push(W))
        }), [...p].forEach(z => z(v, {
            deletedFetchers: N,
            unstable_viewTransitionOpts: g.viewTransitionOpts,
            unstable_flushSync: g.flushSync === !0
        })), s.v7_fetcherPersist && (k.forEach(z => v.fetchers.delete(z)), N.forEach(z => vl(z)))
    }

    function fr(y, g, k) {
        var N, z;
        let {
            flushSync: W
        } = k === void 0 ? {} : k, A = v.actionData != null && v.navigation.formMethod != null && at(v.navigation.formMethod) && v.navigation.state === "loading" && ((N = y.state) == null ? void 0 : N._isRedirect) !== !0, j;
        g.actionData ? Object.keys(g.actionData).length > 0 ? j = g.actionData : j = null : A ? j = v.actionData : j = null;
        let F = g.loaderData ? Ks(v.loaderData, g.loaderData, g.matches || [], g.errors) : v.loaderData,
            Q = v.blockers;
        Q.size > 0 && (Q = new Map(Q), Q.forEach((q, xe) => Q.set(xe, xr)));
        let ge = L === !0 || v.navigation.formMethod != null && at(v.navigation.formMethod) && ((z = y.state) == null ? void 0 : z._isRedirect) !== !0;
        u && (o = u, u = void 0), pe || _ === fe.Pop || (_ === fe.Push ? e.history.push(y, y.state) : _ === fe.Replace && e.history.replace(y, y.state));
        let $;
        if (_ === fe.Pop) {
            let q = Y.get(v.location.pathname);
            q && q.has(y.pathname) ? $ = {
                currentLocation: v.location,
                nextLocation: y
            } : Y.has(y.pathname) && ($ = {
                currentLocation: y,
                nextLocation: v.location
            })
        } else if (I) {
            let q = Y.get(v.location.pathname);
            q ? q.add(y.pathname) : (q = new Set([y.pathname]), Y.set(v.location.pathname, q)), $ = {
                currentLocation: v.location,
                nextLocation: y
            }
        }
        Ve(ce({}, g, {
            actionData: j,
            loaderData: F,
            historyAction: _,
            location: y,
            initialized: !0,
            navigation: So,
            revalidation: "idle",
            restoreScrollPosition: Ra(y, g.matches || v.matches),
            preventScrollReset: ge,
            blockers: Q
        }), {
            viewTransitionOpts: $,
            flushSync: W === !0
        }), _ = fe.Pop, L = !1, I = !1, pe = !1, Ze = !1, Pn = [], Dt = []
    }
    async function ga(y, g) {
        if (typeof y == "number") {
            e.history.go(y);
            return
        }
        let k = mu(v.location, v.matches, a, s.v7_prependBasename, y, s.v7_relativeSplatPath, g == null ? void 0 : g.fromRouteId, g == null ? void 0 : g.relative),
            {
                path: N,
                submission: z,
                error: W
            } = Bs(s.v7_normalizeFormMethod, !1, k, g),
            A = v.location,
            j = ul(v.location, N, g && g.state);
        j = ce({}, j, e.history.encodeLocation(j));
        let F = g && g.replace != null ? g.replace : void 0,
            Q = fe.Push;
        F === !0 ? Q = fe.Replace : F === !1 || z != null && at(z.formMethod) && z.formAction === v.location.pathname + v.location.search && (Q = fe.Replace);
        let ge = g && "preventScrollReset" in g ? g.preventScrollReset === !0 : void 0,
            $ = (g && g.unstable_flushSync) === !0,
            q = _a({
                currentLocation: A,
                nextLocation: j,
                historyAction: Q
            });
        if (q) {
            yl(q, {
                state: "blocked",
                location: j,
                proceed() {
                    yl(q, {
                        state: "proceeding",
                        proceed: void 0,
                        reset: void 0,
                        location: j
                    }), ga(y, g)
                },
                reset() {
                    let xe = new Map(v.blockers);
                    xe.set(q, xr), Ve({
                        blockers: xe
                    })
                }
            });
            return
        }
        return await ln(Q, j, {
            submission: z,
            pendingError: W,
            preventScrollReset: ge,
            replace: g && g.replace,
            enableViewTransition: g && g.unstable_viewTransition,
            flushSync: $
        })
    }

    function Hd() {
        if ($i(), Ve({
                revalidation: "loading"
            }), v.navigation.state !== "submitting") {
            if (v.navigation.state === "idle") {
                ln(v.historyAction, v.location, {
                    startUninterruptedRevalidation: !0
                });
                return
            }
            ln(_ || v.historyAction, v.navigation.location, {
                overrideNavigation: v.navigation
            })
        }
    }
    async function ln(y, g, k) {
        O && O.abort(), O = null, _ = y, pe = (k && k.startUninterruptedRevalidation) === !0, bd(v.location, v.matches), L = (k && k.preventScrollReset) === !0, I = (k && k.enableViewTransition) === !0;
        let N = u || o,
            z = k && k.overrideNavigation,
            W = Kn(N, g, a),
            A = (k && k.flushSync) === !0;
        if (!W) {
            let xe = Je(404, {
                    pathname: g.pathname
                }),
                {
                    matches: We,
                    route: we
                } = Ys(N);
            Vi(), fr(g, {
                matches: We,
                loaderData: {},
                errors: {
                    [we.id]: xe
                }
            }, {
                flushSync: A
            });
            return
        }
        if (v.initialized && !Ze && sv(v.location, g) && !(k && k.submission && at(k.submission.formMethod))) {
            fr(g, {
                matches: W
            }, {
                flushSync: A
            });
            return
        }
        O = new AbortController;
        let j = _r(e.history, g, O.signal, k && k.submission),
            F, Q;
        if (k && k.pendingError) Q = {
            [Wr(W).route.id]: k.pendingError
        };
        else if (k && k.submission && at(k.submission.formMethod)) {
            let xe = await Qd(j, g, k.submission, W, {
                replace: k.replace,
                flushSync: A
            });
            if (xe.shortCircuited) return;
            F = xe.pendingActionData, Q = xe.pendingActionError, z = Eo(g, k.submission), A = !1, j = new Request(j.url, {
                signal: j.signal
            })
        }
        let {
            shortCircuited: ge,
            loaderData: $,
            errors: q
        } = await Kd(j, g, W, z, k && k.submission, k && k.fetcherSubmission, k && k.replace, k && k.initialHydration === !0, A, F, Q);
        ge || (O = null, fr(g, ce({
            matches: W
        }, F ? {
            actionData: F
        } : {}, {
            loaderData: $,
            errors: q
        })))
    }
    async function Qd(y, g, k, N, z) {
        z === void 0 && (z = {}), $i();
        let W = pv(g, k);
        Ve({
            navigation: W
        }, {
            flushSync: z.flushSync === !0
        });
        let A, j = yu(N, g);
        if (!j.route.action && !j.route.lazy) A = {
            type: ae.error,
            error: Je(405, {
                method: y.method,
                pathname: g.pathname,
                routeId: j.route.id
            })
        };
        else if (A = await Cr("action", y, j, N, i, l, a, s.v7_relativeSplatPath), y.signal.aborted) return {
            shortCircuited: !0
        };
        if (mn(A)) {
            let F;
            return z && z.replace != null ? F = z.replace : F = A.location === v.location.pathname + v.location.search, await dr(v, A, {
                submission: k,
                replace: F
            }), {
                shortCircuited: !0
            }
        }
        if (Yn(A)) {
            let F = Wr(N, j.route.id);
            return (z && z.replace) !== !0 && (_ = fe.Push), {
                pendingActionData: {},
                pendingActionError: {
                    [F.route.id]: A.error
                }
            }
        }
        if (hn(A)) throw Je(400, {
            type: "defer-action"
        });
        return {
            pendingActionData: {
                [j.route.id]: A.data
            }
        }
    }
    async function Kd(y, g, k, N, z, W, A, j, F, Q, ge) {
        let $ = N || Eo(g, z),
            q = z || W || Zs($),
            xe = u || o,
            [We, we] = $s(e.history, v, k, q, g, s.v7_partialHydration && j === !0, Ze, Pn, Dt, ke, ee, X, xe, a, Q, ge);
        if (Vi(G => !(k && k.some(J => J.route.id === G)) || We && We.some(J => J.route.id === G)), U = ++D, We.length === 0 && we.length === 0) {
            let G = ka();
            return fr(g, ce({
                matches: k,
                loaderData: {},
                errors: ge || null
            }, Q ? {
                actionData: Q
            } : {}, G ? {
                fetchers: new Map(v.fetchers)
            } : {}), {
                flushSync: F
            }), {
                shortCircuited: !0
            }
        }
        if (!pe && (!s.v7_partialHydration || !j)) {
            we.forEach(J => {
                let Ie = v.fetchers.get(J.key),
                    wl = Pr(void 0, Ie ? Ie.data : void 0);
                v.fetchers.set(J.key, wl)
            });
            let G = Q || v.actionData;
            Ve(ce({
                navigation: $
            }, G ? Object.keys(G).length === 0 ? {
                actionData: null
            } : {
                actionData: G
            } : {}, we.length > 0 ? {
                fetchers: new Map(v.fetchers)
            } : {}), {
                flushSync: F
            })
        }
        we.forEach(G => {
            re.has(G.key) && Ot(G.key), G.controller && re.set(G.key, G.controller)
        });
        let Rn = () => we.forEach(G => Ot(G.key));
        O && O.signal.addEventListener("abort", Rn);
        let {
            results: Wi,
            loaderResults: Tn,
            fetcherResults: Ft
        } = await wa(v.matches, k, We, we, y);
        if (y.signal.aborted) return {
            shortCircuited: !0
        };
        O && O.signal.removeEventListener("abort", Rn), we.forEach(G => re.delete(G.key));
        let on = Xs(Wi);
        if (on) {
            if (on.idx >= We.length) {
                let G = we[on.idx - We.length].key;
                X.add(G)
            }
            return await dr(v, on.result, {
                replace: A
            }), {
                shortCircuited: !0
            }
        }
        let {
            loaderData: Hi,
            errors: hr
        } = Qs(v, k, We, Tn, ge, we, Ft, lt);
        lt.forEach((G, J) => {
            G.subscribe(Ie => {
                (Ie || G.done) && lt.delete(J)
            })
        }), s.v7_partialHydration && j && v.errors && Object.entries(v.errors).filter(G => {
            let [J] = G;
            return !We.some(Ie => Ie.route.id === J)
        }).forEach(G => {
            let [J, Ie] = G;
            hr = Object.assign(hr || {}, {
                [J]: Ie
            })
        });
        let Qi = ka(),
            Nn = xa(U),
            gl = Qi || Nn || we.length > 0;
        return ce({
            loaderData: Hi,
            errors: hr
        }, gl ? {
            fetchers: new Map(v.fetchers)
        } : {})
    }

    function Yd(y, g, k, N) {
        if (r) throw new Error("router.fetch() was called during the server render, but it shouldn't be. You are likely calling a useFetcher() method in the body of your component. Try moving it to a useEffect or a callback.");
        re.has(y) && Ot(y);
        let z = (N && N.unstable_flushSync) === !0,
            W = u || o,
            A = mu(v.location, v.matches, a, s.v7_prependBasename, k, s.v7_relativeSplatPath, g, N == null ? void 0 : N.relative),
            j = Kn(W, A, a);
        if (!j) {
            pr(y, g, Je(404, {
                pathname: A
            }), {
                flushSync: z
            });
            return
        }
        let {
            path: F,
            submission: Q,
            error: ge
        } = Bs(s.v7_normalizeFormMethod, !0, A, N);
        if (ge) {
            pr(y, g, ge, {
                flushSync: z
            });
            return
        }
        let $ = yu(j, F);
        if (L = (N && N.preventScrollReset) === !0, Q && at(Q.formMethod)) {
            Xd(y, g, F, $, j, z, Q);
            return
        }
        ee.set(y, {
            routeId: g,
            path: F
        }), Gd(y, g, F, $, j, z, Q)
    }
    async function Xd(y, g, k, N, z, W, A) {
        if ($i(), ee.delete(y), !N.route.action && !N.route.lazy) {
            let J = Je(405, {
                method: A.formMethod,
                pathname: k,
                routeId: g
            });
            pr(y, g, J, {
                flushSync: W
            });
            return
        }
        let j = v.fetchers.get(y);
        zt(y, hv(A, j), {
            flushSync: W
        });
        let F = new AbortController,
            Q = _r(e.history, k, F.signal, A);
        re.set(y, F);
        let ge = D,
            $ = await Cr("action", Q, N, z, i, l, a, s.v7_relativeSplatPath);
        if (Q.signal.aborted) {
            re.get(y) === F && re.delete(y);
            return
        }
        if (s.v7_fetcherPersist && ke.has(y)) {
            if (mn($) || Yn($)) {
                zt(y, jt(void 0));
                return
            }
        } else {
            if (mn($))
                if (re.delete(y), U > ge) {
                    zt(y, jt(void 0));
                    return
                } else return X.add(y), zt(y, Pr(A)), dr(v, $, {
                    fetcherSubmission: A
                });
            if (Yn($)) {
                pr(y, g, $.error);
                return
            }
        }
        if (hn($)) throw Je(400, {
            type: "defer-action"
        });
        let q = v.navigation.location || v.location,
            xe = _r(e.history, q, F.signal),
            We = u || o,
            we = v.navigation.state !== "idle" ? Kn(We, v.navigation.location, a) : v.matches;
        V(we, "Didn't find any matches after fetcher action");
        let Rn = ++D;
        B.set(y, Rn);
        let Wi = Pr(A, $.data);
        v.fetchers.set(y, Wi);
        let [Tn, Ft] = $s(e.history, v, we, A, q, !1, Ze, Pn, Dt, ke, ee, X, We, a, {
            [N.route.id]: $.data
        }, void 0);
        Ft.filter(J => J.key !== y).forEach(J => {
            let Ie = J.key,
                wl = v.fetchers.get(Ie),
                tp = Pr(void 0, wl ? wl.data : void 0);
            v.fetchers.set(Ie, tp), re.has(Ie) && Ot(Ie), J.controller && re.set(Ie, J.controller)
        }), Ve({
            fetchers: new Map(v.fetchers)
        });
        let on = () => Ft.forEach(J => Ot(J.key));
        F.signal.addEventListener("abort", on);
        let {
            results: Hi,
            loaderResults: hr,
            fetcherResults: Qi
        } = await wa(v.matches, we, Tn, Ft, xe);
        if (F.signal.aborted) return;
        F.signal.removeEventListener("abort", on), B.delete(y), re.delete(y), Ft.forEach(J => re.delete(J.key));
        let Nn = Xs(Hi);
        if (Nn) {
            if (Nn.idx >= Tn.length) {
                let J = Ft[Nn.idx - Tn.length].key;
                X.add(J)
            }
            return dr(v, Nn.result)
        }
        let {
            loaderData: gl,
            errors: G
        } = Qs(v, v.matches, Tn, hr, void 0, Ft, Qi, lt);
        if (v.fetchers.has(y)) {
            let J = jt($.data);
            v.fetchers.set(y, J)
        }
        xa(Rn), v.navigation.state === "loading" && Rn > U ? (V(_, "Expected pending action"), O && O.abort(), fr(v.navigation.location, {
            matches: we,
            loaderData: gl,
            errors: G,
            fetchers: new Map(v.fetchers)
        })) : (Ve({
            errors: G,
            loaderData: Ks(v.loaderData, gl, we, G),
            fetchers: new Map(v.fetchers)
        }), Ze = !1)
    }
    async function Gd(y, g, k, N, z, W, A) {
        let j = v.fetchers.get(y);
        zt(y, Pr(A, j ? j.data : void 0), {
            flushSync: W
        });
        let F = new AbortController,
            Q = _r(e.history, k, F.signal);
        re.set(y, F);
        let ge = D,
            $ = await Cr("loader", Q, N, z, i, l, a, s.v7_relativeSplatPath);
        if (hn($) && ($ = await zd($, Q.signal, !0) || $), re.get(y) === F && re.delete(y), !Q.signal.aborted) {
            if (ke.has(y)) {
                zt(y, jt(void 0));
                return
            }
            if (mn($))
                if (U > ge) {
                    zt(y, jt(void 0));
                    return
                } else {
                    X.add(y), await dr(v, $);
                    return
                }
            if (Yn($)) {
                pr(y, g, $.error);
                return
            }
            V(!hn($), "Unhandled fetcher deferred data"), zt(y, jt($.data))
        }
    }
    async function dr(y, g, k) {
        let {
            submission: N,
            fetcherSubmission: z,
            replace: W
        } = k === void 0 ? {} : k;
        g.revalidate && (Ze = !0);
        let A = ul(y.location, g.location, {
            _isRedirect: !0
        });
        if (V(A, "Expected a location on the redirect navigation"), n) {
            let q = !1;
            if (g.reloadDocument) q = !0;
            else if (Nd.test(g.location)) {
                const xe = e.history.createURL(g.location);
                q = xe.origin !== t.location.origin || ml(xe.pathname, a) == null
            }
            if (q) {
                W ? t.location.replace(g.location) : t.location.assign(g.location);
                return
            }
        }
        O = null;
        let j = W === !0 ? fe.Replace : fe.Push,
            {
                formMethod: F,
                formAction: Q,
                formEncType: ge
            } = y.navigation;
        !N && !z && F && Q && ge && (N = Zs(y.navigation));
        let $ = N || z;
        if (tv.has(g.status) && $ && at($.formMethod)) await ln(j, A, {
            submission: ce({}, $, {
                formAction: g.location
            }),
            preventScrollReset: L
        });
        else {
            let q = Eo(A, N);
            await ln(j, A, {
                overrideNavigation: q,
                fetcherSubmission: z,
                preventScrollReset: L
            })
        }
    }
    async function wa(y, g, k, N, z) {
        let W = await Promise.all([...k.map(F => Cr("loader", z, F, g, i, l, a, s.v7_relativeSplatPath)), ...N.map(F => F.matches && F.match && F.controller ? Cr("loader", _r(e.history, F.path, F.controller.signal), F.match, F.matches, i, l, a, s.v7_relativeSplatPath) : {
                type: ae.error,
                error: Je(404, {
                    pathname: F.path
                })
            })]),
            A = W.slice(0, k.length),
            j = W.slice(k.length);
        return await Promise.all([Gs(y, k, A, A.map(() => z.signal), !1, v.loaderData), Gs(y, N.map(F => F.match), j, N.map(F => F.controller ? F.controller.signal : null), !0)]), {
            results: W,
            loaderResults: A,
            fetcherResults: j
        }
    }

    function $i() {
        Ze = !0, Pn.push(...Vi()), ee.forEach((y, g) => {
            re.has(g) && (Dt.push(g), Ot(g))
        })
    }

    function zt(y, g, k) {
        k === void 0 && (k = {}), v.fetchers.set(y, g), Ve({
            fetchers: new Map(v.fetchers)
        }, {
            flushSync: (k && k.flushSync) === !0
        })
    }

    function pr(y, g, k, N) {
        N === void 0 && (N = {});
        let z = Wr(v.matches, g);
        vl(y), Ve({
            errors: {
                [z.route.id]: k
            },
            fetchers: new Map(v.fetchers)
        }, {
            flushSync: (N && N.flushSync) === !0
        })
    }

    function Sa(y) {
        return s.v7_fetcherPersist && (pt.set(y, (pt.get(y) || 0) + 1), ke.has(y) && ke.delete(y)), v.fetchers.get(y) || nv
    }

    function vl(y) {
        let g = v.fetchers.get(y);
        re.has(y) && !(g && g.state === "loading" && B.has(y)) && Ot(y), ee.delete(y), B.delete(y), X.delete(y), ke.delete(y), v.fetchers.delete(y)
    }

    function Zd(y) {
        if (s.v7_fetcherPersist) {
            let g = (pt.get(y) || 0) - 1;
            g <= 0 ? (pt.delete(y), ke.add(y)) : pt.set(y, g)
        } else vl(y);
        Ve({
            fetchers: new Map(v.fetchers)
        })
    }

    function Ot(y) {
        let g = re.get(y);
        V(g, "Expected fetch controller: " + y), g.abort(), re.delete(y)
    }

    function Ea(y) {
        for (let g of y) {
            let k = Sa(g),
                N = jt(k.data);
            v.fetchers.set(g, N)
        }
    }

    function ka() {
        let y = [],
            g = !1;
        for (let k of X) {
            let N = v.fetchers.get(k);
            V(N, "Expected fetcher: " + k), N.state === "loading" && (X.delete(k), y.push(k), g = !0)
        }
        return Ea(y), g
    }

    function xa(y) {
        let g = [];
        for (let [k, N] of B)
            if (N < y) {
                let z = v.fetchers.get(k);
                V(z, "Expected fetcher: " + k), z.state === "loading" && (Ot(k), B.delete(k), g.push(k))
            }
        return Ea(g), g.length > 0
    }

    function Jd(y, g) {
        let k = v.blockers.get(y) || xr;
        return De.get(y) !== g && De.set(y, g), k
    }

    function Ca(y) {
        v.blockers.delete(y), De.delete(y)
    }

    function yl(y, g) {
        let k = v.blockers.get(y) || xr;
        V(k.state === "unblocked" && g.state === "blocked" || k.state === "blocked" && g.state === "blocked" || k.state === "blocked" && g.state === "proceeding" || k.state === "blocked" && g.state === "unblocked" || k.state === "proceeding" && g.state === "unblocked", "Invalid blocker state transition: " + k.state + " -> " + g.state);
        let N = new Map(v.blockers);
        N.set(y, g), Ve({
            blockers: N
        })
    }

    function _a(y) {
        let {
            currentLocation: g,
            nextLocation: k,
            historyAction: N
        } = y;
        if (De.size === 0) return;
        De.size > 1 && ur(!1, "A router only supports one blocker at a time");
        let z = Array.from(De.entries()),
            [W, A] = z[z.length - 1],
            j = v.blockers.get(W);
        if (!(j && j.state === "proceeding") && A({
                currentLocation: g,
                nextLocation: k,
                historyAction: N
            })) return W
    }

    function Vi(y) {
        let g = [];
        return lt.forEach((k, N) => {
            (!y || y(N)) && (k.cancel(), g.push(N), lt.delete(N))
        }), g
    }

    function qd(y, g, k) {
        if (m = y, S = g, E = k || null, !w && v.navigation === So) {
            w = !0;
            let N = Ra(v.location, v.matches);
            N != null && Ve({
                restoreScrollPosition: N
            })
        }
        return () => {
            m = null, S = null, E = null
        }
    }

    function Pa(y, g) {
        return E && E(y, g.map(N => Mm(N, v.loaderData))) || y.key
    }

    function bd(y, g) {
        if (m && S) {
            let k = Pa(y, g);
            m[k] = S()
        }
    }

    function Ra(y, g) {
        if (m) {
            let k = Pa(y, g),
                N = m[k];
            if (typeof N == "number") return N
        }
        return null
    }

    function ep(y) {
        i = {}, u = hu(y, l, void 0, i)
    }
    return T = {
        get basename() {
            return a
        },
        get future() {
            return s
        },
        get state() {
            return v
        },
        get routes() {
            return o
        },
        get window() {
            return t
        },
        initialize: $d,
        subscribe: Wd,
        enableScrollRestoration: qd,
        navigate: ga,
        fetch: Yd,
        revalidate: Hd,
        createHref: y => e.history.createHref(y),
        encodeLocation: y => e.history.encodeLocation(y),
        getFetcher: Sa,
        deleteFetcher: Zd,
        dispose: Vd,
        getBlocker: Jd,
        deleteBlocker: Ca,
        _internalFetchControllers: re,
        _internalActiveDeferreds: lt,
        _internalSetRoutes: ep
    }, T
}

function iv(e) {
    return e != null && ("formData" in e && e.formData != null || "body" in e && e.body !== void 0)
}

function mu(e, t, n, r, l, i, o, u) {
    let a, s;
    if (o) {
        a = [];
        for (let p of t)
            if (a.push(p), p.route.id === o) {
                s = p;
                break
            }
    } else a = t, s = t[t.length - 1];
    let c = Pd(l || ".", _d(a, i), ml(e.pathname, n) || e.pathname, u === "path");
    return l == null && (c.search = e.search, c.hash = e.hash), (l == null || l === "" || l === ".") && s && s.route.index && !ya(c.search) && (c.search = c.search ? c.search.replace(/^\?/, "?index&") : "?index"), r && n !== "/" && (c.pathname = c.pathname === "/" ? n : qt([n, c.pathname])), hl(c)
}

function Bs(e, t, n, r) {
    if (!r || !iv(r)) return {
        path: n
    };
    if (r.formMethod && !dv(r.formMethod)) return {
        path: n,
        error: Je(405, {
            method: r.formMethod
        })
    };
    let l = () => ({
            path: n,
            error: Je(400, {
                type: "invalid-body"
            })
        }),
        i = r.formMethod || "get",
        o = e ? i.toUpperCase() : i.toLowerCase(),
        u = Md(n);
    if (r.body !== void 0) {
        if (r.formEncType === "text/plain") {
            if (!at(o)) return l();
            let m = typeof r.body == "string" ? r.body : r.body instanceof FormData || r.body instanceof URLSearchParams ? Array.from(r.body.entries()).reduce((E, S) => {
                let [w, C] = S;
                return "" + E + w + "=" + C + `
`
            }, "") : String(r.body);
            return {
                path: n,
                submission: {
                    formMethod: o,
                    formAction: u,
                    formEncType: r.formEncType,
                    formData: void 0,
                    json: void 0,
                    text: m
                }
            }
        } else if (r.formEncType === "application/json") {
            if (!at(o)) return l();
            try {
                let m = typeof r.body == "string" ? JSON.parse(r.body) : r.body;
                return {
                    path: n,
                    submission: {
                        formMethod: o,
                        formAction: u,
                        formEncType: r.formEncType,
                        formData: void 0,
                        json: m,
                        text: void 0
                    }
                }
            } catch {
                return l()
            }
        }
    }
    V(typeof FormData == "function", "FormData is not available in this environment");
    let a, s;
    if (r.formData) a = vu(r.formData), s = r.formData;
    else if (r.body instanceof FormData) a = vu(r.body), s = r.body;
    else if (r.body instanceof URLSearchParams) a = r.body, s = Hs(a);
    else if (r.body == null) a = new URLSearchParams, s = new FormData;
    else try {
        a = new URLSearchParams(r.body), s = Hs(a)
    } catch {
        return l()
    }
    let c = {
        formMethod: o,
        formAction: u,
        formEncType: r && r.formEncType || "application/x-www-form-urlencoded",
        formData: s,
        json: void 0,
        text: void 0
    };
    if (at(c.formMethod)) return {
        path: n,
        submission: c
    };
    let p = Nt(n);
    return t && p.search && ya(p.search) && a.append("index", ""), p.search = "?" + a, {
        path: hl(p),
        submission: c
    }
}

function ov(e, t) {
    let n = e;
    if (t) {
        let r = e.findIndex(l => l.route.id === t);
        r >= 0 && (n = e.slice(0, r))
    }
    return n
}

function $s(e, t, n, r, l, i, o, u, a, s, c, p, m, E, S, w) {
    let C = w ? Object.values(w)[0] : S ? Object.values(S)[0] : void 0,
        d = e.createURL(t.location),
        f = e.createURL(l),
        h = w ? Object.keys(w)[0] : void 0,
        T = ov(n, h).filter((_, L) => {
            let {
                route: O
            } = _;
            if (O.lazy) return !0;
            if (O.loader == null) return !1;
            if (i) return O.loader.hydrate ? !0 : t.loaderData[O.id] === void 0 && (!t.errors || t.errors[O.id] === void 0);
            if (uv(t.loaderData, t.matches[L], _) || u.some(me => me === _.route.id)) return !0;
            let I = t.matches[L],
                Y = _;
            return Vs(_, ce({
                currentUrl: d,
                currentParams: I.params,
                nextUrl: f,
                nextParams: Y.params
            }, r, {
                actionResult: C,
                defaultShouldRevalidate: o || d.pathname + d.search === f.pathname + f.search || d.search !== f.search || Dd(I, Y)
            }))
        }),
        v = [];
    return c.forEach((_, L) => {
        if (i || !n.some(pe => pe.route.id === _.routeId) || s.has(L)) return;
        let O = Kn(m, _.path, E);
        if (!O) {
            v.push({
                key: L,
                routeId: _.routeId,
                path: _.path,
                matches: null,
                match: null,
                controller: null
            });
            return
        }
        let I = t.fetchers.get(L),
            Y = yu(O, _.path),
            me = !1;
        p.has(L) ? me = !1 : a.includes(L) ? me = !0 : I && I.state !== "idle" && I.data === void 0 ? me = o : me = Vs(Y, ce({
            currentUrl: d,
            currentParams: t.matches[t.matches.length - 1].params,
            nextUrl: f,
            nextParams: n[n.length - 1].params
        }, r, {
            actionResult: C,
            defaultShouldRevalidate: o
        })), me && v.push({
            key: L,
            routeId: _.routeId,
            path: _.path,
            matches: O,
            match: Y,
            controller: new AbortController
        })
    }), [T, v]
}

function uv(e, t, n) {
    let r = !t || n.route.id !== t.route.id,
        l = e[n.route.id] === void 0;
    return r || l
}

function Dd(e, t) {
    let n = e.route.path;
    return e.pathname !== t.pathname || n != null && n.endsWith("*") && e.params["*"] !== t.params["*"]
}

function Vs(e, t) {
    if (e.route.shouldRevalidate) {
        let n = e.route.shouldRevalidate(t);
        if (typeof n == "boolean") return n
    }
    return t.defaultShouldRevalidate
}
async function Ws(e, t, n) {
    if (!e.lazy) return;
    let r = await e.lazy();
    if (!e.lazy) return;
    let l = n[e.id];
    V(l, "No route found in manifest");
    let i = {};
    for (let o in r) {
        let a = l[o] !== void 0 && o !== "hasErrorBoundary";
        ur(!a, 'Route "' + l.id + '" has a static property "' + o + '" defined but its lazy function is also returning a value for this property. ' + ('The lazy route property "' + o + '" will be ignored.')), !a && !Lm.has(o) && (i[o] = r[o])
    }
    Object.assign(l, i), Object.assign(l, ce({}, t(l), {
        lazy: void 0
    }))
}
async function Cr(e, t, n, r, l, i, o, u, a) {
    a === void 0 && (a = {});
    let s, c, p, m = w => {
        let C, d = new Promise((f, h) => C = h);
        return p = () => C(), t.signal.addEventListener("abort", p), Promise.race([w({
            request: t,
            params: n.params,
            context: a.requestContext
        }), d])
    };
    try {
        let w = n.route[e];
        if (n.route.lazy)
            if (w) {
                let C, d = await Promise.all([m(w).catch(f => {
                    C = f
                }), Ws(n.route, i, l)]);
                if (C) throw C;
                c = d[0]
            } else if (await Ws(n.route, i, l), w = n.route[e], w) c = await m(w);
        else if (e === "action") {
            let C = new URL(t.url),
                d = C.pathname + C.search;
            throw Je(405, {
                method: t.method,
                pathname: d,
                routeId: n.route.id
            })
        } else return {
            type: ae.data,
            data: void 0
        };
        else if (w) c = await m(w);
        else {
            let C = new URL(t.url),
                d = C.pathname + C.search;
            throw Je(404, {
                pathname: d
            })
        }
        V(c !== void 0, "You defined " + (e === "action" ? "an action" : "a loader") + " for route " + ('"' + n.route.id + "\" but didn't return anything from your `" + e + "` ") + "function. Please return a value or `null`.")
    } catch (w) {
        s = ae.error, c = w
    } finally {
        p && t.signal.removeEventListener("abort", p)
    }
    if (fv(c)) {
        let w = c.status;
        if (ev.has(w)) {
            let d = c.headers.get("Location");
            if (V(d, "Redirects returned/thrown from loaders/actions must have a Location header"), !Nd.test(d)) d = mu(new URL(t.url), r.slice(0, r.indexOf(n) + 1), o, !0, d, u);
            else if (!a.isStaticRequest) {
                let f = new URL(t.url),
                    h = d.startsWith("//") ? new URL(f.protocol + d) : new URL(d),
                    x = ml(h.pathname, o) != null;
                h.origin === f.origin && x && (d = h.pathname + h.search + h.hash)
            }
            if (a.isStaticRequest) throw c.headers.set("Location", d), c;
            return {
                type: ae.redirect,
                status: w,
                location: d,
                revalidate: c.headers.get("X-Remix-Revalidate") !== null,
                reloadDocument: c.headers.get("X-Remix-Reload-Document") !== null
            }
        }
        if (a.isRouteRequest) throw {
            type: s === ae.error ? ae.error : ae.data,
            response: c
        };
        let C;
        try {
            let d = c.headers.get("Content-Type");
            d && /\bapplication\/json\b/.test(d) ? c.body == null ? C = null : C = await c.json() : C = await c.text()
        } catch (d) {
            return {
                type: ae.error,
                error: d
            }
        }
        return s === ae.error ? {
            type: s,
            error: new va(w, c.statusText, C),
            headers: c.headers
        } : {
            type: ae.data,
            data: C,
            statusCode: c.status,
            headers: c.headers
        }
    }
    if (s === ae.error) return {
        type: s,
        error: c
    };
    if (cv(c)) {
        var E, S;
        return {
            type: ae.deferred,
            deferredData: c,
            statusCode: (E = c.init) == null ? void 0 : E.status,
            headers: ((S = c.init) == null ? void 0 : S.headers) && new Headers(c.init.headers)
        }
    }
    return {
        type: ae.data,
        data: c
    }
}

function _r(e, t, n, r) {
    let l = e.createURL(Md(t)).toString(),
        i = {
            signal: n
        };
    if (r && at(r.formMethod)) {
        let {
            formMethod: o,
            formEncType: u
        } = r;
        i.method = o.toUpperCase(), u === "application/json" ? (i.headers = new Headers({
            "Content-Type": u
        }), i.body = JSON.stringify(r.json)) : u === "text/plain" ? i.body = r.text : u === "application/x-www-form-urlencoded" && r.formData ? i.body = vu(r.formData) : i.body = r.formData
    }
    return new Request(l, i)
}

function vu(e) {
    let t = new URLSearchParams;
    for (let [n, r] of e.entries()) t.append(n, typeof r == "string" ? r : r.name);
    return t
}

function Hs(e) {
    let t = new FormData;
    for (let [n, r] of e.entries()) t.append(n, r);
    return t
}

function av(e, t, n, r, l) {
    let i = {},
        o = null,
        u, a = !1,
        s = {};
    return n.forEach((c, p) => {
        let m = t[p].route.id;
        if (V(!mn(c), "Cannot handle redirect results in processLoaderData"), Yn(c)) {
            let E = Wr(e, m),
                S = c.error;
            r && (S = Object.values(r)[0], r = void 0), o = o || {}, o[E.route.id] == null && (o[E.route.id] = S), i[m] = void 0, a || (a = !0, u = Rd(c.error) ? c.error.status : 500), c.headers && (s[m] = c.headers)
        } else hn(c) ? (l.set(m, c.deferredData), i[m] = c.deferredData.data) : i[m] = c.data, c.statusCode != null && c.statusCode !== 200 && !a && (u = c.statusCode), c.headers && (s[m] = c.headers)
    }), r && (o = r, i[Object.keys(r)[0]] = void 0), {
        loaderData: i,
        errors: o,
        statusCode: u || 200,
        loaderHeaders: s
    }
}

function Qs(e, t, n, r, l, i, o, u) {
    let {
        loaderData: a,
        errors: s
    } = av(t, n, r, l, u);
    for (let c = 0; c < i.length; c++) {
        let {
            key: p,
            match: m,
            controller: E
        } = i[c];
        V(o !== void 0 && o[c] !== void 0, "Did not find corresponding fetcher result");
        let S = o[c];
        if (!(E && E.signal.aborted))
            if (Yn(S)) {
                let w = Wr(e.matches, m == null ? void 0 : m.route.id);
                s && s[w.route.id] || (s = ce({}, s, {
                    [w.route.id]: S.error
                })), e.fetchers.delete(p)
            } else if (mn(S)) V(!1, "Unhandled fetcher revalidation redirect");
        else if (hn(S)) V(!1, "Unhandled fetcher deferred data");
        else {
            let w = jt(S.data);
            e.fetchers.set(p, w)
        }
    }
    return {
        loaderData: a,
        errors: s
    }
}

function Ks(e, t, n, r) {
    let l = ce({}, t);
    for (let i of n) {
        let o = i.route.id;
        if (t.hasOwnProperty(o) ? t[o] !== void 0 && (l[o] = t[o]) : e[o] !== void 0 && i.route.loader && (l[o] = e[o]), r && r.hasOwnProperty(o)) break
    }
    return l
}

function Wr(e, t) {
    return (t ? e.slice(0, e.findIndex(r => r.route.id === t) + 1) : [...e]).reverse().find(r => r.route.hasErrorBoundary === !0) || e[0]
}

function Ys(e) {
    let t = e.length === 1 ? e[0] : e.find(n => n.index || !n.path || n.path === "/") || {
        id: "__shim-error-route__"
    };
    return {
        matches: [{
            params: {},
            pathname: "",
            pathnameBase: "",
            route: t
        }],
        route: t
    }
}

function Je(e, t) {
    let {
        pathname: n,
        routeId: r,
        method: l,
        type: i
    } = t === void 0 ? {} : t, o = "Unknown Server Error", u = "Unknown @remix-run/router error";
    return e === 400 ? (o = "Bad Request", l && n && r ? u = "You made a " + l + ' request to "' + n + '" but ' + ('did not provide a `loader` for route "' + r + '", ') + "so there is no way to handle the request." : i === "defer-action" ? u = "defer() is not supported in actions" : i === "invalid-body" && (u = "Unable to encode submission body")) : e === 403 ? (o = "Forbidden", u = 'Route "' + r + '" does not match URL "' + n + '"') : e === 404 ? (o = "Not Found", u = 'No route matches URL "' + n + '"') : e === 405 && (o = "Method Not Allowed", l && n && r ? u = "You made a " + l.toUpperCase() + ' request to "' + n + '" but ' + ('did not provide an `action` for route "' + r + '", ') + "so there is no way to handle the request." : l && (u = 'Invalid request method "' + l.toUpperCase() + '"')), new va(e || 500, o, new Error(u), !0)
}

function Xs(e) {
    for (let t = e.length - 1; t >= 0; t--) {
        let n = e[t];
        if (mn(n)) return {
            result: n,
            idx: t
        }
    }
}

function Md(e) {
    let t = typeof e == "string" ? Nt(e) : e;
    return hl(ce({}, t, {
        hash: ""
    }))
}

function sv(e, t) {
    return e.pathname !== t.pathname || e.search !== t.search ? !1 : e.hash === "" ? t.hash !== "" : e.hash === t.hash ? !0 : t.hash !== ""
}

function hn(e) {
    return e.type === ae.deferred
}

function Yn(e) {
    return e.type === ae.error
}

function mn(e) {
    return (e && e.type) === ae.redirect
}

function cv(e) {
    let t = e;
    return t && typeof t == "object" && typeof t.data == "object" && typeof t.subscribe == "function" && typeof t.cancel == "function" && typeof t.resolveData == "function"
}

function fv(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.headers == "object" && typeof e.body < "u"
}

function dv(e) {
    return bm.has(e.toLowerCase())
}

function at(e) {
    return Jm.has(e.toLowerCase())
}
async function Gs(e, t, n, r, l, i) {
    for (let o = 0; o < n.length; o++) {
        let u = n[o],
            a = t[o];
        if (!a) continue;
        let s = e.find(p => p.route.id === a.route.id),
            c = s != null && !Dd(s, a) && (i && i[a.route.id]) !== void 0;
        if (hn(u) && (l || c)) {
            let p = r[o];
            V(p, "Expected an AbortSignal for revalidating fetcher deferred result"), await zd(u, p, l).then(m => {
                m && (n[o] = m || n[o])
            })
        }
    }
}
async function zd(e, t, n) {
    if (n === void 0 && (n = !1), !await e.deferredData.resolveData(t)) {
        if (n) try {
            return {
                type: ae.data,
                data: e.deferredData.unwrappedData
            }
        } catch (l) {
            return {
                type: ae.error,
                error: l
            }
        }
        return {
            type: ae.data,
            data: e.deferredData.data
        }
    }
}

function ya(e) {
    return new URLSearchParams(e).getAll("index").some(t => t === "")
}

function yu(e, t) {
    let n = typeof t == "string" ? Nt(t).search : t.search;
    if (e[e.length - 1].route.index && ya(n || "")) return e[e.length - 1];
    let r = Cd(e);
    return r[r.length - 1]
}

function Zs(e) {
    let {
        formMethod: t,
        formAction: n,
        formEncType: r,
        text: l,
        formData: i,
        json: o
    } = e;
    if (!(!t || !n || !r)) {
        if (l != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: void 0,
            text: l
        };
        if (i != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: i,
            json: void 0,
            text: void 0
        };
        if (o !== void 0) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: o,
            text: void 0
        }
    }
}

function Eo(e, t) {
    return t ? {
        state: "loading",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    } : {
        state: "loading",
        location: e,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    }
}

function pv(e, t) {
    return {
        state: "submitting",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    }
}

function Pr(e, t) {
    return e ? {
        state: "loading",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t
    } : {
        state: "loading",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: t
    }
}

function hv(e, t) {
    return {
        state: "submitting",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t ? t.data : void 0
    }
}

function jt(e) {
    return {
        state: "idle",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: e
    }
}

function mv(e, t) {
    try {
        let n = e.sessionStorage.getItem(Ld);
        if (n) {
            let r = JSON.parse(n);
            for (let [l, i] of Object.entries(r || {})) i && Array.isArray(i) && t.set(l, new Set(i || []))
        }
    } catch {}
}

function vv(e, t) {
    if (t.size > 0) {
        let n = {};
        for (let [r, l] of t) n[r] = [...l];
        try {
            e.sessionStorage.setItem(Ld, JSON.stringify(n))
        } catch (r) {
            ur(!1, "Failed to save applied view transitions in sessionStorage (" + r + ").")
        }
    }
}
/**
 * React Router v6.22.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function al() {
    return al = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, al.apply(this, arguments)
}
const ji = R.createContext(null),
    Od = R.createContext(null),
    Ui = R.createContext(null),
    Ai = R.createContext(null),
    _n = R.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    Fd = R.createContext(null);

function Bi() {
    return R.useContext(Ai) != null
}

function Id() {
    return Bi() || V(!1), R.useContext(Ai).location
}

function jd(e) {
    R.useContext(Ui).static || R.useLayoutEffect(e)
}

function ey() {
    let {
        isDataRoute: e
    } = R.useContext(_n);
    return e ? Nv() : yv()
}

function yv() {
    Bi() || V(!1);
    let e = R.useContext(ji),
        {
            basename: t,
            future: n,
            navigator: r
        } = R.useContext(Ui),
        {
            matches: l
        } = R.useContext(_n),
        {
            pathname: i
        } = Id(),
        o = JSON.stringify(_d(l, n.v7_relativeSplatPath)),
        u = R.useRef(!1);
    return jd(() => {
        u.current = !0
    }), R.useCallback(function(s, c) {
        if (c === void 0 && (c = {}), !u.current) return;
        if (typeof s == "number") {
            r.go(s);
            return
        }
        let p = Pd(s, JSON.parse(o), i, c.relative === "path");
        e == null && t !== "/" && (p.pathname = p.pathname === "/" ? t : qt([t, p.pathname])), (c.replace ? r.replace : r.push)(p, c.state, c)
    }, [t, r, o, i, e])
}
const gv = R.createContext(null);

function ty(e) {
    let t = R.useContext(_n).outlet;
    return t && R.createElement(gv.Provider, {
        value: e
    }, t)
}

function wv(e, t, n, r) {
    Bi() || V(!1);
    let {
        navigator: l
    } = R.useContext(Ui), {
        matches: i
    } = R.useContext(_n), o = i[i.length - 1], u = o ? o.params : {};
    o && o.pathname;
    let a = o ? o.pathnameBase : "/";
    o && o.route;
    let s = Id(),
        c;
    if (t) {
        var p;
        let C = typeof t == "string" ? Nt(t) : t;
        a === "/" || (p = C.pathname) != null && p.startsWith(a) || V(!1), c = C
    } else c = s;
    let m = c.pathname || "/",
        E = m;
    if (a !== "/") {
        let C = a.replace(/^\//, "").split("/");
        E = "/" + m.replace(/^\//, "").split("/").slice(C.length).join("/")
    }
    let S = Kn(e, {
            pathname: E
        }),
        w = Cv(S && S.map(C => Object.assign({}, C, {
            params: Object.assign({}, u, C.params),
            pathname: qt([a, l.encodeLocation ? l.encodeLocation(C.pathname).pathname : C.pathname]),
            pathnameBase: C.pathnameBase === "/" ? a : qt([a, l.encodeLocation ? l.encodeLocation(C.pathnameBase).pathname : C.pathnameBase])
        })), i, n, r);
    return t && w ? R.createElement(Ai.Provider, {
        value: {
            location: al({
                pathname: "/",
                search: "",
                hash: "",
                state: null,
                key: "default"
            }, c),
            navigationType: fe.Pop
        }
    }, w) : w
}

function Sv() {
    let e = Tv(),
        t = Rd(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        l = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        },
        i = null;
    return R.createElement(R.Fragment, null, R.createElement("h2", null, "Unexpected Application Error!"), R.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? R.createElement("pre", {
        style: l
    }, n) : null, i)
}
const Ev = R.createElement(Sv, null);
class kv extends R.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? R.createElement(_n.Provider, {
            value: this.props.routeContext
        }, R.createElement(Fd.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function xv(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, l = R.useContext(ji);
    return l && l.static && l.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (l.staticContext._deepestRenderedBoundaryId = n.route.id), R.createElement(_n.Provider, {
        value: t
    }, r)
}

function Cv(e, t, n, r) {
    var l;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var i;
        if ((i = n) != null && i.errors) e = n.matches;
        else return null
    }
    let o = e,
        u = (l = n) == null ? void 0 : l.errors;
    if (u != null) {
        let c = o.findIndex(p => p.route.id && (u == null ? void 0 : u[p.route.id]));
        c >= 0 || V(!1), o = o.slice(0, Math.min(o.length, c + 1))
    }
    let a = !1,
        s = -1;
    if (n && r && r.v7_partialHydration)
        for (let c = 0; c < o.length; c++) {
            let p = o[c];
            if ((p.route.HydrateFallback || p.route.hydrateFallbackElement) && (s = c), p.route.id) {
                let {
                    loaderData: m,
                    errors: E
                } = n, S = p.route.loader && m[p.route.id] === void 0 && (!E || E[p.route.id] === void 0);
                if (p.route.lazy || S) {
                    a = !0, s >= 0 ? o = o.slice(0, s + 1) : o = [o[0]];
                    break
                }
            }
        }
    return o.reduceRight((c, p, m) => {
        let E, S = !1,
            w = null,
            C = null;
        n && (E = u && p.route.id ? u[p.route.id] : void 0, w = p.route.errorElement || Ev, a && (s < 0 && m === 0 ? (Lv("route-fallback", !1), S = !0, C = null) : s === m && (S = !0, C = p.route.hydrateFallbackElement || null)));
        let d = t.concat(o.slice(0, m + 1)),
            f = () => {
                let h;
                return E ? h = w : S ? h = C : p.route.Component ? h = R.createElement(p.route.Component, null) : p.route.element ? h = p.route.element : h = c, R.createElement(xv, {
                    match: p,
                    routeContext: {
                        outlet: c,
                        matches: d,
                        isDataRoute: n != null
                    },
                    children: h
                })
            };
        return n && (p.route.ErrorBoundary || p.route.errorElement || m === 0) ? R.createElement(kv, {
            location: n.location,
            revalidation: n.revalidation,
            component: w,
            error: E,
            children: f(),
            routeContext: {
                outlet: null,
                matches: d,
                isDataRoute: !0
            }
        }) : f()
    }, null)
}
var Ud = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(Ud || {}),
    Si = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(Si || {});

function _v(e) {
    let t = R.useContext(ji);
    return t || V(!1), t
}

function Pv(e) {
    let t = R.useContext(Od);
    return t || V(!1), t
}

function Rv(e) {
    let t = R.useContext(_n);
    return t || V(!1), t
}

function Ad(e) {
    let t = Rv(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || V(!1), n.route.id
}

function Tv() {
    var e;
    let t = R.useContext(Fd),
        n = Pv(Si.UseRouteError),
        r = Ad(Si.UseRouteError);
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function Nv() {
    let {
        router: e
    } = _v(Ud.UseNavigateStable), t = Ad(Si.UseNavigateStable), n = R.useRef(!1);
    return jd(() => {
        n.current = !0
    }), R.useCallback(function(l, i) {
        i === void 0 && (i = {}), n.current && (typeof l == "number" ? e.navigate(l) : e.navigate(l, al({
            fromRouteId: t
        }, i)))
    }, [e, t])
}
const Js = {};

function Lv(e, t, n) {
    !t && !Js[e] && (Js[e] = !0)
}

function Dv(e) {
    V(!1)
}

function Mv(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: l = fe.Pop,
        navigator: i,
        static: o = !1,
        future: u
    } = e;
    Bi() && V(!1);
    let a = t.replace(/^\/*/, "/"),
        s = R.useMemo(() => ({
            basename: a,
            navigator: i,
            static: o,
            future: al({
                v7_relativeSplatPath: !1
            }, u)
        }), [a, u, i, o]);
    typeof r == "string" && (r = Nt(r));
    let {
        pathname: c = "/",
        search: p = "",
        hash: m = "",
        state: E = null,
        key: S = "default"
    } = r, w = R.useMemo(() => {
        let C = ml(c, a);
        return C == null ? null : {
            location: {
                pathname: C,
                search: p,
                hash: m,
                state: E,
                key: S
            },
            navigationType: l
        }
    }, [a, c, p, m, E, S, l]);
    return w == null ? null : R.createElement(Ui.Provider, {
        value: s
    }, R.createElement(Ai.Provider, {
        children: n,
        value: w
    }))
}
new Promise(() => {});

function qs(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return R.Children.forEach(e, (r, l) => {
        if (!R.isValidElement(r)) return;
        let i = [...t, l];
        if (r.type === R.Fragment) {
            n.push.apply(n, qs(r.props.children, i));
            return
        }
        r.type !== Dv && V(!1), !r.props.index || !r.props.children || V(!1);
        let o = {
            id: r.props.id || i.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (o.children = qs(r.props.children, i)), n.push(o)
    }), n
}

function zv(e) {
    let t = {
        hasErrorBoundary: e.ErrorBoundary != null || e.errorElement != null
    };
    return e.Component && Object.assign(t, {
        element: R.createElement(e.Component),
        Component: void 0
    }), e.HydrateFallback && Object.assign(t, {
        hydrateFallbackElement: R.createElement(e.HydrateFallback),
        HydrateFallback: void 0
    }), e.ErrorBoundary && Object.assign(t, {
        errorElement: R.createElement(e.ErrorBoundary),
        ErrorBoundary: void 0
    }), t
}
/**
 * React Router DOM v6.22.3
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function Ei() {
    return Ei = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Ei.apply(this, arguments)
}
const Ov = "6";
try {
    window.__reactRouterVersion = Ov
} catch {}

function ny(e, t) {
    return lv({
        basename: t == null ? void 0 : t.basename,
        future: Ei({}, t == null ? void 0 : t.future, {
            v7_prependBasename: !0
        }),
        history: Rm({
            window: t == null ? void 0 : t.window
        }),
        hydrationData: (t == null ? void 0 : t.hydrationData) || Fv(),
        routes: e,
        mapRouteProperties: zv,
        window: t == null ? void 0 : t.window
    }).initialize()
}

function Fv() {
    var e;
    let t = (e = window) == null ? void 0 : e.__staticRouterHydrationData;
    return t && t.errors && (t = Ei({}, t, {
        errors: Iv(t.errors)
    })), t
}

function Iv(e) {
    if (!e) return null;
    let t = Object.entries(e),
        n = {};
    for (let [r, l] of t)
        if (l && l.__type === "RouteErrorResponse") n[r] = new va(l.status, l.statusText, l.data, l.internal === !0);
        else if (l && l.__type === "Error") {
        if (l.__subType) {
            let i = window[l.__subType];
            if (typeof i == "function") try {
                let o = new i(l.message);
                o.stack = "", n[r] = o
            } catch {}
        }
        if (n[r] == null) {
            let i = new Error(l.message);
            i.stack = "", n[r] = i
        }
    } else n[r] = l;
    return n
}
const jv = R.createContext({
        isTransitioning: !1
    }),
    Uv = R.createContext(new Map),
    Av = "startTransition",
    bs = yp[Av],
    Bv = "flushSync",
    ec = Em[Bv];

function $v(e) {
    bs ? bs(e) : e()
}

function Rr(e) {
    ec ? ec(e) : e()
}
class Vv {
    constructor() {
        this.status = "pending", this.promise = new Promise((t, n) => {
            this.resolve = r => {
                this.status === "pending" && (this.status = "resolved", t(r))
            }, this.reject = r => {
                this.status === "pending" && (this.status = "rejected", n(r))
            }
        })
    }
}

function ry(e) {
    let {
        fallbackElement: t,
        router: n,
        future: r
    } = e, [l, i] = R.useState(n.state), [o, u] = R.useState(), [a, s] = R.useState({
        isTransitioning: !1
    }), [c, p] = R.useState(), [m, E] = R.useState(), [S, w] = R.useState(), C = R.useRef(new Map), {
        v7_startTransition: d
    } = r || {}, f = R.useCallback(_ => {
        d ? $v(_) : _()
    }, [d]), h = R.useCallback((_, L) => {
        let {
            deletedFetchers: O,
            unstable_flushSync: I,
            unstable_viewTransitionOpts: Y
        } = L;
        O.forEach(pe => C.current.delete(pe)), _.fetchers.forEach((pe, Ze) => {
            pe.data !== void 0 && C.current.set(Ze, pe.data)
        });
        let me = n.window == null || typeof n.window.document.startViewTransition != "function";
        if (!Y || me) {
            I ? Rr(() => i(_)) : f(() => i(_));
            return
        }
        if (I) {
            Rr(() => {
                m && (c && c.resolve(), m.skipTransition()), s({
                    isTransitioning: !0,
                    flushSync: !0,
                    currentLocation: Y.currentLocation,
                    nextLocation: Y.nextLocation
                })
            });
            let pe = n.window.document.startViewTransition(() => {
                Rr(() => i(_))
            });
            pe.finished.finally(() => {
                Rr(() => {
                    p(void 0), E(void 0), u(void 0), s({
                        isTransitioning: !1
                    })
                })
            }), Rr(() => E(pe));
            return
        }
        m ? (c && c.resolve(), m.skipTransition(), w({
            state: _,
            currentLocation: Y.currentLocation,
            nextLocation: Y.nextLocation
        })) : (u(_), s({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: Y.currentLocation,
            nextLocation: Y.nextLocation
        }))
    }, [n.window, m, c, C, f]);
    R.useLayoutEffect(() => n.subscribe(h), [n, h]), R.useEffect(() => {
        a.isTransitioning && !a.flushSync && p(new Vv)
    }, [a]), R.useEffect(() => {
        if (c && o && n.window) {
            let _ = o,
                L = c.promise,
                O = n.window.document.startViewTransition(async () => {
                    f(() => i(_)), await L
                });
            O.finished.finally(() => {
                p(void 0), E(void 0), u(void 0), s({
                    isTransitioning: !1
                })
            }), E(O)
        }
    }, [f, o, c, n.window]), R.useEffect(() => {
        c && o && l.location.key === o.location.key && c.resolve()
    }, [c, m, l.location, o]), R.useEffect(() => {
        !a.isTransitioning && S && (u(S.state), s({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: S.currentLocation,
            nextLocation: S.nextLocation
        }), w(void 0))
    }, [a.isTransitioning, S]), R.useEffect(() => {}, []);
    let x = R.useMemo(() => ({
            createHref: n.createHref,
            encodeLocation: n.encodeLocation,
            go: _ => n.navigate(_),
            push: (_, L, O) => n.navigate(_, {
                state: L,
                preventScrollReset: O == null ? void 0 : O.preventScrollReset
            }),
            replace: (_, L, O) => n.navigate(_, {
                replace: !0,
                state: L,
                preventScrollReset: O == null ? void 0 : O.preventScrollReset
            })
        }), [n]),
        T = n.basename || "/",
        v = R.useMemo(() => ({
            router: n,
            navigator: x,
            static: !1,
            basename: T
        }), [n, x, T]);
    return R.createElement(R.Fragment, null, R.createElement(ji.Provider, {
        value: v
    }, R.createElement(Od.Provider, {
        value: l
    }, R.createElement(Uv.Provider, {
        value: C.current
    }, R.createElement(jv.Provider, {
        value: a
    }, R.createElement(Mv, {
        basename: T,
        location: l.location,
        navigationType: l.historyAction,
        navigator: x,
        future: {
            v7_relativeSplatPath: n.future.v7_relativeSplatPath
        }
    }, l.initialized || n.future.v7_partialHydration ? R.createElement(Wv, {
        routes: n.routes,
        future: n.future,
        state: l
    }) : t))))), null)
}

function Wv(e) {
    let {
        routes: t,
        future: n,
        state: r
    } = e;
    return wv(t, void 0, r, n)
}
var tc;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(tc || (tc = {}));
var nc;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(nc || (nc = {}));

function Hv(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        l, i;
    for (i = 0; i < r.length; i++) l = r[i], !(t.indexOf(l) >= 0) && (n[l] = e[l]);
    return n
}

function gu(e, t) {
    return gu = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(r, l) {
        return r.__proto__ = l, r
    }, gu(e, t)
}

function Qv(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, gu(e, t)
}
const rc = {
        disabled: !1
    },
    Bd = zn.createContext(null);
var Kv = function(t) {
        return t.scrollTop
    },
    zr = "unmounted",
    sn = "exited",
    cn = "entering",
    Mn = "entered",
    wu = "exiting",
    Lt = function(e) {
        Qv(t, e);

        function t(r, l) {
            var i;
            i = e.call(this, r, l) || this;
            var o = l,
                u = o && !o.isMounting ? r.enter : r.appear,
                a;
            return i.appearStatus = null, r.in ? u ? (a = sn, i.appearStatus = cn) : a = Mn : r.unmountOnExit || r.mountOnEnter ? a = zr : a = sn, i.state = {
                status: a
            }, i.nextCallback = null, i
        }
        t.getDerivedStateFromProps = function(l, i) {
            var o = l.in;
            return o && i.status === zr ? {
                status: sn
            } : null
        };
        var n = t.prototype;
        return n.componentDidMount = function() {
            this.updateStatus(!0, this.appearStatus)
        }, n.componentDidUpdate = function(l) {
            var i = null;
            if (l !== this.props) {
                var o = this.state.status;
                this.props.in ? o !== cn && o !== Mn && (i = cn) : (o === cn || o === Mn) && (i = wu)
            }
            this.updateStatus(!1, i)
        }, n.componentWillUnmount = function() {
            this.cancelNextCallback()
        }, n.getTimeouts = function() {
            var l = this.props.timeout,
                i, o, u;
            return i = o = u = l, l != null && typeof l != "number" && (i = l.exit, o = l.enter, u = l.appear !== void 0 ? l.appear : o), {
                exit: i,
                enter: o,
                appear: u
            }
        }, n.updateStatus = function(l, i) {
            if (l === void 0 && (l = !1), i !== null)
                if (this.cancelNextCallback(), i === cn) {
                    if (this.props.unmountOnExit || this.props.mountOnEnter) {
                        var o = this.props.nodeRef ? this.props.nodeRef.current : Mr.findDOMNode(this);
                        o && Kv(o)
                    }
                    this.performEnter(l)
                } else this.performExit();
            else this.props.unmountOnExit && this.state.status === sn && this.setState({
                status: zr
            })
        }, n.performEnter = function(l) {
            var i = this,
                o = this.props.enter,
                u = this.context ? this.context.isMounting : l,
                a = this.props.nodeRef ? [u] : [Mr.findDOMNode(this), u],
                s = a[0],
                c = a[1],
                p = this.getTimeouts(),
                m = u ? p.appear : p.enter;
            if (!l && !o || rc.disabled) {
                this.safeSetState({
                    status: Mn
                }, function() {
                    i.props.onEntered(s)
                });
                return
            }
            this.props.onEnter(s, c), this.safeSetState({
                status: cn
            }, function() {
                i.props.onEntering(s, c), i.onTransitionEnd(m, function() {
                    i.safeSetState({
                        status: Mn
                    }, function() {
                        i.props.onEntered(s, c)
                    })
                })
            })
        }, n.performExit = function() {
            var l = this,
                i = this.props.exit,
                o = this.getTimeouts(),
                u = this.props.nodeRef ? void 0 : Mr.findDOMNode(this);
            if (!i || rc.disabled) {
                this.safeSetState({
                    status: sn
                }, function() {
                    l.props.onExited(u)
                });
                return
            }
            this.props.onExit(u), this.safeSetState({
                status: wu
            }, function() {
                l.props.onExiting(u), l.onTransitionEnd(o.exit, function() {
                    l.safeSetState({
                        status: sn
                    }, function() {
                        l.props.onExited(u)
                    })
                })
            })
        }, n.cancelNextCallback = function() {
            this.nextCallback !== null && (this.nextCallback.cancel(), this.nextCallback = null)
        }, n.safeSetState = function(l, i) {
            i = this.setNextCallback(i), this.setState(l, i)
        }, n.setNextCallback = function(l) {
            var i = this,
                o = !0;
            return this.nextCallback = function(u) {
                o && (o = !1, i.nextCallback = null, l(u))
            }, this.nextCallback.cancel = function() {
                o = !1
            }, this.nextCallback
        }, n.onTransitionEnd = function(l, i) {
            this.setNextCallback(i);
            var o = this.props.nodeRef ? this.props.nodeRef.current : Mr.findDOMNode(this),
                u = l == null && !this.props.addEndListener;
            if (!o || u) {
                setTimeout(this.nextCallback, 0);
                return
            }
            if (this.props.addEndListener) {
                var a = this.props.nodeRef ? [this.nextCallback] : [o, this.nextCallback],
                    s = a[0],
                    c = a[1];
                this.props.addEndListener(s, c)
            }
            l != null && setTimeout(this.nextCallback, l)
        }, n.render = function() {
            var l = this.state.status;
            if (l === zr) return null;
            var i = this.props,
                o = i.children;
            i.in, i.mountOnEnter, i.unmountOnExit, i.appear, i.enter, i.exit, i.timeout, i.addEndListener, i.onEnter, i.onEntering, i.onEntered, i.onExit, i.onExiting, i.onExited, i.nodeRef;
            var u = Hv(i, ["children", "in", "mountOnEnter", "unmountOnExit", "appear", "enter", "exit", "timeout", "addEndListener", "onEnter", "onEntering", "onEntered", "onExit", "onExiting", "onExited", "nodeRef"]);
            return zn.createElement(Bd.Provider, {
                value: null
            }, typeof o == "function" ? o(l, u) : zn.cloneElement(zn.Children.only(o), u))
        }, t
    }(zn.Component);
Lt.contextType = Bd;
Lt.propTypes = {};

function Dn() {}
Lt.defaultProps = { in: !1,
    mountOnEnter: !1,
    unmountOnExit: !1,
    appear: !1,
    enter: !0,
    exit: !0,
    onEnter: Dn,
    onEntering: Dn,
    onEntered: Dn,
    onExit: Dn,
    onExiting: Dn,
    onExited: Dn
};
Lt.UNMOUNTED = zr;
Lt.EXITED = sn;
Lt.ENTERING = cn;
Lt.ENTERED = Mn;
Lt.EXITING = wu;
const ly = Lt;
var Su = new Map,
    jl = new WeakMap,
    lc = 0,
    Yv = void 0;

function Xv(e) {
    return e ? (jl.has(e) || (lc += 1, jl.set(e, lc.toString())), jl.get(e)) : "0"
}

function Gv(e) {
    return Object.keys(e).sort().filter(t => e[t] !== void 0).map(t => `${t}_${t==="root"?Xv(e.root):e[t]}`).toString()
}

function Zv(e) {
    const t = Gv(e);
    let n = Su.get(t);
    if (!n) {
        const r = new Map;
        let l;
        const i = new IntersectionObserver(o => {
            o.forEach(u => {
                var a;
                const s = u.isIntersecting && l.some(c => u.intersectionRatio >= c);
                e.trackVisibility && typeof u.isVisible > "u" && (u.isVisible = s), (a = r.get(u.target)) == null || a.forEach(c => {
                    c(s, u)
                })
            })
        }, e);
        l = i.thresholds || (Array.isArray(e.threshold) ? e.threshold : [e.threshold || 0]), n = {
            id: t,
            observer: i,
            elements: r
        }, Su.set(t, n)
    }
    return n
}

function Jv(e, t, n = {}, r = Yv) {
    if (typeof window.IntersectionObserver > "u" && r !== void 0) {
        const a = e.getBoundingClientRect();
        return t(r, {
            isIntersecting: r,
            target: e,
            intersectionRatio: typeof n.threshold == "number" ? n.threshold : 0,
            time: 0,
            boundingClientRect: a,
            intersectionRect: a,
            rootBounds: a
        }), () => {}
    }
    const {
        id: l,
        observer: i,
        elements: o
    } = Zv(n), u = o.get(e) || [];
    return o.has(e) || o.set(e, u), u.push(t), i.observe(e),
        function() {
            u.splice(u.indexOf(t), 1), u.length === 0 && (o.delete(e), i.unobserve(e)), o.size === 0 && (i.disconnect(), Su.delete(l))
        }
}

function iy({
    threshold: e,
    delay: t,
    trackVisibility: n,
    rootMargin: r,
    root: l,
    triggerOnce: i,
    skip: o,
    initialInView: u,
    fallbackInView: a,
    onChange: s
} = {}) {
    var c;
    const [p, m] = R.useState(null), E = R.useRef(), [S, w] = R.useState({
        inView: !!u,
        entry: void 0
    });
    E.current = s, R.useEffect(() => {
        if (o || !p) return;
        let h;
        return h = Jv(p, (x, T) => {
            w({
                inView: x,
                entry: T
            }), E.current && E.current(x, T), T.isIntersecting && i && h && (h(), h = void 0)
        }, {
            root: l,
            rootMargin: r,
            threshold: e,
            trackVisibility: n,
            delay: t
        }, a), () => {
            h && h()
        }
    }, [Array.isArray(e) ? e.toString() : e, p, l, r, i, o, n, a, t]);
    const C = (c = S.entry) == null ? void 0 : c.target,
        d = R.useRef();
    !p && C && !i && !o && d.current !== C && (d.current = C, w({
        inView: !!u,
        entry: void 0
    }));
    const f = [m, S.inView, S.entry];
    return f.ref = f[0], f.inView = f[1], f.entry = f[2], f
}
export {
    bv as P, zn as R, ly as T, Is as _, gd as a, Mr as b, qv as c, yp as d, iy as e, ty as f, Eu as g, ny as h, qs as i, Dv as j, ry as k, Kn as m, R as r, ey as u
};