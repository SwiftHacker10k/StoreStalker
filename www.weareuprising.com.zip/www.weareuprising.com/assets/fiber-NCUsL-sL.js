import {
    r as P,
    a as Ff,
    g as Mi,
    _ as qt,
    c as Zt,
    R as sl
} from "./react-ZVDsBwBb.js";
import {
    ax as cl,
    r as Se,
    ay as On,
    az as rt,
    a2 as Jt,
    at as Nt,
    aA as Ct,
    aB as Hf,
    j as yr,
    aC as Gf,
    aD as jf,
    aE as bf,
    aF as Vf,
    aG as vi,
    D as mi,
    am as St,
    a9 as Wf,
    aH as Q,
    A as fl,
    ab as dl,
    V as Ne,
    aI as hl,
    aw as pl,
    aJ as xi,
    w as ht,
    x as Qf,
    aK as nu,
    aL as Ot,
    R as Ri,
    X as ru,
    aM as pr,
    f as iu,
    as as Ei,
    a6 as js,
    ar as Xf,
    aN as vl,
    e as ml,
    u as In,
    ap as _a,
    k as Kf,
    aO as Yf,
    m as Zf,
    aP as bs,
    c as su,
    Z as qf,
    aQ as Vs,
    aR as Jf,
    aS as $f,
    aT as ed,
    aU as td,
    aV as nd,
    aW as rd,
    aX as id,
    aY as sd,
    aZ as ld,
    Y as lu,
    an as od,
    O as wi,
    a_ as ad,
    G as ud
} from "./three-H0uqkCM-.js";
import {
    S as cd,
    L as fd,
    a as dd,
    b as hd,
    c as pd,
    d as vd,
    T as md,
    i as gd
} from "./three-stdlib-orAABGcX.js";
var ou = {
        exports: {}
    },
    Pi = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var yd = P,
    Sd = Symbol.for("react.element"),
    xd = Symbol.for("react.fragment"),
    Ed = Object.prototype.hasOwnProperty,
    _d = yd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    wd = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function au(n, r, l) {
    var a, c = {},
        d = null,
        f = null;
    l !== void 0 && (d = "" + l), r.key !== void 0 && (d = "" + r.key), r.ref !== void 0 && (f = r.ref);
    for (a in r) Ed.call(r, a) && !wd.hasOwnProperty(a) && (c[a] = r[a]);
    if (n && n.defaultProps)
        for (a in r = n.defaultProps, r) c[a] === void 0 && (c[a] = r[a]);
    return {
        $$typeof: Sd,
        type: n,
        key: d,
        ref: f,
        props: c,
        _owner: _d.current
    }
}
Pi.Fragment = xd;
Pi.jsx = au;
Pi.jsxs = au;
ou.exports = Pi;
var vr = ou.exports,
    wa = {},
    Ta = Ff;
wa.createRoot = Ta.createRoot, wa.hydrateRoot = Ta.hydrateRoot;
/**
 * postprocessing v6.33.3 build Mon Oct 30 2023
 * https://github.com/pmndrs/postprocessing
 * Copyright 2015-2023 Raoul van Rüschen
 * @license Zlib
 */
var Td = `#include <packing>
#define packFloatToRGBA(v) packDepthToRGBA(v)
#define unpackRGBAToFloat(v) unpackRGBAToDepth(v)
uniform lowp sampler2D luminanceBuffer0;uniform lowp sampler2D luminanceBuffer1;uniform float minLuminance;uniform float deltaTime;uniform float tau;varying vec2 vUv;void main(){float l0=unpackRGBAToFloat(texture2D(luminanceBuffer0,vUv));
#if __VERSION__ < 300
float l1=texture2DLodEXT(luminanceBuffer1,vUv,MIP_LEVEL_1X1).r;
#else
float l1=textureLod(luminanceBuffer1,vUv,MIP_LEVEL_1X1).r;
#endif
l0=max(minLuminance,l0);l1=max(minLuminance,l1);float adaptedLum=l0+(l1-l0)*(1.0-exp(-deltaTime*tau));gl_FragColor=(adaptedLum==1.0)?vec4(1.0):packFloatToRGBA(adaptedLum);}`,
    gl = "varying vec2 vUv;void main(){vUv=position.xy*0.5+0.5;gl_Position=vec4(position.xy,1.0,1.0);}",
    Md = class extends St {
        constructor() {
            super({
                name: "AdaptiveLuminanceMaterial",
                defines: {
                    MIP_LEVEL_1X1: "0.0"
                },
                uniforms: {
                    luminanceBuffer0: new Q(null),
                    luminanceBuffer1: new Q(null),
                    minLuminance: new Q(.01),
                    deltaTime: new Q(0),
                    tau: new Q(1)
                },
                extensions: {
                    shaderTextureLOD: !0
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Td,
                vertexShader: gl
            })
        }
        set luminanceBuffer0(n) {
            this.uniforms.luminanceBuffer0.value = n
        }
        setLuminanceBuffer0(n) {
            this.uniforms.luminanceBuffer0.value = n
        }
        set luminanceBuffer1(n) {
            this.uniforms.luminanceBuffer1.value = n
        }
        setLuminanceBuffer1(n) {
            this.uniforms.luminanceBuffer1.value = n
        }
        set mipLevel1x1(n) {
            this.defines.MIP_LEVEL_1X1 = n.toFixed(1), this.needsUpdate = !0
        }
        setMipLevel1x1(n) {
            this.mipLevel1x1 = n
        }
        set deltaTime(n) {
            this.uniforms.deltaTime.value = n
        }
        setDeltaTime(n) {
            this.uniforms.deltaTime.value = n
        }
        get minLuminance() {
            return this.uniforms.minLuminance.value
        }
        set minLuminance(n) {
            this.uniforms.minLuminance.value = n
        }
        getMinLuminance() {
            return this.uniforms.minLuminance.value
        }
        setMinLuminance(n) {
            this.uniforms.minLuminance.value = n
        }
        get adaptationRate() {
            return this.uniforms.tau.value
        }
        set adaptationRate(n) {
            this.uniforms.tau.value = n
        }
        getAdaptationRate() {
            return this.uniforms.tau.value
        }
        setAdaptationRate(n) {
            this.uniforms.tau.value = n
        }
    },
    ie = {
        SKIP: 9,
        SET: 30,
        ADD: 0,
        ALPHA: 1,
        AVERAGE: 2,
        COLOR: 3,
        COLOR_BURN: 4,
        COLOR_DODGE: 5,
        DARKEN: 6,
        DIFFERENCE: 7,
        DIVIDE: 8,
        DST: 9,
        EXCLUSION: 10,
        HARD_LIGHT: 11,
        HARD_MIX: 12,
        HUE: 13,
        INVERT: 14,
        INVERT_RGB: 15,
        LIGHTEN: 16,
        LINEAR_BURN: 17,
        LINEAR_DODGE: 18,
        LINEAR_LIGHT: 19,
        LUMINOSITY: 20,
        MULTIPLY: 21,
        NEGATION: 22,
        NORMAL: 23,
        OVERLAY: 24,
        PIN_LIGHT: 25,
        REFLECT: 26,
        SATURATION: 27,
        SCREEN: 28,
        SOFT_LIGHT: 29,
        SRC: 30,
        SUBTRACT: 31,
        VIVID_LIGHT: 32
    },
    uu = "",
    Ie = "srgb",
    An = "srgb-linear",
    Pt = {
        NONE: 0,
        DEPTH: 1,
        CONVOLUTION: 2
    },
    he = {
        FRAGMENT_HEAD: "FRAGMENT_HEAD",
        FRAGMENT_MAIN_UV: "FRAGMENT_MAIN_UV",
        FRAGMENT_MAIN_IMAGE: "FRAGMENT_MAIN_IMAGE",
        VERTEX_HEAD: "VERTEX_HEAD",
        VERTEX_MAIN_SUPPORT: "VERTEX_MAIN_SUPPORT"
    },
    yl = {
        VERY_SMALL: 0,
        SMALL: 1,
        MEDIUM: 2,
        LARGE: 3,
        VERY_LARGE: 4,
        HUGE: 5
    },
    Rd = {
        SCALE_UP: "lut.scaleup"
    },
    Bt = {
        REINHARD: 0,
        REINHARD2: 1,
        REINHARD2_ADAPTIVE: 2,
        OPTIMIZED_CINEON: 3,
        ACES_FILMIC: 4,
        UNCHARTED2: 5
    },
    gi = {
        DEFAULT: 0,
        ESKIL: 1
    },
    cu = Number(Ri.replace(/\D+/g, "")),
    Sl = cu >= 152,
    fu = new Map([
        [nu, An],
        [hl, Ie]
    ]),
    Pd = new Map([
        [An, nu],
        [Ie, hl]
    ]);

function Bn(n) {
    return n === null ? null : Sl ? n.outputColorSpace : fu.get(n.outputEncoding)
}

function yt(n, r) {
    n !== null && (Sl ? n.colorSpace = r : n.encoding = Pd.get(r))
}

function Ws(n, r) {
    n === null || r === null || (Sl ? r.colorSpace = n.colorSpace : r.encoding = n.encoding)
}

function Sr(n) {
    return cu < 154 ? n.replace("colorspace_fragment", "encodings_fragment") : n
}
var Cd = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec4 sum=texture2D(inputBuffer,vUv0);sum+=texture2D(inputBuffer,vUv1);sum+=texture2D(inputBuffer,vUv2);sum+=texture2D(inputBuffer,vUv3);gl_FragColor=sum*0.25;
#include <colorspace_fragment>
}`,
    Ud = "uniform vec4 texelSize;uniform float kernel;uniform float scale;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec2 uv=position.xy*0.5+0.5;vec2 dUv=(texelSize.xy*vec2(kernel)+texelSize.zw)*scale;vUv0=vec2(uv.x-dUv.x,uv.y+dUv.y);vUv1=vec2(uv.x+dUv.x,uv.y+dUv.y);vUv2=vec2(uv.x+dUv.x,uv.y-dUv.y);vUv3=vec2(uv.x-dUv.x,uv.y-dUv.y);gl_Position=vec4(position.xy,1.0,1.0);}",
    Ld = [new Float32Array([0, 0]), new Float32Array([0, 1, 1]), new Float32Array([0, 1, 1, 2]), new Float32Array([0, 1, 2, 2, 3]), new Float32Array([0, 1, 2, 3, 4, 4, 5]), new Float32Array([0, 1, 2, 3, 4, 5, 7, 8, 9, 10])],
    Dd = class extends St {
        constructor(n = new _a) {
            super({
                name: "KawaseBlurMaterial",
                uniforms: {
                    inputBuffer: new Q(null),
                    texelSize: new Q(new _a),
                    scale: new Q(1),
                    kernel: new Q(0)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Cd,
                vertexShader: Ud
            }), this.fragmentShader = Sr(this.fragmentShader), this.setTexelSize(n.x, n.y), this.kernelSize = yl.MEDIUM
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        setInputBuffer(n) {
            this.inputBuffer = n
        }
        get kernelSequence() {
            return Ld[this.kernelSize]
        }
        get scale() {
            return this.uniforms.scale.value
        }
        set scale(n) {
            this.uniforms.scale.value = n
        }
        getScale() {
            return this.uniforms.scale.value
        }
        setScale(n) {
            this.uniforms.scale.value = n
        }
        getKernel() {
            return null
        }
        get kernel() {
            return this.uniforms.kernel.value
        }
        set kernel(n) {
            this.uniforms.kernel.value = n
        }
        setKernel(n) {
            this.kernel = n
        }
        setTexelSize(n, r) {
            this.uniforms.texelSize.value.set(n, r, n * .5, r * .5)
        }
        setSize(n, r) {
            const l = 1 / n,
                a = 1 / r;
            this.uniforms.texelSize.value.set(l, a, l * .5, a * .5)
        }
    },
    Id = `#include <common>
#include <dithering_pars_fragment>
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
uniform float opacity;varying vec2 vUv;void main(){vec4 texel=texture2D(inputBuffer,vUv);gl_FragColor=opacity*texel;
#include <colorspace_fragment>
#include <dithering_fragment>
}`,
    du = class extends St {
        constructor() {
            super({
                name: "CopyMaterial",
                uniforms: {
                    inputBuffer: new Q(null),
                    opacity: new Q(1)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Id,
                vertexShader: gl
            }), this.fragmentShader = Sr(this.fragmentShader)
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        setInputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        getOpacity(n) {
            return this.uniforms.opacity.value
        }
        setOpacity(n) {
            this.uniforms.opacity.value = n
        }
    },
    zd = `#include <packing>
#ifdef GL_FRAGMENT_PRECISION_HIGH
uniform highp sampler2D depthBuffer;
#else
uniform mediump sampler2D depthBuffer;
#endif
#ifdef DOWNSAMPLE_NORMALS
uniform lowp sampler2D normalBuffer;
#endif
varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;float readDepth(const in vec2 uv){
#if DEPTH_PACKING == 3201
return unpackRGBAToDepth(texture2D(depthBuffer,uv));
#else
return texture2D(depthBuffer,uv).r;
#endif
}int findBestDepth(const in float samples[4]){float c=(samples[0]+samples[1]+samples[2]+samples[3])*0.25;float distances[4];distances[0]=abs(c-samples[0]);distances[1]=abs(c-samples[1]);distances[2]=abs(c-samples[2]);distances[3]=abs(c-samples[3]);float maxDistance=max(max(distances[0],distances[1]),max(distances[2],distances[3]));int remaining[3];int rejected[3];int i,j,k;for(i=0,j=0,k=0;i<4;++i){if(distances[i]<maxDistance){remaining[j++]=i;}else{rejected[k++]=i;}}for(;j<3;++j){remaining[j]=rejected[--k];}vec3 s=vec3(samples[remaining[0]],samples[remaining[1]],samples[remaining[2]]);c=(s.x+s.y+s.z)/3.0;distances[0]=abs(c-s.x);distances[1]=abs(c-s.y);distances[2]=abs(c-s.z);float minDistance=min(distances[0],min(distances[1],distances[2]));for(i=0;i<3;++i){if(distances[i]==minDistance){break;}}return remaining[i];}void main(){float d[4];d[0]=readDepth(vUv0);d[1]=readDepth(vUv1);d[2]=readDepth(vUv2);d[3]=readDepth(vUv3);int index=findBestDepth(d);
#ifdef DOWNSAMPLE_NORMALS
vec3 n[4];n[0]=texture2D(normalBuffer,vUv0).rgb;n[1]=texture2D(normalBuffer,vUv1).rgb;n[2]=texture2D(normalBuffer,vUv2).rgb;n[3]=texture2D(normalBuffer,vUv3).rgb;
#else
vec3 n[4];n[0]=vec3(0.0);n[1]=vec3(0.0);n[2]=vec3(0.0);n[3]=vec3(0.0);
#endif
gl_FragColor=vec4(n[index],d[index]);}`,
    Ad = "uniform vec2 texelSize;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;void main(){vec2 uv=position.xy*0.5+0.5;vUv0=uv;vUv1=vec2(uv.x,uv.y+texelSize.y);vUv2=vec2(uv.x+texelSize.x,uv.y);vUv3=uv+texelSize;gl_Position=vec4(position.xy,1.0,1.0);}",
    Bd = class extends St {
        constructor() {
            super({
                name: "DepthDownsamplingMaterial",
                defines: {
                    DEPTH_PACKING: "0"
                },
                uniforms: {
                    depthBuffer: new Q(null),
                    normalBuffer: new Q(null),
                    texelSize: new Q(new Se)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: zd,
                vertexShader: Ad
            })
        }
        set depthBuffer(n) {
            this.uniforms.depthBuffer.value = n
        }
        set depthPacking(n) {
            this.defines.DEPTH_PACKING = n.toFixed(0), this.needsUpdate = !0
        }
        setDepthBuffer(n, r = On) {
            this.depthBuffer = n, this.depthPacking = r
        }
        set normalBuffer(n) {
            this.uniforms.normalBuffer.value = n, n !== null ? this.defines.DOWNSAMPLE_NORMALS = "1" : delete this.defines.DOWNSAMPLE_NORMALS, this.needsUpdate = !0
        }
        setNormalBuffer(n) {
            this.normalBuffer = n
        }
        setTexelSize(n, r) {
            this.uniforms.texelSize.value.set(n, r)
        }
        setSize(n, r) {
            this.uniforms.texelSize.value.set(1 / n, 1 / r)
        }
    },
    Nd = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#define WEIGHT_INNER 0.125
#define WEIGHT_OUTER 0.0555555
varying vec2 vUv;varying vec2 vUv00;varying vec2 vUv01;varying vec2 vUv02;varying vec2 vUv03;varying vec2 vUv04;varying vec2 vUv05;varying vec2 vUv06;varying vec2 vUv07;varying vec2 vUv08;varying vec2 vUv09;varying vec2 vUv10;varying vec2 vUv11;float clampToBorder(const in vec2 uv){return float(uv.s>=0.0&&uv.s<=1.0&&uv.t>=0.0&&uv.t<=1.0);}void main(){vec4 c=vec4(0.0);vec4 w=WEIGHT_INNER*vec4(clampToBorder(vUv00),clampToBorder(vUv01),clampToBorder(vUv02),clampToBorder(vUv03));c+=w.x*texture2D(inputBuffer,vUv00);c+=w.y*texture2D(inputBuffer,vUv01);c+=w.z*texture2D(inputBuffer,vUv02);c+=w.w*texture2D(inputBuffer,vUv03);w=WEIGHT_OUTER*vec4(clampToBorder(vUv04),clampToBorder(vUv05),clampToBorder(vUv06),clampToBorder(vUv07));c+=w.x*texture2D(inputBuffer,vUv04);c+=w.y*texture2D(inputBuffer,vUv05);c+=w.z*texture2D(inputBuffer,vUv06);c+=w.w*texture2D(inputBuffer,vUv07);w=WEIGHT_OUTER*vec4(clampToBorder(vUv08),clampToBorder(vUv09),clampToBorder(vUv10),clampToBorder(vUv11));c+=w.x*texture2D(inputBuffer,vUv08);c+=w.y*texture2D(inputBuffer,vUv09);c+=w.z*texture2D(inputBuffer,vUv10);c+=w.w*texture2D(inputBuffer,vUv11);c+=WEIGHT_OUTER*texture2D(inputBuffer,vUv);gl_FragColor=c;
#include <colorspace_fragment>
}`,
    Od = "uniform vec2 texelSize;varying vec2 vUv;varying vec2 vUv00;varying vec2 vUv01;varying vec2 vUv02;varying vec2 vUv03;varying vec2 vUv04;varying vec2 vUv05;varying vec2 vUv06;varying vec2 vUv07;varying vec2 vUv08;varying vec2 vUv09;varying vec2 vUv10;varying vec2 vUv11;void main(){vUv=position.xy*0.5+0.5;vUv00=vUv+texelSize*vec2(-1.0,1.0);vUv01=vUv+texelSize*vec2(1.0,1.0);vUv02=vUv+texelSize*vec2(-1.0,-1.0);vUv03=vUv+texelSize*vec2(1.0,-1.0);vUv04=vUv+texelSize*vec2(-2.0,2.0);vUv05=vUv+texelSize*vec2(0.0,2.0);vUv06=vUv+texelSize*vec2(2.0,2.0);vUv07=vUv+texelSize*vec2(-2.0,0.0);vUv08=vUv+texelSize*vec2(2.0,0.0);vUv09=vUv+texelSize*vec2(-2.0,-2.0);vUv10=vUv+texelSize*vec2(0.0,-2.0);vUv11=vUv+texelSize*vec2(2.0,-2.0);gl_Position=vec4(position.xy,1.0,1.0);}",
    kd = class extends St {
        constructor() {
            super({
                name: "DownsamplingMaterial",
                uniforms: {
                    inputBuffer: new Q(null),
                    texelSize: new Q(new Se)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Nd,
                vertexShader: Od
            }), this.fragmentShader = Sr(this.fragmentShader)
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        setSize(n, r) {
            this.uniforms.texelSize.value.set(1 / n, 1 / r)
        }
    },
    Fd = `#include <common>
#include <packing>
#include <dithering_pars_fragment>
#define packFloatToRGBA(v) packDepthToRGBA(v)
#define unpackRGBAToFloat(v) unpackRGBAToDepth(v)
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#if DEPTH_PACKING == 3201
uniform lowp sampler2D depthBuffer;
#elif defined(GL_FRAGMENT_PRECISION_HIGH)
uniform highp sampler2D depthBuffer;
#else
uniform mediump sampler2D depthBuffer;
#endif
uniform vec2 resolution;uniform vec2 texelSize;uniform float cameraNear;uniform float cameraFar;uniform float aspect;uniform float time;varying vec2 vUv;
#if THREE_REVISION < 143
#define luminance(v) linearToRelativeLuminance(v)
#endif
#if THREE_REVISION >= 137
vec4 sRGBToLinear(const in vec4 value){return vec4(mix(pow(value.rgb*0.9478672986+vec3(0.0521327014),vec3(2.4)),value.rgb*0.0773993808,vec3(lessThanEqual(value.rgb,vec3(0.04045)))),value.a);}
#endif
float readDepth(const in vec2 uv){
#if DEPTH_PACKING == 3201
return unpackRGBAToDepth(texture2D(depthBuffer,uv));
#else
return texture2D(depthBuffer,uv).r;
#endif
}float getViewZ(const in float depth){
#ifdef PERSPECTIVE_CAMERA
return perspectiveDepthToViewZ(depth,cameraNear,cameraFar);
#else
return orthographicDepthToViewZ(depth,cameraNear,cameraFar);
#endif
}vec3 RGBToHCV(const in vec3 RGB){vec4 P=mix(vec4(RGB.bg,-1.0,2.0/3.0),vec4(RGB.gb,0.0,-1.0/3.0),step(RGB.b,RGB.g));vec4 Q=mix(vec4(P.xyw,RGB.r),vec4(RGB.r,P.yzx),step(P.x,RGB.r));float C=Q.x-min(Q.w,Q.y);float H=abs((Q.w-Q.y)/(6.0*C+EPSILON)+Q.z);return vec3(H,C,Q.x);}vec3 RGBToHSL(const in vec3 RGB){vec3 HCV=RGBToHCV(RGB);float L=HCV.z-HCV.y*0.5;float S=HCV.y/(1.0-abs(L*2.0-1.0)+EPSILON);return vec3(HCV.x,S,L);}vec3 HueToRGB(const in float H){float R=abs(H*6.0-3.0)-1.0;float G=2.0-abs(H*6.0-2.0);float B=2.0-abs(H*6.0-4.0);return clamp(vec3(R,G,B),0.0,1.0);}vec3 HSLToRGB(const in vec3 HSL){vec3 RGB=HueToRGB(HSL.x);float C=(1.0-abs(2.0*HSL.z-1.0))*HSL.y;return(RGB-0.5)*C+HSL.z;}FRAGMENT_HEAD void main(){FRAGMENT_MAIN_UV vec4 color0=texture2D(inputBuffer,UV);vec4 color1=vec4(0.0);FRAGMENT_MAIN_IMAGE color0.a=clamp(color0.a,0.0,1.0);gl_FragColor=color0;
#ifdef ENCODE_OUTPUT
#include <colorspace_fragment>
#endif
#include <dithering_fragment>
}`,
    Hd = "uniform vec2 resolution;uniform vec2 texelSize;uniform float cameraNear;uniform float cameraFar;uniform float aspect;uniform float time;varying vec2 vUv;VERTEX_HEAD void main(){vUv=position.xy*0.5+0.5;VERTEX_MAIN_SUPPORT gl_Position=vec4(position.xy,1.0,1.0);}",
    Gd = class extends St {
        constructor(n, r, l, a, c = !1) {
            super({
                name: "EffectMaterial",
                defines: {
                    THREE_REVISION: Ri.replace(/\D+/g, ""),
                    DEPTH_PACKING: "0",
                    ENCODE_OUTPUT: "1"
                },
                uniforms: {
                    inputBuffer: new Q(null),
                    depthBuffer: new Q(null),
                    resolution: new Q(new Se),
                    texelSize: new Q(new Se),
                    cameraNear: new Q(.3),
                    cameraFar: new Q(1e3),
                    aspect: new Q(1),
                    time: new Q(0)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                dithering: c
            }), n && this.setShaderParts(n), r && this.setDefines(r), l && this.setUniforms(l), this.copyCameraSettings(a)
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        setInputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        get depthBuffer() {
            return this.uniforms.depthBuffer.value
        }
        set depthBuffer(n) {
            this.uniforms.depthBuffer.value = n
        }
        get depthPacking() {
            return Number(this.defines.DEPTH_PACKING)
        }
        set depthPacking(n) {
            this.defines.DEPTH_PACKING = n.toFixed(0), this.needsUpdate = !0
        }
        setDepthBuffer(n, r = On) {
            this.depthBuffer = n, this.depthPacking = r
        }
        setShaderData(n) {
            this.setShaderParts(n.shaderParts), this.setDefines(n.defines), this.setUniforms(n.uniforms), this.setExtensions(n.extensions)
        }
        setShaderParts(n) {
            return this.fragmentShader = Fd.replace(he.FRAGMENT_HEAD, n.get(he.FRAGMENT_HEAD) || "").replace(he.FRAGMENT_MAIN_UV, n.get(he.FRAGMENT_MAIN_UV) || "").replace(he.FRAGMENT_MAIN_IMAGE, n.get(he.FRAGMENT_MAIN_IMAGE) || ""), this.vertexShader = Hd.replace(he.VERTEX_HEAD, n.get(he.VERTEX_HEAD) || "").replace(he.VERTEX_MAIN_SUPPORT, n.get(he.VERTEX_MAIN_SUPPORT) || ""), this.fragmentShader = Sr(this.fragmentShader), this.needsUpdate = !0, this
        }
        setDefines(n) {
            for (const r of n.entries()) this.defines[r[0]] = r[1];
            return this.needsUpdate = !0, this
        }
        setUniforms(n) {
            for (const r of n.entries()) this.uniforms[r[0]] = r[1];
            return this
        }
        setExtensions(n) {
            this.extensions = {};
            for (const r of n) this.extensions[r] = !0;
            return this
        }
        get encodeOutput() {
            return this.defines.ENCODE_OUTPUT !== void 0
        }
        set encodeOutput(n) {
            this.encodeOutput !== n && (n ? this.defines.ENCODE_OUTPUT = "1" : delete this.defines.ENCODE_OUTPUT, this.needsUpdate = !0)
        }
        isOutputEncodingEnabled(n) {
            return this.encodeOutput
        }
        setOutputEncodingEnabled(n) {
            this.encodeOutput = n
        }
        get time() {
            return this.uniforms.time.value
        }
        set time(n) {
            this.uniforms.time.value = n
        }
        setDeltaTime(n) {
            this.uniforms.time.value += n
        }
        adoptCameraSettings(n) {
            this.copyCameraSettings(n)
        }
        copyCameraSettings(n) {
            n && (this.uniforms.cameraNear.value = n.near, this.uniforms.cameraFar.value = n.far, n instanceof ru ? this.defines.PERSPECTIVE_CAMERA = "1" : delete this.defines.PERSPECTIVE_CAMERA, this.needsUpdate = !0)
        }
        setSize(n, r) {
            const l = this.uniforms;
            l.resolution.value.set(n, r), l.texelSize.value.set(1 / n, 1 / r), l.aspect.value = n / r
        }
        static get Section() {
            return he
        }
    },
    jd = `#include <common>
#if THREE_REVISION < 143
#define luminance(v) linearToRelativeLuminance(v)
#endif
#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;
#else
uniform lowp sampler2D inputBuffer;
#endif
#ifdef RANGE
uniform vec2 range;
#elif defined(THRESHOLD)
uniform float threshold;uniform float smoothing;
#endif
varying vec2 vUv;void main(){vec4 texel=texture2D(inputBuffer,vUv);float l=luminance(texel.rgb);
#ifdef RANGE
float low=step(range.x,l);float high=step(l,range.y);l*=low*high;
#elif defined(THRESHOLD)
l=smoothstep(threshold,threshold+smoothing,l);
#endif
#ifdef COLOR
gl_FragColor=vec4(texel.rgb*l,l);
#else
gl_FragColor=vec4(l);
#endif
}`,
    bd = class extends St {
        constructor(n = !1, r = null) {
            super({
                name: "LuminanceMaterial",
                defines: {
                    THREE_REVISION: Ri.replace(/\D+/g, "")
                },
                uniforms: {
                    inputBuffer: new Q(null),
                    threshold: new Q(0),
                    smoothing: new Q(1),
                    range: new Q(null)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: jd,
                vertexShader: gl
            }), this.colorOutput = n, this.luminanceRange = r
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        setInputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        get threshold() {
            return this.uniforms.threshold.value
        }
        set threshold(n) {
            this.smoothing > 0 || n > 0 ? this.defines.THRESHOLD = "1" : delete this.defines.THRESHOLD, this.uniforms.threshold.value = n
        }
        getThreshold() {
            return this.threshold
        }
        setThreshold(n) {
            this.threshold = n
        }
        get smoothing() {
            return this.uniforms.smoothing.value
        }
        set smoothing(n) {
            this.threshold > 0 || n > 0 ? this.defines.THRESHOLD = "1" : delete this.defines.THRESHOLD, this.uniforms.smoothing.value = n
        }
        getSmoothingFactor() {
            return this.smoothing
        }
        setSmoothingFactor(n) {
            this.smoothing = n
        }
        get useThreshold() {
            return this.threshold > 0 || this.smoothing > 0
        }
        set useThreshold(n) {}
        get colorOutput() {
            return this.defines.COLOR !== void 0
        }
        set colorOutput(n) {
            n ? this.defines.COLOR = "1" : delete this.defines.COLOR, this.needsUpdate = !0
        }
        isColorOutputEnabled(n) {
            return this.colorOutput
        }
        setColorOutputEnabled(n) {
            this.colorOutput = n
        }
        get useRange() {
            return this.luminanceRange !== null
        }
        set useRange(n) {
            this.luminanceRange = null
        }
        get luminanceRange() {
            return this.uniforms.range.value
        }
        set luminanceRange(n) {
            n !== null ? this.defines.RANGE = "1" : delete this.defines.RANGE, this.uniforms.range.value = n, this.needsUpdate = !0
        }
        getLuminanceRange() {
            return this.luminanceRange
        }
        setLuminanceRange(n) {
            this.luminanceRange = n
        }
    },
    Vd = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D inputBuffer;uniform mediump sampler2D supportBuffer;
#else
uniform lowp sampler2D inputBuffer;uniform lowp sampler2D supportBuffer;
#endif
uniform float radius;varying vec2 vUv;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;varying vec2 vUv4;varying vec2 vUv5;varying vec2 vUv6;varying vec2 vUv7;void main(){vec4 c=vec4(0.0);c+=texture2D(inputBuffer,vUv0)*0.0625;c+=texture2D(inputBuffer,vUv1)*0.125;c+=texture2D(inputBuffer,vUv2)*0.0625;c+=texture2D(inputBuffer,vUv3)*0.125;c+=texture2D(inputBuffer,vUv)*0.25;c+=texture2D(inputBuffer,vUv4)*0.125;c+=texture2D(inputBuffer,vUv5)*0.0625;c+=texture2D(inputBuffer,vUv6)*0.125;c+=texture2D(inputBuffer,vUv7)*0.0625;vec4 baseColor=texture2D(supportBuffer,vUv);gl_FragColor=mix(baseColor,c,radius);
#include <colorspace_fragment>
}`,
    Wd = "uniform vec2 texelSize;varying vec2 vUv;varying vec2 vUv0;varying vec2 vUv1;varying vec2 vUv2;varying vec2 vUv3;varying vec2 vUv4;varying vec2 vUv5;varying vec2 vUv6;varying vec2 vUv7;void main(){vUv=position.xy*0.5+0.5;vUv0=vUv+texelSize*vec2(-1.0,1.0);vUv1=vUv+texelSize*vec2(0.0,1.0);vUv2=vUv+texelSize*vec2(1.0,1.0);vUv3=vUv+texelSize*vec2(-1.0,0.0);vUv4=vUv+texelSize*vec2(1.0,0.0);vUv5=vUv+texelSize*vec2(-1.0,-1.0);vUv6=vUv+texelSize*vec2(0.0,-1.0);vUv7=vUv+texelSize*vec2(1.0,-1.0);gl_Position=vec4(position.xy,1.0,1.0);}",
    Qd = class extends St {
        constructor() {
            super({
                name: "UpsamplingMaterial",
                uniforms: {
                    inputBuffer: new Q(null),
                    supportBuffer: new Q(null),
                    texelSize: new Q(new Se),
                    radius: new Q(.85)
                },
                blending: Ot,
                toneMapped: !1,
                depthWrite: !1,
                depthTest: !1,
                fragmentShader: Vd,
                vertexShader: Wd
            }), this.fragmentShader = Sr(this.fragmentShader)
        }
        set inputBuffer(n) {
            this.uniforms.inputBuffer.value = n
        }
        set supportBuffer(n) {
            this.uniforms.supportBuffer.value = n
        }
        get radius() {
            return this.uniforms.radius.value
        }
        set radius(n) {
            this.uniforms.radius.value = n
        }
        setSize(n, r) {
            this.uniforms.texelSize.value.set(1 / n, 1 / r)
        }
    },
    Xd = new vl,
    Kt = null;

function Kd() {
    if (Kt === null) {
        const n = new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]),
            r = new Float32Array([0, 0, 2, 0, 0, 2]);
        Kt = new ml, Kt.setAttribute !== void 0 ? (Kt.setAttribute("position", new In(n, 3)), Kt.setAttribute("uv", new In(r, 2))) : (Kt.addAttribute("position", new In(n, 3)), Kt.addAttribute("uv", new In(r, 2)))
    }
    return Kt
}
var qe = class hu {
        constructor(r = "Pass", l = new pr, a = Xd) {
            this.name = r, this.renderer = null, this.scene = l, this.camera = a, this.screen = null, this.rtt = !0, this.needsSwap = !0, this.needsDepthTexture = !1, this.enabled = !0
        }
        get renderToScreen() {
            return !this.rtt
        }
        set renderToScreen(r) {
            if (this.rtt === r) {
                const l = this.fullscreenMaterial;
                l !== null && (l.needsUpdate = !0), this.rtt = !r
            }
        }
        set mainScene(r) {}
        set mainCamera(r) {}
        setRenderer(r) {
            this.renderer = r
        }
        isEnabled() {
            return this.enabled
        }
        setEnabled(r) {
            this.enabled = r
        }
        get fullscreenMaterial() {
            return this.screen !== null ? this.screen.material : null
        }
        set fullscreenMaterial(r) {
            let l = this.screen;
            l !== null ? l.material = r : (l = new iu(Kd(), r), l.frustumCulled = !1, this.scene === null && (this.scene = new pr), this.scene.add(l), this.screen = l)
        }
        getFullscreenMaterial() {
            return this.fullscreenMaterial
        }
        setFullscreenMaterial(r) {
            this.fullscreenMaterial = r
        }
        getDepthTexture() {
            return null
        }
        setDepthTexture(r, l = On) {}
        render(r, l, a, c, d) {
            throw new Error("Render method not implemented!")
        }
        setSize(r, l) {}
        initialize(r, l, a) {}
        dispose() {
            for (const r of Object.keys(this)) {
                const l = this[r];
                (l instanceof rt || l instanceof fl || l instanceof dl || l instanceof hu) && this[r].dispose()
            }
        }
    },
    pu = class extends qe {
        constructor(n, r = !0) {
            super("CopyPass"), this.fullscreenMaterial = new du, this.needsSwap = !1, this.renderTarget = n, n === void 0 && (this.renderTarget = new rt(1, 1, {
                minFilter: ht,
                magFilter: ht,
                stencilBuffer: !1,
                depthBuffer: !1
            }), this.renderTarget.texture.name = "CopyPass.Target"), this.autoResize = r
        }
        get resize() {
            return this.autoResize
        }
        set resize(n) {
            this.autoResize = n
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        setAutoResizeEnabled(n) {
            this.autoResize = n
        }
        render(n, r, l, a, c) {
            this.fullscreenMaterial.inputBuffer = r.texture, n.setRenderTarget(this.renderToScreen ? null : this.renderTarget), n.render(this.scene, this.camera)
        }
        setSize(n, r) {
            this.autoResize && this.renderTarget.setSize(n, r)
        }
        initialize(n, r, l) {
            l !== void 0 && (this.renderTarget.texture.type = l, l !== Ct ? this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1" : Bn(n) === Ie && yt(this.renderTarget.texture, Ie))
        }
    },
    Yd = class extends qe {
        constructor(n, {
            minLuminance: r = .01,
            adaptationRate: l = 1
        } = {}) {
            super("AdaptiveLuminancePass"), this.fullscreenMaterial = new Md, this.needsSwap = !1, this.renderTargetPrevious = new rt(1, 1, {
                minFilter: Jt,
                magFilter: Jt,
                depthBuffer: !1
            }), this.renderTargetPrevious.texture.name = "Luminance.Previous";
            const a = this.fullscreenMaterial;
            a.luminanceBuffer0 = this.renderTargetPrevious.texture, a.luminanceBuffer1 = n, a.minLuminance = r, a.adaptationRate = l, this.renderTargetAdapted = this.renderTargetPrevious.clone(), this.renderTargetAdapted.texture.name = "Luminance.Adapted", this.copyPass = new pu(this.renderTargetPrevious, !1)
        }
        get texture() {
            return this.renderTargetAdapted.texture
        }
        getTexture() {
            return this.renderTargetAdapted.texture
        }
        set mipLevel1x1(n) {
            this.fullscreenMaterial.mipLevel1x1 = n
        }
        get adaptationRate() {
            return this.fullscreenMaterial.adaptationRate
        }
        set adaptationRate(n) {
            this.fullscreenMaterial.adaptationRate = n
        }
        render(n, r, l, a, c) {
            this.fullscreenMaterial.deltaTime = a, n.setRenderTarget(this.renderToScreen ? null : this.renderTargetAdapted), n.render(this.scene, this.camera), this.copyPass.render(n, this.renderTargetAdapted)
        }
    },
    Zd = class extends qe {
        constructor() {
            super("ClearMaskPass", null, null), this.needsSwap = !1
        }
        render(n, r, l, a, c) {
            const d = n.state.buffers.stencil;
            d.setLocked(!1), d.setTest(!1)
        }
    },
    Ma = new yr,
    vu = class extends qe {
        constructor(n = !0, r = !0, l = !1) {
            super("ClearPass", null, null), this.needsSwap = !1, this.color = n, this.depth = r, this.stencil = l, this.overrideClearColor = null, this.overrideClearAlpha = -1
        }
        setClearFlags(n, r, l) {
            this.color = n, this.depth = r, this.stencil = l
        }
        getOverrideClearColor() {
            return this.overrideClearColor
        }
        setOverrideClearColor(n) {
            this.overrideClearColor = n
        }
        getOverrideClearAlpha() {
            return this.overrideClearAlpha
        }
        setOverrideClearAlpha(n) {
            this.overrideClearAlpha = n
        }
        render(n, r, l, a, c) {
            const d = this.overrideClearColor,
                f = this.overrideClearAlpha,
                g = n.getClearAlpha(),
                h = d !== null,
                y = f >= 0;
            h ? (n.getClearColor(Ma), n.setClearColor(d, y ? f : g)) : y && n.setClearAlpha(f), n.setRenderTarget(this.renderToScreen ? null : r), n.clear(this.color, this.depth, this.stencil), h ? n.setClearColor(Ma, g) : y && n.setClearAlpha(g)
        }
    },
    mu = class extends qe {
        constructor(n, r, l = null) {
            super("RenderPass", n, r), this.needsSwap = !1, this.clearPass = new vu, this.overrideMaterialManager = l === null ? null : new Pa(l), this.ignoreBackground = !1, this.skipShadowMapUpdate = !1, this.selection = null
        }
        set mainScene(n) {
            this.scene = n
        }
        set mainCamera(n) {
            this.camera = n
        }
        get renderToScreen() {
            return super.renderToScreen
        }
        set renderToScreen(n) {
            super.renderToScreen = n, this.clearPass.renderToScreen = n
        }
        get overrideMaterial() {
            const n = this.overrideMaterialManager;
            return n !== null ? n.material : null
        }
        set overrideMaterial(n) {
            const r = this.overrideMaterialManager;
            n !== null ? r !== null ? r.setMaterial(n) : this.overrideMaterialManager = new Pa(n) : r !== null && (r.dispose(), this.overrideMaterialManager = null)
        }
        getOverrideMaterial() {
            return this.overrideMaterial
        }
        setOverrideMaterial(n) {
            this.overrideMaterial = n
        }
        get clear() {
            return this.clearPass.enabled
        }
        set clear(n) {
            this.clearPass.enabled = n
        }
        getSelection() {
            return this.selection
        }
        setSelection(n) {
            this.selection = n
        }
        isBackgroundDisabled() {
            return this.ignoreBackground
        }
        setBackgroundDisabled(n) {
            this.ignoreBackground = n
        }
        isShadowMapDisabled() {
            return this.skipShadowMapUpdate
        }
        setShadowMapDisabled(n) {
            this.skipShadowMapUpdate = n
        }
        getClearPass() {
            return this.clearPass
        }
        render(n, r, l, a, c) {
            const d = this.scene,
                f = this.camera,
                g = this.selection,
                h = f.layers.mask,
                y = d.background,
                v = n.shadowMap.autoUpdate,
                p = this.renderToScreen ? null : r;
            g !== null && f.layers.set(g.getLayer()), this.skipShadowMapUpdate && (n.shadowMap.autoUpdate = !1), (this.ignoreBackground || this.clearPass.overrideClearColor !== null) && (d.background = null), this.clearPass.enabled && this.clearPass.render(n, r), n.setRenderTarget(p), this.overrideMaterialManager !== null ? this.overrideMaterialManager.render(n, d, f) : n.render(d, f), f.layers.mask = h, d.background = y, n.shadowMap.autoUpdate = v
        }
    },
    qd = class extends qe {
        constructor({
            normalBuffer: n = null,
            resolutionScale: r = .5,
            width: l = be.AUTO_SIZE,
            height: a = be.AUTO_SIZE,
            resolutionX: c = l,
            resolutionY: d = a
        } = {}) {
            super("DepthDownsamplingPass");
            const f = new Bd;
            f.normalBuffer = n, this.fullscreenMaterial = f, this.needsDepthTexture = !0, this.needsSwap = !1, this.renderTarget = new rt(1, 1, {
                minFilter: Jt,
                magFilter: Jt,
                depthBuffer: !1,
                type: Nt
            }), this.renderTarget.texture.name = "DepthDownsamplingPass.Target", this.renderTarget.texture.generateMipmaps = !1;
            const g = this.resolution = new be(this, c, d, r);
            g.addEventListener("change", h => this.setSize(g.baseWidth, g.baseHeight))
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        setDepthTexture(n, r = On) {
            this.fullscreenMaterial.depthBuffer = n, this.fullscreenMaterial.depthPacking = r
        }
        render(n, r, l, a, c) {
            n.setRenderTarget(this.renderToScreen ? null : this.renderTarget), n.render(this.scene, this.camera)
        }
        setSize(n, r) {
            const l = this.resolution;
            l.setBaseSize(n, r), this.renderTarget.setSize(l.width, l.height), this.fullscreenMaterial.setSize(n, r)
        }
        initialize(n, r, l) {
            const a = n.getContext();
            if (!(a.getExtension("EXT_color_buffer_float") || a.getExtension("EXT_color_buffer_half_float"))) throw new Error("Rendering to float texture is not supported.")
        }
    };

function Ra(n, r, l) {
    for (const a of r) {
        const c = "$1" + n + a.charAt(0).toUpperCase() + a.slice(1),
            d = new RegExp("([^\\.])(\\b" + a + "\\b)", "g");
        for (const f of l.entries()) f[1] !== null && l.set(f[0], f[1].replace(d, c))
    }
}

function Jd(n, r, l) {
    let a = r.getFragmentShader(),
        c = r.getVertexShader();
    const d = a !== void 0 && /mainImage/.test(a),
        f = a !== void 0 && /mainUv/.test(a);
    if (l.attributes |= r.getAttributes(), a === void 0) throw new Error(`Missing fragment shader (${r.name})`);
    if (f && l.attributes & Pt.CONVOLUTION) throw new Error(`Effects that transform UVs are incompatible with convolution effects (${r.name})`);
    if (!d && !f) throw new Error(`Could not find mainImage or mainUv function (${r.name})`); {
        const g = /\w+\s+(\w+)\([\w\s,]*\)\s*{/g,
            h = l.shaderParts;
        let y = h.get(he.FRAGMENT_HEAD) || "",
            v = h.get(he.FRAGMENT_MAIN_UV) || "",
            p = h.get(he.FRAGMENT_MAIN_IMAGE) || "",
            S = h.get(he.VERTEX_HEAD) || "",
            x = h.get(he.VERTEX_MAIN_SUPPORT) || "";
        const w = new Set,
            z = new Set;
        if (f && (v += `	${n}MainUv(UV);
`, l.uvTransformation = !0), c !== null && /mainSupport/.test(c)) {
            const T = /mainSupport *\([\w\s]*?uv\s*?\)/.test(c);
            x += `	${n}MainSupport(`, x += T ? `vUv);
` : `);
`;
            for (const D of c.matchAll(/(?:varying\s+\w+\s+([\S\s]*?);)/g))
                for (const H of D[1].split(/\s*,\s*/)) l.varyings.add(H), w.add(H), z.add(H);
            for (const D of c.matchAll(g)) z.add(D[1])
        }
        for (const T of a.matchAll(g)) z.add(T[1]);
        for (const T of r.defines.keys()) z.add(T.replace(/\([\w\s,]*\)/g, ""));
        for (const T of r.uniforms.keys()) z.add(T);
        z.delete("while"), z.delete("for"), z.delete("if"), r.uniforms.forEach((T, D) => l.uniforms.set(n + D.charAt(0).toUpperCase() + D.slice(1), T)), r.defines.forEach((T, D) => l.defines.set(n + D.charAt(0).toUpperCase() + D.slice(1), T));
        const I = new Map([
            ["fragment", a],
            ["vertex", c]
        ]);
        Ra(n, z, l.defines), Ra(n, z, I), a = I.get("fragment"), c = I.get("vertex");
        const C = r.blendMode;
        if (l.blendModes.set(C.blendFunction, C), d) {
            r.inputColorSpace !== null && r.inputColorSpace !== l.colorSpace && (p += r.inputColorSpace === Ie ? `color0 = LinearTosRGB(color0);
	` : `color0 = sRGBToLinear(color0);
	`), r.outputColorSpace !== uu ? l.colorSpace = r.outputColorSpace : r.inputColorSpace !== null && (l.colorSpace = r.inputColorSpace);
            const T = /MainImage *\([\w\s,]*?depth[\w\s,]*?\)/;
            p += `${n}MainImage(color0, UV, `, l.attributes & Pt.DEPTH && T.test(a) && (p += "depth, ", l.readDepth = !0), p += `color1);
	`;
            const D = n + "BlendOpacity";
            l.uniforms.set(D, C.opacity), p += `color0 = blend${C.blendFunction}(color0, color1, ${D});

	`, y += `uniform float ${D};

`
        }
        if (y += a + `
`, c !== null && (S += c + `
`), h.set(he.FRAGMENT_HEAD, y), h.set(he.FRAGMENT_MAIN_UV, v), h.set(he.FRAGMENT_MAIN_IMAGE, p), h.set(he.VERTEX_HEAD, S), h.set(he.VERTEX_MAIN_SUPPORT, x), r.extensions !== null)
            for (const T of r.extensions) l.extensions.add(T)
    }
}
var $d = class extends qe {
        constructor(n, ...r) {
            super("EffectPass"), this.fullscreenMaterial = new Gd(null, null, null, n), this.listener = l => this.handleEvent(l), this.effects = [], this.setEffects(r), this.skipRendering = !1, this.minTime = 1, this.maxTime = Number.POSITIVE_INFINITY, this.timeScale = 1
        }
        set mainScene(n) {
            for (const r of this.effects) r.mainScene = n
        }
        set mainCamera(n) {
            this.fullscreenMaterial.copyCameraSettings(n);
            for (const r of this.effects) r.mainCamera = n
        }
        get encodeOutput() {
            return this.fullscreenMaterial.encodeOutput
        }
        set encodeOutput(n) {
            this.fullscreenMaterial.encodeOutput = n
        }
        get dithering() {
            return this.fullscreenMaterial.dithering
        }
        set dithering(n) {
            const r = this.fullscreenMaterial;
            r.dithering = n, r.needsUpdate = !0
        }
        setEffects(n) {
            for (const r of this.effects) r.removeEventListener("change", this.listener);
            this.effects = n.sort((r, l) => l.attributes - r.attributes);
            for (const r of this.effects) r.addEventListener("change", this.listener)
        }
        updateMaterial() {
            const n = new oh;
            let r = 0;
            for (const f of this.effects)
                if (f.blendMode.blendFunction === ie.DST) n.attributes |= f.getAttributes() & Pt.DEPTH;
                else {
                    if (n.attributes & f.getAttributes() & Pt.CONVOLUTION) throw new Error(`Convolution effects cannot be merged (${f.name})`);
                    Jd("e" + r++, f, n)
                }
            let l = n.shaderParts.get(he.FRAGMENT_HEAD),
                a = n.shaderParts.get(he.FRAGMENT_MAIN_IMAGE),
                c = n.shaderParts.get(he.FRAGMENT_MAIN_UV);
            const d = /\bblend\b/g;
            for (const f of n.blendModes.values()) l += f.getShaderCode().replace(d, `blend${f.blendFunction}`) + `
`;
            n.attributes & Pt.DEPTH ? (n.readDepth && (a = `float depth = readDepth(UV);

	` + a), this.needsDepthTexture = this.getDepthTexture() === null) : this.needsDepthTexture = !1, n.colorSpace === Ie && (a += `color0 = sRGBToLinear(color0);
	`), n.uvTransformation ? (c = `vec2 transformedUv = vUv;
` + c, n.defines.set("UV", "transformedUv")) : n.defines.set("UV", "vUv"), n.shaderParts.set(he.FRAGMENT_HEAD, l), n.shaderParts.set(he.FRAGMENT_MAIN_IMAGE, a), n.shaderParts.set(he.FRAGMENT_MAIN_UV, c);
            for (const [f, g] of n.shaderParts) g !== null && n.shaderParts.set(f, g.trim().replace(/^#/, `
#`));
            this.skipRendering = r === 0, this.needsSwap = !this.skipRendering, this.fullscreenMaterial.setShaderData(n)
        }
        recompile() {
            this.updateMaterial()
        }
        getDepthTexture() {
            return this.fullscreenMaterial.depthBuffer
        }
        setDepthTexture(n, r = On) {
            this.fullscreenMaterial.depthBuffer = n, this.fullscreenMaterial.depthPacking = r;
            for (const l of this.effects) l.setDepthTexture(n, r)
        }
        render(n, r, l, a, c) {
            for (const d of this.effects) d.update(n, r, a);
            if (!this.skipRendering || this.renderToScreen) {
                const d = this.fullscreenMaterial;
                d.inputBuffer = r.texture, d.time += a * this.timeScale, n.setRenderTarget(this.renderToScreen ? null : l), n.render(this.scene, this.camera)
            }
        }
        setSize(n, r) {
            this.fullscreenMaterial.setSize(n, r);
            for (const l of this.effects) l.setSize(n, r)
        }
        initialize(n, r, l) {
            this.renderer = n;
            for (const a of this.effects) a.initialize(n, r, l);
            this.updateMaterial(), l !== void 0 && l !== Ct && (this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1")
        }
        dispose() {
            super.dispose();
            for (const n of this.effects) n.removeEventListener("change", this.listener), n.dispose()
        }
        handleEvent(n) {
            switch (n.type) {
                case "change":
                    this.recompile();
                    break
            }
        }
    },
    eh = class extends qe {
        constructor({
            kernelSize: n = yl.MEDIUM,
            resolutionScale: r = .5,
            width: l = be.AUTO_SIZE,
            height: a = be.AUTO_SIZE,
            resolutionX: c = l,
            resolutionY: d = a
        } = {}) {
            super("KawaseBlurPass"), this.renderTargetA = new rt(1, 1, {
                depthBuffer: !1
            }), this.renderTargetA.texture.name = "Blur.Target.A", this.renderTargetB = this.renderTargetA.clone(), this.renderTargetB.texture.name = "Blur.Target.B";
            const f = this.resolution = new be(this, c, d, r);
            f.addEventListener("change", g => this.setSize(f.baseWidth, f.baseHeight)), this._blurMaterial = new Dd, this._blurMaterial.kernelSize = n, this.copyMaterial = new du
        }
        getResolution() {
            return this.resolution
        }
        get blurMaterial() {
            return this._blurMaterial
        }
        set blurMaterial(n) {
            this._blurMaterial = n
        }
        get dithering() {
            return this.copyMaterial.dithering
        }
        set dithering(n) {
            this.copyMaterial.dithering = n
        }
        get kernelSize() {
            return this.blurMaterial.kernelSize
        }
        set kernelSize(n) {
            this.blurMaterial.kernelSize = n
        }
        get width() {
            return this.resolution.width
        }
        set width(n) {
            this.resolution.preferredWidth = n
        }
        get height() {
            return this.resolution.height
        }
        set height(n) {
            this.resolution.preferredHeight = n
        }
        get scale() {
            return this.blurMaterial.scale
        }
        set scale(n) {
            this.blurMaterial.scale = n
        }
        getScale() {
            return this.blurMaterial.scale
        }
        setScale(n) {
            this.blurMaterial.scale = n
        }
        getKernelSize() {
            return this.kernelSize
        }
        setKernelSize(n) {
            this.kernelSize = n
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(n) {
            this.resolution.scale = n
        }
        render(n, r, l, a, c) {
            const d = this.scene,
                f = this.camera,
                g = this.renderTargetA,
                h = this.renderTargetB,
                y = this.blurMaterial,
                v = y.kernelSequence;
            let p = r;
            this.fullscreenMaterial = y;
            for (let S = 0, x = v.length; S < x; ++S) {
                const w = S & 1 ? h : g;
                y.kernel = v[S], y.inputBuffer = p.texture, n.setRenderTarget(w), n.render(d, f), p = w
            }
            this.fullscreenMaterial = this.copyMaterial, this.copyMaterial.inputBuffer = p.texture, n.setRenderTarget(this.renderToScreen ? null : l), n.render(d, f)
        }
        setSize(n, r) {
            const l = this.resolution;
            l.setBaseSize(n, r);
            const a = l.width,
                c = l.height;
            this.renderTargetA.setSize(a, c), this.renderTargetB.setSize(a, c), this.blurMaterial.setSize(n, r)
        }
        initialize(n, r, l) {
            l !== void 0 && (this.renderTargetA.texture.type = l, this.renderTargetB.texture.type = l, l !== Ct ? (this.blurMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1", this.copyMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1") : Bn(n) === Ie && (yt(this.renderTargetA.texture, Ie), yt(this.renderTargetB.texture, Ie)))
        }
        static get AUTO_SIZE() {
            return be.AUTO_SIZE
        }
    },
    gu = class extends qe {
        constructor({
            renderTarget: n,
            luminanceRange: r,
            colorOutput: l,
            resolutionScale: a = 1,
            width: c = be.AUTO_SIZE,
            height: d = be.AUTO_SIZE,
            resolutionX: f = c,
            resolutionY: g = d
        } = {}) {
            super("LuminancePass"), this.fullscreenMaterial = new bd(l, r), this.needsSwap = !1, this.renderTarget = n, this.renderTarget === void 0 && (this.renderTarget = new rt(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "LuminancePass.Target");
            const h = this.resolution = new be(this, f, g, a);
            h.addEventListener("change", y => this.setSize(h.baseWidth, h.baseHeight))
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        render(n, r, l, a, c) {
            const d = this.fullscreenMaterial;
            d.inputBuffer = r.texture, n.setRenderTarget(this.renderToScreen ? null : this.renderTarget), n.render(this.scene, this.camera)
        }
        setSize(n, r) {
            const l = this.resolution;
            l.setBaseSize(n, r), this.renderTarget.setSize(l.width, l.height)
        }
        initialize(n, r, l) {
            l !== void 0 && l !== Ct && (this.renderTarget.texture.type = l, this.fullscreenMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1")
        }
    },
    th = class extends qe {
        constructor(n, r) {
            super("MaskPass", n, r), this.needsSwap = !1, this.clearPass = new vu(!1, !1, !0), this.inverse = !1
        }
        set mainScene(n) {
            this.scene = n
        }
        set mainCamera(n) {
            this.camera = n
        }
        get inverted() {
            return this.inverse
        }
        set inverted(n) {
            this.inverse = n
        }
        get clear() {
            return this.clearPass.enabled
        }
        set clear(n) {
            this.clearPass.enabled = n
        }
        getClearPass() {
            return this.clearPass
        }
        isInverted() {
            return this.inverted
        }
        setInverted(n) {
            this.inverted = n
        }
        render(n, r, l, a, c) {
            const d = n.getContext(),
                f = n.state.buffers,
                g = this.scene,
                h = this.camera,
                y = this.clearPass,
                v = this.inverted ? 0 : 1,
                p = 1 - v;
            f.color.setMask(!1), f.depth.setMask(!1), f.color.setLocked(!0), f.depth.setLocked(!0), f.stencil.setTest(!0), f.stencil.setOp(d.REPLACE, d.REPLACE, d.REPLACE), f.stencil.setFunc(d.ALWAYS, v, 4294967295), f.stencil.setClear(p), f.stencil.setLocked(!0), this.clearPass.enabled && (this.renderToScreen ? y.render(n, null) : (y.render(n, r), y.render(n, l))), this.renderToScreen ? (n.setRenderTarget(null), n.render(g, h)) : (n.setRenderTarget(r), n.render(g, h), n.setRenderTarget(l), n.render(g, h)), f.color.setLocked(!1), f.depth.setLocked(!1), f.stencil.setLocked(!1), f.stencil.setFunc(d.EQUAL, 1, 4294967295), f.stencil.setOp(d.KEEP, d.KEEP, d.KEEP), f.stencil.setLocked(!0)
        }
    },
    nh = class extends qe {
        constructor() {
            super("MipmapBlurPass"), this.needsSwap = !1, this.renderTarget = new rt(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "Upsampling.Mipmap0", this.downsamplingMipmaps = [], this.upsamplingMipmaps = [], this.downsamplingMaterial = new kd, this.upsamplingMaterial = new Qd, this.resolution = new Se
        }
        get texture() {
            return this.renderTarget.texture
        }
        get levels() {
            return this.downsamplingMipmaps.length
        }
        set levels(n) {
            if (this.levels !== n) {
                const r = this.renderTarget;
                this.dispose(), this.downsamplingMipmaps = [], this.upsamplingMipmaps = [];
                for (let l = 0; l < n; ++l) {
                    const a = r.clone();
                    a.texture.name = "Downsampling.Mipmap" + l, this.downsamplingMipmaps.push(a)
                }
                this.upsamplingMipmaps.push(r);
                for (let l = 1, a = n - 1; l < a; ++l) {
                    const c = r.clone();
                    c.texture.name = "Upsampling.Mipmap" + l, this.upsamplingMipmaps.push(c)
                }
                this.setSize(this.resolution.x, this.resolution.y)
            }
        }
        get radius() {
            return this.upsamplingMaterial.radius
        }
        set radius(n) {
            this.upsamplingMaterial.radius = n
        }
        render(n, r, l, a, c) {
            const {
                scene: d,
                camera: f
            } = this, {
                downsamplingMaterial: g,
                upsamplingMaterial: h
            } = this, {
                downsamplingMipmaps: y,
                upsamplingMipmaps: v
            } = this;
            let p = r;
            this.fullscreenMaterial = g;
            for (let S = 0, x = y.length; S < x; ++S) {
                const w = y[S];
                g.setSize(p.width, p.height), g.inputBuffer = p.texture, n.setRenderTarget(w), n.render(d, f), p = w
            }
            this.fullscreenMaterial = h;
            for (let S = v.length - 1; S >= 0; --S) {
                const x = v[S];
                h.setSize(p.width, p.height), h.inputBuffer = p.texture, h.supportBuffer = y[S].texture, n.setRenderTarget(x), n.render(d, f), p = x
            }
        }
        setSize(n, r) {
            const l = this.resolution;
            l.set(n, r);
            let a = l.width,
                c = l.height;
            for (let d = 0, f = this.downsamplingMipmaps.length; d < f; ++d) a = Math.round(a * .5), c = Math.round(c * .5), this.downsamplingMipmaps[d].setSize(a, c), d < this.upsamplingMipmaps.length && this.upsamplingMipmaps[d].setSize(a, c)
        }
        initialize(n, r, l) {
            if (l !== void 0) {
                const a = this.downsamplingMipmaps.concat(this.upsamplingMipmaps);
                for (const c of a) c.texture.type = l;
                if (l !== Ct) this.downsamplingMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1", this.upsamplingMaterial.defines.FRAMEBUFFER_PRECISION_HIGH = "1";
                else if (Bn(n) === Ie)
                    for (const c of a) yt(c.texture, Ie)
            }
        }
        dispose() {
            super.dispose();
            for (const n of this.downsamplingMipmaps.concat(this.upsamplingMipmaps)) n.dispose()
        }
    },
    rh = class extends qe {
        constructor(n, r, {
            renderTarget: l,
            resolutionScale: a = 1,
            width: c = be.AUTO_SIZE,
            height: d = be.AUTO_SIZE,
            resolutionX: f = c,
            resolutionY: g = d
        } = {}) {
            super("NormalPass"), this.needsSwap = !1, this.renderPass = new mu(n, r, new Hf);
            const h = this.renderPass;
            h.ignoreBackground = !0, h.skipShadowMapUpdate = !0;
            const y = h.getClearPass();
            y.overrideClearColor = new yr(7829503), y.overrideClearAlpha = 1, this.renderTarget = l, this.renderTarget === void 0 && (this.renderTarget = new rt(1, 1, {
                minFilter: Jt,
                magFilter: Jt
            }), this.renderTarget.texture.name = "NormalPass.Target");
            const v = this.resolution = new be(this, f, g, a);
            v.addEventListener("change", p => this.setSize(v.baseWidth, v.baseHeight))
        }
        set mainScene(n) {
            this.renderPass.mainScene = n
        }
        set mainCamera(n) {
            this.renderPass.mainCamera = n
        }
        get texture() {
            return this.renderTarget.texture
        }
        getTexture() {
            return this.renderTarget.texture
        }
        getResolution() {
            return this.resolution
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(n) {
            this.resolution.scale = n
        }
        render(n, r, l, a, c) {
            const d = this.renderToScreen ? null : this.renderTarget;
            this.renderPass.render(n, d, d)
        }
        setSize(n, r) {
            const l = this.resolution;
            l.setBaseSize(n, r), this.renderTarget.setSize(l.width, l.height)
        }
    },
    Qs = 1 / 1e3,
    ih = 1e3,
    sh = class {
        constructor() {
            this.startTime = performance.now(), this.previousTime = 0, this.currentTime = 0, this._delta = 0, this._elapsed = 0, this._fixedDelta = 1e3 / 60, this.timescale = 1, this.useFixedDelta = !1, this._autoReset = !1
        }
        get autoReset() {
            return this._autoReset
        }
        set autoReset(n) {
            typeof document < "u" && document.hidden !== void 0 && (n ? document.addEventListener("visibilitychange", this) : document.removeEventListener("visibilitychange", this), this._autoReset = n)
        }
        get delta() {
            return this._delta * Qs
        }
        get fixedDelta() {
            return this._fixedDelta * Qs
        }
        set fixedDelta(n) {
            this._fixedDelta = n * ih
        }
        get elapsed() {
            return this._elapsed * Qs
        }
        update(n) {
            this.useFixedDelta ? this._delta = this.fixedDelta : (this.previousTime = this.currentTime, this.currentTime = (n !== void 0 ? n : performance.now()) - this.startTime, this._delta = this.currentTime - this.previousTime), this._delta *= this.timescale, this._elapsed += this._delta
        }
        reset() {
            this._delta = 0, this._elapsed = 0, this.currentTime = performance.now() - this.startTime
        }
        handleEvent(n) {
            document.hidden || (this.currentTime = performance.now() - this.startTime)
        }
        dispose() {
            this.autoReset = !1
        }
    },
    lh = class {
        constructor(r = null, {
            depthBuffer: l = !0,
            stencilBuffer: a = !1,
            multisampling: c = 0,
            frameBufferType: d
        } = {}) {
            this.renderer = null, this.inputBuffer = this.createBuffer(l, a, d, c), this.outputBuffer = this.inputBuffer.clone(), this.copyPass = new pu, this.depthTexture = null, this.passes = [], this.timer = new sh, this.autoRenderToScreen = !0, this.setRenderer(r)
        }
        get multisampling() {
            return this.inputBuffer.samples || 0
        }
        set multisampling(r) {
            const l = this.inputBuffer,
                a = this.multisampling;
            a > 0 && r > 0 ? (this.inputBuffer.samples = r, this.outputBuffer.samples = r, this.inputBuffer.dispose(), this.outputBuffer.dispose()) : a !== r && (this.inputBuffer.dispose(), this.outputBuffer.dispose(), this.inputBuffer = this.createBuffer(l.depthBuffer, l.stencilBuffer, l.texture.type, r), this.inputBuffer.depthTexture = this.depthTexture, this.outputBuffer = this.inputBuffer.clone())
        }
        getTimer() {
            return this.timer
        }
        getRenderer() {
            return this.renderer
        }
        setRenderer(r) {
            if (this.renderer = r, r !== null) {
                const l = r.getSize(new Se),
                    a = r.getContext().getContextAttributes().alpha,
                    c = this.inputBuffer.texture.type;
                c === Ct && Bn(r) === Ie && (yt(this.inputBuffer.texture, Ie), yt(this.outputBuffer.texture, Ie), this.inputBuffer.dispose(), this.outputBuffer.dispose()), r.autoClear = !1, this.setSize(l.width, l.height);
                for (const d of this.passes) d.initialize(r, a, c)
            }
        }
        replaceRenderer(r, l = !0) {
            const a = this.renderer,
                c = a.domElement.parentNode;
            return this.setRenderer(r), l && c !== null && (c.removeChild(a.domElement), c.appendChild(r.domElement)), a
        }
        createDepthTexture() {
            const r = this.depthTexture = new Gf;
            return this.inputBuffer.depthTexture = r, this.inputBuffer.dispose(), this.inputBuffer.stencilBuffer ? (r.format = jf, r.type = bf) : r.type = Vf, r
        }
        deleteDepthTexture() {
            if (this.depthTexture !== null) {
                this.depthTexture.dispose(), this.depthTexture = null, this.inputBuffer.depthTexture = null, this.inputBuffer.dispose();
                for (const r of this.passes) r.setDepthTexture(null)
            }
        }
        createBuffer(r, l, a, c) {
            const d = this.renderer,
                f = d === null ? new Se : d.getDrawingBufferSize(new Se),
                g = {
                    minFilter: ht,
                    magFilter: ht,
                    stencilBuffer: l,
                    depthBuffer: r,
                    type: a
                },
                h = new rt(f.width, f.height, g);
            return c > 0 && (h.ignoreDepthForMultisampleCopy = !1, h.samples = c), a === Ct && Bn(d) === Ie && yt(h.texture, Ie), h.texture.name = "EffectComposer.Buffer", h.texture.generateMipmaps = !1, h
        }
        setMainScene(r) {
            for (const l of this.passes) l.mainScene = r
        }
        setMainCamera(r) {
            for (const l of this.passes) l.mainCamera = r
        }
        addPass(r, l) {
            const a = this.passes,
                c = this.renderer,
                d = c.getDrawingBufferSize(new Se),
                f = c.getContext().getContextAttributes().alpha,
                g = this.inputBuffer.texture.type;
            if (r.setRenderer(c), r.setSize(d.width, d.height), r.initialize(c, f, g), this.autoRenderToScreen && (a.length > 0 && (a[a.length - 1].renderToScreen = !1), r.renderToScreen && (this.autoRenderToScreen = !1)), l !== void 0 ? a.splice(l, 0, r) : a.push(r), this.autoRenderToScreen && (a[a.length - 1].renderToScreen = !0), r.needsDepthTexture || this.depthTexture !== null)
                if (this.depthTexture === null) {
                    const h = this.createDepthTexture();
                    for (r of a) r.setDepthTexture(h)
                } else r.setDepthTexture(this.depthTexture)
        }
        removePass(r) {
            const l = this.passes,
                a = l.indexOf(r);
            if (a !== -1 && l.splice(a, 1).length > 0) {
                if (this.depthTexture !== null) {
                    const f = (h, y) => h || y.needsDepthTexture;
                    l.reduce(f, !1) || (r.getDepthTexture() === this.depthTexture && r.setDepthTexture(null), this.deleteDepthTexture())
                }
                this.autoRenderToScreen && a === l.length && (r.renderToScreen = !1, l.length > 0 && (l[l.length - 1].renderToScreen = !0))
            }
        }
        removeAllPasses() {
            const r = this.passes;
            this.deleteDepthTexture(), r.length > 0 && (this.autoRenderToScreen && (r[r.length - 1].renderToScreen = !1), this.passes = [])
        }
        render(r) {
            const l = this.renderer,
                a = this.copyPass;
            let c = this.inputBuffer,
                d = this.outputBuffer,
                f = !1,
                g, h, y;
            r === void 0 && (this.timer.update(), r = this.timer.delta);
            for (const v of this.passes) v.enabled && (v.render(l, c, d, r, f), v.needsSwap && (f && (a.renderToScreen = v.renderToScreen, g = l.getContext(), h = l.state.buffers.stencil, h.setFunc(g.NOTEQUAL, 1, 4294967295), a.render(l, c, d, r, f), h.setFunc(g.EQUAL, 1, 4294967295)), y = c, c = d, d = y), v instanceof th ? f = !0 : v instanceof Zd && (f = !1))
        }
        setSize(r, l, a) {
            const c = this.renderer,
                d = c.getSize(new Se);
            (r === void 0 || l === void 0) && (r = d.width, l = d.height), (d.width !== r || d.height !== l) && c.setSize(r, l, a);
            const f = c.getDrawingBufferSize(new Se);
            this.inputBuffer.setSize(f.width, f.height), this.outputBuffer.setSize(f.width, f.height);
            for (const g of this.passes) g.setSize(f.width, f.height)
        }
        reset() {
            const r = this.timer.autoReset;
            this.dispose(), this.autoRenderToScreen = !0, this.timer.autoReset = r
        }
        dispose() {
            for (const r of this.passes) r.dispose();
            this.passes = [], this.inputBuffer !== null && this.inputBuffer.dispose(), this.outputBuffer !== null && this.outputBuffer.dispose(), this.deleteDepthTexture(), this.copyPass.dispose(), this.timer.dispose()
        }
    },
    oh = class {
        constructor() {
            this.shaderParts = new Map([
                [he.FRAGMENT_HEAD, null],
                [he.FRAGMENT_MAIN_UV, null],
                [he.FRAGMENT_MAIN_IMAGE, null],
                [he.VERTEX_HEAD, null],
                [he.VERTEX_MAIN_SUPPORT, null]
            ]), this.defines = new Map, this.uniforms = new Map, this.blendModes = new Map, this.extensions = new Set, this.attributes = Pt.NONE, this.varyings = new Set, this.uvTransformation = !1, this.readDepth = !1, this.colorSpace = An
        }
    },
    Xs = !1,
    Pa = class {
        constructor(n = null) {
            this.originalMaterials = new Map, this.material = null, this.materials = null, this.materialsBackSide = null, this.materialsDoubleSide = null, this.materialsFlatShaded = null, this.materialsFlatShadedBackSide = null, this.materialsFlatShadedDoubleSide = null, this.setMaterial(n), this.meshCount = 0, this.replaceMaterial = r => {
                if (r.isMesh) {
                    let l;
                    if (r.material.flatShading) switch (r.material.side) {
                        case mi:
                            l = this.materialsFlatShadedDoubleSide;
                            break;
                        case vi:
                            l = this.materialsFlatShadedBackSide;
                            break;
                        default:
                            l = this.materialsFlatShaded;
                            break
                    } else switch (r.material.side) {
                        case mi:
                            l = this.materialsDoubleSide;
                            break;
                        case vi:
                            l = this.materialsBackSide;
                            break;
                        default:
                            l = this.materials;
                            break
                    }
                    this.originalMaterials.set(r, r.material), r.isSkinnedMesh ? r.material = l[2] : r.isInstancedMesh ? r.material = l[1] : r.material = l[0], ++this.meshCount
                }
            }
        }
        cloneMaterial(n) {
            if (!(n instanceof St)) return n.clone();
            const r = n.uniforms,
                l = new Map;
            for (const c in r) {
                const d = r[c].value;
                d.isRenderTargetTexture && (r[c].value = null, l.set(c, d))
            }
            const a = n.clone();
            for (const c of l) r[c[0]].value = c[1], a.uniforms[c[0]].value = c[1];
            return a
        }
        setMaterial(n) {
            if (this.disposeMaterials(), this.material = n, n !== null) {
                const r = this.materials = [this.cloneMaterial(n), this.cloneMaterial(n), this.cloneMaterial(n)];
                for (const l of r) l.uniforms = Object.assign({}, n.uniforms), l.side = Wf;
                r[2].skinning = !0, this.materialsBackSide = r.map(l => {
                    const a = this.cloneMaterial(l);
                    return a.uniforms = Object.assign({}, n.uniforms), a.side = vi, a
                }), this.materialsDoubleSide = r.map(l => {
                    const a = this.cloneMaterial(l);
                    return a.uniforms = Object.assign({}, n.uniforms), a.side = mi, a
                }), this.materialsFlatShaded = r.map(l => {
                    const a = this.cloneMaterial(l);
                    return a.uniforms = Object.assign({}, n.uniforms), a.flatShading = !0, a
                }), this.materialsFlatShadedBackSide = r.map(l => {
                    const a = this.cloneMaterial(l);
                    return a.uniforms = Object.assign({}, n.uniforms), a.flatShading = !0, a.side = vi, a
                }), this.materialsFlatShadedDoubleSide = r.map(l => {
                    const a = this.cloneMaterial(l);
                    return a.uniforms = Object.assign({}, n.uniforms), a.flatShading = !0, a.side = mi, a
                })
            }
        }
        render(n, r, l) {
            const a = n.shadowMap.enabled;
            if (n.shadowMap.enabled = !1, Xs) {
                const c = this.originalMaterials;
                this.meshCount = 0, r.traverse(this.replaceMaterial), n.render(r, l);
                for (const d of c) d[0].material = d[1];
                this.meshCount !== c.size && c.clear()
            } else {
                const c = r.overrideMaterial;
                r.overrideMaterial = this.material, n.render(r, l), r.overrideMaterial = c
            }
            n.shadowMap.enabled = a
        }
        disposeMaterials() {
            if (this.material !== null) {
                const n = this.materials.concat(this.materialsBackSide).concat(this.materialsDoubleSide).concat(this.materialsFlatShaded).concat(this.materialsFlatShadedBackSide).concat(this.materialsFlatShadedDoubleSide);
                for (const r of n) r.dispose()
            }
        }
        dispose() {
            this.originalMaterials.clear(), this.disposeMaterials()
        }
        static get workaroundEnabled() {
            return Xs
        }
        static set workaroundEnabled(n) {
            Xs = n
        }
    },
    Yt = -1,
    be = class extends cl {
        constructor(n, r = Yt, l = Yt, a = 1) {
            super(), this.resizable = n, this.baseSize = new Se(1, 1), this.preferredSize = new Se(r, l), this.target = this.preferredSize, this.s = a, this.effectiveSize = new Se, this.addEventListener("change", () => this.updateEffectiveSize()), this.updateEffectiveSize()
        }
        updateEffectiveSize() {
            const n = this.baseSize,
                r = this.preferredSize,
                l = this.effectiveSize,
                a = this.scale;
            r.width !== Yt ? l.width = r.width : r.height !== Yt ? l.width = Math.round(r.height * (n.width / Math.max(n.height, 1))) : l.width = Math.round(n.width * a), r.height !== Yt ? l.height = r.height : r.width !== Yt ? l.height = Math.round(r.width / Math.max(n.width / Math.max(n.height, 1), 1)) : l.height = Math.round(n.height * a)
        }
        get width() {
            return this.effectiveSize.width
        }
        set width(n) {
            this.preferredWidth = n
        }
        get height() {
            return this.effectiveSize.height
        }
        set height(n) {
            this.preferredHeight = n
        }
        getWidth() {
            return this.width
        }
        getHeight() {
            return this.height
        }
        get scale() {
            return this.s
        }
        set scale(n) {
            this.s !== n && (this.s = n, this.preferredSize.setScalar(Yt), this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        getScale() {
            return this.scale
        }
        setScale(n) {
            this.scale = n
        }
        get baseWidth() {
            return this.baseSize.width
        }
        set baseWidth(n) {
            this.baseSize.width !== n && (this.baseSize.width = n, this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        getBaseWidth() {
            return this.baseWidth
        }
        setBaseWidth(n) {
            this.baseWidth = n
        }
        get baseHeight() {
            return this.baseSize.height
        }
        set baseHeight(n) {
            this.baseSize.height !== n && (this.baseSize.height = n, this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        getBaseHeight() {
            return this.baseHeight
        }
        setBaseHeight(n) {
            this.baseHeight = n
        }
        setBaseSize(n, r) {
            (this.baseSize.width !== n || this.baseSize.height !== r) && (this.baseSize.set(n, r), this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        get preferredWidth() {
            return this.preferredSize.width
        }
        set preferredWidth(n) {
            this.preferredSize.width !== n && (this.preferredSize.width = n, this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        getPreferredWidth() {
            return this.preferredWidth
        }
        setPreferredWidth(n) {
            this.preferredWidth = n
        }
        get preferredHeight() {
            return this.preferredSize.height
        }
        set preferredHeight(n) {
            this.preferredSize.height !== n && (this.preferredSize.height = n, this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        getPreferredHeight() {
            return this.preferredHeight
        }
        setPreferredHeight(n) {
            this.preferredHeight = n
        }
        setPreferredSize(n, r) {
            (this.preferredSize.width !== n || this.preferredSize.height !== r) && (this.preferredSize.set(n, r), this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height))
        }
        copy(n) {
            this.s = n.scale, this.baseSize.set(n.baseWidth, n.baseHeight), this.preferredSize.set(n.preferredWidth, n.preferredHeight), this.dispatchEvent({
                type: "change"
            }), this.resizable.setSize(this.baseSize.width, this.baseSize.height)
        }
        static get AUTO_SIZE() {
            return Yt
        }
    },
    ah = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,x+y,opacity);}",
    uh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,y,min(y.a,opacity));}",
    ch = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,(x+y)*0.5,opacity);}",
    fh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec3 xHSL=RGBToHSL(x.rgb);vec3 yHSL=RGBToHSL(y.rgb);vec3 z=HSLToRGB(vec3(yHSL.rg,xHSL.b));return vec4(mix(x.rgb,z,opacity),y.a);}",
    dh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 z=mix(step(0.0,y)*(1.0-min(vec4(1.0),(1.0-x)/y)),vec4(1.0),step(1.0,x));return mix(x,z,opacity);}",
    hh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 z=step(0.0,x)*mix(min(vec4(1.0),x/max(1.0-y,1e-9)),vec4(1.0),step(1.0,y));return mix(x,z,opacity);}",
    ph = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,min(x,y),opacity);}",
    vh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,abs(x-y),opacity);}",
    mh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,x/max(y,1e-12),opacity);}",
    gh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,(x+y-2.0*x*y),opacity);}",
    yh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 a=min(x,1.0),b=min(y,1.0);vec4 z=mix(2.0*a*b,1.0-2.0*(1.0-a)*(1.0-b),step(0.5,y));return mix(x,z,opacity);}",
    Sh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,step(1.0,x+y),opacity);}",
    xh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec3 xHSL=RGBToHSL(x.rgb);vec3 yHSL=RGBToHSL(y.rgb);vec3 z=HSLToRGB(vec3(yHSL.r,xHSL.gb));return vec4(mix(x.rgb,z,opacity),y.a);}",
    Eh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,1.0-y,opacity);}",
    _h = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,y*(1.0-x),opacity);}",
    wh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,max(x,y),opacity);}",
    Th = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,clamp(y+x-1.0,0.0,1.0),opacity);}",
    Mh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,min(x+y,1.0),opacity);}",
    Rh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,clamp(2.0*y+x-1.0,0.0,1.0),opacity);}",
    Ph = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec3 xHSL=RGBToHSL(x.rgb);vec3 yHSL=RGBToHSL(y.rgb);vec3 z=HSLToRGB(vec3(xHSL.rg,yHSL.b));return vec4(mix(x.rgb,z,opacity),y.a);}",
    Ch = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,x*y,opacity);}",
    Uh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,1.0-abs(1.0-x-y),opacity);}",
    Lh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,y,opacity);}",
    Dh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 z=mix(2.0*y*x,1.0-2.0*(1.0-y)*(1.0-x),step(0.5,x));return mix(x,z,opacity);}",
    Ih = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 y2=2.0*y;vec4 z=mix(mix(y2,x,step(0.5*x,y)),max(vec4(0.0),y2-1.0),step(x,(y2-1.0)));return mix(x,z,opacity);}",
    zh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 z=mix(min(x*x/max(1.0-y,1e-12),1.0),y,step(1.0,y));return mix(x,z,opacity);}",
    Ah = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec3 xHSL=RGBToHSL(x.rgb);vec3 yHSL=RGBToHSL(y.rgb);vec3 z=HSLToRGB(vec3(xHSL.r,yHSL.g,xHSL.b));return vec4(mix(x.rgb,z,opacity),y.a);}",
    Bh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,x+y-min(x*y,1.0),opacity);}",
    Nh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 y2=2.0*y;vec4 w=step(0.5,y);vec4 z=mix(x-(1.0-y2)*x*(1.0-x),mix(x+(y2-1.0)*(sqrt(x)-x),x+(y2-1.0)*x*((16.0*x-12.0)*x+3.0),w*(1.0-step(0.25,x))),w);return mix(x,z,opacity);}",
    Oh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return y;}",
    kh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){return mix(x,max(x+y-1.0,0.0),opacity);}",
    Fh = "vec4 blend(const in vec4 x,const in vec4 y,const in float opacity){vec4 z=mix(max(1.0-min((1.0-x)/(2.0*y),1.0),0.0),min(x/(2.0*(1.0-y)),1.0),step(0.5,y));return mix(x,z,opacity);}",
    Hh = new Map([
        [ie.ADD, ah],
        [ie.ALPHA, uh],
        [ie.AVERAGE, ch],
        [ie.COLOR, fh],
        [ie.COLOR_BURN, dh],
        [ie.COLOR_DODGE, hh],
        [ie.DARKEN, ph],
        [ie.DIFFERENCE, vh],
        [ie.DIVIDE, mh],
        [ie.DST, null],
        [ie.EXCLUSION, gh],
        [ie.HARD_LIGHT, yh],
        [ie.HARD_MIX, Sh],
        [ie.HUE, xh],
        [ie.INVERT, Eh],
        [ie.INVERT_RGB, _h],
        [ie.LIGHTEN, wh],
        [ie.LINEAR_BURN, Th],
        [ie.LINEAR_DODGE, Mh],
        [ie.LINEAR_LIGHT, Rh],
        [ie.LUMINOSITY, Ph],
        [ie.MULTIPLY, Ch],
        [ie.NEGATION, Uh],
        [ie.NORMAL, Lh],
        [ie.OVERLAY, Dh],
        [ie.PIN_LIGHT, Ih],
        [ie.REFLECT, zh],
        [ie.SATURATION, Ah],
        [ie.SCREEN, Bh],
        [ie.SOFT_LIGHT, Nh],
        [ie.SRC, Oh],
        [ie.SUBTRACT, kh],
        [ie.VIVID_LIGHT, Fh]
    ]),
    Gh = class extends cl {
        constructor(n, r = 1) {
            super(), this._blendFunction = n, this.opacity = new Q(r)
        }
        getOpacity() {
            return this.opacity.value
        }
        setOpacity(n) {
            this.opacity.value = n
        }
        get blendFunction() {
            return this._blendFunction
        }
        set blendFunction(n) {
            this._blendFunction = n, this.dispatchEvent({
                type: "change"
            })
        }
        getBlendFunction() {
            return this.blendFunction
        }
        setBlendFunction(n) {
            this.blendFunction = n
        }
        getShaderCode() {
            return Hh.get(this.blendFunction)
        }
    },
    $t = class extends cl {
        constructor(n, r, {
            attributes: l = Pt.NONE,
            blendFunction: a = ie.NORMAL,
            defines: c = new Map,
            uniforms: d = new Map,
            extensions: f = null,
            vertexShader: g = null
        } = {}) {
            super(), this.name = n, this.renderer = null, this.attributes = l, this.fragmentShader = r, this.vertexShader = g, this.defines = c, this.uniforms = d, this.extensions = f, this.blendMode = new Gh(a), this.blendMode.addEventListener("change", h => this.setChanged()), this._inputColorSpace = An, this._outputColorSpace = uu
        }
        get inputColorSpace() {
            return this._inputColorSpace
        }
        set inputColorSpace(n) {
            this._inputColorSpace = n, this.setChanged()
        }
        get outputColorSpace() {
            return this._outputColorSpace
        }
        set outputColorSpace(n) {
            this._outputColorSpace = n, this.setChanged()
        }
        set mainScene(n) {}
        set mainCamera(n) {}
        getName() {
            return this.name
        }
        setRenderer(n) {
            this.renderer = n
        }
        getDefines() {
            return this.defines
        }
        getUniforms() {
            return this.uniforms
        }
        getExtensions() {
            return this.extensions
        }
        getBlendMode() {
            return this.blendMode
        }
        getAttributes() {
            return this.attributes
        }
        setAttributes(n) {
            this.attributes = n, this.setChanged()
        }
        getFragmentShader() {
            return this.fragmentShader
        }
        setFragmentShader(n) {
            this.fragmentShader = n, this.setChanged()
        }
        getVertexShader() {
            return this.vertexShader
        }
        setVertexShader(n) {
            this.vertexShader = n, this.setChanged()
        }
        setChanged() {
            this.dispatchEvent({
                type: "change"
            })
        }
        setDepthTexture(n, r = On) {}
        update(n, r, l) {}
        setSize(n, r) {}
        initialize(n, r, l) {}
        dispose() {
            for (const n of Object.keys(this)) {
                const r = this[n];
                (r instanceof rt || r instanceof fl || r instanceof dl || r instanceof qe) && this[n].dispose()
            }
        }
    },
    jh = `#ifdef FRAMEBUFFER_PRECISION_HIGH
uniform mediump sampler2D map;
#else
uniform lowp sampler2D map;
#endif
uniform float intensity;void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){vec4 texel=texture2D(map,uv);outputColor=vec4(texel.rgb*intensity,texel.a);}`,
    bh = class extends $t {
        constructor({
            blendFunction: n = ie.SCREEN,
            luminanceThreshold: r = .9,
            luminanceSmoothing: l = .025,
            mipmapBlur: a = !1,
            intensity: c = 1,
            radius: d = .85,
            levels: f = 8,
            kernelSize: g = yl.LARGE,
            resolutionScale: h = .5,
            width: y = be.AUTO_SIZE,
            height: v = be.AUTO_SIZE,
            resolutionX: p = y,
            resolutionY: S = v
        } = {}) {
            super("BloomEffect", jh, {
                blendFunction: n,
                uniforms: new Map([
                    ["map", new Q(null)],
                    ["intensity", new Q(c)]
                ])
            }), this.renderTarget = new rt(1, 1, {
                depthBuffer: !1
            }), this.renderTarget.texture.name = "Bloom.Target", this.blurPass = new eh({
                kernelSize: g
            }), this.luminancePass = new gu({
                colorOutput: !0
            }), this.luminanceMaterial.threshold = r, this.luminanceMaterial.smoothing = l, this.mipmapBlurPass = new nh, this.mipmapBlurPass.enabled = a, this.mipmapBlurPass.radius = d, this.mipmapBlurPass.levels = f, this.uniforms.get("map").value = a ? this.mipmapBlurPass.texture : this.renderTarget.texture;
            const x = this.resolution = new be(this, p, S, h);
            x.addEventListener("change", w => this.setSize(x.baseWidth, x.baseHeight))
        }
        get texture() {
            return this.mipmapBlurPass.enabled ? this.mipmapBlurPass.texture : this.renderTarget.texture
        }
        getTexture() {
            return this.texture
        }
        getResolution() {
            return this.resolution
        }
        getBlurPass() {
            return this.blurPass
        }
        getLuminancePass() {
            return this.luminancePass
        }
        get luminanceMaterial() {
            return this.luminancePass.fullscreenMaterial
        }
        getLuminanceMaterial() {
            return this.luminancePass.fullscreenMaterial
        }
        get width() {
            return this.resolution.width
        }
        set width(n) {
            this.resolution.preferredWidth = n
        }
        get height() {
            return this.resolution.height
        }
        set height(n) {
            this.resolution.preferredHeight = n
        }
        get dithering() {
            return this.blurPass.dithering
        }
        set dithering(n) {
            this.blurPass.dithering = n
        }
        get kernelSize() {
            return this.blurPass.kernelSize
        }
        set kernelSize(n) {
            this.blurPass.kernelSize = n
        }
        get distinction() {
            return console.warn(this.name, "distinction was removed"), 1
        }
        set distinction(n) {
            console.warn(this.name, "distinction was removed")
        }
        get intensity() {
            return this.uniforms.get("intensity").value
        }
        set intensity(n) {
            this.uniforms.get("intensity").value = n
        }
        getIntensity() {
            return this.intensity
        }
        setIntensity(n) {
            this.intensity = n
        }
        getResolutionScale() {
            return this.resolution.scale
        }
        setResolutionScale(n) {
            this.resolution.scale = n
        }
        update(n, r, l) {
            const a = this.renderTarget,
                c = this.luminancePass;
            c.enabled ? (c.render(n, r), this.mipmapBlurPass.enabled ? this.mipmapBlurPass.render(n, c.renderTarget) : this.blurPass.render(n, c.renderTarget, a)) : this.mipmapBlurPass.enabled ? this.mipmapBlurPass.render(n, r) : this.blurPass.render(n, r, a)
        }
        setSize(n, r) {
            const l = this.resolution;
            l.setBaseSize(n, r), this.renderTarget.setSize(l.width, l.height), this.blurPass.resolution.copy(l), this.luminancePass.setSize(n, r), this.mipmapBlurPass.setSize(n, r)
        }
        initialize(n, r, l) {
            this.blurPass.initialize(n, r, l), this.luminancePass.initialize(n, r, l), this.mipmapBlurPass.initialize(n, r, l), l !== void 0 && (this.renderTarget.texture.type = l, Bn(n) === Ie && yt(this.renderTarget.texture, Ie))
        }
    };

function Ca(n, r, l) {
    const a = document.createElement("canvas"),
        c = a.getContext("2d");
    if (a.width = n, a.height = r, l instanceof Image) c.drawImage(l, 0, 0);
    else {
        const d = c.createImageData(n, r);
        d.data.set(l), c.putImageData(d, 0, 0)
    }
    return a
}
var Vh = class yu {
        constructor(r = 0, l = 0, a = null) {
            this.width = r, this.height = l, this.data = a
        }
        toCanvas() {
            return typeof document > "u" ? null : Ca(this.width, this.height, this.data)
        }
        static from(r) {
            const {
                width: l,
                height: a
            } = r;
            let c;
            if (r instanceof Image) {
                const d = Ca(l, a, r);
                d !== null && (c = d.getContext("2d").getImageData(0, 0, l, a).data)
            } else c = r.data;
            return new yu(l, a, c)
        }
    },
    Wh = `"use strict";(()=>{var O={SCALE_UP:"lut.scaleup"};var _=[new Float32Array(3),new Float32Array(3)],n=[new Float32Array(3),new Float32Array(3),new Float32Array(3),new Float32Array(3)],Z=[[new Float32Array([0,0,0]),new Float32Array([1,0,0]),new Float32Array([1,1,0]),new Float32Array([1,1,1])],[new Float32Array([0,0,0]),new Float32Array([1,0,0]),new Float32Array([1,0,1]),new Float32Array([1,1,1])],[new Float32Array([0,0,0]),new Float32Array([0,0,1]),new Float32Array([1,0,1]),new Float32Array([1,1,1])],[new Float32Array([0,0,0]),new Float32Array([0,1,0]),new Float32Array([1,1,0]),new Float32Array([1,1,1])],[new Float32Array([0,0,0]),new Float32Array([0,1,0]),new Float32Array([0,1,1]),new Float32Array([1,1,1])],[new Float32Array([0,0,0]),new Float32Array([0,0,1]),new Float32Array([0,1,1]),new Float32Array([1,1,1])]];function d(a,t,r,m){let i=r[0]-t[0],e=r[1]-t[1],y=r[2]-t[2],h=a[0]-t[0],A=a[1]-t[1],w=a[2]-t[2],c=e*w-y*A,l=y*h-i*w,x=i*A-e*h,u=Math.sqrt(c*c+l*l+x*x),b=u*.5,s=c/u,F=l/u,f=x/u,p=-(a[0]*s+a[1]*F+a[2]*f),M=m[0]*s+m[1]*F+m[2]*f;return Math.abs(M+p)*b/3}function V(a,t,r,m,i,e){let y=(r+m*t+i*t*t)*4;e[0]=a[y+0],e[1]=a[y+1],e[2]=a[y+2]}function k(a,t,r,m,i,e){let y=r*(t-1),h=m*(t-1),A=i*(t-1),w=Math.floor(y),c=Math.floor(h),l=Math.floor(A),x=Math.ceil(y),u=Math.ceil(h),b=Math.ceil(A),s=y-w,F=h-c,f=A-l;if(w===y&&c===h&&l===A)V(a,t,y,h,A,e);else{let p;s>=F&&F>=f?p=Z[0]:s>=f&&f>=F?p=Z[1]:f>=s&&s>=F?p=Z[2]:F>=s&&s>=f?p=Z[3]:F>=f&&f>=s?p=Z[4]:f>=F&&F>=s&&(p=Z[5]);let[M,g,X,Y]=p,P=_[0];P[0]=s,P[1]=F,P[2]=f;let o=_[1],L=x-w,S=u-c,U=b-l;o[0]=L*M[0]+w,o[1]=S*M[1]+c,o[2]=U*M[2]+l,V(a,t,o[0],o[1],o[2],n[0]),o[0]=L*g[0]+w,o[1]=S*g[1]+c,o[2]=U*g[2]+l,V(a,t,o[0],o[1],o[2],n[1]),o[0]=L*X[0]+w,o[1]=S*X[1]+c,o[2]=U*X[2]+l,V(a,t,o[0],o[1],o[2],n[2]),o[0]=L*Y[0]+w,o[1]=S*Y[1]+c,o[2]=U*Y[2]+l,V(a,t,o[0],o[1],o[2],n[3]);let T=d(g,X,Y,P)*6,q=d(M,X,Y,P)*6,C=d(M,g,Y,P)*6,E=d(M,g,X,P)*6;n[0][0]*=T,n[0][1]*=T,n[0][2]*=T,n[1][0]*=q,n[1][1]*=q,n[1][2]*=q,n[2][0]*=C,n[2][1]*=C,n[2][2]*=C,n[3][0]*=E,n[3][1]*=E,n[3][2]*=E,e[0]=n[0][0]+n[1][0]+n[2][0]+n[3][0],e[1]=n[0][1]+n[1][1]+n[2][1]+n[3][1],e[2]=n[0][2]+n[1][2]+n[2][2]+n[3][2]}}var v=class{static expand(t,r){let m=Math.cbrt(t.length/4),i=new Float32Array(3),e=new t.constructor(r**3*4),y=t instanceof Uint8Array?255:1,h=r**2,A=1/(r-1);for(let w=0;w<r;++w)for(let c=0;c<r;++c)for(let l=0;l<r;++l){let x=l*A,u=c*A,b=w*A,s=Math.round(l+c*r+w*h)*4;k(t,m,x,u,b,i),e[s+0]=i[0],e[s+1]=i[1],e[s+2]=i[2],e[s+3]=y}return e}};self.addEventListener("message",a=>{let t=a.data,r=t.data;switch(t.operation){case O.SCALE_UP:r=v.expand(r,t.size);break}postMessage(r,[r.buffer]),close()});})();
`,
    Ua = new yr,
    Su = class _i extends xi {
        constructor(r, l) {
            super(r, l, l, l), this.type = Nt, this.format = Ei, this.minFilter = ht, this.magFilter = ht, this.wrapS = js, this.wrapT = js, this.wrapR = js, this.unpackAlignment = 1, this.needsUpdate = !0, yt(this, An), this.domainMin = new Ne(0, 0, 0), this.domainMax = new Ne(1, 1, 1)
        }
        get isLookupTexture3D() {
            return !0
        }
        scaleUp(r, l = !0) {
            const a = this.image;
            let c;
            return r <= a.width ? c = Promise.reject(new Error("The target size must be greater than the current size")) : c = new Promise((d, f) => {
                const g = URL.createObjectURL(new Blob([Wh], {
                        type: "text/javascript"
                    })),
                    h = new Worker(g);
                h.addEventListener("error", v => f(v.error)), h.addEventListener("message", v => {
                    const p = new _i(v.data, r);
                    Ws(this, p), p.type = this.type, p.name = this.name, URL.revokeObjectURL(g), d(p)
                });
                const y = l ? [a.data.buffer] : [];
                h.postMessage({
                    operation: Rd.SCALE_UP,
                    data: a.data,
                    size: r
                }, y)
            }), c
        }
        applyLUT(r) {
            const l = this.image,
                a = r.image,
                c = Math.min(l.width, l.height, l.depth),
                d = Math.min(a.width, a.height, a.depth);
            if (c !== d) console.error("Size mismatch");
            else if (r.type !== Nt || this.type !== Nt) console.error("Both LUTs must be FloatType textures");
            else if (r.format !== Ei || this.format !== Ei) console.error("Both LUTs must be RGBA textures");
            else {
                const f = l.data,
                    g = a.data,
                    h = c,
                    y = h ** 2,
                    v = h - 1;
                for (let p = 0, S = h ** 3; p < S; ++p) {
                    const x = p * 4,
                        w = f[x + 0] * v,
                        z = f[x + 1] * v,
                        I = f[x + 2] * v,
                        C = Math.round(w + z * h + I * y) * 4;
                    f[x + 0] = g[C + 0], f[x + 1] = g[C + 1], f[x + 2] = g[C + 2]
                }
                this.needsUpdate = !0
            }
            return this
        }
        convertToUint8() {
            if (this.type === Nt) {
                const r = this.image.data,
                    l = new Uint8Array(r.length);
                for (let a = 0, c = r.length; a < c; ++a) l[a] = r[a] * 255 + .5;
                this.image.data = l, this.type = Ct, this.needsUpdate = !0
            }
            return this
        }
        convertToFloat() {
            if (this.type === Ct) {
                const r = this.image.data,
                    l = new Float32Array(r.length);
                for (let a = 0, c = r.length; a < c; ++a) l[a] = r[a] / 255;
                this.image.data = l, this.type = Nt, this.needsUpdate = !0
            }
            return this
        }
        convertToRGBA() {
            return console.warn("LookupTexture", "convertToRGBA() is deprecated, LUTs are now RGBA by default"), this
        }
        convertLinearToSRGB() {
            const r = this.image.data;
            if (this.type === Nt) {
                for (let l = 0, a = r.length; l < a; l += 4) Ua.fromArray(r, l).convertLinearToSRGB().toArray(r, l);
                yt(this, Ie), this.needsUpdate = !0
            } else console.error("Color space conversion requires FloatType data");
            return this
        }
        convertSRGBToLinear() {
            const r = this.image.data;
            if (this.type === Nt) {
                for (let l = 0, a = r.length; l < a; l += 4) Ua.fromArray(r, l).convertSRGBToLinear().toArray(r, l);
                yt(this, An), this.needsUpdate = !0
            } else console.error("Color space conversion requires FloatType data");
            return this
        }
        toDataTexture() {
            const r = this.image.width,
                l = this.image.height * this.image.depth,
                a = new Xf(this.image.data, r, l);
            return a.name = this.name, a.type = this.type, a.format = this.format, a.minFilter = ht, a.magFilter = ht, a.wrapS = this.wrapS, a.wrapT = this.wrapT, a.generateMipmaps = !1, a.needsUpdate = !0, Ws(this, a), a
        }
        static from(r) {
            const l = r.image,
                {
                    width: a,
                    height: c
                } = l,
                d = Math.min(a, c);
            let f;
            if (l instanceof Image) {
                const y = Vh.from(l).data;
                if (a > c) {
                    f = new Uint8Array(y.length);
                    for (let v = 0; v < d; ++v)
                        for (let p = 0; p < d; ++p)
                            for (let S = 0; S < d; ++S) {
                                const x = (S + v * d + p * d * d) * 4,
                                    w = (S + p * d + v * d * d) * 4;
                                f[w + 0] = y[x + 0], f[w + 1] = y[x + 1], f[w + 2] = y[x + 2], f[w + 3] = y[x + 3]
                            }
                } else f = new Uint8Array(y.buffer)
            } else f = l.data.slice();
            const g = new _i(f, d);
            return g.type = r.type, g.name = r.name, Ws(r, g), g
        }
        static createNeutral(r) {
            const l = new Float32Array(r ** 3 * 4),
                a = r ** 2,
                c = 1 / (r - 1);
            for (let f = 0; f < r; ++f)
                for (let g = 0; g < r; ++g)
                    for (let h = 0; h < r; ++h) {
                        const y = (f + g * r + h * a) * 4;
                        l[y + 0] = f * c, l[y + 1] = g * c, l[y + 2] = h * c, l[y + 3] = 1
                    }
            const d = new _i(l, r);
            return d.name = "neutral", d
        }
    },
    Qh = "uniform vec3 hue;uniform float saturation;void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){vec3 color=vec3(dot(inputColor.rgb,hue.xyz),dot(inputColor.rgb,hue.zxy),dot(inputColor.rgb,hue.yzx));float average=(color.r+color.g+color.b)/3.0;vec3 diff=average-color;if(saturation>0.0){color+=diff*(1.0-1.0/(1.001-saturation));}else{color+=diff*-saturation;}outputColor=vec4(min(color,1.0),inputColor.a);}",
    Xh = class extends $t {
        constructor({
            blendFunction: n = ie.SRC,
            hue: r = 0,
            saturation: l = 0
        } = {}) {
            super("HueSaturationEffect", Qh, {
                blendFunction: n,
                uniforms: new Map([
                    ["hue", new Q(new Ne)],
                    ["saturation", new Q(l)]
                ])
            }), this.hue = r
        }
        get saturation() {
            return this.uniforms.get("saturation").value
        }
        set saturation(n) {
            this.uniforms.get("saturation").value = n
        }
        getSaturation() {
            return this.saturation
        }
        setSaturation(n) {
            this.saturation = n
        }
        get hue() {
            const n = this.uniforms.get("hue").value;
            return Math.acos((n.x * 3 - 1) / 2)
        }
        set hue(n) {
            const r = Math.sin(n),
                l = Math.cos(n);
            this.uniforms.get("hue").value.set((2 * l + 1) / 3, (-Math.sqrt(3) * r - l + 1) / 3, (Math.sqrt(3) * r - l + 1) / 3)
        }
        getHue() {
            return this.hue
        }
        setHue(n) {
            this.hue = n
        }
    },
    Kh = `uniform vec3 scale;uniform vec3 offset;
#ifdef CUSTOM_INPUT_DOMAIN
uniform vec3 domainMin;uniform vec3 domainMax;
#endif
#ifdef LUT_3D
#ifdef LUT_PRECISION_HIGH
#ifdef GL_FRAGMENT_PRECISION_HIGH
uniform highp sampler3D lut;
#else
uniform mediump sampler3D lut;
#endif
#else
uniform lowp sampler3D lut;
#endif
vec4 applyLUT(const in vec3 rgb){
#ifdef TETRAHEDRAL_INTERPOLATION
vec3 p=floor(rgb);vec3 f=rgb-p;vec3 v1=(p+0.5)*LUT_TEXEL_WIDTH;vec3 v4=(p+1.5)*LUT_TEXEL_WIDTH;vec3 v2,v3;vec3 frac;if(f.r>=f.g){if(f.g>f.b){frac=f.rgb;v2=vec3(v4.x,v1.y,v1.z);v3=vec3(v4.x,v4.y,v1.z);}else if(f.r>=f.b){frac=f.rbg;v2=vec3(v4.x,v1.y,v1.z);v3=vec3(v4.x,v1.y,v4.z);}else{frac=f.brg;v2=vec3(v1.x,v1.y,v4.z);v3=vec3(v4.x,v1.y,v4.z);}}else{if(f.b>f.g){frac=f.bgr;v2=vec3(v1.x,v1.y,v4.z);v3=vec3(v1.x,v4.y,v4.z);}else if(f.r>=f.b){frac=f.grb;v2=vec3(v1.x,v4.y,v1.z);v3=vec3(v4.x,v4.y,v1.z);}else{frac=f.gbr;v2=vec3(v1.x,v4.y,v1.z);v3=vec3(v1.x,v4.y,v4.z);}}vec4 n1=texture(lut,v1);vec4 n2=texture(lut,v2);vec4 n3=texture(lut,v3);vec4 n4=texture(lut,v4);vec4 weights=vec4(1.0-frac.x,frac.x-frac.y,frac.y-frac.z,frac.z);vec4 result=weights*mat4(vec4(n1.r,n2.r,n3.r,n4.r),vec4(n1.g,n2.g,n3.g,n4.g),vec4(n1.b,n2.b,n3.b,n4.b),vec4(1.0));return vec4(result.rgb,1.0);
#else
return texture(lut,rgb);
#endif
}
#else
#ifdef LUT_PRECISION_HIGH
#ifdef GL_FRAGMENT_PRECISION_HIGH
uniform highp sampler2D lut;
#else
uniform mediump sampler2D lut;
#endif
#else
uniform lowp sampler2D lut;
#endif
vec4 applyLUT(const in vec3 rgb){float slice=rgb.b*LUT_SIZE;float slice0=floor(slice);float interp=slice-slice0;float centeredInterp=interp-0.5;float slice1=slice0+sign(centeredInterp);
#ifdef LUT_STRIP_HORIZONTAL
float xOffset=clamp(rgb.r*LUT_TEXEL_HEIGHT,LUT_TEXEL_WIDTH*0.5,LUT_TEXEL_HEIGHT-LUT_TEXEL_WIDTH*0.5);vec2 uv0=vec2(slice0*LUT_TEXEL_HEIGHT+xOffset,rgb.g);vec2 uv1=vec2(slice1*LUT_TEXEL_HEIGHT+xOffset,rgb.g);
#else
float yOffset=clamp(rgb.g*LUT_TEXEL_WIDTH,LUT_TEXEL_HEIGHT*0.5,LUT_TEXEL_WIDTH-LUT_TEXEL_HEIGHT*0.5);vec2 uv0=vec2(rgb.r,slice0*LUT_TEXEL_WIDTH+yOffset);vec2 uv1=vec2(rgb.r,slice1*LUT_TEXEL_WIDTH+yOffset);
#endif
vec4 sample0=texture2D(lut,uv0);vec4 sample1=texture2D(lut,uv1);return mix(sample0,sample1,abs(centeredInterp));}
#endif
void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){vec3 c=inputColor.rgb;
#ifdef CUSTOM_INPUT_DOMAIN
if(c.r>=domainMin.r&&c.g>=domainMin.g&&c.b>=domainMin.b&&c.r<=domainMax.r&&c.g<=domainMax.g&&c.b<=domainMax.b){c=applyLUT(scale*c+offset).rgb;}else{c=inputColor.rgb;}
#else
#if !defined(LUT_3D) || defined(TETRAHEDRAL_INTERPOLATION)
c=clamp(c,0.0,1.0);
#endif
c=applyLUT(scale*c+offset).rgb;
#endif
outputColor=vec4(c,inputColor.a);}`,
    Yh = class extends $t {
        constructor(n, {
            blendFunction: r = ie.SRC,
            tetrahedralInterpolation: l = !1,
            inputEncoding: a = hl,
            inputColorSpace: c
        } = {}) {
            super("LUT3DEffect", Kh, {
                blendFunction: r,
                uniforms: new Map([
                    ["lut", new Q(null)],
                    ["scale", new Q(new Ne)],
                    ["offset", new Q(new Ne)],
                    ["domainMin", new Q(null)],
                    ["domainMax", new Q(null)]
                ])
            }), this.tetrahedralInterpolation = l, this.inputColorSpace = c || fu.get(a), this.lut = n
        }
        get inputEncoding() {
            return this.inputColorSpace
        }
        set inputEncoding(n) {
            this.inputColorSpace = n
        }
        getInputEncoding() {
            return this.inputColorSpace
        }
        setInputEncoding(n) {
            this.inputColorSpace = n
        }
        getOutputEncoding() {
            return this.outputColorSpace
        }
        get lut() {
            return this.uniforms.get("lut").value
        }
        set lut(n) {
            const r = this.defines,
                l = this.uniforms;
            if (this.lut !== n && (l.get("lut").value = n, n !== null)) {
                const a = n.image,
                    c = this.tetrahedralInterpolation;
                if (r.clear(), r.set("LUT_SIZE", Math.min(a.width, a.height).toFixed(16)), r.set("LUT_TEXEL_WIDTH", (1 / a.width).toFixed(16)), r.set("LUT_TEXEL_HEIGHT", (1 / a.height).toFixed(16)), l.get("domainMin").value = null, l.get("domainMax").value = null, (n.type === Nt || n.type === pl) && r.set("LUT_PRECISION_HIGH", "1"), a.width > a.height ? r.set("LUT_STRIP_HORIZONTAL", "1") : n instanceof xi && r.set("LUT_3D", "1"), n instanceof Su) {
                    const d = n.domainMin,
                        f = n.domainMax;
                    (d.x !== 0 || d.y !== 0 || d.z !== 0 || f.x !== 1 || f.y !== 1 || f.z !== 1) && (r.set("CUSTOM_INPUT_DOMAIN", "1"), l.get("domainMin").value = d.clone(), l.get("domainMax").value = f.clone())
                }
                this.tetrahedralInterpolation = c
            }
        }
        getLUT() {
            return this.lut
        }
        setLUT(n) {
            this.lut = n
        }
        updateScaleOffset() {
            const n = this.lut;
            if (n !== null) {
                const r = Math.min(n.image.width, n.image.height),
                    l = this.uniforms.get("scale").value,
                    a = this.uniforms.get("offset").value;
                if (this.tetrahedralInterpolation && n instanceof xi)
                    if (this.defines.has("CUSTOM_INPUT_DOMAIN")) {
                        const c = n.domainMax.clone().sub(n.domainMin);
                        l.setScalar(r - 1).divide(c), a.copy(n.domainMin).negate().multiply(l)
                    } else l.setScalar(r - 1), a.setScalar(0);
                else if (this.defines.has("CUSTOM_INPUT_DOMAIN")) {
                    const c = n.domainMax.clone().sub(n.domainMin).multiplyScalar(r);
                    l.setScalar(r - 1).divide(c), a.copy(n.domainMin).negate().multiply(l).addScalar(1 / (2 * r))
                } else l.setScalar((r - 1) / r), a.setScalar(1 / (2 * r))
            }
        }
        configureTetrahedralInterpolation() {
            const n = this.lut;
            n !== null && (n.minFilter = ht, n.magFilter = ht, this.tetrahedralInterpolation && (n instanceof xi ? (n.minFilter = Jt, n.magFilter = Jt) : console.warn("Tetrahedral interpolation requires a 3D texture")), n.source === void 0 && (n.needsUpdate = !0))
        }
        get tetrahedralInterpolation() {
            return this.defines.has("TETRAHEDRAL_INTERPOLATION")
        }
        set tetrahedralInterpolation(n) {
            n ? this.defines.set("TETRAHEDRAL_INTERPOLATION", "1") : this.defines.delete("TETRAHEDRAL_INTERPOLATION"), this.configureTetrahedralInterpolation(), this.updateScaleOffset(), this.setChanged()
        }
        setTetrahedralInterpolationEnabled(n) {
            this.tetrahedralInterpolation = n
        }
    },
    Zh = `void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){vec3 noise=vec3(rand(uv*(1.0+time)));
#ifdef PREMULTIPLY
outputColor=vec4(min(inputColor.rgb*noise,vec3(1.0)),inputColor.a);
#else
outputColor=vec4(noise,inputColor.a);
#endif
}`,
    qh = class extends $t {
        constructor({
            blendFunction: n = ie.SCREEN,
            premultiply: r = !1
        } = {}) {
            super("NoiseEffect", Zh, {
                blendFunction: n
            }), this.premultiply = r
        }
        get premultiply() {
            return this.defines.has("PREMULTIPLY")
        }
        set premultiply(n) {
            this.premultiply !== n && (n ? this.defines.set("PREMULTIPLY", "1") : this.defines.delete("PREMULTIPLY"), this.setChanged())
        }
        isPremultiplied() {
            return this.premultiply
        }
        setPremultiplied(n) {
            this.premultiply = n
        }
    },
    Jh = `#include <tonemapping_pars_fragment>
#if THREE_REVISION < 143
#define luminance(v) linearToRelativeLuminance(v)
#endif
uniform float whitePoint;
#if TONE_MAPPING_MODE == 1 || TONE_MAPPING_MODE == 2
uniform float middleGrey;
#if TONE_MAPPING_MODE == 2
uniform lowp sampler2D luminanceBuffer;
#else
uniform float averageLuminance;
#endif
vec3 Reinhard2ToneMapping(vec3 color){color*=toneMappingExposure;float l=luminance(color);
#if TONE_MAPPING_MODE == 2
float lumAvg=unpackRGBAToFloat(texture2D(luminanceBuffer,vec2(0.5)));
#else
float lumAvg=averageLuminance;
#endif
float lumScaled=(l*middleGrey)/max(lumAvg,1e-6);float lumCompressed=lumScaled*(1.0+lumScaled/(whitePoint*whitePoint));lumCompressed/=(1.0+lumScaled);return clamp(lumCompressed*color,0.0,1.0);}
#elif TONE_MAPPING_MODE == 5
#define A 0.15
#define B 0.50
#define C 0.10
#define D 0.20
#define E 0.02
#define F 0.30
vec3 Uncharted2Helper(const in vec3 x){return((x*(A*x+C*B)+D*E)/(x*(A*x+B)+D*F))-E/F;}vec3 Uncharted2ToneMapping(vec3 color){color*=toneMappingExposure;return clamp(Uncharted2Helper(color)/Uncharted2Helper(vec3(whitePoint)),0.0,1.0);}
#endif
void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){
#if TONE_MAPPING_MODE == 1 || TONE_MAPPING_MODE == 2
outputColor=vec4(Reinhard2ToneMapping(inputColor.rgb),inputColor.a);
#elif TONE_MAPPING_MODE == 5
outputColor=vec4(Uncharted2ToneMapping(inputColor.rgb),inputColor.a);
#else
outputColor=vec4(toneMapping(inputColor.rgb),inputColor.a);
#endif
}`,
    $h = class extends $t {
        constructor({
            blendFunction: n = ie.SRC,
            adaptive: r = !1,
            mode: l = r ? Bt.REINHARD2_ADAPTIVE : Bt.ACES_FILMIC,
            resolution: a = 256,
            maxLuminance: c = 4,
            whitePoint: d = c,
            middleGrey: f = .6,
            minLuminance: g = .01,
            averageLuminance: h = 1,
            adaptationRate: y = 1
        } = {}) {
            super("ToneMappingEffect", Jh, {
                blendFunction: n,
                uniforms: new Map([
                    ["luminanceBuffer", new Q(null)],
                    ["maxLuminance", new Q(c)],
                    ["whitePoint", new Q(d)],
                    ["middleGrey", new Q(f)],
                    ["averageLuminance", new Q(h)]
                ])
            }), this.renderTargetLuminance = new rt(1, 1, {
                minFilter: Qf,
                depthBuffer: !1
            }), this.renderTargetLuminance.texture.generateMipmaps = !0, this.renderTargetLuminance.texture.name = "Luminance", this.luminancePass = new gu({
                renderTarget: this.renderTargetLuminance
            }), this.adaptiveLuminancePass = new Yd(this.luminancePass.texture, {
                minLuminance: g,
                adaptationRate: y
            }), this.uniforms.get("luminanceBuffer").value = this.adaptiveLuminancePass.texture, this.resolution = a, this.mode = l
        }
        get mode() {
            return Number(this.defines.get("TONE_MAPPING_MODE"))
        }
        set mode(n) {
            if (this.mode !== n) {
                switch (this.defines.clear(), this.defines.set("TONE_MAPPING_MODE", n.toFixed(0)), n) {
                    case Bt.REINHARD:
                        this.defines.set("toneMapping(texel)", "ReinhardToneMapping(texel)");
                        break;
                    case Bt.OPTIMIZED_CINEON:
                        this.defines.set("toneMapping(texel)", "OptimizedCineonToneMapping(texel)");
                        break;
                    case Bt.ACES_FILMIC:
                        this.defines.set("toneMapping(texel)", "ACESFilmicToneMapping(texel)");
                        break;
                    default:
                        this.defines.set("toneMapping(texel)", "texel");
                        break
                }
                this.adaptiveLuminancePass.enabled = n === Bt.REINHARD2_ADAPTIVE, this.setChanged()
            }
        }
        getMode() {
            return this.mode
        }
        setMode(n) {
            this.mode = n
        }
        get whitePoint() {
            return this.uniforms.get("whitePoint").value
        }
        set whitePoint(n) {
            this.uniforms.get("whitePoint").value = n
        }
        get middleGrey() {
            return this.uniforms.get("middleGrey").value
        }
        set middleGrey(n) {
            this.uniforms.get("middleGrey").value = n
        }
        get averageLuminance() {
            return this.uniforms.get("averageLuminance").value
        }
        set averageLuminance(n) {
            this.uniforms.get("averageLuminance").value = n
        }
        get adaptiveLuminanceMaterial() {
            return this.adaptiveLuminancePass.fullscreenMaterial
        }
        getAdaptiveLuminanceMaterial() {
            return this.adaptiveLuminanceMaterial
        }
        get resolution() {
            return this.luminancePass.resolution.width
        }
        set resolution(n) {
            const r = Math.max(0, Math.ceil(Math.log2(n))),
                l = Math.pow(2, r);
            this.luminancePass.resolution.setPreferredSize(l, l), this.adaptiveLuminanceMaterial.mipLevel1x1 = r
        }
        getResolution() {
            return this.resolution
        }
        setResolution(n) {
            this.resolution = n
        }
        get adaptive() {
            return this.mode === Bt.REINHARD2_ADAPTIVE
        }
        set adaptive(n) {
            this.mode = n ? Bt.REINHARD2_ADAPTIVE : Bt.REINHARD2
        }
        get adaptationRate() {
            return this.adaptiveLuminanceMaterial.adaptationRate
        }
        set adaptationRate(n) {
            this.adaptiveLuminanceMaterial.adaptationRate = n
        }
        get distinction() {
            return console.warn(this.name, "distinction was removed."), 1
        }
        set distinction(n) {
            console.warn(this.name, "distinction was removed.")
        }
        update(n, r, l) {
            this.adaptiveLuminancePass.enabled && (this.luminancePass.render(n, r), this.adaptiveLuminancePass.render(n, null, null, l))
        }
        initialize(n, r, l) {
            this.adaptiveLuminancePass.initialize(n, r, l)
        }
    },
    ep = `uniform float offset;uniform float darkness;void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){const vec2 center=vec2(0.5);vec3 color=inputColor.rgb;
#if VIGNETTE_TECHNIQUE == 0
float d=distance(uv,center);color*=smoothstep(0.8,offset*0.799,d*(darkness+offset));
#else
vec2 coord=(uv-center)*vec2(offset);color=mix(color,vec3(1.0-darkness),dot(coord,coord));
#endif
outputColor=vec4(color,inputColor.a);}`,
    tp = class extends $t {
        constructor({
            blendFunction: n,
            technique: r = gi.DEFAULT,
            eskil: l = !1,
            offset: a = .5,
            darkness: c = .5
        } = {}) {
            super("VignetteEffect", ep, {
                blendFunction: n,
                defines: new Map([
                    ["VIGNETTE_TECHNIQUE", r.toFixed(0)]
                ]),
                uniforms: new Map([
                    ["offset", new Q(a)],
                    ["darkness", new Q(c)]
                ])
            })
        }
        get technique() {
            return Number(this.defines.get("VIGNETTE_TECHNIQUE"))
        }
        set technique(n) {
            this.technique !== n && (this.defines.set("VIGNETTE_TECHNIQUE", n.toFixed(0)), this.setChanged())
        }
        get eskil() {
            return this.technique === gi.ESKIL
        }
        set eskil(n) {
            this.technique = n ? gi.ESKIL : gi.DEFAULT
        }
        getTechnique() {
            return this.technique
        }
        setTechnique(n) {
            this.technique = n
        }
        get offset() {
            return this.uniforms.get("offset").value
        }
        set offset(n) {
            this.uniforms.get("offset").value = n
        }
        getOffset() {
            return this.offset
        }
        setOffset(n) {
            this.offset = n
        }
        get darkness() {
            return this.uniforms.get("darkness").value
        }
        set darkness(n) {
            this.uniforms.get("darkness").value = n
        }
        getDarkness() {
            return this.darkness
        }
        setDarkness(n) {
            this.darkness = n
        }
    },
    tg = class extends Kf {
        load(n, r = () => {}, l = () => {}, a = null) {
            const c = this.manager,
                d = new Yf,
                f = new Zf(d);
            return f.setPath(this.path), f.setResponseType("text"), new Promise((g, h) => {
                d.onError = y => {
                    c.itemError(y), a !== null ? (a(`Failed to load ${y}`), g()) : h(`Failed to load ${y}`)
                }, c.itemStart(n), f.load(n, y => {
                    try {
                        const v = this.parse(y);
                        c.itemEnd(n), r(v), g(v)
                    } catch (v) {
                        console.error(v), d.onError(n)
                    }
                }, l)
            })
        }
        parse(n) {
            const r = /TITLE +"([^"]*)"/,
                l = /LUT_3D_SIZE +(\d+)/,
                a = /DOMAIN_MIN +([\d.]+) +([\d.]+) +([\d.]+)/,
                c = /DOMAIN_MAX +([\d.]+) +([\d.]+) +([\d.]+)/,
                d = /^([\d.e+-]+) +([\d.e+-]+) +([\d.e+-]+) *$/gm;
            let f = r.exec(n);
            const g = f !== null ? f[1] : null;
            if (f = l.exec(n), f === null) throw new Error("Missing LUT_3D_SIZE information");
            const h = Number(f[1]),
                y = new Float32Array(h ** 3 * 4),
                v = new Ne(0, 0, 0),
                p = new Ne(1, 1, 1);
            if (f = a.exec(n), f !== null && v.set(Number(f[1]), Number(f[2]), Number(f[3])), f = c.exec(n), f !== null && p.set(Number(f[1]), Number(f[2]), Number(f[3])), v.x > p.x || v.y > p.y || v.z > p.z) throw v.set(0, 0, 0), p.set(1, 1, 1), new Error("Invalid input domain");
            let S = 0;
            for (;
                (f = d.exec(n)) !== null;) y[S++] = Number(f[1]), y[S++] = Number(f[2]), y[S++] = Number(f[3]), y[S++] = 1;
            const x = new Su(y, h);
            return x.domainMin.copy(v), x.domainMax.copy(p), g !== null && (x.name = g), x
        }
    },
    xu = {
        exports: {}
    },
    dn = {};
/**
 * @license React
 * react-reconciler-constants.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
dn.ConcurrentRoot = 1;
dn.ContinuousEventPriority = 4;
dn.DefaultEventPriority = 16;
dn.DiscreteEventPriority = 1;
dn.IdleEventPriority = 536870912;
dn.LegacyRoot = 0;
xu.exports = dn;
var zn = xu.exports;

function np(n) {
    let r;
    const l = new Set,
        a = (y, v) => {
            const p = typeof y == "function" ? y(r) : y;
            if (p !== r) {
                const S = r;
                r = v ? p : Object.assign({}, r, p), l.forEach(x => x(r, S))
            }
        },
        c = () => r,
        d = (y, v = c, p = Object.is) => {
            console.warn("[DEPRECATED] Please use `subscribeWithSelector` middleware");
            let S = v(r);

            function x() {
                const w = v(r);
                if (!p(S, w)) {
                    const z = S;
                    y(S = w, z)
                }
            }
            return l.add(x), () => l.delete(x)
        },
        h = {
            setState: a,
            getState: c,
            subscribe: (y, v, p) => v || p ? d(y, v, p) : (l.add(y), () => l.delete(y)),
            destroy: () => l.clear()
        };
    return r = n(a, c, h), h
}
const rp = typeof window > "u" || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent),
    La = rp ? P.useEffect : P.useLayoutEffect;

function Eu(n) {
    const r = typeof n == "function" ? np(n) : n,
        l = (a = r.getState, c = Object.is) => {
            const [, d] = P.useReducer(I => I + 1, 0), f = r.getState(), g = P.useRef(f), h = P.useRef(a), y = P.useRef(c), v = P.useRef(!1), p = P.useRef();
            p.current === void 0 && (p.current = a(f));
            let S, x = !1;
            (g.current !== f || h.current !== a || y.current !== c || v.current) && (S = a(f), x = !c(p.current, S)), La(() => {
                x && (p.current = S), g.current = f, h.current = a, y.current = c, v.current = !1
            });
            const w = P.useRef(f);
            La(() => {
                const I = () => {
                        try {
                            const T = r.getState(),
                                D = h.current(T);
                            y.current(p.current, D) || (g.current = T, p.current = D, d())
                        } catch {
                            v.current = !0, d()
                        }
                    },
                    C = r.subscribe(I);
                return r.getState() !== w.current && I(), C
            }, []);
            const z = x ? S : p.current;
            return P.useDebugValue(z), z
        };
    return Object.assign(l, r), l[Symbol.iterator] = function() {
        console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
        const a = [l, r];
        return {
            next() {
                const c = a.length <= 0;
                return {
                    value: a.shift(),
                    done: c
                }
            }
        }
    }, l
}
var _u = {
        exports: {}
    },
    Ks = {
        exports: {}
    },
    Ys = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Da;

function ip() {
    return Da || (Da = 1, function(n) {
        function r(M, B) {
            var N = M.length;
            M.push(B);
            e: for (; 0 < N;) {
                var W = N - 1 >>> 1,
                    K = M[W];
                if (0 < c(K, B)) M[W] = B, M[N] = K, N = W;
                else break e
            }
        }

        function l(M) {
            return M.length === 0 ? null : M[0]
        }

        function a(M) {
            if (M.length === 0) return null;
            var B = M[0],
                N = M.pop();
            if (N !== B) {
                M[0] = N;
                e: for (var W = 0, K = M.length, ue = K >>> 1; W < ue;) {
                    var ve = 2 * (W + 1) - 1,
                        ee = M[ve],
                        pe = ve + 1,
                        Re = M[pe];
                    if (0 > c(ee, N)) pe < K && 0 > c(Re, ee) ? (M[W] = Re, M[pe] = N, W = pe) : (M[W] = ee, M[ve] = N, W = ve);
                    else if (pe < K && 0 > c(Re, N)) M[W] = Re, M[pe] = N, W = pe;
                    else break e
                }
            }
            return B
        }

        function c(M, B) {
            var N = M.sortIndex - B.sortIndex;
            return N !== 0 ? N : M.id - B.id
        }
        if (typeof performance == "object" && typeof performance.now == "function") {
            var d = performance;
            n.unstable_now = function() {
                return d.now()
            }
        } else {
            var f = Date,
                g = f.now();
            n.unstable_now = function() {
                return f.now() - g
            }
        }
        var h = [],
            y = [],
            v = 1,
            p = null,
            S = 3,
            x = !1,
            w = !1,
            z = !1,
            I = typeof setTimeout == "function" ? setTimeout : null,
            C = typeof clearTimeout == "function" ? clearTimeout : null,
            T = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

        function D(M) {
            for (var B = l(y); B !== null;) {
                if (B.callback === null) a(y);
                else if (B.startTime <= M) a(y), B.sortIndex = B.expirationTime, r(h, B);
                else break;
                B = l(y)
            }
        }

        function H(M) {
            if (z = !1, D(M), !w)
                if (l(h) !== null) w = !0, ge(b);
                else {
                    var B = l(y);
                    B !== null && Ce(H, B.startTime - M)
                }
        }

        function b(M, B) {
            w = !1, z && (z = !1, C(V), V = -1), x = !0;
            var N = S;
            try {
                for (D(B), p = l(h); p !== null && (!(p.expirationTime > B) || M && !A());) {
                    var W = p.callback;
                    if (typeof W == "function") {
                        p.callback = null, S = p.priorityLevel;
                        var K = W(p.expirationTime <= B);
                        B = n.unstable_now(), typeof K == "function" ? p.callback = K : p === l(h) && a(h), D(B)
                    } else a(h);
                    p = l(h)
                }
                if (p !== null) var ue = !0;
                else {
                    var ve = l(y);
                    ve !== null && Ce(H, ve.startTime - B), ue = !1
                }
                return ue
            } finally {
                p = null, S = N, x = !1
            }
        }
        var X = !1,
            te = null,
            V = -1,
            q = 5,
            k = -1;

        function A() {
            return !(n.unstable_now() - k < q)
        }

        function Y() {
            if (te !== null) {
                var M = n.unstable_now();
                k = M;
                var B = !0;
                try {
                    B = te(!0, M)
                } finally {
                    B ? ae() : (X = !1, te = null)
                }
            } else X = !1
        }
        var ae;
        if (typeof T == "function") ae = function() {
            T(Y)
        };
        else if (typeof MessageChannel < "u") {
            var se = new MessageChannel,
                Ee = se.port2;
            se.port1.onmessage = Y, ae = function() {
                Ee.postMessage(null)
            }
        } else ae = function() {
            I(Y, 0)
        };

        function ge(M) {
            te = M, X || (X = !0, ae())
        }

        function Ce(M, B) {
            V = I(function() {
                M(n.unstable_now())
            }, B)
        }
        n.unstable_IdlePriority = 5, n.unstable_ImmediatePriority = 1, n.unstable_LowPriority = 4, n.unstable_NormalPriority = 3, n.unstable_Profiling = null, n.unstable_UserBlockingPriority = 2, n.unstable_cancelCallback = function(M) {
            M.callback = null
        }, n.unstable_continueExecution = function() {
            w || x || (w = !0, ge(b))
        }, n.unstable_forceFrameRate = function(M) {
            0 > M || 125 < M ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : q = 0 < M ? Math.floor(1e3 / M) : 5
        }, n.unstable_getCurrentPriorityLevel = function() {
            return S
        }, n.unstable_getFirstCallbackNode = function() {
            return l(h)
        }, n.unstable_next = function(M) {
            switch (S) {
                case 1:
                case 2:
                case 3:
                    var B = 3;
                    break;
                default:
                    B = S
            }
            var N = S;
            S = B;
            try {
                return M()
            } finally {
                S = N
            }
        }, n.unstable_pauseExecution = function() {}, n.unstable_requestPaint = function() {}, n.unstable_runWithPriority = function(M, B) {
            switch (M) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    M = 3
            }
            var N = S;
            S = M;
            try {
                return B()
            } finally {
                S = N
            }
        }, n.unstable_scheduleCallback = function(M, B, N) {
            var W = n.unstable_now();
            switch (typeof N == "object" && N !== null ? (N = N.delay, N = typeof N == "number" && 0 < N ? W + N : W) : N = W, M) {
                case 1:
                    var K = -1;
                    break;
                case 2:
                    K = 250;
                    break;
                case 5:
                    K = 1073741823;
                    break;
                case 4:
                    K = 1e4;
                    break;
                default:
                    K = 5e3
            }
            return K = N + K, M = {
                id: v++,
                callback: B,
                priorityLevel: M,
                startTime: N,
                expirationTime: K,
                sortIndex: -1
            }, N > W ? (M.sortIndex = N, r(y, M), l(h) === null && M === l(y) && (z ? (C(V), V = -1) : z = !0, Ce(H, N - W))) : (M.sortIndex = K, r(h, M), w || x || (w = !0, ge(b))), M
        }, n.unstable_shouldYield = A, n.unstable_wrapCallback = function(M) {
            var B = S;
            return function() {
                var N = S;
                S = B;
                try {
                    return M.apply(this, arguments)
                } finally {
                    S = N
                }
            }
        }
    }(Ys)), Ys
}
var Ia;

function sp() {
    return Ia || (Ia = 1, Ks.exports = ip()), Ks.exports
}
/**
 * @license React
 * react-reconciler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var lp = function(r) {
    var l = {},
        a = P,
        c = sp(),
        d = Object.assign;

    function f(e) {
        for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, i = 1; i < arguments.length; i++) t += "&args[]=" + encodeURIComponent(arguments[i]);
        return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }
    var g = a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
        h = Symbol.for("react.element"),
        y = Symbol.for("react.portal"),
        v = Symbol.for("react.fragment"),
        p = Symbol.for("react.strict_mode"),
        S = Symbol.for("react.profiler"),
        x = Symbol.for("react.provider"),
        w = Symbol.for("react.context"),
        z = Symbol.for("react.forward_ref"),
        I = Symbol.for("react.suspense"),
        C = Symbol.for("react.suspense_list"),
        T = Symbol.for("react.memo"),
        D = Symbol.for("react.lazy"),
        H = Symbol.for("react.offscreen"),
        b = Symbol.iterator;

    function X(e) {
        return e === null || typeof e != "object" ? null : (e = b && e[b] || e["@@iterator"], typeof e == "function" ? e : null)
    }

    function te(e) {
        if (e == null) return null;
        if (typeof e == "function") return e.displayName || e.name || null;
        if (typeof e == "string") return e;
        switch (e) {
            case v:
                return "Fragment";
            case y:
                return "Portal";
            case S:
                return "Profiler";
            case p:
                return "StrictMode";
            case I:
                return "Suspense";
            case C:
                return "SuspenseList"
        }
        if (typeof e == "object") switch (e.$$typeof) {
            case w:
                return (e.displayName || "Context") + ".Consumer";
            case x:
                return (e._context.displayName || "Context") + ".Provider";
            case z:
                var t = e.render;
                return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
            case T:
                return t = e.displayName || null, t !== null ? t : te(e.type) || "Memo";
            case D:
                t = e._payload, e = e._init;
                try {
                    return te(e(t))
                } catch {}
        }
        return null
    }

    function V(e) {
        var t = e.type;
        switch (e.tag) {
            case 24:
                return "Cache";
            case 9:
                return (t.displayName || "Context") + ".Consumer";
            case 10:
                return (t._context.displayName || "Context") + ".Provider";
            case 18:
                return "DehydratedFragment";
            case 11:
                return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
            case 7:
                return "Fragment";
            case 5:
                return t;
            case 4:
                return "Portal";
            case 3:
                return "Root";
            case 6:
                return "Text";
            case 16:
                return te(t);
            case 8:
                return t === p ? "StrictMode" : "Mode";
            case 22:
                return "Offscreen";
            case 12:
                return "Profiler";
            case 21:
                return "Scope";
            case 13:
                return "Suspense";
            case 19:
                return "SuspenseList";
            case 25:
                return "TracingMarker";
            case 1:
            case 0:
            case 17:
            case 2:
            case 14:
            case 15:
                if (typeof t == "function") return t.displayName || t.name || null;
                if (typeof t == "string") return t
        }
        return null
    }

    function q(e) {
        var t = e,
            i = e;
        if (e.alternate)
            for (; t.return;) t = t.return;
        else {
            e = t;
            do t = e, t.flags & 4098 && (i = t.return), e = t.return; while (e)
        }
        return t.tag === 3 ? i : null
    }

    function k(e) {
        if (q(e) !== e) throw Error(f(188))
    }

    function A(e) {
        var t = e.alternate;
        if (!t) {
            if (t = q(e), t === null) throw Error(f(188));
            return t !== e ? null : e
        }
        for (var i = e, s = t;;) {
            var o = i.return;
            if (o === null) break;
            var u = o.alternate;
            if (u === null) {
                if (s = o.return, s !== null) {
                    i = s;
                    continue
                }
                break
            }
            if (o.child === u.child) {
                for (u = o.child; u;) {
                    if (u === i) return k(o), e;
                    if (u === s) return k(o), t;
                    u = u.sibling
                }
                throw Error(f(188))
            }
            if (i.return !== s.return) i = o, s = u;
            else {
                for (var m = !1, E = o.child; E;) {
                    if (E === i) {
                        m = !0, i = o, s = u;
                        break
                    }
                    if (E === s) {
                        m = !0, s = o, i = u;
                        break
                    }
                    E = E.sibling
                }
                if (!m) {
                    for (E = u.child; E;) {
                        if (E === i) {
                            m = !0, i = u, s = o;
                            break
                        }
                        if (E === s) {
                            m = !0, s = u, i = o;
                            break
                        }
                        E = E.sibling
                    }
                    if (!m) throw Error(f(189))
                }
            }
            if (i.alternate !== s) throw Error(f(190))
        }
        if (i.tag !== 3) throw Error(f(188));
        return i.stateNode.current === i ? e : t
    }

    function Y(e) {
        return e = A(e), e !== null ? ae(e) : null
    }

    function ae(e) {
        if (e.tag === 5 || e.tag === 6) return e;
        for (e = e.child; e !== null;) {
            var t = ae(e);
            if (t !== null) return t;
            e = e.sibling
        }
        return null
    }

    function se(e) {
        if (e.tag === 5 || e.tag === 6) return e;
        for (e = e.child; e !== null;) {
            if (e.tag !== 4) {
                var t = se(e);
                if (t !== null) return t
            }
            e = e.sibling
        }
        return null
    }
    var Ee = Array.isArray,
        ge = r.getPublicInstance,
        Ce = r.getRootHostContext,
        M = r.getChildHostContext,
        B = r.prepareForCommit,
        N = r.resetAfterCommit,
        W = r.createInstance,
        K = r.appendInitialChild,
        ue = r.finalizeInitialChildren,
        ve = r.prepareUpdate,
        ee = r.shouldSetTextContent,
        pe = r.createTextInstance,
        Re = r.scheduleTimeout,
        Ii = r.cancelTimeout,
        jn = r.noTimeout,
        hn = r.isPrimaryRenderer,
        pt = r.supportsMutation,
        xr = r.supportsPersistence,
        Je = r.supportsHydration,
        tc = r.getInstanceFromNode,
        nc = r.preparePortalMount,
        rc = r.getCurrentEventPriority,
        ic = r.detachDeletedInstance,
        sc = r.supportsMicrotasks,
        lc = r.scheduleMicrotask,
        bn = r.supportsTestSelectors,
        oc = r.findFiberRoot,
        ac = r.getBoundingRect,
        uc = r.getTextContent,
        Vn = r.isHiddenSubtree,
        cc = r.matchAccessibilityRole,
        fc = r.setFocusIfFocusable,
        dc = r.setupIntersectionObserver,
        hc = r.appendChild,
        pc = r.appendChildToContainer,
        vc = r.commitTextUpdate,
        mc = r.commitMount,
        gc = r.commitUpdate,
        yc = r.insertBefore,
        Sc = r.insertInContainerBefore,
        xc = r.removeChild,
        Ec = r.removeChildFromContainer,
        zl = r.resetTextContent,
        _c = r.hideInstance,
        wc = r.hideTextInstance,
        Tc = r.unhideInstance,
        Mc = r.unhideTextInstance,
        Rc = r.clearContainer,
        Pc = r.cloneInstance,
        Al = r.createContainerChildSet,
        Bl = r.appendChildToContainerChildSet,
        Cc = r.finalizeContainerChildren,
        Nl = r.replaceContainerChildren,
        Ol = r.cloneHiddenInstance,
        kl = r.cloneHiddenTextInstance,
        Uc = r.canHydrateInstance,
        Lc = r.canHydrateTextInstance,
        Dc = r.canHydrateSuspenseInstance,
        Fl = r.isSuspenseInstancePending,
        zi = r.isSuspenseInstanceFallback,
        Ic = r.registerSuspenseInstanceRetry,
        Wn = r.getNextHydratableSibling,
        zc = r.getFirstHydratableChild,
        Ac = r.getFirstHydratableChildWithinContainer,
        Bc = r.getFirstHydratableChildWithinSuspenseInstance,
        Nc = r.hydrateInstance,
        Oc = r.hydrateTextInstance,
        kc = r.hydrateSuspenseInstance,
        Fc = r.getNextHydratableInstanceAfterSuspenseInstance,
        Hl = r.commitHydratedContainer,
        Hc = r.commitHydratedSuspenseInstance,
        Gc = r.clearSuspenseBoundary,
        jc = r.clearSuspenseBoundaryFromContainer,
        bc = r.shouldDeleteUnhydratedTailInstances,
        Vc = r.didNotMatchHydratedContainerTextInstance,
        Wc = r.didNotMatchHydratedTextInstance,
        Ai;

    function Qn(e) {
        if (Ai === void 0) try {
            throw Error()
        } catch (i) {
            var t = i.stack.trim().match(/\n( *(at )?)/);
            Ai = t && t[1] || ""
        }
        return `
` + Ai + e
    }
    var Bi = !1;

    function Ni(e, t) {
        if (!e || Bi) return "";
        Bi = !0;
        var i = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
            if (t)
                if (t = function() {
                        throw Error()
                    }, Object.defineProperty(t.prototype, "props", {
                        set: function() {
                            throw Error()
                        }
                    }), typeof Reflect == "object" && Reflect.construct) {
                    try {
                        Reflect.construct(t, [])
                    } catch (O) {
                        var s = O
                    }
                    Reflect.construct(e, [], t)
                } else {
                    try {
                        t.call()
                    } catch (O) {
                        s = O
                    }
                    e.call(t.prototype)
                }
            else {
                try {
                    throw Error()
                } catch (O) {
                    s = O
                }
                e()
            }
        } catch (O) {
            if (O && s && typeof O.stack == "string") {
                for (var o = O.stack.split(`
`), u = s.stack.split(`
`), m = o.length - 1, E = u.length - 1; 1 <= m && 0 <= E && o[m] !== u[E];) E--;
                for (; 1 <= m && 0 <= E; m--, E--)
                    if (o[m] !== u[E]) {
                        if (m !== 1 || E !== 1)
                            do
                                if (m--, E--, 0 > E || o[m] !== u[E]) {
                                    var L = `
` + o[m].replace(" at new ", " at ");
                                    return e.displayName && L.includes("<anonymous>") && (L = L.replace("<anonymous>", e.displayName)), L
                                }
                        while (1 <= m && 0 <= E);
                        break
                    }
            }
        } finally {
            Bi = !1, Error.prepareStackTrace = i
        }
        return (e = e ? e.displayName || e.name : "") ? Qn(e) : ""
    }
    var Qc = Object.prototype.hasOwnProperty,
        Oi = [],
        pn = -1;

    function kt(e) {
        return {
            current: e
        }
    }

    function xe(e) {
        0 > pn || (e.current = Oi[pn], Oi[pn] = null, pn--)
    }

    function ye(e, t) {
        pn++, Oi[pn] = e.current, e.current = t
    }
    var Ft = {},
        ke = kt(Ft),
        Qe = kt(!1),
        en = Ft;

    function vn(e, t) {
        var i = e.type.contextTypes;
        if (!i) return Ft;
        var s = e.stateNode;
        if (s && s.__reactInternalMemoizedUnmaskedChildContext === t) return s.__reactInternalMemoizedMaskedChildContext;
        var o = {},
            u;
        for (u in i) o[u] = t[u];
        return s && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o
    }

    function Xe(e) {
        return e = e.childContextTypes, e != null
    }

    function Er() {
        xe(Qe), xe(ke)
    }

    function Gl(e, t, i) {
        if (ke.current !== Ft) throw Error(f(168));
        ye(ke, t), ye(Qe, i)
    }

    function jl(e, t, i) {
        var s = e.stateNode;
        if (t = t.childContextTypes, typeof s.getChildContext != "function") return i;
        s = s.getChildContext();
        for (var o in s)
            if (!(o in t)) throw Error(f(108, V(e) || "Unknown", o));
        return d({}, i, s)
    }

    function _r(e) {
        return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Ft, en = ke.current, ye(ke, e), ye(Qe, Qe.current), !0
    }

    function bl(e, t, i) {
        var s = e.stateNode;
        if (!s) throw Error(f(169));
        i ? (e = jl(e, t, en), s.__reactInternalMemoizedMergedChildContext = e, xe(Qe), xe(ke), ye(ke, e)) : xe(Qe), ye(Qe, i)
    }
    var vt = Math.clz32 ? Math.clz32 : Yc,
        Xc = Math.log,
        Kc = Math.LN2;

    function Yc(e) {
        return e >>>= 0, e === 0 ? 32 : 31 - (Xc(e) / Kc | 0) | 0
    }
    var wr = 64,
        Tr = 4194304;

    function Xn(e) {
        switch (e & -e) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 4:
                return 4;
            case 8:
                return 8;
            case 16:
                return 16;
            case 32:
                return 32;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return e & 4194240;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
                return e & 130023424;
            case 134217728:
                return 134217728;
            case 268435456:
                return 268435456;
            case 536870912:
                return 536870912;
            case 1073741824:
                return 1073741824;
            default:
                return e
        }
    }

    function Mr(e, t) {
        var i = e.pendingLanes;
        if (i === 0) return 0;
        var s = 0,
            o = e.suspendedLanes,
            u = e.pingedLanes,
            m = i & 268435455;
        if (m !== 0) {
            var E = m & ~o;
            E !== 0 ? s = Xn(E) : (u &= m, u !== 0 && (s = Xn(u)))
        } else m = i & ~o, m !== 0 ? s = Xn(m) : u !== 0 && (s = Xn(u));
        if (s === 0) return 0;
        if (t !== 0 && t !== s && !(t & o) && (o = s & -s, u = t & -t, o >= u || o === 16 && (u & 4194240) !== 0)) return t;
        if (s & 4 && (s |= i & 16), t = e.entangledLanes, t !== 0)
            for (e = e.entanglements, t &= s; 0 < t;) i = 31 - vt(t), o = 1 << i, s |= e[i], t &= ~o;
        return s
    }

    function Zc(e, t) {
        switch (e) {
            case 1:
            case 2:
            case 4:
                return t + 250;
            case 8:
            case 16:
            case 32:
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return t + 5e3;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
                return -1;
            case 134217728:
            case 268435456:
            case 536870912:
            case 1073741824:
                return -1;
            default:
                return -1
        }
    }

    function qc(e, t) {
        for (var i = e.suspendedLanes, s = e.pingedLanes, o = e.expirationTimes, u = e.pendingLanes; 0 < u;) {
            var m = 31 - vt(u),
                E = 1 << m,
                L = o[m];
            L === -1 ? (!(E & i) || E & s) && (o[m] = Zc(E, t)) : L <= t && (e.expiredLanes |= E), u &= ~E
        }
    }

    function ki(e) {
        return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
    }

    function Fi(e) {
        for (var t = [], i = 0; 31 > i; i++) t.push(e);
        return t
    }

    function Kn(e, t, i) {
        e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - vt(t), e[t] = i
    }

    function Jc(e, t) {
        var i = e.pendingLanes & ~t;
        e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
        var s = e.eventTimes;
        for (e = e.expirationTimes; 0 < i;) {
            var o = 31 - vt(i),
                u = 1 << o;
            t[o] = 0, s[o] = -1, e[o] = -1, i &= ~u
        }
    }

    function Hi(e, t) {
        var i = e.entangledLanes |= t;
        for (e = e.entanglements; i;) {
            var s = 31 - vt(i),
                o = 1 << s;
            o & t | e[s] & t && (e[s] |= t), i &= ~o
        }
    }
    var ce = 0;

    function Vl(e) {
        return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
    }
    var Gi = c.unstable_scheduleCallback,
        Wl = c.unstable_cancelCallback,
        $c = c.unstable_shouldYield,
        ef = c.unstable_requestPaint,
        ze = c.unstable_now,
        ji = c.unstable_ImmediatePriority,
        tf = c.unstable_UserBlockingPriority,
        bi = c.unstable_NormalPriority,
        nf = c.unstable_IdlePriority,
        Rr = null,
        xt = null;

    function rf(e) {
        if (xt && typeof xt.onCommitFiberRoot == "function") try {
            xt.onCommitFiberRoot(Rr, e, void 0, (e.current.flags & 128) === 128)
        } catch {}
    }

    function sf(e, t) {
        return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
    }
    var Et = typeof Object.is == "function" ? Object.is : sf,
        Ut = null,
        Pr = !1,
        Vi = !1;

    function Ql(e) {
        Ut === null ? Ut = [e] : Ut.push(e)
    }

    function lf(e) {
        Pr = !0, Ql(e)
    }

    function _t() {
        if (!Vi && Ut !== null) {
            Vi = !0;
            var e = 0,
                t = ce;
            try {
                var i = Ut;
                for (ce = 1; e < i.length; e++) {
                    var s = i[e];
                    do s = s(!0); while (s !== null)
                }
                Ut = null, Pr = !1
            } catch (o) {
                throw Ut !== null && (Ut = Ut.slice(e + 1)), Gi(ji, _t), o
            } finally {
                ce = t, Vi = !1
            }
        }
        return null
    }
    var of = g.ReactCurrentBatchConfig;

    function Cr(e, t) {
        if (Et(e, t)) return !0;
        if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
        var i = Object.keys(e),
            s = Object.keys(t);
        if (i.length !== s.length) return !1;
        for (s = 0; s < i.length; s++) {
            var o = i[s];
            if (!Qc.call(t, o) || !Et(e[o], t[o])) return !1
        }
        return !0
    }

    function af(e) {
        switch (e.tag) {
            case 5:
                return Qn(e.type);
            case 16:
                return Qn("Lazy");
            case 13:
                return Qn("Suspense");
            case 19:
                return Qn("SuspenseList");
            case 0:
            case 2:
            case 15:
                return e = Ni(e.type, !1), e;
            case 11:
                return e = Ni(e.type.render, !1), e;
            case 1:
                return e = Ni(e.type, !0), e;
            default:
                return ""
        }
    }

    function mt(e, t) {
        if (e && e.defaultProps) {
            t = d({}, t), e = e.defaultProps;
            for (var i in e) t[i] === void 0 && (t[i] = e[i]);
            return t
        }
        return t
    }
    var Ur = kt(null),
        Lr = null,
        mn = null,
        Wi = null;

    function Qi() {
        Wi = mn = Lr = null
    }

    function Xl(e, t, i) {
        hn ? (ye(Ur, t._currentValue), t._currentValue = i) : (ye(Ur, t._currentValue2), t._currentValue2 = i)
    }

    function Xi(e) {
        var t = Ur.current;
        xe(Ur), hn ? e._currentValue = t : e._currentValue2 = t
    }

    function Ki(e, t, i) {
        for (; e !== null;) {
            var s = e.alternate;
            if ((e.childLanes & t) !== t ? (e.childLanes |= t, s !== null && (s.childLanes |= t)) : s !== null && (s.childLanes & t) !== t && (s.childLanes |= t), e === i) break;
            e = e.return
        }
    }

    function gn(e, t) {
        Lr = e, Wi = mn = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (tt = !0), e.firstContext = null)
    }

    function it(e) {
        var t = hn ? e._currentValue : e._currentValue2;
        if (Wi !== e)
            if (e = {
                    context: e,
                    memoizedValue: t,
                    next: null
                }, mn === null) {
                if (Lr === null) throw Error(f(308));
                mn = e, Lr.dependencies = {
                    lanes: 0,
                    firstContext: e
                }
            } else mn = mn.next = e;
        return t
    }
    var wt = null,
        Ht = !1;

    function Yi(e) {
        e.updateQueue = {
            baseState: e.memoizedState,
            firstBaseUpdate: null,
            lastBaseUpdate: null,
            shared: {
                pending: null,
                interleaved: null,
                lanes: 0
            },
            effects: null
        }
    }

    function Kl(e, t) {
        e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
            baseState: e.baseState,
            firstBaseUpdate: e.firstBaseUpdate,
            lastBaseUpdate: e.lastBaseUpdate,
            shared: e.shared,
            effects: e.effects
        })
    }

    function Lt(e, t) {
        return {
            eventTime: e,
            lane: t,
            tag: 0,
            payload: null,
            callback: null,
            next: null
        }
    }

    function Gt(e, t) {
        var i = e.updateQueue;
        i !== null && (i = i.shared, Ue !== null && e.mode & 1 && !(oe & 2) ? (e = i.interleaved, e === null ? (t.next = t, wt === null ? wt = [i] : wt.push(i)) : (t.next = e.next, e.next = t), i.interleaved = t) : (e = i.pending, e === null ? t.next = t : (t.next = e.next, e.next = t), i.pending = t))
    }

    function Dr(e, t, i) {
        if (t = t.updateQueue, t !== null && (t = t.shared, (i & 4194240) !== 0)) {
            var s = t.lanes;
            s &= e.pendingLanes, i |= s, t.lanes = i, Hi(e, i)
        }
    }

    function Yl(e, t) {
        var i = e.updateQueue,
            s = e.alternate;
        if (s !== null && (s = s.updateQueue, i === s)) {
            var o = null,
                u = null;
            if (i = i.firstBaseUpdate, i !== null) {
                do {
                    var m = {
                        eventTime: i.eventTime,
                        lane: i.lane,
                        tag: i.tag,
                        payload: i.payload,
                        callback: i.callback,
                        next: null
                    };
                    u === null ? o = u = m : u = u.next = m, i = i.next
                } while (i !== null);
                u === null ? o = u = t : u = u.next = t
            } else o = u = t;
            i = {
                baseState: s.baseState,
                firstBaseUpdate: o,
                lastBaseUpdate: u,
                shared: s.shared,
                effects: s.effects
            }, e.updateQueue = i;
            return
        }
        e = i.lastBaseUpdate, e === null ? i.firstBaseUpdate = t : e.next = t, i.lastBaseUpdate = t
    }

    function Ir(e, t, i, s) {
        var o = e.updateQueue;
        Ht = !1;
        var u = o.firstBaseUpdate,
            m = o.lastBaseUpdate,
            E = o.shared.pending;
        if (E !== null) {
            o.shared.pending = null;
            var L = E,
                O = L.next;
            L.next = null, m === null ? u = O : m.next = O, m = L;
            var j = e.alternate;
            j !== null && (j = j.updateQueue, E = j.lastBaseUpdate, E !== m && (E === null ? j.firstBaseUpdate = O : E.next = O, j.lastBaseUpdate = L))
        }
        if (u !== null) {
            var ne = o.baseState;
            m = 0, j = O = L = null, E = u;
            do {
                var $ = E.lane,
                    me = E.eventTime;
                if ((s & $) === $) {
                    j !== null && (j = j.next = {
                        eventTime: me,
                        lane: 0,
                        tag: E.tag,
                        payload: E.payload,
                        callback: E.callback,
                        next: null
                    });
                    e: {
                        var J = e,
                            je = E;
                        switch ($ = t, me = i, je.tag) {
                            case 1:
                                if (J = je.payload, typeof J == "function") {
                                    ne = J.call(me, ne, $);
                                    break e
                                }
                                ne = J;
                                break e;
                            case 3:
                                J.flags = J.flags & -65537 | 128;
                            case 0:
                                if (J = je.payload, $ = typeof J == "function" ? J.call(me, ne, $) : J, $ == null) break e;
                                ne = d({}, ne, $);
                                break e;
                            case 2:
                                Ht = !0
                        }
                    }
                    E.callback !== null && E.lane !== 0 && (e.flags |= 64, $ = o.effects, $ === null ? o.effects = [E] : $.push(E))
                } else me = {
                    eventTime: me,
                    lane: $,
                    tag: E.tag,
                    payload: E.payload,
                    callback: E.callback,
                    next: null
                }, j === null ? (O = j = me, L = ne) : j = j.next = me, m |= $;
                if (E = E.next, E === null) {
                    if (E = o.shared.pending, E === null) break;
                    $ = E, E = $.next, $.next = null, o.lastBaseUpdate = $, o.shared.pending = null
                }
            } while (1);
            if (j === null && (L = ne), o.baseState = L, o.firstBaseUpdate = O, o.lastBaseUpdate = j, t = o.shared.interleaved, t !== null) {
                o = t;
                do m |= o.lane, o = o.next; while (o !== t)
            } else u === null && (o.shared.lanes = 0);
            Rn |= m, e.lanes = m, e.memoizedState = ne
        }
    }

    function Zl(e, t, i) {
        if (e = t.effects, t.effects = null, e !== null)
            for (t = 0; t < e.length; t++) {
                var s = e[t],
                    o = s.callback;
                if (o !== null) {
                    if (s.callback = null, s = i, typeof o != "function") throw Error(f(191, o));
                    o.call(s)
                }
            }
    }
    var ql = new a.Component().refs;

    function Zi(e, t, i, s) {
        t = e.memoizedState, i = i(s, t), i = i == null ? t : d({}, t, i), e.memoizedState = i, e.lanes === 0 && (e.updateQueue.baseState = i)
    }
    var zr = {
        isMounted: function(e) {
            return (e = e._reactInternals) ? q(e) === e : !1
        },
        enqueueSetState: function(e, t, i) {
            e = e._reactInternals;
            var s = We(),
                o = Vt(e),
                u = Lt(s, o);
            u.payload = t, i != null && (u.callback = i), Gt(e, u), t = ut(e, o, s), t !== null && Dr(t, e, o)
        },
        enqueueReplaceState: function(e, t, i) {
            e = e._reactInternals;
            var s = We(),
                o = Vt(e),
                u = Lt(s, o);
            u.tag = 1, u.payload = t, i != null && (u.callback = i), Gt(e, u), t = ut(e, o, s), t !== null && Dr(t, e, o)
        },
        enqueueForceUpdate: function(e, t) {
            e = e._reactInternals;
            var i = We(),
                s = Vt(e),
                o = Lt(i, s);
            o.tag = 2, t != null && (o.callback = t), Gt(e, o), t = ut(e, s, i), t !== null && Dr(t, e, s)
        }
    };

    function Jl(e, t, i, s, o, u, m) {
        return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(s, u, m) : t.prototype && t.prototype.isPureReactComponent ? !Cr(i, s) || !Cr(o, u) : !0
    }

    function $l(e, t, i) {
        var s = !1,
            o = Ft,
            u = t.contextType;
        return typeof u == "object" && u !== null ? u = it(u) : (o = Xe(t) ? en : ke.current, s = t.contextTypes, u = (s = s != null) ? vn(e, o) : Ft), t = new t(i, u), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = zr, e.stateNode = t, t._reactInternals = e, s && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = o, e.__reactInternalMemoizedMaskedChildContext = u), t
    }

    function eo(e, t, i, s) {
        e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(i, s), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(i, s), t.state !== e && zr.enqueueReplaceState(t, t.state, null)
    }

    function qi(e, t, i, s) {
        var o = e.stateNode;
        o.props = i, o.state = e.memoizedState, o.refs = ql, Yi(e);
        var u = t.contextType;
        typeof u == "object" && u !== null ? o.context = it(u) : (u = Xe(t) ? en : ke.current, o.context = vn(e, u)), o.state = e.memoizedState, u = t.getDerivedStateFromProps, typeof u == "function" && (Zi(e, t, u, i), o.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (t = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), t !== o.state && zr.enqueueReplaceState(o, o.state, null), Ir(e, i, o, s), o.state = e.memoizedState), typeof o.componentDidMount == "function" && (e.flags |= 4194308)
    }
    var yn = [],
        Sn = 0,
        Ar = null,
        Br = 0,
        st = [],
        lt = 0,
        tn = null,
        Dt = 1,
        It = "";

    function nn(e, t) {
        yn[Sn++] = Br, yn[Sn++] = Ar, Ar = e, Br = t
    }

    function to(e, t, i) {
        st[lt++] = Dt, st[lt++] = It, st[lt++] = tn, tn = e;
        var s = Dt;
        e = It;
        var o = 32 - vt(s) - 1;
        s &= ~(1 << o), i += 1;
        var u = 32 - vt(t) + o;
        if (30 < u) {
            var m = o - o % 5;
            u = (s & (1 << m) - 1).toString(32), s >>= m, o -= m, Dt = 1 << 32 - vt(t) + o | i << o | s, It = u + e
        } else Dt = 1 << u | i << o | s, It = e
    }

    function Ji(e) {
        e.return !== null && (nn(e, 1), to(e, 1, 0))
    }

    function $i(e) {
        for (; e === Ar;) Ar = yn[--Sn], yn[Sn] = null, Br = yn[--Sn], yn[Sn] = null;
        for (; e === tn;) tn = st[--lt], st[lt] = null, It = st[--lt], st[lt] = null, Dt = st[--lt], st[lt] = null
    }
    var $e = null,
        et = null,
        _e = !1,
        Yn = !1,
        gt = null;

    function no(e, t) {
        var i = ct(5, null, null, 0);
        i.elementType = "DELETED", i.stateNode = t, i.return = e, t = e.deletions, t === null ? (e.deletions = [i], e.flags |= 16) : t.push(i)
    }

    function ro(e, t) {
        switch (e.tag) {
            case 5:
                return t = Uc(t, e.type, e.pendingProps), t !== null ? (e.stateNode = t, $e = e, et = zc(t), !0) : !1;
            case 6:
                return t = Lc(t, e.pendingProps), t !== null ? (e.stateNode = t, $e = e, et = null, !0) : !1;
            case 13:
                if (t = Dc(t), t !== null) {
                    var i = tn !== null ? {
                        id: Dt,
                        overflow: It
                    } : null;
                    return e.memoizedState = {
                        dehydrated: t,
                        treeContext: i,
                        retryLane: 1073741824
                    }, i = ct(18, null, null, 0), i.stateNode = t, i.return = e, e.child = i, $e = e, et = null, !0
                }
                return !1;
            default:
                return !1
        }
    }

    function es(e) {
        return (e.mode & 1) !== 0 && (e.flags & 128) === 0
    }

    function ts(e) {
        if (_e) {
            var t = et;
            if (t) {
                var i = t;
                if (!ro(e, t)) {
                    if (es(e)) throw Error(f(418));
                    t = Wn(i);
                    var s = $e;
                    t && ro(e, t) ? no(s, i) : (e.flags = e.flags & -4097 | 2, _e = !1, $e = e)
                }
            } else {
                if (es(e)) throw Error(f(418));
                e.flags = e.flags & -4097 | 2, _e = !1, $e = e
            }
        }
    }

    function io(e) {
        for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
        $e = e
    }

    function Zn(e) {
        if (!Je || e !== $e) return !1;
        if (!_e) return io(e), _e = !0, !1;
        if (e.tag !== 3 && (e.tag !== 5 || bc(e.type) && !ee(e.type, e.memoizedProps))) {
            var t = et;
            if (t) {
                if (es(e)) {
                    for (e = et; e;) e = Wn(e);
                    throw Error(f(418))
                }
                for (; t;) no(e, t), t = Wn(t)
            }
        }
        if (io(e), e.tag === 13) {
            if (!Je) throw Error(f(316));
            if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(f(317));
            et = Fc(e)
        } else et = $e ? Wn(e.stateNode) : null;
        return !0
    }

    function xn() {
        Je && (et = $e = null, Yn = _e = !1)
    }

    function ns(e) {
        gt === null ? gt = [e] : gt.push(e)
    }

    function qn(e, t, i) {
        if (e = i.ref, e !== null && typeof e != "function" && typeof e != "object") {
            if (i._owner) {
                if (i = i._owner, i) {
                    if (i.tag !== 1) throw Error(f(309));
                    var s = i.stateNode
                }
                if (!s) throw Error(f(147, e));
                var o = s,
                    u = "" + e;
                return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === u ? t.ref : (t = function(m) {
                    var E = o.refs;
                    E === ql && (E = o.refs = {}), m === null ? delete E[u] : E[u] = m
                }, t._stringRef = u, t)
            }
            if (typeof e != "string") throw Error(f(284));
            if (!i._owner) throw Error(f(290, e))
        }
        return e
    }

    function Nr(e, t) {
        throw e = Object.prototype.toString.call(t), Error(f(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
    }

    function so(e) {
        var t = e._init;
        return t(e._payload)
    }

    function lo(e) {
        function t(R, _) {
            if (e) {
                var U = R.deletions;
                U === null ? (R.deletions = [_], R.flags |= 16) : U.push(_)
            }
        }

        function i(R, _) {
            if (!e) return null;
            for (; _ !== null;) t(R, _), _ = _.sibling;
            return null
        }

        function s(R, _) {
            for (R = new Map; _ !== null;) _.key !== null ? R.set(_.key, _) : R.set(_.index, _), _ = _.sibling;
            return R
        }

        function o(R, _) {
            return R = Qt(R, _), R.index = 0, R.sibling = null, R
        }

        function u(R, _, U) {
            return R.index = U, e ? (U = R.alternate, U !== null ? (U = U.index, U < _ ? (R.flags |= 2, _) : U) : (R.flags |= 2, _)) : (R.flags |= 1048576, _)
        }

        function m(R) {
            return e && R.alternate === null && (R.flags |= 2), R
        }

        function E(R, _, U, G) {
            return _ === null || _.tag !== 6 ? (_ = Fs(U, R.mode, G), _.return = R, _) : (_ = o(_, U), _.return = R, _)
        }

        function L(R, _, U, G) {
            var Z = U.type;
            return Z === v ? j(R, _, U.props.children, G, U.key) : _ !== null && (_.elementType === Z || typeof Z == "object" && Z !== null && Z.$$typeof === D && so(Z) === _.type) ? (G = o(_, U.props), G.ref = qn(R, _, U), G.return = R, G) : (G = hi(U.type, U.key, U.props, null, R.mode, G), G.ref = qn(R, _, U), G.return = R, G)
        }

        function O(R, _, U, G) {
            return _ === null || _.tag !== 4 || _.stateNode.containerInfo !== U.containerInfo || _.stateNode.implementation !== U.implementation ? (_ = Hs(U, R.mode, G), _.return = R, _) : (_ = o(_, U.children || []), _.return = R, _)
        }

        function j(R, _, U, G, Z) {
            return _ === null || _.tag !== 7 ? (_ = cn(U, R.mode, G, Z), _.return = R, _) : (_ = o(_, U), _.return = R, _)
        }

        function ne(R, _, U) {
            if (typeof _ == "string" && _ !== "" || typeof _ == "number") return _ = Fs("" + _, R.mode, U), _.return = R, _;
            if (typeof _ == "object" && _ !== null) {
                switch (_.$$typeof) {
                    case h:
                        return U = hi(_.type, _.key, _.props, null, R.mode, U), U.ref = qn(R, null, _), U.return = R, U;
                    case y:
                        return _ = Hs(_, R.mode, U), _.return = R, _;
                    case D:
                        var G = _._init;
                        return ne(R, G(_._payload), U)
                }
                if (Ee(_) || X(_)) return _ = cn(_, R.mode, U, null), _.return = R, _;
                Nr(R, _)
            }
            return null
        }

        function $(R, _, U, G) {
            var Z = _ !== null ? _.key : null;
            if (typeof U == "string" && U !== "" || typeof U == "number") return Z !== null ? null : E(R, _, "" + U, G);
            if (typeof U == "object" && U !== null) {
                switch (U.$$typeof) {
                    case h:
                        return U.key === Z ? L(R, _, U, G) : null;
                    case y:
                        return U.key === Z ? O(R, _, U, G) : null;
                    case D:
                        return Z = U._init, $(R, _, Z(U._payload), G)
                }
                if (Ee(U) || X(U)) return Z !== null ? null : j(R, _, U, G, null);
                Nr(R, U)
            }
            return null
        }

        function me(R, _, U, G, Z) {
            if (typeof G == "string" && G !== "" || typeof G == "number") return R = R.get(U) || null, E(_, R, "" + G, Z);
            if (typeof G == "object" && G !== null) {
                switch (G.$$typeof) {
                    case h:
                        return R = R.get(G.key === null ? U : G.key) || null, L(_, R, G, Z);
                    case y:
                        return R = R.get(G.key === null ? U : G.key) || null, O(_, R, G, Z);
                    case D:
                        var le = G._init;
                        return me(R, _, U, le(G._payload), Z)
                }
                if (Ee(G) || X(G)) return R = R.get(U) || null, j(_, R, G, Z, null);
                Nr(_, G)
            }
            return null
        }

        function J(R, _, U, G) {
            for (var Z = null, le = null, re = _, fe = _ = 0, Be = null; re !== null && fe < U.length; fe++) {
                re.index > fe ? (Be = re, re = null) : Be = re.sibling;
                var de = $(R, re, U[fe], G);
                if (de === null) {
                    re === null && (re = Be);
                    break
                }
                e && re && de.alternate === null && t(R, re), _ = u(de, _, fe), le === null ? Z = de : le.sibling = de, le = de, re = Be
            }
            if (fe === U.length) return i(R, re), _e && nn(R, fe), Z;
            if (re === null) {
                for (; fe < U.length; fe++) re = ne(R, U[fe], G), re !== null && (_ = u(re, _, fe), le === null ? Z = re : le.sibling = re, le = re);
                return _e && nn(R, fe), Z
            }
            for (re = s(R, re); fe < U.length; fe++) Be = me(re, R, fe, U[fe], G), Be !== null && (e && Be.alternate !== null && re.delete(Be.key === null ? fe : Be.key), _ = u(Be, _, fe), le === null ? Z = Be : le.sibling = Be, le = Be);
            return e && re.forEach(function(Xt) {
                return t(R, Xt)
            }), _e && nn(R, fe), Z
        }

        function je(R, _, U, G) {
            var Z = X(U);
            if (typeof Z != "function") throw Error(f(150));
            if (U = Z.call(U), U == null) throw Error(f(151));
            for (var le = Z = null, re = _, fe = _ = 0, Be = null, de = U.next(); re !== null && !de.done; fe++, de = U.next()) {
                re.index > fe ? (Be = re, re = null) : Be = re.sibling;
                var Xt = $(R, re, de.value, G);
                if (Xt === null) {
                    re === null && (re = Be);
                    break
                }
                e && re && Xt.alternate === null && t(R, re), _ = u(Xt, _, fe), le === null ? Z = Xt : le.sibling = Xt, le = Xt, re = Be
            }
            if (de.done) return i(R, re), _e && nn(R, fe), Z;
            if (re === null) {
                for (; !de.done; fe++, de = U.next()) de = ne(R, de.value, G), de !== null && (_ = u(de, _, fe), le === null ? Z = de : le.sibling = de, le = de);
                return _e && nn(R, fe), Z
            }
            for (re = s(R, re); !de.done; fe++, de = U.next()) de = me(re, R, fe, de.value, G), de !== null && (e && de.alternate !== null && re.delete(de.key === null ? fe : de.key), _ = u(de, _, fe), le === null ? Z = de : le.sibling = de, le = de);
            return e && re.forEach(function(kf) {
                return t(R, kf)
            }), _e && nn(R, fe), Z
        }

        function ft(R, _, U, G) {
            if (typeof U == "object" && U !== null && U.type === v && U.key === null && (U = U.props.children), typeof U == "object" && U !== null) {
                switch (U.$$typeof) {
                    case h:
                        e: {
                            for (var Z = U.key, le = _; le !== null;) {
                                if (le.key === Z) {
                                    if (Z = U.type, Z === v) {
                                        if (le.tag === 7) {
                                            i(R, le.sibling), _ = o(le, U.props.children), _.return = R, R = _;
                                            break e
                                        }
                                    } else if (le.elementType === Z || typeof Z == "object" && Z !== null && Z.$$typeof === D && so(Z) === le.type) {
                                        i(R, le.sibling), _ = o(le, U.props), _.ref = qn(R, le, U), _.return = R, R = _;
                                        break e
                                    }
                                    i(R, le);
                                    break
                                } else t(R, le);
                                le = le.sibling
                            }
                            U.type === v ? (_ = cn(U.props.children, R.mode, G, U.key), _.return = R, R = _) : (G = hi(U.type, U.key, U.props, null, R.mode, G), G.ref = qn(R, _, U), G.return = R, R = G)
                        }
                        return m(R);
                    case y:
                        e: {
                            for (le = U.key; _ !== null;) {
                                if (_.key === le)
                                    if (_.tag === 4 && _.stateNode.containerInfo === U.containerInfo && _.stateNode.implementation === U.implementation) {
                                        i(R, _.sibling), _ = o(_, U.children || []), _.return = R, R = _;
                                        break e
                                    } else {
                                        i(R, _);
                                        break
                                    }
                                else t(R, _);
                                _ = _.sibling
                            }
                            _ = Hs(U, R.mode, G),
                            _.return = R,
                            R = _
                        }
                        return m(R);
                    case D:
                        return le = U._init, ft(R, _, le(U._payload), G)
                }
                if (Ee(U)) return J(R, _, U, G);
                if (X(U)) return je(R, _, U, G);
                Nr(R, U)
            }
            return typeof U == "string" && U !== "" || typeof U == "number" ? (U = "" + U, _ !== null && _.tag === 6 ? (i(R, _.sibling), _ = o(_, U), _.return = R, R = _) : (i(R, _), _ = Fs(U, R.mode, G), _.return = R, R = _), m(R)) : i(R, _)
        }
        return ft
    }
    var En = lo(!0),
        oo = lo(!1),
        Jn = {},
        ot = kt(Jn),
        $n = kt(Jn),
        _n = kt(Jn);

    function Tt(e) {
        if (e === Jn) throw Error(f(174));
        return e
    }

    function rs(e, t) {
        ye(_n, t), ye($n, e), ye(ot, Jn), e = Ce(t), xe(ot), ye(ot, e)
    }

    function wn() {
        xe(ot), xe($n), xe(_n)
    }

    function ao(e) {
        var t = Tt(_n.current),
            i = Tt(ot.current);
        t = M(i, e.type, t), i !== t && (ye($n, e), ye(ot, t))
    }

    function is(e) {
        $n.current === e && (xe(ot), xe($n))
    }
    var Te = kt(0);

    function Or(e) {
        for (var t = e; t !== null;) {
            if (t.tag === 13) {
                var i = t.memoizedState;
                if (i !== null && (i = i.dehydrated, i === null || Fl(i) || zi(i))) return t
            } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
                if (t.flags & 128) return t
            } else if (t.child !== null) {
                t.child.return = t, t = t.child;
                continue
            }
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return null;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
        return null
    }
    var ss = [];

    function ls() {
        for (var e = 0; e < ss.length; e++) {
            var t = ss[e];
            hn ? t._workInProgressVersionPrimary = null : t._workInProgressVersionSecondary = null
        }
        ss.length = 0
    }
    var kr = g.ReactCurrentDispatcher,
        at = g.ReactCurrentBatchConfig,
        Tn = 0,
        Me = null,
        Fe = null,
        Ae = null,
        Fr = !1,
        er = !1,
        tr = 0,
        uf = 0;

    function He() {
        throw Error(f(321))
    }

    function os(e, t) {
        if (t === null) return !1;
        for (var i = 0; i < t.length && i < e.length; i++)
            if (!Et(e[i], t[i])) return !1;
        return !0
    }

    function as(e, t, i, s, o, u) {
        if (Tn = u, Me = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, kr.current = e === null || e.memoizedState === null ? hf : pf, e = i(s, o), er) {
            u = 0;
            do {
                if (er = !1, tr = 0, 25 <= u) throw Error(f(301));
                u += 1, Ae = Fe = null, t.updateQueue = null, kr.current = vf, e = i(s, o)
            } while (er)
        }
        if (kr.current = Vr, t = Fe !== null && Fe.next !== null, Tn = 0, Ae = Fe = Me = null, Fr = !1, t) throw Error(f(300));
        return e
    }

    function us() {
        var e = tr !== 0;
        return tr = 0, e
    }

    function zt() {
        var e = {
            memoizedState: null,
            baseState: null,
            baseQueue: null,
            queue: null,
            next: null
        };
        return Ae === null ? Me.memoizedState = Ae = e : Ae = Ae.next = e, Ae
    }

    function Mt() {
        if (Fe === null) {
            var e = Me.alternate;
            e = e !== null ? e.memoizedState : null
        } else e = Fe.next;
        var t = Ae === null ? Me.memoizedState : Ae.next;
        if (t !== null) Ae = t, Fe = e;
        else {
            if (e === null) throw Error(f(310));
            Fe = e, e = {
                memoizedState: Fe.memoizedState,
                baseState: Fe.baseState,
                baseQueue: Fe.baseQueue,
                queue: Fe.queue,
                next: null
            }, Ae === null ? Me.memoizedState = Ae = e : Ae = Ae.next = e
        }
        return Ae
    }

    function rn(e, t) {
        return typeof t == "function" ? t(e) : t
    }

    function Hr(e) {
        var t = Mt(),
            i = t.queue;
        if (i === null) throw Error(f(311));
        i.lastRenderedReducer = e;
        var s = Fe,
            o = s.baseQueue,
            u = i.pending;
        if (u !== null) {
            if (o !== null) {
                var m = o.next;
                o.next = u.next, u.next = m
            }
            s.baseQueue = o = u, i.pending = null
        }
        if (o !== null) {
            u = o.next, s = s.baseState;
            var E = m = null,
                L = null,
                O = u;
            do {
                var j = O.lane;
                if ((Tn & j) === j) L !== null && (L = L.next = {
                    lane: 0,
                    action: O.action,
                    hasEagerState: O.hasEagerState,
                    eagerState: O.eagerState,
                    next: null
                }), s = O.hasEagerState ? O.eagerState : e(s, O.action);
                else {
                    var ne = {
                        lane: j,
                        action: O.action,
                        hasEagerState: O.hasEagerState,
                        eagerState: O.eagerState,
                        next: null
                    };
                    L === null ? (E = L = ne, m = s) : L = L.next = ne, Me.lanes |= j, Rn |= j
                }
                O = O.next
            } while (O !== null && O !== u);
            L === null ? m = s : L.next = E, Et(s, t.memoizedState) || (tt = !0), t.memoizedState = s, t.baseState = m, t.baseQueue = L, i.lastRenderedState = s
        }
        if (e = i.interleaved, e !== null) {
            o = e;
            do u = o.lane, Me.lanes |= u, Rn |= u, o = o.next; while (o !== e)
        } else o === null && (i.lanes = 0);
        return [t.memoizedState, i.dispatch]
    }

    function Gr(e) {
        var t = Mt(),
            i = t.queue;
        if (i === null) throw Error(f(311));
        i.lastRenderedReducer = e;
        var s = i.dispatch,
            o = i.pending,
            u = t.memoizedState;
        if (o !== null) {
            i.pending = null;
            var m = o = o.next;
            do u = e(u, m.action), m = m.next; while (m !== o);
            Et(u, t.memoizedState) || (tt = !0), t.memoizedState = u, t.baseQueue === null && (t.baseState = u), i.lastRenderedState = u
        }
        return [u, s]
    }

    function uo() {}

    function co(e, t) {
        var i = Me,
            s = Mt(),
            o = t(),
            u = !Et(s.memoizedState, o);
        if (u && (s.memoizedState = o, tt = !0), s = s.queue, rr(po.bind(null, i, s, e), [e]), s.getSnapshot !== t || u || Ae !== null && Ae.memoizedState.tag & 1) {
            if (i.flags |= 2048, nr(9, ho.bind(null, i, s, o, t), void 0, null), Ue === null) throw Error(f(349));
            Tn & 30 || fo(i, t, o)
        }
        return o
    }

    function fo(e, t, i) {
        e.flags |= 16384, e = {
            getSnapshot: t,
            value: i
        }, t = Me.updateQueue, t === null ? (t = {
            lastEffect: null,
            stores: null
        }, Me.updateQueue = t, t.stores = [e]) : (i = t.stores, i === null ? t.stores = [e] : i.push(e))
    }

    function ho(e, t, i, s) {
        t.value = i, t.getSnapshot = s, vo(t) && ut(e, 1, -1)
    }

    function po(e, t, i) {
        return i(function() {
            vo(t) && ut(e, 1, -1)
        })
    }

    function vo(e) {
        var t = e.getSnapshot;
        e = e.value;
        try {
            var i = t();
            return !Et(e, i)
        } catch {
            return !0
        }
    }

    function cs(e) {
        var t = zt();
        return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: rn,
            lastRenderedState: e
        }, t.queue = e, e = e.dispatch = df.bind(null, Me, e), [t.memoizedState, e]
    }

    function nr(e, t, i, s) {
        return e = {
            tag: e,
            create: t,
            destroy: i,
            deps: s,
            next: null
        }, t = Me.updateQueue, t === null ? (t = {
            lastEffect: null,
            stores: null
        }, Me.updateQueue = t, t.lastEffect = e.next = e) : (i = t.lastEffect, i === null ? t.lastEffect = e.next = e : (s = i.next, i.next = e, e.next = s, t.lastEffect = e)), e
    }

    function mo() {
        return Mt().memoizedState
    }

    function jr(e, t, i, s) {
        var o = zt();
        Me.flags |= e, o.memoizedState = nr(1 | t, i, void 0, s === void 0 ? null : s)
    }

    function br(e, t, i, s) {
        var o = Mt();
        s = s === void 0 ? null : s;
        var u = void 0;
        if (Fe !== null) {
            var m = Fe.memoizedState;
            if (u = m.destroy, s !== null && os(s, m.deps)) {
                o.memoizedState = nr(t, i, u, s);
                return
            }
        }
        Me.flags |= e, o.memoizedState = nr(1 | t, i, u, s)
    }

    function fs(e, t) {
        return jr(8390656, 8, e, t)
    }

    function rr(e, t) {
        return br(2048, 8, e, t)
    }

    function go(e, t) {
        return br(4, 2, e, t)
    }

    function yo(e, t) {
        return br(4, 4, e, t)
    }

    function So(e, t) {
        if (typeof t == "function") return e = e(), t(e),
            function() {
                t(null)
            };
        if (t != null) return e = e(), t.current = e,
            function() {
                t.current = null
            }
    }

    function xo(e, t, i) {
        return i = i != null ? i.concat([e]) : null, br(4, 4, So.bind(null, t, e), i)
    }

    function ds() {}

    function Eo(e, t) {
        var i = Mt();
        t = t === void 0 ? null : t;
        var s = i.memoizedState;
        return s !== null && t !== null && os(t, s[1]) ? s[0] : (i.memoizedState = [e, t], e)
    }

    function _o(e, t) {
        var i = Mt();
        t = t === void 0 ? null : t;
        var s = i.memoizedState;
        return s !== null && t !== null && os(t, s[1]) ? s[0] : (e = e(), i.memoizedState = [e, t], e)
    }

    function cf(e, t) {
        var i = ce;
        ce = i !== 0 && 4 > i ? i : 4, e(!0);
        var s = at.transition;
        at.transition = {};
        try {
            e(!1), t()
        } finally {
            ce = i, at.transition = s
        }
    }

    function wo() {
        return Mt().memoizedState
    }

    function ff(e, t, i) {
        var s = Vt(e);
        i = {
            lane: s,
            action: i,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, To(e) ? Mo(t, i) : (Ro(e, t, i), i = We(), e = ut(e, s, i), e !== null && Po(e, t, s))
    }

    function df(e, t, i) {
        var s = Vt(e),
            o = {
                lane: s,
                action: i,
                hasEagerState: !1,
                eagerState: null,
                next: null
            };
        if (To(e)) Mo(t, o);
        else {
            Ro(e, t, o);
            var u = e.alternate;
            if (e.lanes === 0 && (u === null || u.lanes === 0) && (u = t.lastRenderedReducer, u !== null)) try {
                var m = t.lastRenderedState,
                    E = u(m, i);
                if (o.hasEagerState = !0, o.eagerState = E, Et(E, m)) return
            } catch {} finally {}
            i = We(), e = ut(e, s, i), e !== null && Po(e, t, s)
        }
    }

    function To(e) {
        var t = e.alternate;
        return e === Me || t !== null && t === Me
    }

    function Mo(e, t) {
        er = Fr = !0;
        var i = e.pending;
        i === null ? t.next = t : (t.next = i.next, i.next = t), e.pending = t
    }

    function Ro(e, t, i) {
        Ue !== null && e.mode & 1 && !(oe & 2) ? (e = t.interleaved, e === null ? (i.next = i, wt === null ? wt = [t] : wt.push(t)) : (i.next = e.next, e.next = i), t.interleaved = i) : (e = t.pending, e === null ? i.next = i : (i.next = e.next, e.next = i), t.pending = i)
    }

    function Po(e, t, i) {
        if (i & 4194240) {
            var s = t.lanes;
            s &= e.pendingLanes, i |= s, t.lanes = i, Hi(e, i)
        }
    }
    var Vr = {
            readContext: it,
            useCallback: He,
            useContext: He,
            useEffect: He,
            useImperativeHandle: He,
            useInsertionEffect: He,
            useLayoutEffect: He,
            useMemo: He,
            useReducer: He,
            useRef: He,
            useState: He,
            useDebugValue: He,
            useDeferredValue: He,
            useTransition: He,
            useMutableSource: He,
            useSyncExternalStore: He,
            useId: He,
            unstable_isNewReconciler: !1
        },
        hf = {
            readContext: it,
            useCallback: function(e, t) {
                return zt().memoizedState = [e, t === void 0 ? null : t], e
            },
            useContext: it,
            useEffect: fs,
            useImperativeHandle: function(e, t, i) {
                return i = i != null ? i.concat([e]) : null, jr(4194308, 4, So.bind(null, t, e), i)
            },
            useLayoutEffect: function(e, t) {
                return jr(4194308, 4, e, t)
            },
            useInsertionEffect: function(e, t) {
                return jr(4, 2, e, t)
            },
            useMemo: function(e, t) {
                var i = zt();
                return t = t === void 0 ? null : t, e = e(), i.memoizedState = [e, t], e
            },
            useReducer: function(e, t, i) {
                var s = zt();
                return t = i !== void 0 ? i(t) : t, s.memoizedState = s.baseState = t, e = {
                    pending: null,
                    interleaved: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: e,
                    lastRenderedState: t
                }, s.queue = e, e = e.dispatch = ff.bind(null, Me, e), [s.memoizedState, e]
            },
            useRef: function(e) {
                var t = zt();
                return e = {
                    current: e
                }, t.memoizedState = e
            },
            useState: cs,
            useDebugValue: ds,
            useDeferredValue: function(e) {
                var t = cs(e),
                    i = t[0],
                    s = t[1];
                return fs(function() {
                    var o = at.transition;
                    at.transition = {};
                    try {
                        s(e)
                    } finally {
                        at.transition = o
                    }
                }, [e]), i
            },
            useTransition: function() {
                var e = cs(!1),
                    t = e[0];
                return e = cf.bind(null, e[1]), zt().memoizedState = e, [t, e]
            },
            useMutableSource: function() {},
            useSyncExternalStore: function(e, t, i) {
                var s = Me,
                    o = zt();
                if (_e) {
                    if (i === void 0) throw Error(f(407));
                    i = i()
                } else {
                    if (i = t(), Ue === null) throw Error(f(349));
                    Tn & 30 || fo(s, t, i)
                }
                o.memoizedState = i;
                var u = {
                    value: i,
                    getSnapshot: t
                };
                return o.queue = u, fs(po.bind(null, s, u, e), [e]), s.flags |= 2048, nr(9, ho.bind(null, s, u, i, t), void 0, null), i
            },
            useId: function() {
                var e = zt(),
                    t = Ue.identifierPrefix;
                if (_e) {
                    var i = It,
                        s = Dt;
                    i = (s & ~(1 << 32 - vt(s) - 1)).toString(32) + i, t = ":" + t + "R" + i, i = tr++, 0 < i && (t += "H" + i.toString(32)), t += ":"
                } else i = uf++, t = ":" + t + "r" + i.toString(32) + ":";
                return e.memoizedState = t
            },
            unstable_isNewReconciler: !1
        },
        pf = {
            readContext: it,
            useCallback: Eo,
            useContext: it,
            useEffect: rr,
            useImperativeHandle: xo,
            useInsertionEffect: go,
            useLayoutEffect: yo,
            useMemo: _o,
            useReducer: Hr,
            useRef: mo,
            useState: function() {
                return Hr(rn)
            },
            useDebugValue: ds,
            useDeferredValue: function(e) {
                var t = Hr(rn),
                    i = t[0],
                    s = t[1];
                return rr(function() {
                    var o = at.transition;
                    at.transition = {};
                    try {
                        s(e)
                    } finally {
                        at.transition = o
                    }
                }, [e]), i
            },
            useTransition: function() {
                var e = Hr(rn)[0],
                    t = Mt().memoizedState;
                return [e, t]
            },
            useMutableSource: uo,
            useSyncExternalStore: co,
            useId: wo,
            unstable_isNewReconciler: !1
        },
        vf = {
            readContext: it,
            useCallback: Eo,
            useContext: it,
            useEffect: rr,
            useImperativeHandle: xo,
            useInsertionEffect: go,
            useLayoutEffect: yo,
            useMemo: _o,
            useReducer: Gr,
            useRef: mo,
            useState: function() {
                return Gr(rn)
            },
            useDebugValue: ds,
            useDeferredValue: function(e) {
                var t = Gr(rn),
                    i = t[0],
                    s = t[1];
                return rr(function() {
                    var o = at.transition;
                    at.transition = {};
                    try {
                        s(e)
                    } finally {
                        at.transition = o
                    }
                }, [e]), i
            },
            useTransition: function() {
                var e = Gr(rn)[0],
                    t = Mt().memoizedState;
                return [e, t]
            },
            useMutableSource: uo,
            useSyncExternalStore: co,
            useId: wo,
            unstable_isNewReconciler: !1
        };

    function hs(e, t) {
        try {
            var i = "",
                s = t;
            do i += af(s), s = s.return; while (s);
            var o = i
        } catch (u) {
            o = `
Error generating stack: ` + u.message + `
` + u.stack
        }
        return {
            value: e,
            source: t,
            stack: o
        }
    }

    function ps(e, t) {
        try {
            console.error(t.value)
        } catch (i) {
            setTimeout(function() {
                throw i
            })
        }
    }
    var mf = typeof WeakMap == "function" ? WeakMap : Map;

    function Co(e, t, i) {
        i = Lt(-1, i), i.tag = 3, i.payload = {
            element: null
        };
        var s = t.value;
        return i.callback = function() {
            li || (li = !0, Is = s), ps(e, t)
        }, i
    }

    function Uo(e, t, i) {
        i = Lt(-1, i), i.tag = 3;
        var s = e.type.getDerivedStateFromError;
        if (typeof s == "function") {
            var o = t.value;
            i.payload = function() {
                return s(o)
            }, i.callback = function() {
                ps(e, t)
            }
        }
        var u = e.stateNode;
        return u !== null && typeof u.componentDidCatch == "function" && (i.callback = function() {
            ps(e, t), typeof s != "function" && (jt === null ? jt = new Set([this]) : jt.add(this));
            var m = t.stack;
            this.componentDidCatch(t.value, {
                componentStack: m !== null ? m : ""
            })
        }), i
    }

    function Lo(e, t, i) {
        var s = e.pingCache;
        if (s === null) {
            s = e.pingCache = new mf;
            var o = new Set;
            s.set(t, o)
        } else o = s.get(t), o === void 0 && (o = new Set, s.set(t, o));
        o.has(i) || (o.add(i), e = Lf.bind(null, e, t, i), t.then(e, e))
    }

    function Do(e) {
        do {
            var t;
            if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
            e = e.return
        } while (e !== null);
        return null
    }

    function Io(e, t, i, s, o) {
        return e.mode & 1 ? (e.flags |= 65536, e.lanes = o, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, i.flags |= 131072, i.flags &= -52805, i.tag === 1 && (i.alternate === null ? i.tag = 17 : (t = Lt(-1, 1), t.tag = 2, Gt(i, t))), i.lanes |= 1), e)
    }

    function Rt(e) {
        e.flags |= 4
    }

    function zo(e, t) {
        if (e !== null && e.child === t.child) return !0;
        if (t.flags & 16) return !1;
        for (e = t.child; e !== null;) {
            if (e.flags & 12854 || e.subtreeFlags & 12854) return !1;
            e = e.sibling
        }
        return !0
    }
    var ir, sr, Wr, Qr;
    if (pt) ir = function(e, t) {
        for (var i = t.child; i !== null;) {
            if (i.tag === 5 || i.tag === 6) K(e, i.stateNode);
            else if (i.tag !== 4 && i.child !== null) {
                i.child.return = i, i = i.child;
                continue
            }
            if (i === t) break;
            for (; i.sibling === null;) {
                if (i.return === null || i.return === t) return;
                i = i.return
            }
            i.sibling.return = i.return, i = i.sibling
        }
    }, sr = function() {}, Wr = function(e, t, i, s, o) {
        if (e = e.memoizedProps, e !== s) {
            var u = t.stateNode,
                m = Tt(ot.current);
            i = ve(u, i, e, s, o, m), (t.updateQueue = i) && Rt(t)
        }
    }, Qr = function(e, t, i, s) {
        i !== s && Rt(t)
    };
    else if (xr) {
        ir = function(e, t, i, s) {
            for (var o = t.child; o !== null;) {
                if (o.tag === 5) {
                    var u = o.stateNode;
                    i && s && (u = Ol(u, o.type, o.memoizedProps, o)), K(e, u)
                } else if (o.tag === 6) u = o.stateNode, i && s && (u = kl(u, o.memoizedProps, o)), K(e, u);
                else if (o.tag !== 4) {
                    if (o.tag === 22 && o.memoizedState !== null) u = o.child, u !== null && (u.return = o), ir(e, o, !0, !0);
                    else if (o.child !== null) {
                        o.child.return = o, o = o.child;
                        continue
                    }
                }
                if (o === t) break;
                for (; o.sibling === null;) {
                    if (o.return === null || o.return === t) return;
                    o = o.return
                }
                o.sibling.return = o.return, o = o.sibling
            }
        };
        var Ao = function(e, t, i, s) {
            for (var o = t.child; o !== null;) {
                if (o.tag === 5) {
                    var u = o.stateNode;
                    i && s && (u = Ol(u, o.type, o.memoizedProps, o)), Bl(e, u)
                } else if (o.tag === 6) u = o.stateNode, i && s && (u = kl(u, o.memoizedProps, o)), Bl(e, u);
                else if (o.tag !== 4) {
                    if (o.tag === 22 && o.memoizedState !== null) u = o.child, u !== null && (u.return = o), Ao(e, o, !0, !0);
                    else if (o.child !== null) {
                        o.child.return = o, o = o.child;
                        continue
                    }
                }
                if (o === t) break;
                for (; o.sibling === null;) {
                    if (o.return === null || o.return === t) return;
                    o = o.return
                }
                o.sibling.return = o.return, o = o.sibling
            }
        };
        sr = function(e, t) {
            var i = t.stateNode;
            if (!zo(e, t)) {
                e = i.containerInfo;
                var s = Al(e);
                Ao(s, t, !1, !1), i.pendingChildren = s, Rt(t), Cc(e, s)
            }
        }, Wr = function(e, t, i, s, o) {
            var u = e.stateNode,
                m = e.memoizedProps;
            if ((e = zo(e, t)) && m === s) t.stateNode = u;
            else {
                var E = t.stateNode,
                    L = Tt(ot.current),
                    O = null;
                m !== s && (O = ve(E, i, m, s, o, L)), e && O === null ? t.stateNode = u : (u = Pc(u, O, i, m, s, t, e, E), ue(u, i, s, o, L) && Rt(t), t.stateNode = u, e ? Rt(t) : ir(u, t, !1, !1))
            }
        }, Qr = function(e, t, i, s) {
            i !== s ? (e = Tt(_n.current), i = Tt(ot.current), t.stateNode = pe(s, e, i, t), Rt(t)) : t.stateNode = e.stateNode
        }
    } else sr = function() {}, Wr = function() {}, Qr = function() {};

    function lr(e, t) {
        if (!_e) switch (e.tailMode) {
            case "hidden":
                t = e.tail;
                for (var i = null; t !== null;) t.alternate !== null && (i = t), t = t.sibling;
                i === null ? e.tail = null : i.sibling = null;
                break;
            case "collapsed":
                i = e.tail;
                for (var s = null; i !== null;) i.alternate !== null && (s = i), i = i.sibling;
                s === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : s.sibling = null
        }
    }

    function Ge(e) {
        var t = e.alternate !== null && e.alternate.child === e.child,
            i = 0,
            s = 0;
        if (t)
            for (var o = e.child; o !== null;) i |= o.lanes | o.childLanes, s |= o.subtreeFlags & 14680064, s |= o.flags & 14680064, o.return = e, o = o.sibling;
        else
            for (o = e.child; o !== null;) i |= o.lanes | o.childLanes, s |= o.subtreeFlags, s |= o.flags, o.return = e, o = o.sibling;
        return e.subtreeFlags |= s, e.childLanes = i, t
    }

    function gf(e, t, i) {
        var s = t.pendingProps;
        switch ($i(t), t.tag) {
            case 2:
            case 16:
            case 15:
            case 0:
            case 11:
            case 7:
            case 8:
            case 12:
            case 9:
            case 14:
                return Ge(t), null;
            case 1:
                return Xe(t.type) && Er(), Ge(t), null;
            case 3:
                return s = t.stateNode, wn(), xe(Qe), xe(ke), ls(), s.pendingContext && (s.context = s.pendingContext, s.pendingContext = null), (e === null || e.child === null) && (Zn(t) ? Rt(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, gt !== null && (Bs(gt), gt = null))), sr(e, t), Ge(t), null;
            case 5:
                is(t), i = Tt(_n.current);
                var o = t.type;
                if (e !== null && t.stateNode != null) Wr(e, t, o, s, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
                else {
                    if (!s) {
                        if (t.stateNode === null) throw Error(f(166));
                        return Ge(t), null
                    }
                    if (e = Tt(ot.current), Zn(t)) {
                        if (!Je) throw Error(f(175));
                        e = Nc(t.stateNode, t.type, t.memoizedProps, i, e, t, !Yn), t.updateQueue = e, e !== null && Rt(t)
                    } else {
                        var u = W(o, s, i, e, t);
                        ir(u, t, !1, !1), t.stateNode = u, ue(u, o, s, i, e) && Rt(t)
                    }
                    t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
                }
                return Ge(t), null;
            case 6:
                if (e && t.stateNode != null) Qr(e, t, e.memoizedProps, s);
                else {
                    if (typeof s != "string" && t.stateNode === null) throw Error(f(166));
                    if (e = Tt(_n.current), i = Tt(ot.current), Zn(t)) {
                        if (!Je) throw Error(f(176));
                        if (e = t.stateNode, s = t.memoizedProps, (i = Oc(e, s, t, !Yn)) && (o = $e, o !== null)) switch (u = (o.mode & 1) !== 0, o.tag) {
                            case 3:
                                Vc(o.stateNode.containerInfo, e, s, u);
                                break;
                            case 5:
                                Wc(o.type, o.memoizedProps, o.stateNode, e, s, u)
                        }
                        i && Rt(t)
                    } else t.stateNode = pe(s, e, i, t)
                }
                return Ge(t), null;
            case 13:
                if (xe(Te), s = t.memoizedState, _e && et !== null && t.mode & 1 && !(t.flags & 128)) {
                    for (e = et; e;) e = Wn(e);
                    return xn(), t.flags |= 98560, t
                }
                if (s !== null && s.dehydrated !== null) {
                    if (s = Zn(t), e === null) {
                        if (!s) throw Error(f(318));
                        if (!Je) throw Error(f(344));
                        if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(f(317));
                        kc(e, t)
                    } else xn(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    return Ge(t), null
                }
                return gt !== null && (Bs(gt), gt = null), t.flags & 128 ? (t.lanes = i, t) : (s = s !== null, i = !1, e === null ? Zn(t) : i = e.memoizedState !== null, s && !i && (t.child.flags |= 8192, t.mode & 1 && (e === null || Te.current & 1 ? De === 0 && (De = 3) : Os())), t.updateQueue !== null && (t.flags |= 4), Ge(t), null);
            case 4:
                return wn(), sr(e, t), e === null && nc(t.stateNode.containerInfo), Ge(t), null;
            case 10:
                return Xi(t.type._context), Ge(t), null;
            case 17:
                return Xe(t.type) && Er(), Ge(t), null;
            case 19:
                if (xe(Te), o = t.memoizedState, o === null) return Ge(t), null;
                if (s = (t.flags & 128) !== 0, u = o.rendering, u === null)
                    if (s) lr(o, !1);
                    else {
                        if (De !== 0 || e !== null && e.flags & 128)
                            for (e = t.child; e !== null;) {
                                if (u = Or(e), u !== null) {
                                    for (t.flags |= 128, lr(o, !1), e = u.updateQueue, e !== null && (t.updateQueue = e, t.flags |= 4), t.subtreeFlags = 0, e = i, s = t.child; s !== null;) i = s, o = e, i.flags &= 14680066, u = i.alternate, u === null ? (i.childLanes = 0, i.lanes = o, i.child = null, i.subtreeFlags = 0, i.memoizedProps = null, i.memoizedState = null, i.updateQueue = null, i.dependencies = null, i.stateNode = null) : (i.childLanes = u.childLanes, i.lanes = u.lanes, i.child = u.child, i.subtreeFlags = 0, i.deletions = null, i.memoizedProps = u.memoizedProps, i.memoizedState = u.memoizedState, i.updateQueue = u.updateQueue, i.type = u.type, o = u.dependencies, i.dependencies = o === null ? null : {
                                        lanes: o.lanes,
                                        firstContext: o.firstContext
                                    }), s = s.sibling;
                                    return ye(Te, Te.current & 1 | 2), t.child
                                }
                                e = e.sibling
                            }
                        o.tail !== null && ze() > Ds && (t.flags |= 128, s = !0, lr(o, !1), t.lanes = 4194304)
                    }
                else {
                    if (!s)
                        if (e = Or(u), e !== null) {
                            if (t.flags |= 128, s = !0, e = e.updateQueue, e !== null && (t.updateQueue = e, t.flags |= 4), lr(o, !0), o.tail === null && o.tailMode === "hidden" && !u.alternate && !_e) return Ge(t), null
                        } else 2 * ze() - o.renderingStartTime > Ds && i !== 1073741824 && (t.flags |= 128, s = !0, lr(o, !1), t.lanes = 4194304);
                    o.isBackwards ? (u.sibling = t.child, t.child = u) : (e = o.last, e !== null ? e.sibling = u : t.child = u, o.last = u)
                }
                return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = ze(), t.sibling = null, e = Te.current, ye(Te, s ? e & 1 | 2 : e & 1), t) : (Ge(t), null);
            case 22:
            case 23:
                return Ns(), s = t.memoizedState !== null, e !== null && e.memoizedState !== null !== s && (t.flags |= 8192), s && t.mode & 1 ? nt & 1073741824 && (Ge(t), pt && t.subtreeFlags & 6 && (t.flags |= 8192)) : Ge(t), null;
            case 24:
                return null;
            case 25:
                return null
        }
        throw Error(f(156, t.tag))
    }
    var yf = g.ReactCurrentOwner,
        tt = !1;

    function Ve(e, t, i, s) {
        t.child = e === null ? oo(t, null, i, s) : En(t, e.child, i, s)
    }

    function Bo(e, t, i, s, o) {
        i = i.render;
        var u = t.ref;
        return gn(t, o), s = as(e, t, i, s, u, o), i = us(), e !== null && !tt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, At(e, t, o)) : (_e && i && Ji(t), t.flags |= 1, Ve(e, t, s, o), t.child)
    }

    function No(e, t, i, s, o) {
        if (e === null) {
            var u = i.type;
            return typeof u == "function" && !ks(u) && u.defaultProps === void 0 && i.compare === null && i.defaultProps === void 0 ? (t.tag = 15, t.type = u, Oo(e, t, u, s, o)) : (e = hi(i.type, null, s, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e)
        }
        if (u = e.child, !(e.lanes & o)) {
            var m = u.memoizedProps;
            if (i = i.compare, i = i !== null ? i : Cr, i(m, s) && e.ref === t.ref) return At(e, t, o)
        }
        return t.flags |= 1, e = Qt(u, s), e.ref = t.ref, e.return = t, t.child = e
    }

    function Oo(e, t, i, s, o) {
        if (e !== null && Cr(e.memoizedProps, s) && e.ref === t.ref)
            if (tt = !1, (e.lanes & o) !== 0) e.flags & 131072 && (tt = !0);
            else return t.lanes = e.lanes, At(e, t, o);
        return vs(e, t, i, s, o)
    }

    function ko(e, t, i) {
        var s = t.pendingProps,
            o = s.children,
            u = e !== null ? e.memoizedState : null;
        if (s.mode === "hidden")
            if (!(t.mode & 1)) t.memoizedState = {
                baseLanes: 0,
                cachePool: null
            }, ye(Mn, nt), nt |= i;
            else if (i & 1073741824) t.memoizedState = {
            baseLanes: 0,
            cachePool: null
        }, s = u !== null ? u.baseLanes : i, ye(Mn, nt), nt |= s;
        else return e = u !== null ? u.baseLanes | i : i, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
            baseLanes: e,
            cachePool: null
        }, t.updateQueue = null, ye(Mn, nt), nt |= e, null;
        else u !== null ? (s = u.baseLanes | i, t.memoizedState = null) : s = i, ye(Mn, nt), nt |= s;
        return Ve(e, t, o, i), t.child
    }

    function Fo(e, t) {
        var i = t.ref;
        (e === null && i !== null || e !== null && e.ref !== i) && (t.flags |= 512, t.flags |= 2097152)
    }

    function vs(e, t, i, s, o) {
        var u = Xe(i) ? en : ke.current;
        return u = vn(t, u), gn(t, o), i = as(e, t, i, s, u, o), s = us(), e !== null && !tt ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~o, At(e, t, o)) : (_e && s && Ji(t), t.flags |= 1, Ve(e, t, i, o), t.child)
    }

    function Ho(e, t, i, s, o) {
        if (Xe(i)) {
            var u = !0;
            _r(t)
        } else u = !1;
        if (gn(t, o), t.stateNode === null) e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), $l(t, i, s), qi(t, i, s, o), s = !0;
        else if (e === null) {
            var m = t.stateNode,
                E = t.memoizedProps;
            m.props = E;
            var L = m.context,
                O = i.contextType;
            typeof O == "object" && O !== null ? O = it(O) : (O = Xe(i) ? en : ke.current, O = vn(t, O));
            var j = i.getDerivedStateFromProps,
                ne = typeof j == "function" || typeof m.getSnapshotBeforeUpdate == "function";
            ne || typeof m.UNSAFE_componentWillReceiveProps != "function" && typeof m.componentWillReceiveProps != "function" || (E !== s || L !== O) && eo(t, m, s, O), Ht = !1;
            var $ = t.memoizedState;
            m.state = $, Ir(t, s, m, o), L = t.memoizedState, E !== s || $ !== L || Qe.current || Ht ? (typeof j == "function" && (Zi(t, i, j, s), L = t.memoizedState), (E = Ht || Jl(t, i, E, s, $, L, O)) ? (ne || typeof m.UNSAFE_componentWillMount != "function" && typeof m.componentWillMount != "function" || (typeof m.componentWillMount == "function" && m.componentWillMount(), typeof m.UNSAFE_componentWillMount == "function" && m.UNSAFE_componentWillMount()), typeof m.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof m.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = s, t.memoizedState = L), m.props = s, m.state = L, m.context = O, s = E) : (typeof m.componentDidMount == "function" && (t.flags |= 4194308), s = !1)
        } else {
            m = t.stateNode, Kl(e, t), E = t.memoizedProps, O = t.type === t.elementType ? E : mt(t.type, E), m.props = O, ne = t.pendingProps, $ = m.context, L = i.contextType, typeof L == "object" && L !== null ? L = it(L) : (L = Xe(i) ? en : ke.current, L = vn(t, L));
            var me = i.getDerivedStateFromProps;
            (j = typeof me == "function" || typeof m.getSnapshotBeforeUpdate == "function") || typeof m.UNSAFE_componentWillReceiveProps != "function" && typeof m.componentWillReceiveProps != "function" || (E !== ne || $ !== L) && eo(t, m, s, L), Ht = !1, $ = t.memoizedState, m.state = $, Ir(t, s, m, o);
            var J = t.memoizedState;
            E !== ne || $ !== J || Qe.current || Ht ? (typeof me == "function" && (Zi(t, i, me, s), J = t.memoizedState), (O = Ht || Jl(t, i, O, s, $, J, L) || !1) ? (j || typeof m.UNSAFE_componentWillUpdate != "function" && typeof m.componentWillUpdate != "function" || (typeof m.componentWillUpdate == "function" && m.componentWillUpdate(s, J, L), typeof m.UNSAFE_componentWillUpdate == "function" && m.UNSAFE_componentWillUpdate(s, J, L)), typeof m.componentDidUpdate == "function" && (t.flags |= 4), typeof m.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof m.componentDidUpdate != "function" || E === e.memoizedProps && $ === e.memoizedState || (t.flags |= 4), typeof m.getSnapshotBeforeUpdate != "function" || E === e.memoizedProps && $ === e.memoizedState || (t.flags |= 1024), t.memoizedProps = s, t.memoizedState = J), m.props = s, m.state = J, m.context = L, s = O) : (typeof m.componentDidUpdate != "function" || E === e.memoizedProps && $ === e.memoizedState || (t.flags |= 4), typeof m.getSnapshotBeforeUpdate != "function" || E === e.memoizedProps && $ === e.memoizedState || (t.flags |= 1024), s = !1)
        }
        return ms(e, t, i, s, u, o)
    }

    function ms(e, t, i, s, o, u) {
        Fo(e, t);
        var m = (t.flags & 128) !== 0;
        if (!s && !m) return o && bl(t, i, !1), At(e, t, u);
        s = t.stateNode, yf.current = t;
        var E = m && typeof i.getDerivedStateFromError != "function" ? null : s.render();
        return t.flags |= 1, e !== null && m ? (t.child = En(t, e.child, null, u), t.child = En(t, null, E, u)) : Ve(e, t, E, u), t.memoizedState = s.state, o && bl(t, i, !0), t.child
    }

    function Go(e) {
        var t = e.stateNode;
        t.pendingContext ? Gl(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Gl(e, t.context, !1), rs(e, t.containerInfo)
    }

    function jo(e, t, i, s, o) {
        return xn(), ns(o), t.flags |= 256, Ve(e, t, i, s), t.child
    }
    var Xr = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0
    };

    function Kr(e) {
        return {
            baseLanes: e,
            cachePool: null
        }
    }

    function bo(e, t, i) {
        var s = t.pendingProps,
            o = Te.current,
            u = !1,
            m = (t.flags & 128) !== 0,
            E;
        if ((E = m) || (E = e !== null && e.memoizedState === null ? !1 : (o & 2) !== 0), E ? (u = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (o |= 1), ye(Te, o & 1), e === null) return ts(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? zi(e) ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (o = s.children, e = s.fallback, u ? (s = t.mode, u = t.child, o = {
            mode: "hidden",
            children: o
        }, !(s & 1) && u !== null ? (u.childLanes = 0, u.pendingProps = o) : u = pi(o, s, 0, null), e = cn(e, s, i, null), u.return = t, e.return = t, u.sibling = e, t.child = u, t.child.memoizedState = Kr(i), t.memoizedState = Xr, e) : gs(t, o));
        if (o = e.memoizedState, o !== null) {
            if (E = o.dehydrated, E !== null) {
                if (m) return t.flags & 256 ? (t.flags &= -257, Yr(e, t, i, Error(f(422)))) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (u = s.fallback, o = t.mode, s = pi({
                    mode: "visible",
                    children: s.children
                }, o, 0, null), u = cn(u, o, i, null), u.flags |= 2, s.return = t, u.return = t, s.sibling = u, t.child = s, t.mode & 1 && En(t, e.child, null, i), t.child.memoizedState = Kr(i), t.memoizedState = Xr, u);
                if (!(t.mode & 1)) t = Yr(e, t, i, null);
                else if (zi(E)) t = Yr(e, t, i, Error(f(419)));
                else if (s = (i & e.childLanes) !== 0, tt || s) {
                    if (s = Ue, s !== null) {
                        switch (i & -i) {
                            case 4:
                                u = 2;
                                break;
                            case 16:
                                u = 8;
                                break;
                            case 64:
                            case 128:
                            case 256:
                            case 512:
                            case 1024:
                            case 2048:
                            case 4096:
                            case 8192:
                            case 16384:
                            case 32768:
                            case 65536:
                            case 131072:
                            case 262144:
                            case 524288:
                            case 1048576:
                            case 2097152:
                            case 4194304:
                            case 8388608:
                            case 16777216:
                            case 33554432:
                            case 67108864:
                                u = 32;
                                break;
                            case 536870912:
                                u = 268435456;
                                break;
                            default:
                                u = 0
                        }
                        s = u & (s.suspendedLanes | i) ? 0 : u, s !== 0 && s !== o.retryLane && (o.retryLane = s, ut(e, s, -1))
                    }
                    Os(), t = Yr(e, t, i, Error(f(421)))
                } else Fl(E) ? (t.flags |= 128, t.child = e.child, t = Df.bind(null, e), Ic(E, t), t = null) : (i = o.treeContext, Je && (et = Bc(E), $e = t, _e = !0, gt = null, Yn = !1, i !== null && (st[lt++] = Dt, st[lt++] = It, st[lt++] = tn, Dt = i.id, It = i.overflow, tn = t)), t = gs(t, t.pendingProps.children), t.flags |= 4096);
                return t
            }
            return u ? (s = Wo(e, t, s.children, s.fallback, i), u = t.child, o = e.child.memoizedState, u.memoizedState = o === null ? Kr(i) : {
                baseLanes: o.baseLanes | i,
                cachePool: null
            }, u.childLanes = e.childLanes & ~i, t.memoizedState = Xr, s) : (i = Vo(e, t, s.children, i), t.memoizedState = null, i)
        }
        return u ? (s = Wo(e, t, s.children, s.fallback, i), u = t.child, o = e.child.memoizedState, u.memoizedState = o === null ? Kr(i) : {
            baseLanes: o.baseLanes | i,
            cachePool: null
        }, u.childLanes = e.childLanes & ~i, t.memoizedState = Xr, s) : (i = Vo(e, t, s.children, i), t.memoizedState = null, i)
    }

    function gs(e, t) {
        return t = pi({
            mode: "visible",
            children: t
        }, e.mode, 0, null), t.return = e, e.child = t
    }

    function Vo(e, t, i, s) {
        var o = e.child;
        return e = o.sibling, i = Qt(o, {
            mode: "visible",
            children: i
        }), !(t.mode & 1) && (i.lanes = s), i.return = t, i.sibling = null, e !== null && (s = t.deletions, s === null ? (t.deletions = [e], t.flags |= 16) : s.push(e)), t.child = i
    }

    function Wo(e, t, i, s, o) {
        var u = t.mode;
        e = e.child;
        var m = e.sibling,
            E = {
                mode: "hidden",
                children: i
            };
        return !(u & 1) && t.child !== e ? (i = t.child, i.childLanes = 0, i.pendingProps = E, t.deletions = null) : (i = Qt(e, E), i.subtreeFlags = e.subtreeFlags & 14680064), m !== null ? s = Qt(m, s) : (s = cn(s, u, o, null), s.flags |= 2), s.return = t, i.return = t, i.sibling = s, t.child = i, s
    }

    function Yr(e, t, i, s) {
        return s !== null && ns(s), En(t, e.child, null, i), e = gs(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
    }

    function Qo(e, t, i) {
        e.lanes |= t;
        var s = e.alternate;
        s !== null && (s.lanes |= t), Ki(e.return, t, i)
    }

    function ys(e, t, i, s, o) {
        var u = e.memoizedState;
        u === null ? e.memoizedState = {
            isBackwards: t,
            rendering: null,
            renderingStartTime: 0,
            last: s,
            tail: i,
            tailMode: o
        } : (u.isBackwards = t, u.rendering = null, u.renderingStartTime = 0, u.last = s, u.tail = i, u.tailMode = o)
    }

    function Xo(e, t, i) {
        var s = t.pendingProps,
            o = s.revealOrder,
            u = s.tail;
        if (Ve(e, t, s.children, i), s = Te.current, s & 2) s = s & 1 | 2, t.flags |= 128;
        else {
            if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
                if (e.tag === 13) e.memoizedState !== null && Qo(e, i, t);
                else if (e.tag === 19) Qo(e, i, t);
                else if (e.child !== null) {
                    e.child.return = e, e = e.child;
                    continue
                }
                if (e === t) break e;
                for (; e.sibling === null;) {
                    if (e.return === null || e.return === t) break e;
                    e = e.return
                }
                e.sibling.return = e.return, e = e.sibling
            }
            s &= 1
        }
        if (ye(Te, s), !(t.mode & 1)) t.memoizedState = null;
        else switch (o) {
            case "forwards":
                for (i = t.child, o = null; i !== null;) e = i.alternate, e !== null && Or(e) === null && (o = i), i = i.sibling;
                i = o, i === null ? (o = t.child, t.child = null) : (o = i.sibling, i.sibling = null), ys(t, !1, o, i, u);
                break;
            case "backwards":
                for (i = null, o = t.child, t.child = null; o !== null;) {
                    if (e = o.alternate, e !== null && Or(e) === null) {
                        t.child = o;
                        break
                    }
                    e = o.sibling, o.sibling = i, i = o, o = e
                }
                ys(t, !0, i, null, u);
                break;
            case "together":
                ys(t, !1, null, null, void 0);
                break;
            default:
                t.memoizedState = null
        }
        return t.child
    }

    function At(e, t, i) {
        if (e !== null && (t.dependencies = e.dependencies), Rn |= t.lanes, !(i & t.childLanes)) return null;
        if (e !== null && t.child !== e.child) throw Error(f(153));
        if (t.child !== null) {
            for (e = t.child, i = Qt(e, e.pendingProps), t.child = i, i.return = t; e.sibling !== null;) e = e.sibling, i = i.sibling = Qt(e, e.pendingProps), i.return = t;
            i.sibling = null
        }
        return t.child
    }

    function Sf(e, t, i) {
        switch (t.tag) {
            case 3:
                Go(t), xn();
                break;
            case 5:
                ao(t);
                break;
            case 1:
                Xe(t.type) && _r(t);
                break;
            case 4:
                rs(t, t.stateNode.containerInfo);
                break;
            case 10:
                Xl(t, t.type._context, t.memoizedProps.value);
                break;
            case 13:
                var s = t.memoizedState;
                if (s !== null) return s.dehydrated !== null ? (ye(Te, Te.current & 1), t.flags |= 128, null) : i & t.child.childLanes ? bo(e, t, i) : (ye(Te, Te.current & 1), e = At(e, t, i), e !== null ? e.sibling : null);
                ye(Te, Te.current & 1);
                break;
            case 19:
                if (s = (i & t.childLanes) !== 0, e.flags & 128) {
                    if (s) return Xo(e, t, i);
                    t.flags |= 128
                }
                var o = t.memoizedState;
                if (o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), ye(Te, Te.current), s) break;
                return null;
            case 22:
            case 23:
                return t.lanes = 0, ko(e, t, i)
        }
        return At(e, t, i)
    }

    function xf(e, t) {
        switch ($i(t), t.tag) {
            case 1:
                return Xe(t.type) && Er(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 3:
                return wn(), xe(Qe), xe(ke), ls(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
            case 5:
                return is(t), null;
            case 13:
                if (xe(Te), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                    if (t.alternate === null) throw Error(f(340));
                    xn()
                }
                return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
            case 19:
                return xe(Te), null;
            case 4:
                return wn(), null;
            case 10:
                return Xi(t.type._context), null;
            case 22:
            case 23:
                return Ns(), null;
            case 24:
                return null;
            default:
                return null
        }
    }
    var Zr = !1,
        sn = !1,
        Ef = typeof WeakSet == "function" ? WeakSet : Set,
        F = null;

    function qr(e, t) {
        var i = e.ref;
        if (i !== null)
            if (typeof i == "function") try {
                i(null)
            } catch (s) {
                Ze(e, t, s)
            } else i.current = null
    }

    function Ss(e, t, i) {
        try {
            i()
        } catch (s) {
            Ze(e, t, s)
        }
    }
    var Ko = !1;

    function _f(e, t) {
        for (B(e.containerInfo), F = t; F !== null;)
            if (e = F, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, F = t;
            else
                for (; F !== null;) {
                    e = F;
                    try {
                        var i = e.alternate;
                        if (e.flags & 1024) switch (e.tag) {
                            case 0:
                            case 11:
                            case 15:
                                break;
                            case 1:
                                if (i !== null) {
                                    var s = i.memoizedProps,
                                        o = i.memoizedState,
                                        u = e.stateNode,
                                        m = u.getSnapshotBeforeUpdate(e.elementType === e.type ? s : mt(e.type, s), o);
                                    u.__reactInternalSnapshotBeforeUpdate = m
                                }
                                break;
                            case 3:
                                pt && Rc(e.stateNode.containerInfo);
                                break;
                            case 5:
                            case 6:
                            case 4:
                            case 17:
                                break;
                            default:
                                throw Error(f(163))
                        }
                    } catch (E) {
                        Ze(e, e.return, E)
                    }
                    if (t = e.sibling, t !== null) {
                        t.return = e.return, F = t;
                        break
                    }
                    F = e.return
                }
        return i = Ko, Ko = !1, i
    }

    function ln(e, t, i) {
        var s = t.updateQueue;
        if (s = s !== null ? s.lastEffect : null, s !== null) {
            var o = s = s.next;
            do {
                if ((o.tag & e) === e) {
                    var u = o.destroy;
                    o.destroy = void 0, u !== void 0 && Ss(t, i, u)
                }
                o = o.next
            } while (o !== s)
        }
    }

    function or(e, t) {
        if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
            var i = t = t.next;
            do {
                if ((i.tag & e) === e) {
                    var s = i.create;
                    i.destroy = s()
                }
                i = i.next
            } while (i !== t)
        }
    }

    function xs(e) {
        var t = e.ref;
        if (t !== null) {
            var i = e.stateNode;
            switch (e.tag) {
                case 5:
                    e = ge(i);
                    break;
                default:
                    e = i
            }
            typeof t == "function" ? t(e) : t.current = e
        }
    }

    function Yo(e, t, i) {
        if (xt && typeof xt.onCommitFiberUnmount == "function") try {
            xt.onCommitFiberUnmount(Rr, t)
        } catch {}
        switch (t.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                if (e = t.updateQueue, e !== null && (e = e.lastEffect, e !== null)) {
                    var s = e = e.next;
                    do {
                        var o = s,
                            u = o.destroy;
                        o = o.tag, u !== void 0 && (o & 2 || o & 4) && Ss(t, i, u), s = s.next
                    } while (s !== e)
                }
                break;
            case 1:
                if (qr(t, i), e = t.stateNode, typeof e.componentWillUnmount == "function") try {
                    e.props = t.memoizedProps, e.state = t.memoizedState, e.componentWillUnmount()
                } catch (m) {
                    Ze(t, i, m)
                }
                break;
            case 5:
                qr(t, i);
                break;
            case 4:
                pt ? ta(e, t, i) : xr && xr && (t = t.stateNode.containerInfo, i = Al(t), Nl(t, i))
        }
    }

    function Zo(e, t, i) {
        for (var s = t;;)
            if (Yo(e, s, i), s.child === null || pt && s.tag === 4) {
                if (s === t) break;
                for (; s.sibling === null;) {
                    if (s.return === null || s.return === t) return;
                    s = s.return
                }
                s.sibling.return = s.return, s = s.sibling
            } else s.child.return = s, s = s.child
    }

    function qo(e) {
        var t = e.alternate;
        t !== null && (e.alternate = null, qo(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && ic(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
    }

    function Jo(e) {
        return e.tag === 5 || e.tag === 3 || e.tag === 4
    }

    function $o(e) {
        e: for (;;) {
            for (; e.sibling === null;) {
                if (e.return === null || Jo(e.return)) return null;
                e = e.return
            }
            for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
                if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
                e.child.return = e, e = e.child
            }
            if (!(e.flags & 2)) return e.stateNode
        }
    }

    function ea(e) {
        if (pt) {
            e: {
                for (var t = e.return; t !== null;) {
                    if (Jo(t)) break e;
                    t = t.return
                }
                throw Error(f(160))
            }
            var i = t;
            switch (i.tag) {
                case 5:
                    t = i.stateNode, i.flags & 32 && (zl(t), i.flags &= -33), i = $o(e), _s(e, i, t);
                    break;
                case 3:
                case 4:
                    t = i.stateNode.containerInfo, i = $o(e), Es(e, i, t);
                    break;
                default:
                    throw Error(f(161))
            }
        }
    }

    function Es(e, t, i) {
        var s = e.tag;
        if (s === 5 || s === 6) e = e.stateNode, t ? Sc(i, e, t) : pc(i, e);
        else if (s !== 4 && (e = e.child, e !== null))
            for (Es(e, t, i), e = e.sibling; e !== null;) Es(e, t, i), e = e.sibling
    }

    function _s(e, t, i) {
        var s = e.tag;
        if (s === 5 || s === 6) e = e.stateNode, t ? yc(i, e, t) : hc(i, e);
        else if (s !== 4 && (e = e.child, e !== null))
            for (_s(e, t, i), e = e.sibling; e !== null;) _s(e, t, i), e = e.sibling
    }

    function ta(e, t, i) {
        for (var s = t, o = !1, u, m;;) {
            if (!o) {
                o = s.return;
                e: for (;;) {
                    if (o === null) throw Error(f(160));
                    switch (u = o.stateNode, o.tag) {
                        case 5:
                            m = !1;
                            break e;
                        case 3:
                            u = u.containerInfo, m = !0;
                            break e;
                        case 4:
                            u = u.containerInfo, m = !0;
                            break e
                    }
                    o = o.return
                }
                o = !0
            }
            if (s.tag === 5 || s.tag === 6) Zo(e, s, i), m ? Ec(u, s.stateNode) : xc(u, s.stateNode);
            else if (s.tag === 18) m ? jc(u, s.stateNode) : Gc(u, s.stateNode);
            else if (s.tag === 4) {
                if (s.child !== null) {
                    u = s.stateNode.containerInfo, m = !0, s.child.return = s, s = s.child;
                    continue
                }
            } else if (Yo(e, s, i), s.child !== null) {
                s.child.return = s, s = s.child;
                continue
            }
            if (s === t) break;
            for (; s.sibling === null;) {
                if (s.return === null || s.return === t) return;
                s = s.return, s.tag === 4 && (o = !1)
            }
            s.sibling.return = s.return, s = s.sibling
        }
    }

    function ws(e, t) {
        if (pt) {
            switch (t.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    ln(3, t, t.return), or(3, t), ln(5, t, t.return);
                    return;
                case 1:
                    return;
                case 5:
                    var i = t.stateNode;
                    if (i != null) {
                        var s = t.memoizedProps;
                        e = e !== null ? e.memoizedProps : s;
                        var o = t.type,
                            u = t.updateQueue;
                        t.updateQueue = null, u !== null && gc(i, u, o, e, s, t)
                    }
                    return;
                case 6:
                    if (t.stateNode === null) throw Error(f(162));
                    i = t.memoizedProps, vc(t.stateNode, e !== null ? e.memoizedProps : i, i);
                    return;
                case 3:
                    Je && e !== null && e.memoizedState.isDehydrated && Hl(t.stateNode.containerInfo);
                    return;
                case 12:
                    return;
                case 13:
                    Jr(t);
                    return;
                case 19:
                    Jr(t);
                    return;
                case 17:
                    return
            }
            throw Error(f(163))
        }
        switch (t.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                ln(3, t, t.return), or(3, t), ln(5, t, t.return);
                return;
            case 12:
                return;
            case 13:
                Jr(t);
                return;
            case 19:
                Jr(t);
                return;
            case 3:
                Je && e !== null && e.memoizedState.isDehydrated && Hl(t.stateNode.containerInfo);
                break;
            case 22:
            case 23:
                return
        }
        e: if (xr) {
            switch (t.tag) {
                case 1:
                case 5:
                case 6:
                    break e;
                case 3:
                case 4:
                    t = t.stateNode, Nl(t.containerInfo, t.pendingChildren);
                    break e
            }
            throw Error(f(163))
        }
    }

    function Jr(e) {
        var t = e.updateQueue;
        if (t !== null) {
            e.updateQueue = null;
            var i = e.stateNode;
            i === null && (i = e.stateNode = new Ef), t.forEach(function(s) {
                var o = If.bind(null, e, s);
                i.has(s) || (i.add(s), s.then(o, o))
            })
        }
    }

    function wf(e, t) {
        for (F = t; F !== null;) {
            t = F;
            var i = t.deletions;
            if (i !== null)
                for (var s = 0; s < i.length; s++) {
                    var o = i[s];
                    try {
                        var u = e;
                        pt ? ta(u, o, t) : Zo(u, o, t);
                        var m = o.alternate;
                        m !== null && (m.return = null), o.return = null
                    } catch (Z) {
                        Ze(o, t, Z)
                    }
                }
            if (i = t.child, t.subtreeFlags & 12854 && i !== null) i.return = t, F = i;
            else
                for (; F !== null;) {
                    t = F;
                    try {
                        var E = t.flags;
                        if (E & 32 && pt && zl(t.stateNode), E & 512) {
                            var L = t.alternate;
                            if (L !== null) {
                                var O = L.ref;
                                O !== null && (typeof O == "function" ? O(null) : O.current = null)
                            }
                        }
                        if (E & 8192) switch (t.tag) {
                            case 13:
                                if (t.memoizedState !== null) {
                                    var j = t.alternate;
                                    (j === null || j.memoizedState === null) && (Ls = ze())
                                }
                                break;
                            case 22:
                                var ne = t.memoizedState !== null,
                                    $ = t.alternate,
                                    me = $ !== null && $.memoizedState !== null;
                                if (i = t, pt) {
                                    e: if (s = i, o = ne, u = null, pt)
                                        for (var J = s;;) {
                                            if (J.tag === 5) {
                                                if (u === null) {
                                                    u = J;
                                                    var je = J.stateNode;
                                                    o ? _c(je) : Tc(J.stateNode, J.memoizedProps)
                                                }
                                            } else if (J.tag === 6) {
                                                if (u === null) {
                                                    var ft = J.stateNode;
                                                    o ? wc(ft) : Mc(ft, J.memoizedProps)
                                                }
                                            } else if ((J.tag !== 22 && J.tag !== 23 || J.memoizedState === null || J === s) && J.child !== null) {
                                                J.child.return = J, J = J.child;
                                                continue
                                            }
                                            if (J === s) break;
                                            for (; J.sibling === null;) {
                                                if (J.return === null || J.return === s) break e;
                                                u === J && (u = null), J = J.return
                                            }
                                            u === J && (u = null), J.sibling.return = J.return, J = J.sibling
                                        }
                                }
                                if (ne && !me && i.mode & 1) {
                                    F = i;
                                    for (var R = i.child; R !== null;) {
                                        for (i = F = R; F !== null;) {
                                            s = F;
                                            var _ = s.child;
                                            switch (s.tag) {
                                                case 0:
                                                case 11:
                                                case 14:
                                                case 15:
                                                    ln(4, s, s.return);
                                                    break;
                                                case 1:
                                                    qr(s, s.return);
                                                    var U = s.stateNode;
                                                    if (typeof U.componentWillUnmount == "function") {
                                                        var G = s.return;
                                                        try {
                                                            U.props = s.memoizedProps, U.state = s.memoizedState, U.componentWillUnmount()
                                                        } catch (Z) {
                                                            Ze(s, G, Z)
                                                        }
                                                    }
                                                    break;
                                                case 5:
                                                    qr(s, s.return);
                                                    break;
                                                case 22:
                                                    if (s.memoizedState !== null) {
                                                        ia(i);
                                                        continue
                                                    }
                                            }
                                            _ !== null ? (_.return = s, F = _) : ia(i)
                                        }
                                        R = R.sibling
                                    }
                                }
                        }
                        switch (E & 4102) {
                            case 2:
                                ea(t), t.flags &= -3;
                                break;
                            case 6:
                                ea(t), t.flags &= -3, ws(t.alternate, t);
                                break;
                            case 4096:
                                t.flags &= -4097;
                                break;
                            case 4100:
                                t.flags &= -4097, ws(t.alternate, t);
                                break;
                            case 4:
                                ws(t.alternate, t)
                        }
                    } catch (Z) {
                        Ze(t, t.return, Z)
                    }
                    if (i = t.sibling, i !== null) {
                        i.return = t.return, F = i;
                        break
                    }
                    F = t.return
                }
        }
    }

    function Tf(e, t, i) {
        F = e, na(e)
    }

    function na(e, t, i) {
        for (var s = (e.mode & 1) !== 0; F !== null;) {
            var o = F,
                u = o.child;
            if (o.tag === 22 && s) {
                var m = o.memoizedState !== null || Zr;
                if (!m) {
                    var E = o.alternate,
                        L = E !== null && E.memoizedState !== null || sn;
                    E = Zr;
                    var O = sn;
                    if (Zr = m, (sn = L) && !O)
                        for (F = o; F !== null;) m = F, L = m.child, m.tag === 22 && m.memoizedState !== null ? sa(o) : L !== null ? (L.return = m, F = L) : sa(o);
                    for (; u !== null;) F = u, na(u), u = u.sibling;
                    F = o, Zr = E, sn = O
                }
                ra(e)
            } else o.subtreeFlags & 8772 && u !== null ? (u.return = o, F = u) : ra(e)
        }
    }

    function ra(e) {
        for (; F !== null;) {
            var t = F;
            if (t.flags & 8772) {
                var i = t.alternate;
                try {
                    if (t.flags & 8772) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            sn || or(5, t);
                            break;
                        case 1:
                            var s = t.stateNode;
                            if (t.flags & 4 && !sn)
                                if (i === null) s.componentDidMount();
                                else {
                                    var o = t.elementType === t.type ? i.memoizedProps : mt(t.type, i.memoizedProps);
                                    s.componentDidUpdate(o, i.memoizedState, s.__reactInternalSnapshotBeforeUpdate)
                                }
                            var u = t.updateQueue;
                            u !== null && Zl(t, u, s);
                            break;
                        case 3:
                            var m = t.updateQueue;
                            if (m !== null) {
                                if (i = null, t.child !== null) switch (t.child.tag) {
                                    case 5:
                                        i = ge(t.child.stateNode);
                                        break;
                                    case 1:
                                        i = t.child.stateNode
                                }
                                Zl(t, m, i)
                            }
                            break;
                        case 5:
                            var E = t.stateNode;
                            i === null && t.flags & 4 && mc(E, t.type, t.memoizedProps, t);
                            break;
                        case 6:
                            break;
                        case 4:
                            break;
                        case 12:
                            break;
                        case 13:
                            if (Je && t.memoizedState === null) {
                                var L = t.alternate;
                                if (L !== null) {
                                    var O = L.memoizedState;
                                    if (O !== null) {
                                        var j = O.dehydrated;
                                        j !== null && Hc(j)
                                    }
                                }
                            }
                            break;
                        case 19:
                        case 17:
                        case 21:
                        case 22:
                        case 23:
                            break;
                        default:
                            throw Error(f(163))
                    }
                    sn || t.flags & 512 && xs(t)
                } catch (ne) {
                    Ze(t, t.return, ne)
                }
            }
            if (t === e) {
                F = null;
                break
            }
            if (i = t.sibling, i !== null) {
                i.return = t.return, F = i;
                break
            }
            F = t.return
        }
    }

    function ia(e) {
        for (; F !== null;) {
            var t = F;
            if (t === e) {
                F = null;
                break
            }
            var i = t.sibling;
            if (i !== null) {
                i.return = t.return, F = i;
                break
            }
            F = t.return
        }
    }

    function sa(e) {
        for (; F !== null;) {
            var t = F;
            try {
                switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        var i = t.return;
                        try {
                            or(4, t)
                        } catch (L) {
                            Ze(t, i, L)
                        }
                        break;
                    case 1:
                        var s = t.stateNode;
                        if (typeof s.componentDidMount == "function") {
                            var o = t.return;
                            try {
                                s.componentDidMount()
                            } catch (L) {
                                Ze(t, o, L)
                            }
                        }
                        var u = t.return;
                        try {
                            xs(t)
                        } catch (L) {
                            Ze(t, u, L)
                        }
                        break;
                    case 5:
                        var m = t.return;
                        try {
                            xs(t)
                        } catch (L) {
                            Ze(t, m, L)
                        }
                }
            } catch (L) {
                Ze(t, t.return, L)
            }
            if (t === e) {
                F = null;
                break
            }
            var E = t.sibling;
            if (E !== null) {
                E.return = t.return, F = E;
                break
            }
            F = t.return
        }
    }
    var $r = 0,
        ei = 1,
        ti = 2,
        ni = 3,
        ri = 4;
    if (typeof Symbol == "function" && Symbol.for) {
        var ar = Symbol.for;
        $r = ar("selector.component"), ei = ar("selector.has_pseudo_class"), ti = ar("selector.role"), ni = ar("selector.test_id"), ri = ar("selector.text")
    }

    function Ts(e) {
        var t = tc(e);
        if (t != null) {
            if (typeof t.memoizedProps["data-testname"] != "string") throw Error(f(364));
            return t
        }
        if (e = oc(e), e === null) throw Error(f(362));
        return e.stateNode.current
    }

    function Ms(e, t) {
        switch (t.$$typeof) {
            case $r:
                if (e.type === t.value) return !0;
                break;
            case ei:
                e: {
                    t = t.value,
                    e = [e, 0];
                    for (var i = 0; i < e.length;) {
                        var s = e[i++],
                            o = e[i++],
                            u = t[o];
                        if (s.tag !== 5 || !Vn(s)) {
                            for (; u != null && Ms(s, u);) o++, u = t[o];
                            if (o === t.length) {
                                t = !0;
                                break e
                            } else
                                for (s = s.child; s !== null;) e.push(s, o), s = s.sibling
                        }
                    }
                    t = !1
                }
                return t;
            case ti:
                if (e.tag === 5 && cc(e.stateNode, t.value)) return !0;
                break;
            case ri:
                if ((e.tag === 5 || e.tag === 6) && (e = uc(e), e !== null && 0 <= e.indexOf(t.value))) return !0;
                break;
            case ni:
                if (e.tag === 5 && (e = e.memoizedProps["data-testname"], typeof e == "string" && e.toLowerCase() === t.value.toLowerCase())) return !0;
                break;
            default:
                throw Error(f(365))
        }
        return !1
    }

    function Rs(e) {
        switch (e.$$typeof) {
            case $r:
                return "<" + (te(e.value) || "Unknown") + ">";
            case ei:
                return ":has(" + (Rs(e) || "") + ")";
            case ti:
                return '[role="' + e.value + '"]';
            case ri:
                return '"' + e.value + '"';
            case ni:
                return '[data-testname="' + e.value + '"]';
            default:
                throw Error(f(365))
        }
    }

    function la(e, t) {
        var i = [];
        e = [e, 0];
        for (var s = 0; s < e.length;) {
            var o = e[s++],
                u = e[s++],
                m = t[u];
            if (o.tag !== 5 || !Vn(o)) {
                for (; m != null && Ms(o, m);) u++, m = t[u];
                if (u === t.length) i.push(o);
                else
                    for (o = o.child; o !== null;) e.push(o, u), o = o.sibling
            }
        }
        return i
    }

    function Ps(e, t) {
        if (!bn) throw Error(f(363));
        e = Ts(e), e = la(e, t), t = [], e = Array.from(e);
        for (var i = 0; i < e.length;) {
            var s = e[i++];
            if (s.tag === 5) Vn(s) || t.push(s.stateNode);
            else
                for (s = s.child; s !== null;) e.push(s), s = s.sibling
        }
        return t
    }
    var Mf = Math.ceil,
        ii = g.ReactCurrentDispatcher,
        Cs = g.ReactCurrentOwner,
        Pe = g.ReactCurrentBatchConfig,
        oe = 0,
        Ue = null,
        Le = null,
        Oe = 0,
        nt = 0,
        Mn = kt(0),
        De = 0,
        ur = null,
        Rn = 0,
        si = 0,
        Us = 0,
        cr = null,
        Ke = null,
        Ls = 0,
        Ds = 1 / 0;

    function Pn() {
        Ds = ze() + 500
    }
    var li = !1,
        Is = null,
        jt = null,
        oi = !1,
        bt = null,
        ai = 0,
        fr = 0,
        zs = null,
        ui = -1,
        ci = 0;

    function We() {
        return oe & 6 ? ze() : ui !== -1 ? ui : ui = ze()
    }

    function Vt(e) {
        return e.mode & 1 ? oe & 2 && Oe !== 0 ? Oe & -Oe : of .transition !== null ? (ci === 0 && (e = wr, wr <<= 1, !(wr & 4194240) && (wr = 64), ci = e), ci) : (e = ce, e !== 0 ? e : rc()) : 1
    }

    function ut(e, t, i) {
        if (50 < fr) throw fr = 0, zs = null, Error(f(185));
        var s = fi(e, t);
        return s === null ? null : (Kn(s, t, i), (!(oe & 2) || s !== Ue) && (s === Ue && (!(oe & 2) && (si |= t), De === 4 && Wt(s, Oe)), Ye(s, i), t === 1 && oe === 0 && !(e.mode & 1) && (Pn(), Pr && _t())), s)
    }

    function fi(e, t) {
        e.lanes |= t;
        var i = e.alternate;
        for (i !== null && (i.lanes |= t), i = e, e = e.return; e !== null;) e.childLanes |= t, i = e.alternate, i !== null && (i.childLanes |= t), i = e, e = e.return;
        return i.tag === 3 ? i.stateNode : null
    }

    function Ye(e, t) {
        var i = e.callbackNode;
        qc(e, t);
        var s = Mr(e, e === Ue ? Oe : 0);
        if (s === 0) i !== null && Wl(i), e.callbackNode = null, e.callbackPriority = 0;
        else if (t = s & -s, e.callbackPriority !== t) {
            if (i != null && Wl(i), t === 1) e.tag === 0 ? lf(aa.bind(null, e)) : Ql(aa.bind(null, e)), sc ? lc(function() {
                oe === 0 && _t()
            }) : Gi(ji, _t), i = null;
            else {
                switch (Vl(s)) {
                    case 1:
                        i = ji;
                        break;
                    case 4:
                        i = tf;
                        break;
                    case 16:
                        i = bi;
                        break;
                    case 536870912:
                        i = nf;
                        break;
                    default:
                        i = bi
                }
                i = ga(i, oa.bind(null, e))
            }
            e.callbackPriority = t, e.callbackNode = i
        }
    }

    function oa(e, t) {
        if (ui = -1, ci = 0, oe & 6) throw Error(f(327));
        var i = e.callbackNode;
        if (un() && e.callbackNode !== i) return null;
        var s = Mr(e, e === Ue ? Oe : 0);
        if (s === 0) return null;
        if (s & 30 || s & e.expiredLanes || t) t = di(e, s);
        else {
            t = s;
            var o = oe;
            oe |= 2;
            var u = fa();
            (Ue !== e || Oe !== t) && (Pn(), on(e, t));
            do try {
                Cf();
                break
            } catch (E) {
                ca(e, E)
            }
            while (1);
            Qi(), ii.current = u, oe = o, Le !== null ? t = 0 : (Ue = null, Oe = 0, t = De)
        }
        if (t !== 0) {
            if (t === 2 && (o = ki(e), o !== 0 && (s = o, t = As(e, o))), t === 1) throw i = ur, on(e, 0), Wt(e, s), Ye(e, ze()), i;
            if (t === 6) Wt(e, s);
            else {
                if (o = e.current.alternate, !(s & 30) && !Rf(o) && (t = di(e, s), t === 2 && (u = ki(e), u !== 0 && (s = u, t = As(e, u))), t === 1)) throw i = ur, on(e, 0), Wt(e, s), Ye(e, ze()), i;
                switch (e.finishedWork = o, e.finishedLanes = s, t) {
                    case 0:
                    case 1:
                        throw Error(f(345));
                    case 2:
                        an(e, Ke);
                        break;
                    case 3:
                        if (Wt(e, s), (s & 130023424) === s && (t = Ls + 500 - ze(), 10 < t)) {
                            if (Mr(e, 0) !== 0) break;
                            if (o = e.suspendedLanes, (o & s) !== s) {
                                We(), e.pingedLanes |= e.suspendedLanes & o;
                                break
                            }
                            e.timeoutHandle = Re(an.bind(null, e, Ke), t);
                            break
                        }
                        an(e, Ke);
                        break;
                    case 4:
                        if (Wt(e, s), (s & 4194240) === s) break;
                        for (t = e.eventTimes, o = -1; 0 < s;) {
                            var m = 31 - vt(s);
                            u = 1 << m, m = t[m], m > o && (o = m), s &= ~u
                        }
                        if (s = o, s = ze() - s, s = (120 > s ? 120 : 480 > s ? 480 : 1080 > s ? 1080 : 1920 > s ? 1920 : 3e3 > s ? 3e3 : 4320 > s ? 4320 : 1960 * Mf(s / 1960)) - s, 10 < s) {
                            e.timeoutHandle = Re(an.bind(null, e, Ke), s);
                            break
                        }
                        an(e, Ke);
                        break;
                    case 5:
                        an(e, Ke);
                        break;
                    default:
                        throw Error(f(329))
                }
            }
        }
        return Ye(e, ze()), e.callbackNode === i ? oa.bind(null, e) : null
    }

    function As(e, t) {
        var i = cr;
        return e.current.memoizedState.isDehydrated && (on(e, t).flags |= 256), e = di(e, t), e !== 2 && (t = Ke, Ke = i, t !== null && Bs(t)), e
    }

    function Bs(e) {
        Ke === null ? Ke = e : Ke.push.apply(Ke, e)
    }

    function Rf(e) {
        for (var t = e;;) {
            if (t.flags & 16384) {
                var i = t.updateQueue;
                if (i !== null && (i = i.stores, i !== null))
                    for (var s = 0; s < i.length; s++) {
                        var o = i[s],
                            u = o.getSnapshot;
                        o = o.value;
                        try {
                            if (!Et(u(), o)) return !1
                        } catch {
                            return !1
                        }
                    }
            }
            if (i = t.child, t.subtreeFlags & 16384 && i !== null) i.return = t, t = i;
            else {
                if (t === e) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === e) return !0;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
        }
        return !0
    }

    function Wt(e, t) {
        for (t &= ~Us, t &= ~si, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
            var i = 31 - vt(t),
                s = 1 << i;
            e[i] = -1, t &= ~s
        }
    }

    function aa(e) {
        if (oe & 6) throw Error(f(327));
        un();
        var t = Mr(e, 0);
        if (!(t & 1)) return Ye(e, ze()), null;
        var i = di(e, t);
        if (e.tag !== 0 && i === 2) {
            var s = ki(e);
            s !== 0 && (t = s, i = As(e, s))
        }
        if (i === 1) throw i = ur, on(e, 0), Wt(e, t), Ye(e, ze()), i;
        if (i === 6) throw Error(f(345));
        return e.finishedWork = e.current.alternate, e.finishedLanes = t, an(e, Ke), Ye(e, ze()), null
    }

    function ua(e) {
        bt !== null && bt.tag === 0 && !(oe & 6) && un();
        var t = oe;
        oe |= 1;
        var i = Pe.transition,
            s = ce;
        try {
            if (Pe.transition = null, ce = 1, e) return e()
        } finally {
            ce = s, Pe.transition = i, oe = t, !(oe & 6) && _t()
        }
    }

    function Ns() {
        nt = Mn.current, xe(Mn)
    }

    function on(e, t) {
        e.finishedWork = null, e.finishedLanes = 0;
        var i = e.timeoutHandle;
        if (i !== jn && (e.timeoutHandle = jn, Ii(i)), Le !== null)
            for (i = Le.return; i !== null;) {
                var s = i;
                switch ($i(s), s.tag) {
                    case 1:
                        s = s.type.childContextTypes, s != null && Er();
                        break;
                    case 3:
                        wn(), xe(Qe), xe(ke), ls();
                        break;
                    case 5:
                        is(s);
                        break;
                    case 4:
                        wn();
                        break;
                    case 13:
                        xe(Te);
                        break;
                    case 19:
                        xe(Te);
                        break;
                    case 10:
                        Xi(s.type._context);
                        break;
                    case 22:
                    case 23:
                        Ns()
                }
                i = i.return
            }
        if (Ue = e, Le = e = Qt(e.current, null), Oe = nt = t, De = 0, ur = null, Us = si = Rn = 0, Ke = cr = null, wt !== null) {
            for (t = 0; t < wt.length; t++)
                if (i = wt[t], s = i.interleaved, s !== null) {
                    i.interleaved = null;
                    var o = s.next,
                        u = i.pending;
                    if (u !== null) {
                        var m = u.next;
                        u.next = o, s.next = m
                    }
                    i.pending = s
                }
            wt = null
        }
        return e
    }

    function ca(e, t) {
        do {
            var i = Le;
            try {
                if (Qi(), kr.current = Vr, Fr) {
                    for (var s = Me.memoizedState; s !== null;) {
                        var o = s.queue;
                        o !== null && (o.pending = null), s = s.next
                    }
                    Fr = !1
                }
                if (Tn = 0, Ae = Fe = Me = null, er = !1, tr = 0, Cs.current = null, i === null || i.return === null) {
                    De = 1, ur = t, Le = null;
                    break
                }
                e: {
                    var u = e,
                        m = i.return,
                        E = i,
                        L = t;
                    if (t = Oe, E.flags |= 32768, L !== null && typeof L == "object" && typeof L.then == "function") {
                        var O = L,
                            j = E,
                            ne = j.tag;
                        if (!(j.mode & 1) && (ne === 0 || ne === 11 || ne === 15)) {
                            var $ = j.alternate;
                            $ ? (j.updateQueue = $.updateQueue, j.memoizedState = $.memoizedState, j.lanes = $.lanes) : (j.updateQueue = null, j.memoizedState = null)
                        }
                        var me = Do(m);
                        if (me !== null) {
                            me.flags &= -257, Io(me, m, E, u, t), me.mode & 1 && Lo(u, O, t), t = me, L = O;
                            var J = t.updateQueue;
                            if (J === null) {
                                var je = new Set;
                                je.add(L), t.updateQueue = je
                            } else J.add(L);
                            break e
                        } else {
                            if (!(t & 1)) {
                                Lo(u, O, t), Os();
                                break e
                            }
                            L = Error(f(426))
                        }
                    } else if (_e && E.mode & 1) {
                        var ft = Do(m);
                        if (ft !== null) {
                            !(ft.flags & 65536) && (ft.flags |= 256), Io(ft, m, E, u, t), ns(L);
                            break e
                        }
                    }
                    u = L,
                    De !== 4 && (De = 2),
                    cr === null ? cr = [u] : cr.push(u),
                    L = hs(L, E),
                    E = m;do {
                        switch (E.tag) {
                            case 3:
                                E.flags |= 65536, t &= -t, E.lanes |= t;
                                var R = Co(E, L, t);
                                Yl(E, R);
                                break e;
                            case 1:
                                u = L;
                                var _ = E.type,
                                    U = E.stateNode;
                                if (!(E.flags & 128) && (typeof _.getDerivedStateFromError == "function" || U !== null && typeof U.componentDidCatch == "function" && (jt === null || !jt.has(U)))) {
                                    E.flags |= 65536, t &= -t, E.lanes |= t;
                                    var G = Uo(E, u, t);
                                    Yl(E, G);
                                    break e
                                }
                        }
                        E = E.return
                    } while (E !== null)
                }
                ha(i)
            } catch (Z) {
                t = Z, Le === i && i !== null && (Le = i = i.return);
                continue
            }
            break
        } while (1)
    }

    function fa() {
        var e = ii.current;
        return ii.current = Vr, e === null ? Vr : e
    }

    function Os() {
        (De === 0 || De === 3 || De === 2) && (De = 4), Ue === null || !(Rn & 268435455) && !(si & 268435455) || Wt(Ue, Oe)
    }

    function di(e, t) {
        var i = oe;
        oe |= 2;
        var s = fa();
        Ue === e && Oe === t || on(e, t);
        do try {
            Pf();
            break
        } catch (o) {
            ca(e, o)
        }
        while (1);
        if (Qi(), oe = i, ii.current = s, Le !== null) throw Error(f(261));
        return Ue = null, Oe = 0, De
    }

    function Pf() {
        for (; Le !== null;) da(Le)
    }

    function Cf() {
        for (; Le !== null && !$c();) da(Le)
    }

    function da(e) {
        var t = ma(e.alternate, e, nt);
        e.memoizedProps = e.pendingProps, t === null ? ha(e) : Le = t, Cs.current = null
    }

    function ha(e) {
        var t = e;
        do {
            var i = t.alternate;
            if (e = t.return, t.flags & 32768) {
                if (i = xf(i, t), i !== null) {
                    i.flags &= 32767, Le = i;
                    return
                }
                if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
                else {
                    De = 6, Le = null;
                    return
                }
            } else if (i = gf(i, t, nt), i !== null) {
                Le = i;
                return
            }
            if (t = t.sibling, t !== null) {
                Le = t;
                return
            }
            Le = t = e
        } while (t !== null);
        De === 0 && (De = 5)
    }

    function an(e, t) {
        var i = ce,
            s = Pe.transition;
        try {
            Pe.transition = null, ce = 1, Uf(e, t, i)
        } finally {
            Pe.transition = s, ce = i
        }
        return null
    }

    function Uf(e, t, i) {
        do un(); while (bt !== null);
        if (oe & 6) throw Error(f(327));
        var s = e.finishedWork,
            o = e.finishedLanes;
        if (s === null) return null;
        if (e.finishedWork = null, e.finishedLanes = 0, s === e.current) throw Error(f(177));
        e.callbackNode = null, e.callbackPriority = 0;
        var u = s.lanes | s.childLanes;
        if (Jc(e, u), e === Ue && (Le = Ue = null, Oe = 0), !(s.subtreeFlags & 2064) && !(s.flags & 2064) || oi || (oi = !0, ga(bi, function() {
                return un(), null
            })), u = (s.flags & 15990) !== 0, s.subtreeFlags & 15990 || u) {
            u = Pe.transition, Pe.transition = null;
            var m = ce;
            ce = 1;
            var E = oe;
            oe |= 4, Cs.current = null, _f(e, s), wf(e, s), N(e.containerInfo), e.current = s, Tf(s), ef(), oe = E, ce = m, Pe.transition = u
        } else e.current = s;
        if (oi && (oi = !1, bt = e, ai = o), u = e.pendingLanes, u === 0 && (jt = null), rf(s.stateNode), Ye(e, ze()), t !== null)
            for (i = e.onRecoverableError, s = 0; s < t.length; s++) i(t[s]);
        if (li) throw li = !1, e = Is, Is = null, e;
        return ai & 1 && e.tag !== 0 && un(), u = e.pendingLanes, u & 1 ? e === zs ? fr++ : (fr = 0, zs = e) : fr = 0, _t(), null
    }

    function un() {
        if (bt !== null) {
            var e = Vl(ai),
                t = Pe.transition,
                i = ce;
            try {
                if (Pe.transition = null, ce = 16 > e ? 16 : e, bt === null) var s = !1;
                else {
                    if (e = bt, bt = null, ai = 0, oe & 6) throw Error(f(331));
                    var o = oe;
                    for (oe |= 4, F = e.current; F !== null;) {
                        var u = F,
                            m = u.child;
                        if (F.flags & 16) {
                            var E = u.deletions;
                            if (E !== null) {
                                for (var L = 0; L < E.length; L++) {
                                    var O = E[L];
                                    for (F = O; F !== null;) {
                                        var j = F;
                                        switch (j.tag) {
                                            case 0:
                                            case 11:
                                            case 15:
                                                ln(8, j, u)
                                        }
                                        var ne = j.child;
                                        if (ne !== null) ne.return = j, F = ne;
                                        else
                                            for (; F !== null;) {
                                                j = F;
                                                var $ = j.sibling,
                                                    me = j.return;
                                                if (qo(j), j === O) {
                                                    F = null;
                                                    break
                                                }
                                                if ($ !== null) {
                                                    $.return = me, F = $;
                                                    break
                                                }
                                                F = me
                                            }
                                    }
                                }
                                var J = u.alternate;
                                if (J !== null) {
                                    var je = J.child;
                                    if (je !== null) {
                                        J.child = null;
                                        do {
                                            var ft = je.sibling;
                                            je.sibling = null, je = ft
                                        } while (je !== null)
                                    }
                                }
                                F = u
                            }
                        }
                        if (u.subtreeFlags & 2064 && m !== null) m.return = u, F = m;
                        else e: for (; F !== null;) {
                            if (u = F, u.flags & 2048) switch (u.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    ln(9, u, u.return)
                            }
                            var R = u.sibling;
                            if (R !== null) {
                                R.return = u.return, F = R;
                                break e
                            }
                            F = u.return
                        }
                    }
                    var _ = e.current;
                    for (F = _; F !== null;) {
                        m = F;
                        var U = m.child;
                        if (m.subtreeFlags & 2064 && U !== null) U.return = m, F = U;
                        else e: for (m = _; F !== null;) {
                            if (E = F, E.flags & 2048) try {
                                switch (E.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        or(9, E)
                                }
                            } catch (Z) {
                                Ze(E, E.return, Z)
                            }
                            if (E === m) {
                                F = null;
                                break e
                            }
                            var G = E.sibling;
                            if (G !== null) {
                                G.return = E.return, F = G;
                                break e
                            }
                            F = E.return
                        }
                    }
                    if (oe = o, _t(), xt && typeof xt.onPostCommitFiberRoot == "function") try {
                        xt.onPostCommitFiberRoot(Rr, e)
                    } catch {}
                    s = !0
                }
                return s
            } finally {
                ce = i, Pe.transition = t
            }
        }
        return !1
    }

    function pa(e, t, i) {
        t = hs(i, t), t = Co(e, t, 1), Gt(e, t), t = We(), e = fi(e, 1), e !== null && (Kn(e, 1, t), Ye(e, t))
    }

    function Ze(e, t, i) {
        if (e.tag === 3) pa(e, e, i);
        else
            for (; t !== null;) {
                if (t.tag === 3) {
                    pa(t, e, i);
                    break
                } else if (t.tag === 1) {
                    var s = t.stateNode;
                    if (typeof t.type.getDerivedStateFromError == "function" || typeof s.componentDidCatch == "function" && (jt === null || !jt.has(s))) {
                        e = hs(i, e), e = Uo(t, e, 1), Gt(t, e), e = We(), t = fi(t, 1), t !== null && (Kn(t, 1, e), Ye(t, e));
                        break
                    }
                }
                t = t.return
            }
    }

    function Lf(e, t, i) {
        var s = e.pingCache;
        s !== null && s.delete(t), t = We(), e.pingedLanes |= e.suspendedLanes & i, Ue === e && (Oe & i) === i && (De === 4 || De === 3 && (Oe & 130023424) === Oe && 500 > ze() - Ls ? on(e, 0) : Us |= i), Ye(e, t)
    }

    function va(e, t) {
        t === 0 && (e.mode & 1 ? (t = Tr, Tr <<= 1, !(Tr & 130023424) && (Tr = 4194304)) : t = 1);
        var i = We();
        e = fi(e, t), e !== null && (Kn(e, t, i), Ye(e, i))
    }

    function Df(e) {
        var t = e.memoizedState,
            i = 0;
        t !== null && (i = t.retryLane), va(e, i)
    }

    function If(e, t) {
        var i = 0;
        switch (e.tag) {
            case 13:
                var s = e.stateNode,
                    o = e.memoizedState;
                o !== null && (i = o.retryLane);
                break;
            case 19:
                s = e.stateNode;
                break;
            default:
                throw Error(f(314))
        }
        s !== null && s.delete(t), va(e, i)
    }
    var ma;
    ma = function(e, t, i) {
        if (e !== null)
            if (e.memoizedProps !== t.pendingProps || Qe.current) tt = !0;
            else {
                if (!(e.lanes & i) && !(t.flags & 128)) return tt = !1, Sf(e, t, i);
                tt = !!(e.flags & 131072)
            }
        else tt = !1, _e && t.flags & 1048576 && to(t, Br, t.index);
        switch (t.lanes = 0, t.tag) {
            case 2:
                var s = t.type;
                e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps;
                var o = vn(t, ke.current);
                gn(t, i), o = as(null, t, s, e, o, i);
                var u = us();
                return t.flags |= 1, typeof o == "object" && o !== null && typeof o.render == "function" && o.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Xe(s) ? (u = !0, _r(t)) : u = !1, t.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, Yi(t), o.updater = zr, t.stateNode = o, o._reactInternals = t, qi(t, s, e, i), t = ms(null, t, s, !0, u, i)) : (t.tag = 0, _e && u && Ji(t), Ve(null, t, o, i), t = t.child), t;
            case 16:
                s = t.elementType;
                e: {
                    switch (e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps, o = s._init, s = o(s._payload), t.type = s, o = t.tag = Af(s), e = mt(s, e), o) {
                        case 0:
                            t = vs(null, t, s, e, i);
                            break e;
                        case 1:
                            t = Ho(null, t, s, e, i);
                            break e;
                        case 11:
                            t = Bo(null, t, s, e, i);
                            break e;
                        case 14:
                            t = No(null, t, s, mt(s.type, e), i);
                            break e
                    }
                    throw Error(f(306, s, ""))
                }
                return t;
            case 0:
                return s = t.type, o = t.pendingProps, o = t.elementType === s ? o : mt(s, o), vs(e, t, s, o, i);
            case 1:
                return s = t.type, o = t.pendingProps, o = t.elementType === s ? o : mt(s, o), Ho(e, t, s, o, i);
            case 3:
                e: {
                    if (Go(t), e === null) throw Error(f(387));s = t.pendingProps,
                    u = t.memoizedState,
                    o = u.element,
                    Kl(e, t),
                    Ir(t, s, null, i);
                    var m = t.memoizedState;
                    if (s = m.element, Je && u.isDehydrated)
                        if (u = {
                                element: s,
                                isDehydrated: !1,
                                cache: m.cache,
                                transitions: m.transitions
                            }, t.updateQueue.baseState = u, t.memoizedState = u, t.flags & 256) {
                            o = Error(f(423)), t = jo(e, t, s, i, o);
                            break e
                        } else if (s !== o) {
                        o = Error(f(424)), t = jo(e, t, s, i, o);
                        break e
                    } else
                        for (Je && (et = Ac(t.stateNode.containerInfo), $e = t, _e = !0, gt = null, Yn = !1), i = oo(t, null, s, i), t.child = i; i;) i.flags = i.flags & -3 | 4096, i = i.sibling;
                    else {
                        if (xn(), s === o) {
                            t = At(e, t, i);
                            break e
                        }
                        Ve(e, t, s, i)
                    }
                    t = t.child
                }
                return t;
            case 5:
                return ao(t), e === null && ts(t), s = t.type, o = t.pendingProps, u = e !== null ? e.memoizedProps : null, m = o.children, ee(s, o) ? m = null : u !== null && ee(s, u) && (t.flags |= 32), Fo(e, t), Ve(e, t, m, i), t.child;
            case 6:
                return e === null && ts(t), null;
            case 13:
                return bo(e, t, i);
            case 4:
                return rs(t, t.stateNode.containerInfo), s = t.pendingProps, e === null ? t.child = En(t, null, s, i) : Ve(e, t, s, i), t.child;
            case 11:
                return s = t.type, o = t.pendingProps, o = t.elementType === s ? o : mt(s, o), Bo(e, t, s, o, i);
            case 7:
                return Ve(e, t, t.pendingProps, i), t.child;
            case 8:
                return Ve(e, t, t.pendingProps.children, i), t.child;
            case 12:
                return Ve(e, t, t.pendingProps.children, i), t.child;
            case 10:
                e: {
                    if (s = t.type._context, o = t.pendingProps, u = t.memoizedProps, m = o.value, Xl(t, s, m), u !== null)
                        if (Et(u.value, m)) {
                            if (u.children === o.children && !Qe.current) {
                                t = At(e, t, i);
                                break e
                            }
                        } else
                            for (u = t.child, u !== null && (u.return = t); u !== null;) {
                                var E = u.dependencies;
                                if (E !== null) {
                                    m = u.child;
                                    for (var L = E.firstContext; L !== null;) {
                                        if (L.context === s) {
                                            if (u.tag === 1) {
                                                L = Lt(-1, i & -i), L.tag = 2;
                                                var O = u.updateQueue;
                                                if (O !== null) {
                                                    O = O.shared;
                                                    var j = O.pending;
                                                    j === null ? L.next = L : (L.next = j.next, j.next = L), O.pending = L
                                                }
                                            }
                                            u.lanes |= i, L = u.alternate, L !== null && (L.lanes |= i), Ki(u.return, i, t), E.lanes |= i;
                                            break
                                        }
                                        L = L.next
                                    }
                                } else if (u.tag === 10) m = u.type === t.type ? null : u.child;
                                else if (u.tag === 18) {
                                    if (m = u.return, m === null) throw Error(f(341));
                                    m.lanes |= i, E = m.alternate, E !== null && (E.lanes |= i), Ki(m, i, t), m = u.sibling
                                } else m = u.child;
                                if (m !== null) m.return = u;
                                else
                                    for (m = u; m !== null;) {
                                        if (m === t) {
                                            m = null;
                                            break
                                        }
                                        if (u = m.sibling, u !== null) {
                                            u.return = m.return, m = u;
                                            break
                                        }
                                        m = m.return
                                    }
                                u = m
                            }
                    Ve(e, t, o.children, i),
                    t = t.child
                }
                return t;
            case 9:
                return o = t.type, s = t.pendingProps.children, gn(t, i), o = it(o), s = s(o), t.flags |= 1, Ve(e, t, s, i), t.child;
            case 14:
                return s = t.type, o = mt(s, t.pendingProps), o = mt(s.type, o), No(e, t, s, o, i);
            case 15:
                return Oo(e, t, t.type, t.pendingProps, i);
            case 17:
                return s = t.type, o = t.pendingProps, o = t.elementType === s ? o : mt(s, o), e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), t.tag = 1, Xe(s) ? (e = !0, _r(t)) : e = !1, gn(t, i), $l(t, s, o), qi(t, s, o, i), ms(null, t, s, !0, e, i);
            case 19:
                return Xo(e, t, i);
            case 22:
                return ko(e, t, i)
        }
        throw Error(f(156, t.tag))
    };

    function ga(e, t) {
        return Gi(e, t)
    }

    function zf(e, t, i, s) {
        this.tag = e, this.key = i, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = s, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function ct(e, t, i, s) {
        return new zf(e, t, i, s)
    }

    function ks(e) {
        return e = e.prototype, !(!e || !e.isReactComponent)
    }

    function Af(e) {
        if (typeof e == "function") return ks(e) ? 1 : 0;
        if (e != null) {
            if (e = e.$$typeof, e === z) return 11;
            if (e === T) return 14
        }
        return 2
    }

    function Qt(e, t) {
        var i = e.alternate;
        return i === null ? (i = ct(e.tag, t, e.key, e.mode), i.elementType = e.elementType, i.type = e.type, i.stateNode = e.stateNode, i.alternate = e, e.alternate = i) : (i.pendingProps = t, i.type = e.type, i.flags = 0, i.subtreeFlags = 0, i.deletions = null), i.flags = e.flags & 14680064, i.childLanes = e.childLanes, i.lanes = e.lanes, i.child = e.child, i.memoizedProps = e.memoizedProps, i.memoizedState = e.memoizedState, i.updateQueue = e.updateQueue, t = e.dependencies, i.dependencies = t === null ? null : {
            lanes: t.lanes,
            firstContext: t.firstContext
        }, i.sibling = e.sibling, i.index = e.index, i.ref = e.ref, i
    }

    function hi(e, t, i, s, o, u) {
        var m = 2;
        if (s = e, typeof e == "function") ks(e) && (m = 1);
        else if (typeof e == "string") m = 5;
        else e: switch (e) {
            case v:
                return cn(i.children, o, u, t);
            case p:
                m = 8, o |= 8;
                break;
            case S:
                return e = ct(12, i, t, o | 2), e.elementType = S, e.lanes = u, e;
            case I:
                return e = ct(13, i, t, o), e.elementType = I, e.lanes = u, e;
            case C:
                return e = ct(19, i, t, o), e.elementType = C, e.lanes = u, e;
            case H:
                return pi(i, o, u, t);
            default:
                if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                    case x:
                        m = 10;
                        break e;
                    case w:
                        m = 9;
                        break e;
                    case z:
                        m = 11;
                        break e;
                    case T:
                        m = 14;
                        break e;
                    case D:
                        m = 16, s = null;
                        break e
                }
                throw Error(f(130, e == null ? e : typeof e, ""))
        }
        return t = ct(m, i, t, o), t.elementType = e, t.type = s, t.lanes = u, t
    }

    function cn(e, t, i, s) {
        return e = ct(7, e, s, t), e.lanes = i, e
    }

    function pi(e, t, i, s) {
        return e = ct(22, e, s, t), e.elementType = H, e.lanes = i, e.stateNode = {}, e
    }

    function Fs(e, t, i) {
        return e = ct(6, e, null, t), e.lanes = i, e
    }

    function Hs(e, t, i) {
        return t = ct(4, e.children !== null ? e.children : [], e.key, t), t.lanes = i, t.stateNode = {
            containerInfo: e.containerInfo,
            pendingChildren: null,
            implementation: e.implementation
        }, t
    }

    function Bf(e, t, i, s, o) {
        this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = jn, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Fi(0), this.expirationTimes = Fi(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Fi(0), this.identifierPrefix = s, this.onRecoverableError = o, Je && (this.mutableSourceEagerHydrationData = null)
    }

    function ya(e, t, i, s, o, u, m, E, L) {
        return e = new Bf(e, t, i, E, L), t === 1 ? (t = 1, u === !0 && (t |= 8)) : t = 0, u = ct(3, null, null, t), e.current = u, u.stateNode = e, u.memoizedState = {
            element: s,
            isDehydrated: i,
            cache: null,
            transitions: null
        }, Yi(u), e
    }

    function Sa(e) {
        if (!e) return Ft;
        e = e._reactInternals;
        e: {
            if (q(e) !== e || e.tag !== 1) throw Error(f(170));
            var t = e;do {
                switch (t.tag) {
                    case 3:
                        t = t.stateNode.context;
                        break e;
                    case 1:
                        if (Xe(t.type)) {
                            t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                            break e
                        }
                }
                t = t.return
            } while (t !== null);
            throw Error(f(171))
        }
        if (e.tag === 1) {
            var i = e.type;
            if (Xe(i)) return jl(e, i, t)
        }
        return t
    }

    function xa(e) {
        var t = e._reactInternals;
        if (t === void 0) throw typeof e.render == "function" ? Error(f(188)) : (e = Object.keys(e).join(","), Error(f(268, e)));
        return e = Y(t), e === null ? null : e.stateNode
    }

    function Ea(e, t) {
        if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
            var i = e.retryLane;
            e.retryLane = i !== 0 && i < t ? i : t
        }
    }

    function Gs(e, t) {
        Ea(e, t), (e = e.alternate) && Ea(e, t)
    }

    function Nf(e) {
        return e = Y(e), e === null ? null : e.stateNode
    }

    function Of() {
        return null
    }
    return l.attemptContinuousHydration = function(e) {
        if (e.tag === 13) {
            var t = We();
            ut(e, 134217728, t), Gs(e, 134217728)
        }
    }, l.attemptHydrationAtCurrentPriority = function(e) {
        if (e.tag === 13) {
            var t = We(),
                i = Vt(e);
            ut(e, i, t), Gs(e, i)
        }
    }, l.attemptSynchronousHydration = function(e) {
        switch (e.tag) {
            case 3:
                var t = e.stateNode;
                if (t.current.memoizedState.isDehydrated) {
                    var i = Xn(t.pendingLanes);
                    i !== 0 && (Hi(t, i | 1), Ye(t, ze()), !(oe & 6) && (Pn(), _t()))
                }
                break;
            case 13:
                var s = We();
                ua(function() {
                    return ut(e, 1, s)
                }), Gs(e, 1)
        }
    }, l.batchedUpdates = function(e, t) {
        var i = oe;
        oe |= 1;
        try {
            return e(t)
        } finally {
            oe = i, oe === 0 && (Pn(), Pr && _t())
        }
    }, l.createComponentSelector = function(e) {
        return {
            $$typeof: $r,
            value: e
        }
    }, l.createContainer = function(e, t, i, s, o, u, m) {
        return ya(e, t, !1, null, i, s, o, u, m)
    }, l.createHasPseudoClassSelector = function(e) {
        return {
            $$typeof: ei,
            value: e
        }
    }, l.createHydrationContainer = function(e, t, i, s, o, u, m, E, L) {
        return e = ya(i, s, !0, e, o, u, m, E, L), e.context = Sa(null), i = e.current, s = We(), o = Vt(i), u = Lt(s, o), u.callback = t ? ? null, Gt(i, u), e.current.lanes = o, Kn(e, o, s), Ye(e, s), e
    }, l.createPortal = function(e, t, i) {
        var s = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
            $$typeof: y,
            key: s == null ? null : "" + s,
            children: e,
            containerInfo: t,
            implementation: i
        }
    }, l.createRoleSelector = function(e) {
        return {
            $$typeof: ti,
            value: e
        }
    }, l.createTestNameSelector = function(e) {
        return {
            $$typeof: ni,
            value: e
        }
    }, l.createTextSelector = function(e) {
        return {
            $$typeof: ri,
            value: e
        }
    }, l.deferredUpdates = function(e) {
        var t = ce,
            i = Pe.transition;
        try {
            return Pe.transition = null, ce = 16, e()
        } finally {
            ce = t, Pe.transition = i
        }
    }, l.discreteUpdates = function(e, t, i, s, o) {
        var u = ce,
            m = Pe.transition;
        try {
            return Pe.transition = null, ce = 1, e(t, i, s, o)
        } finally {
            ce = u, Pe.transition = m, oe === 0 && Pn()
        }
    }, l.findAllNodes = Ps, l.findBoundingRects = function(e, t) {
        if (!bn) throw Error(f(363));
        t = Ps(e, t), e = [];
        for (var i = 0; i < t.length; i++) e.push(ac(t[i]));
        for (t = e.length - 1; 0 < t; t--) {
            i = e[t];
            for (var s = i.x, o = s + i.width, u = i.y, m = u + i.height, E = t - 1; 0 <= E; E--)
                if (t !== E) {
                    var L = e[E],
                        O = L.x,
                        j = O + L.width,
                        ne = L.y,
                        $ = ne + L.height;
                    if (s >= O && u >= ne && o <= j && m <= $) {
                        e.splice(t, 1);
                        break
                    } else if (s !== O || i.width !== L.width || $ < u || ne > m) {
                        if (!(u !== ne || i.height !== L.height || j < s || O > o)) {
                            O > s && (L.width += O - s, L.x = s), j < o && (L.width = o - O), e.splice(t, 1);
                            break
                        }
                    } else {
                        ne > u && (L.height += ne - u, L.y = u), $ < m && (L.height = m - ne), e.splice(t, 1);
                        break
                    }
                }
        }
        return e
    }, l.findHostInstance = xa, l.findHostInstanceWithNoPortals = function(e) {
        return e = A(e), e = e !== null ? se(e) : null, e === null ? null : e.stateNode
    }, l.findHostInstanceWithWarning = function(e) {
        return xa(e)
    }, l.flushControlled = function(e) {
        var t = oe;
        oe |= 1;
        var i = Pe.transition,
            s = ce;
        try {
            Pe.transition = null, ce = 1, e()
        } finally {
            ce = s, Pe.transition = i, oe = t, oe === 0 && (Pn(), _t())
        }
    }, l.flushPassiveEffects = un, l.flushSync = ua, l.focusWithin = function(e, t) {
        if (!bn) throw Error(f(363));
        for (e = Ts(e), t = la(e, t), t = Array.from(t), e = 0; e < t.length;) {
            var i = t[e++];
            if (!Vn(i)) {
                if (i.tag === 5 && fc(i.stateNode)) return !0;
                for (i = i.child; i !== null;) t.push(i), i = i.sibling
            }
        }
        return !1
    }, l.getCurrentUpdatePriority = function() {
        return ce
    }, l.getFindAllNodesFailureDescription = function(e, t) {
        if (!bn) throw Error(f(363));
        var i = 0,
            s = [];
        e = [Ts(e), 0];
        for (var o = 0; o < e.length;) {
            var u = e[o++],
                m = e[o++],
                E = t[m];
            if ((u.tag !== 5 || !Vn(u)) && (Ms(u, E) && (s.push(Rs(E)), m++, m > i && (i = m)), m < t.length))
                for (u = u.child; u !== null;) e.push(u, m), u = u.sibling
        }
        if (i < t.length) {
            for (e = []; i < t.length; i++) e.push(Rs(t[i]));
            return `findAllNodes was able to match part of the selector:
  ` + (s.join(" > ") + `

No matching component was found for:
  `) + e.join(" > ")
        }
        return null
    }, l.getPublicRootInstance = function(e) {
        if (e = e.current, !e.child) return null;
        switch (e.child.tag) {
            case 5:
                return ge(e.child.stateNode);
            default:
                return e.child.stateNode
        }
    }, l.injectIntoDevTools = function(e) {
        if (e = {
                bundleType: e.bundleType,
                version: e.version,
                rendererPackageName: e.rendererPackageName,
                rendererConfig: e.rendererConfig,
                overrideHookState: null,
                overrideHookStateDeletePath: null,
                overrideHookStateRenamePath: null,
                overrideProps: null,
                overridePropsDeletePath: null,
                overridePropsRenamePath: null,
                setErrorHandler: null,
                setSuspenseHandler: null,
                scheduleUpdate: null,
                currentDispatcherRef: g.ReactCurrentDispatcher,
                findHostInstanceByFiber: Nf,
                findFiberByHostInstance: e.findFiberByHostInstance || Of,
                findHostInstancesForRefresh: null,
                scheduleRefresh: null,
                scheduleRoot: null,
                setRefreshHandler: null,
                getCurrentFiber: null,
                reconcilerVersion: "18.0.0-fc46dba67-20220329"
            }, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u") e = !1;
        else {
            var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
            if (t.isDisabled || !t.supportsFiber) e = !0;
            else {
                try {
                    Rr = t.inject(e), xt = t
                } catch {}
                e = !!t.checkDCE
            }
        }
        return e
    }, l.isAlreadyRendering = function() {
        return !1
    }, l.observeVisibleRects = function(e, t, i, s) {
        if (!bn) throw Error(f(363));
        e = Ps(e, t);
        var o = dc(e, i, s).disconnect;
        return {
            disconnect: function() {
                o()
            }
        }
    }, l.registerMutableSourceForHydration = function(e, t) {
        var i = t._getVersion;
        i = i(t._source), e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [t, i] : e.mutableSourceEagerHydrationData.push(t, i)
    }, l.runWithPriority = function(e, t) {
        var i = ce;
        try {
            return ce = e, t()
        } finally {
            ce = i
        }
    }, l.shouldError = function() {
        return null
    }, l.shouldSuspend = function() {
        return !1
    }, l.updateContainer = function(e, t, i, s) {
        var o = t.current,
            u = We(),
            m = Vt(o);
        return i = Sa(i), t.context === null ? t.context = i : t.pendingContext = i, t = Lt(u, m), t.payload = {
            element: e
        }, s = s === void 0 ? null : s, s !== null && (t.callback = s), Gt(o, t), e = ut(o, m, u), e !== null && Dr(e, o, m), m
    }, l
};
_u.exports = lp;
var op = _u.exports;
const ap = Mi(op);
var wu = {
        exports: {}
    },
    Tu = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(n) {
    function r(M, B) {
        var N = M.length;
        M.push(B);
        e: for (; 0 < N;) {
            var W = N - 1 >>> 1,
                K = M[W];
            if (0 < c(K, B)) M[W] = B, M[N] = K, N = W;
            else break e
        }
    }

    function l(M) {
        return M.length === 0 ? null : M[0]
    }

    function a(M) {
        if (M.length === 0) return null;
        var B = M[0],
            N = M.pop();
        if (N !== B) {
            M[0] = N;
            e: for (var W = 0, K = M.length, ue = K >>> 1; W < ue;) {
                var ve = 2 * (W + 1) - 1,
                    ee = M[ve],
                    pe = ve + 1,
                    Re = M[pe];
                if (0 > c(ee, N)) pe < K && 0 > c(Re, ee) ? (M[W] = Re, M[pe] = N, W = pe) : (M[W] = ee, M[ve] = N, W = ve);
                else if (pe < K && 0 > c(Re, N)) M[W] = Re, M[pe] = N, W = pe;
                else break e
            }
        }
        return B
    }

    function c(M, B) {
        var N = M.sortIndex - B.sortIndex;
        return N !== 0 ? N : M.id - B.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var d = performance;
        n.unstable_now = function() {
            return d.now()
        }
    } else {
        var f = Date,
            g = f.now();
        n.unstable_now = function() {
            return f.now() - g
        }
    }
    var h = [],
        y = [],
        v = 1,
        p = null,
        S = 3,
        x = !1,
        w = !1,
        z = !1,
        I = typeof setTimeout == "function" ? setTimeout : null,
        C = typeof clearTimeout == "function" ? clearTimeout : null,
        T = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function D(M) {
        for (var B = l(y); B !== null;) {
            if (B.callback === null) a(y);
            else if (B.startTime <= M) a(y), B.sortIndex = B.expirationTime, r(h, B);
            else break;
            B = l(y)
        }
    }

    function H(M) {
        if (z = !1, D(M), !w)
            if (l(h) !== null) w = !0, ge(b);
            else {
                var B = l(y);
                B !== null && Ce(H, B.startTime - M)
            }
    }

    function b(M, B) {
        w = !1, z && (z = !1, C(V), V = -1), x = !0;
        var N = S;
        try {
            for (D(B), p = l(h); p !== null && (!(p.expirationTime > B) || M && !A());) {
                var W = p.callback;
                if (typeof W == "function") {
                    p.callback = null, S = p.priorityLevel;
                    var K = W(p.expirationTime <= B);
                    B = n.unstable_now(), typeof K == "function" ? p.callback = K : p === l(h) && a(h), D(B)
                } else a(h);
                p = l(h)
            }
            if (p !== null) var ue = !0;
            else {
                var ve = l(y);
                ve !== null && Ce(H, ve.startTime - B), ue = !1
            }
            return ue
        } finally {
            p = null, S = N, x = !1
        }
    }
    var X = !1,
        te = null,
        V = -1,
        q = 5,
        k = -1;

    function A() {
        return !(n.unstable_now() - k < q)
    }

    function Y() {
        if (te !== null) {
            var M = n.unstable_now();
            k = M;
            var B = !0;
            try {
                B = te(!0, M)
            } finally {
                B ? ae() : (X = !1, te = null)
            }
        } else X = !1
    }
    var ae;
    if (typeof T == "function") ae = function() {
        T(Y)
    };
    else if (typeof MessageChannel < "u") {
        var se = new MessageChannel,
            Ee = se.port2;
        se.port1.onmessage = Y, ae = function() {
            Ee.postMessage(null)
        }
    } else ae = function() {
        I(Y, 0)
    };

    function ge(M) {
        te = M, X || (X = !0, ae())
    }

    function Ce(M, B) {
        V = I(function() {
            M(n.unstable_now())
        }, B)
    }
    n.unstable_IdlePriority = 5, n.unstable_ImmediatePriority = 1, n.unstable_LowPriority = 4, n.unstable_NormalPriority = 3, n.unstable_Profiling = null, n.unstable_UserBlockingPriority = 2, n.unstable_cancelCallback = function(M) {
        M.callback = null
    }, n.unstable_continueExecution = function() {
        w || x || (w = !0, ge(b))
    }, n.unstable_forceFrameRate = function(M) {
        0 > M || 125 < M ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : q = 0 < M ? Math.floor(1e3 / M) : 5
    }, n.unstable_getCurrentPriorityLevel = function() {
        return S
    }, n.unstable_getFirstCallbackNode = function() {
        return l(h)
    }, n.unstable_next = function(M) {
        switch (S) {
            case 1:
            case 2:
            case 3:
                var B = 3;
                break;
            default:
                B = S
        }
        var N = S;
        S = B;
        try {
            return M()
        } finally {
            S = N
        }
    }, n.unstable_pauseExecution = function() {}, n.unstable_requestPaint = function() {}, n.unstable_runWithPriority = function(M, B) {
        switch (M) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                M = 3
        }
        var N = S;
        S = M;
        try {
            return B()
        } finally {
            S = N
        }
    }, n.unstable_scheduleCallback = function(M, B, N) {
        var W = n.unstable_now();
        switch (typeof N == "object" && N !== null ? (N = N.delay, N = typeof N == "number" && 0 < N ? W + N : W) : N = W, M) {
            case 1:
                var K = -1;
                break;
            case 2:
                K = 250;
                break;
            case 5:
                K = 1073741823;
                break;
            case 4:
                K = 1e4;
                break;
            default:
                K = 5e3
        }
        return K = N + K, M = {
            id: v++,
            callback: B,
            priorityLevel: M,
            startTime: N,
            expirationTime: K,
            sortIndex: -1
        }, N > W ? (M.sortIndex = N, r(y, M), l(h) === null && M === l(y) && (z ? (C(V), V = -1) : z = !0, Ce(H, N - W))) : (M.sortIndex = K, r(h, M), w || x || (w = !0, ge(b))), M
    }, n.unstable_shouldYield = A, n.unstable_wrapCallback = function(M) {
        var B = S;
        return function() {
            var N = S;
            S = B;
            try {
                return M.apply(this, arguments)
            } finally {
                S = N
            }
        }
    }
})(Tu);
wu.exports = Tu;
var za = wu.exports;
const xl = {},
    Mu = n => void Object.assign(xl, n);

function up(n, r) {
    function l(v, {
        args: p = [],
        attach: S,
        ...x
    }, w) {
        let z = `${v[0].toUpperCase()}${v.slice(1)}`,
            I;
        if (v === "primitive") {
            if (x.object === void 0) throw new Error("R3F: Primitives without 'object' are invalid!");
            const C = x.object;
            I = Ln(C, {
                type: v,
                root: w,
                attach: S,
                primitive: !0
            })
        } else {
            const C = xl[z];
            if (!C) throw new Error(`R3F: ${z} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
            if (!Array.isArray(p)) throw new Error("R3F: The args prop must be an array!");
            I = Ln(new C(...p), {
                type: v,
                root: w,
                attach: S,
                memoizedProps: {
                    args: p
                }
            })
        }
        return I.__r3f.attach === void 0 && (I instanceof ml ? I.__r3f.attach = "geometry" : I instanceof fl && (I.__r3f.attach = "material")), z !== "inject" && Js(I, x), I
    }

    function a(v, p) {
        let S = !1;
        if (p) {
            var x, w;
            (x = p.__r3f) != null && x.attach ? qs(v, p, p.__r3f.attach) : p.isObject3D && v.isObject3D && (v.add(p), S = !0), S || (w = v.__r3f) == null || w.objects.push(p), p.__r3f || Ln(p, {}), p.__r3f.parent = v, ol(p), Dn(p)
        }
    }

    function c(v, p, S) {
        let x = !1;
        if (p) {
            var w, z;
            if ((w = p.__r3f) != null && w.attach) qs(v, p, p.__r3f.attach);
            else if (p.isObject3D && v.isObject3D) {
                p.parent = v, p.dispatchEvent({
                    type: "added"
                });
                const I = v.children.filter(T => T !== p),
                    C = I.indexOf(S);
                v.children = [...I.slice(0, C), p, ...I.slice(C)], x = !0
            }
            x || (z = v.__r3f) == null || z.objects.push(p), p.__r3f || Ln(p, {}), p.__r3f.parent = v, ol(p), Dn(p)
        }
    }

    function d(v, p, S = !1) {
        v && [...v].forEach(x => f(p, x, S))
    }

    function f(v, p, S) {
        if (p) {
            var x, w, z;
            if (p.__r3f && (p.__r3f.parent = null), (x = v.__r3f) != null && x.objects && (v.__r3f.objects = v.__r3f.objects.filter(H => H !== p)), (w = p.__r3f) != null && w.attach) ka(v, p, p.__r3f.attach);
            else if (p.isObject3D && v.isObject3D) {
                var I;
                v.remove(p), (I = p.__r3f) != null && I.root && mp(p.__r3f.root, p)
            }
            const T = (z = p.__r3f) == null ? void 0 : z.primitive,
                D = !T && (S === void 0 ? p.dispose !== null : S);
            if (!T) {
                var C;
                d((C = p.__r3f) == null ? void 0 : C.objects, p, D), d(p.children, p, D)
            }
            if (delete p.__r3f, D && p.dispose && p.type !== "Scene") {
                const H = () => {
                    try {
                        p.dispose()
                    } catch {}
                };
                typeof IS_REACT_ACT_ENVIRONMENT > "u" ? za.unstable_scheduleCallback(za.unstable_IdlePriority, H) : H()
            }
            Dn(v)
        }
    }

    function g(v, p, S, x) {
        var w;
        const z = (w = v.__r3f) == null ? void 0 : w.parent;
        if (!z) return;
        const I = l(p, S, v.__r3f.root);
        if (v.children) {
            for (const C of v.children) C.__r3f && a(I, C);
            v.children = v.children.filter(C => !C.__r3f)
        }
        v.__r3f.objects.forEach(C => a(I, C)), v.__r3f.objects = [], v.__r3f.autoRemovedBeforeAppend || f(z, v), I.parent && (I.__r3f.autoRemovedBeforeAppend = !0), a(z, I), I.raycast && I.__r3f.eventCount && I.__r3f.root.getState().internal.interaction.push(I), [x, x.alternate].forEach(C => {
            C !== null && (C.stateNode = I, C.ref && (typeof C.ref == "function" ? C.ref(I) : C.ref.current = I))
        })
    }
    const h = () => console.warn("Text is not allowed in the R3F tree! This could be stray whitespace or characters.");
    return {
        reconciler: ap({
            createInstance: l,
            removeChild: f,
            appendChild: a,
            appendInitialChild: a,
            insertBefore: c,
            supportsMutation: !0,
            isPrimaryRenderer: !1,
            supportsPersistence: !1,
            supportsHydration: !1,
            noTimeout: -1,
            appendChildToContainer: (v, p) => {
                if (!p) return;
                const S = v.getState().scene;
                S.__r3f && (S.__r3f.root = v, a(S, p))
            },
            removeChildFromContainer: (v, p) => {
                p && f(v.getState().scene, p)
            },
            insertInContainerBefore: (v, p, S) => {
                if (!p || !S) return;
                const x = v.getState().scene;
                x.__r3f && c(x, p, S)
            },
            getRootHostContext: () => null,
            getChildHostContext: v => v,
            finalizeInitialChildren(v) {
                var p;
                return !!((p = v == null ? void 0 : v.__r3f) != null ? p : {}).handlers
            },
            prepareUpdate(v, p, S, x) {
                var w;
                if (((w = v == null ? void 0 : v.__r3f) != null ? w : {}).primitive && x.object && x.object !== v) return [!0]; {
                    const {
                        args: I = [],
                        children: C,
                        ...T
                    } = x, {
                        args: D = [],
                        children: H,
                        ...b
                    } = S;
                    if (!Array.isArray(I)) throw new Error("R3F: the args prop must be an array!");
                    if (I.some((te, V) => te !== D[V])) return [!0];
                    const X = Iu(v, T, b, !0);
                    return X.changes.length ? [!1, X] : null
                }
            },
            commitUpdate(v, [p, S], x, w, z, I) {
                p ? g(v, x, z, I) : Js(v, S)
            },
            commitMount(v, p, S, x) {
                var w;
                const z = (w = v.__r3f) != null ? w : {};
                v.raycast && z.handlers && z.eventCount && v.__r3f.root.getState().internal.interaction.push(v)
            },
            getPublicInstance: v => v,
            prepareForCommit: () => null,
            preparePortalMount: v => Ln(v.getState().scene),
            resetAfterCommit: () => {},
            shouldSetTextContent: () => !1,
            clearContainer: () => !1,
            hideInstance(v) {
                var p;
                const {
                    attach: S,
                    parent: x
                } = (p = v.__r3f) != null ? p : {};
                S && x && ka(x, v, S), v.isObject3D && (v.visible = !1), Dn(v)
            },
            unhideInstance(v, p) {
                var S;
                const {
                    attach: x,
                    parent: w
                } = (S = v.__r3f) != null ? S : {};
                x && w && qs(w, v, x), (v.isObject3D && p.visible == null || p.visible) && (v.visible = !0), Dn(v)
            },
            createTextInstance: h,
            hideTextInstance: h,
            unhideTextInstance: h,
            getCurrentEventPriority: () => r ? r() : zn.DefaultEventPriority,
            beforeActiveInstanceBlur: () => {},
            afterActiveInstanceBlur: () => {},
            detachDeletedInstance: () => {},
            now: typeof performance < "u" && we.fun(performance.now) ? performance.now : we.fun(Date.now) ? Date.now : () => 0,
            scheduleTimeout: we.fun(setTimeout) ? setTimeout : void 0,
            cancelTimeout: we.fun(clearTimeout) ? clearTimeout : void 0
        }),
        applyProps: Js
    }
}
var Aa, Ba;
const Zs = n => "colorSpace" in n || "outputColorSpace" in n,
    Ru = () => {
        var n;
        return (n = xl.ColorManagement) != null ? n : null
    },
    Pu = n => n && n.isOrthographicCamera,
    cp = n => n && n.hasOwnProperty("current"),
    kn = typeof window < "u" && ((Aa = window.document) != null && Aa.createElement || ((Ba = window.navigator) == null ? void 0 : Ba.product) === "ReactNative") ? P.useLayoutEffect : P.useEffect;

function Cu(n) {
    const r = P.useRef(n);
    return kn(() => void(r.current = n), [n]), r
}

function fp({
    set: n
}) {
    return kn(() => (n(new Promise(() => null)), () => n(!1)), [n]), null
}
class Uu extends P.Component {
    constructor(...r) {
        super(...r), this.state = {
            error: !1
        }
    }
    componentDidCatch(r) {
        this.props.set(r)
    }
    render() {
        return this.state.error ? null : this.props.children
    }
}
Uu.getDerivedStateFromError = () => ({
    error: !0
});
const Lu = "__default",
    Na = new Map,
    dp = n => n && !!n.memoized && !!n.changes;

function Du(n) {
    var r;
    const l = typeof window < "u" ? (r = window.devicePixelRatio) != null ? r : 2 : 1;
    return Array.isArray(n) ? Math.min(Math.max(n[0], l), n[1]) : n
}
const dr = n => {
        var r;
        return (r = n.__r3f) == null ? void 0 : r.root.getState()
    },
    we = {
        obj: n => n === Object(n) && !we.arr(n) && typeof n != "function",
        fun: n => typeof n == "function",
        str: n => typeof n == "string",
        num: n => typeof n == "number",
        boo: n => typeof n == "boolean",
        und: n => n === void 0,
        arr: n => Array.isArray(n),
        equ(n, r, {
            arrays: l = "shallow",
            objects: a = "reference",
            strict: c = !0
        } = {}) {
            if (typeof n != typeof r || !!n != !!r) return !1;
            if (we.str(n) || we.num(n)) return n === r;
            const d = we.obj(n);
            if (d && a === "reference") return n === r;
            const f = we.arr(n);
            if (f && l === "reference") return n === r;
            if ((f || d) && n === r) return !0;
            let g;
            for (g in n)
                if (!(g in r)) return !1;
            if (d && l === "shallow" && a === "shallow") {
                for (g in c ? r : n)
                    if (!we.equ(n[g], r[g], {
                            strict: c,
                            objects: "reference"
                        })) return !1
            } else
                for (g in c ? r : n)
                    if (n[g] !== r[g]) return !1;
            if (we.und(g)) {
                if (f && n.length === 0 && r.length === 0 || d && Object.keys(n).length === 0 && Object.keys(r).length === 0) return !0;
                if (n !== r) return !1
            }
            return !0
        }
    };

function hp(n) {
    n.dispose && n.type !== "Scene" && n.dispose();
    for (const r in n) r.dispose == null || r.dispose(), delete n[r]
}

function Ln(n, r) {
    const l = n;
    return l.__r3f = {
        type: "",
        root: null,
        previousAttach: null,
        memoizedProps: {},
        eventCount: 0,
        handlers: {},
        objects: [],
        parent: null,
        ...r
    }, n
}

function ll(n, r) {
    let l = n;
    if (r.includes("-")) {
        const a = r.split("-"),
            c = a.pop();
        return l = a.reduce((d, f) => d[f], n), {
            target: l,
            key: c
        }
    } else return {
        target: l,
        key: r
    }
}
const Oa = /-\d+$/;

function qs(n, r, l) {
    if (we.str(l)) {
        if (Oa.test(l)) {
            const d = l.replace(Oa, ""),
                {
                    target: f,
                    key: g
                } = ll(n, d);
            Array.isArray(f[g]) || (f[g] = [])
        }
        const {
            target: a,
            key: c
        } = ll(n, l);
        r.__r3f.previousAttach = a[c], a[c] = r
    } else r.__r3f.previousAttach = l(n, r)
}

function ka(n, r, l) {
    var a, c;
    if (we.str(l)) {
        const {
            target: d,
            key: f
        } = ll(n, l), g = r.__r3f.previousAttach;
        g === void 0 ? delete d[f] : d[f] = g
    } else(a = r.__r3f) == null || a.previousAttach == null || a.previousAttach(n, r);
    (c = r.__r3f) == null || delete c.previousAttach
}

function Iu(n, {
    children: r,
    key: l,
    ref: a,
    ...c
}, {
    children: d,
    key: f,
    ref: g,
    ...h
} = {}, y = !1) {
    var v;
    const p = (v = n == null ? void 0 : n.__r3f) != null ? v : {},
        S = Object.entries(c),
        x = [];
    if (y) {
        const z = Object.keys(h);
        for (let I = 0; I < z.length; I++) c.hasOwnProperty(z[I]) || S.unshift([z[I], Lu + "remove"])
    }
    S.forEach(([z, I]) => {
        var C;
        if ((C = n.__r3f) != null && C.primitive && z === "object" || we.equ(I, h[z])) return;
        if (/^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/.test(z)) return x.push([z, I, !0, []]);
        let T = [];
        z.includes("-") && (T = z.split("-")), x.push([z, I, !1, T]);
        for (const D in c) {
            const H = c[D];
            D.startsWith(`${z}-`) && x.push([D, H, !1, D.split("-")])
        }
    });
    const w = { ...c
    };
    return p.memoizedProps && p.memoizedProps.args && (w.args = p.memoizedProps.args), p.memoizedProps && p.memoizedProps.attach && (w.attach = p.memoizedProps.attach), {
        memoized: w,
        changes: x
    }
}
const pp = typeof process < "u" && !1;

function Js(n, r) {
    var l, a, c;
    const d = (l = n.__r3f) != null ? l : {},
        f = d.root,
        g = (a = f == null || f.getState == null ? void 0 : f.getState()) != null ? a : {},
        {
            memoized: h,
            changes: y
        } = dp(r) ? r : Iu(n, r),
        v = d.eventCount;
    n.__r3f && (n.__r3f.memoizedProps = h);
    for (let S = 0; S < y.length; S++) {
        let [x, w, z, I] = y[S];
        if (Zs(n)) {
            const H = "srgb",
                b = "srgb-linear";
            x === "encoding" ? (x = "colorSpace", w = w === 3001 ? H : b) : x === "outputEncoding" && (x = "outputColorSpace", w = w === 3001 ? H : b)
        }
        let C = n,
            T = C[x];
        if (I.length && (T = I.reduce((D, H) => D[H], n), !(T && T.set))) {
            const [D, ...H] = I.reverse();
            C = H.reverse().reduce((b, X) => b[X], n), x = D
        }
        if (w === Lu + "remove")
            if (C.constructor) {
                let D = Na.get(C.constructor);
                D || (D = new C.constructor, Na.set(C.constructor, D)), w = D[x]
            } else w = 0;
        if (z) w ? d.handlers[x] = w : delete d.handlers[x], d.eventCount = Object.keys(d.handlers).length;
        else if (T && T.set && (T.copy || T instanceof bs)) {
            if (Array.isArray(w)) T.fromArray ? T.fromArray(w) : T.set(...w);
            else if (T.copy && w && w.constructor && (pp ? T.constructor.name === w.constructor.name : T.constructor === w.constructor)) T.copy(w);
            else if (w !== void 0) {
                const D = T instanceof yr;
                !D && T.setScalar ? T.setScalar(w) : T instanceof bs && w instanceof bs ? T.mask = w.mask : T.set(w), !Ru() && !g.linear && D && T.convertSRGBToLinear()
            }
        } else if (C[x] = w, C[x] instanceof dl && C[x].format === Ei && C[x].type === Ct) {
            const D = C[x];
            Zs(D) && Zs(g.gl) ? D.colorSpace = g.gl.outputColorSpace : D.encoding = g.gl.outputEncoding
        }
        Dn(n)
    }
    if (d.parent && g.internal && n.raycast && v !== d.eventCount) {
        const S = g.internal.interaction.indexOf(n);
        S > -1 && g.internal.interaction.splice(S, 1), d.eventCount && g.internal.interaction.push(n)
    }
    return !(y.length === 1 && y[0][0] === "onUpdate") && y.length && (c = n.__r3f) != null && c.parent && ol(n), n
}

function Dn(n) {
    var r, l;
    const a = (r = n.__r3f) == null || (l = r.root) == null || l.getState == null ? void 0 : l.getState();
    a && a.internal.frames === 0 && a.invalidate()
}

function ol(n) {
    n.onUpdate == null || n.onUpdate(n)
}

function zu(n, r) {
    n.manual || (Pu(n) ? (n.left = r.width / -2, n.right = r.width / 2, n.top = r.height / 2, n.bottom = r.height / -2) : n.aspect = r.width / r.height, n.updateProjectionMatrix(), n.updateMatrixWorld())
}

function yi(n) {
    return (n.eventObject || n.object).uuid + "/" + n.index + n.instanceId
}

function vp() {
    var n;
    const r = typeof self < "u" && self || typeof window < "u" && window;
    if (!r) return zn.DefaultEventPriority;
    switch ((n = r.event) == null ? void 0 : n.type) {
        case "click":
        case "contextmenu":
        case "dblclick":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
            return zn.DiscreteEventPriority;
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "pointerenter":
        case "pointerleave":
        case "wheel":
            return zn.ContinuousEventPriority;
        default:
            return zn.DefaultEventPriority
    }
}

function Au(n, r, l, a) {
    const c = l.get(r);
    c && (l.delete(r), l.size === 0 && (n.delete(a), c.target.releasePointerCapture(a)))
}

function mp(n, r) {
    const {
        internal: l
    } = n.getState();
    l.interaction = l.interaction.filter(a => a !== r), l.initialHits = l.initialHits.filter(a => a !== r), l.hovered.forEach((a, c) => {
        (a.eventObject === r || a.object === r) && l.hovered.delete(c)
    }), l.capturedMap.forEach((a, c) => {
        Au(l.capturedMap, r, a, c)
    })
}

function gp(n) {
    function r(h) {
        const {
            internal: y
        } = n.getState(), v = h.offsetX - y.initialClick[0], p = h.offsetY - y.initialClick[1];
        return Math.round(Math.sqrt(v * v + p * p))
    }

    function l(h) {
        return h.filter(y => ["Move", "Over", "Enter", "Out", "Leave"].some(v => {
            var p;
            return (p = y.__r3f) == null ? void 0 : p.handlers["onPointer" + v]
        }))
    }

    function a(h, y) {
        const v = n.getState(),
            p = new Set,
            S = [],
            x = y ? y(v.internal.interaction) : v.internal.interaction;
        for (let C = 0; C < x.length; C++) {
            const T = dr(x[C]);
            T && (T.raycaster.camera = void 0)
        }
        v.previousRoot || v.events.compute == null || v.events.compute(h, v);

        function w(C) {
            const T = dr(C);
            if (!T || !T.events.enabled || T.raycaster.camera === null) return [];
            if (T.raycaster.camera === void 0) {
                var D;
                T.events.compute == null || T.events.compute(h, T, (D = T.previousRoot) == null ? void 0 : D.getState()), T.raycaster.camera === void 0 && (T.raycaster.camera = null)
            }
            return T.raycaster.camera ? T.raycaster.intersectObject(C, !0) : []
        }
        let z = x.flatMap(w).sort((C, T) => {
            const D = dr(C.object),
                H = dr(T.object);
            return !D || !H ? C.distance - T.distance : H.events.priority - D.events.priority || C.distance - T.distance
        }).filter(C => {
            const T = yi(C);
            return p.has(T) ? !1 : (p.add(T), !0)
        });
        v.events.filter && (z = v.events.filter(z, v));
        for (const C of z) {
            let T = C.object;
            for (; T;) {
                var I;
                (I = T.__r3f) != null && I.eventCount && S.push({ ...C,
                    eventObject: T
                }), T = T.parent
            }
        }
        if ("pointerId" in h && v.internal.capturedMap.has(h.pointerId))
            for (let C of v.internal.capturedMap.get(h.pointerId).values()) p.has(yi(C.intersection)) || S.push(C.intersection);
        return S
    }

    function c(h, y, v, p) {
        const S = n.getState();
        if (h.length) {
            const x = {
                stopped: !1
            };
            for (const w of h) {
                const z = dr(w.object) || S,
                    {
                        raycaster: I,
                        pointer: C,
                        camera: T,
                        internal: D
                    } = z,
                    H = new Ne(C.x, C.y, 0).unproject(T),
                    b = k => {
                        var A, Y;
                        return (A = (Y = D.capturedMap.get(k)) == null ? void 0 : Y.has(w.eventObject)) != null ? A : !1
                    },
                    X = k => {
                        const A = {
                            intersection: w,
                            target: y.target
                        };
                        D.capturedMap.has(k) ? D.capturedMap.get(k).set(w.eventObject, A) : D.capturedMap.set(k, new Map([
                            [w.eventObject, A]
                        ])), y.target.setPointerCapture(k)
                    },
                    te = k => {
                        const A = D.capturedMap.get(k);
                        A && Au(D.capturedMap, w.eventObject, A, k)
                    };
                let V = {};
                for (let k in y) {
                    let A = y[k];
                    typeof A != "function" && (V[k] = A)
                }
                let q = { ...w,
                    ...V,
                    pointer: C,
                    intersections: h,
                    stopped: x.stopped,
                    delta: v,
                    unprojectedPoint: H,
                    ray: I.ray,
                    camera: T,
                    stopPropagation() {
                        const k = "pointerId" in y && D.capturedMap.get(y.pointerId);
                        if ((!k || k.has(w.eventObject)) && (q.stopped = x.stopped = !0, D.hovered.size && Array.from(D.hovered.values()).find(A => A.eventObject === w.eventObject))) {
                            const A = h.slice(0, h.indexOf(w));
                            d([...A, w])
                        }
                    },
                    target: {
                        hasPointerCapture: b,
                        setPointerCapture: X,
                        releasePointerCapture: te
                    },
                    currentTarget: {
                        hasPointerCapture: b,
                        setPointerCapture: X,
                        releasePointerCapture: te
                    },
                    nativeEvent: y
                };
                if (p(q), x.stopped === !0) break
            }
        }
        return h
    }

    function d(h) {
        const {
            internal: y
        } = n.getState();
        for (const v of y.hovered.values())
            if (!h.length || !h.find(p => p.object === v.object && p.index === v.index && p.instanceId === v.instanceId)) {
                const S = v.eventObject.__r3f,
                    x = S == null ? void 0 : S.handlers;
                if (y.hovered.delete(yi(v)), S != null && S.eventCount) {
                    const w = { ...v,
                        intersections: h
                    };
                    x.onPointerOut == null || x.onPointerOut(w), x.onPointerLeave == null || x.onPointerLeave(w)
                }
            }
    }

    function f(h, y) {
        for (let v = 0; v < y.length; v++) {
            const p = y[v].__r3f;
            p == null || p.handlers.onPointerMissed == null || p.handlers.onPointerMissed(h)
        }
    }

    function g(h) {
        switch (h) {
            case "onPointerLeave":
            case "onPointerCancel":
                return () => d([]);
            case "onLostPointerCapture":
                return y => {
                    const {
                        internal: v
                    } = n.getState();
                    "pointerId" in y && v.capturedMap.has(y.pointerId) && requestAnimationFrame(() => {
                        v.capturedMap.has(y.pointerId) && (v.capturedMap.delete(y.pointerId), d([]))
                    })
                }
        }
        return function(v) {
            const {
                onPointerMissed: p,
                internal: S
            } = n.getState();
            S.lastEvent.current = v;
            const x = h === "onPointerMove",
                w = h === "onClick" || h === "onContextMenu" || h === "onDoubleClick",
                I = a(v, x ? l : void 0),
                C = w ? r(v) : 0;
            h === "onPointerDown" && (S.initialClick = [v.offsetX, v.offsetY], S.initialHits = I.map(D => D.eventObject)), w && !I.length && C <= 2 && (f(v, S.interaction), p && p(v)), x && d(I);

            function T(D) {
                const H = D.eventObject,
                    b = H.__r3f,
                    X = b == null ? void 0 : b.handlers;
                if (b != null && b.eventCount)
                    if (x) {
                        if (X.onPointerOver || X.onPointerEnter || X.onPointerOut || X.onPointerLeave) {
                            const te = yi(D),
                                V = S.hovered.get(te);
                            V ? V.stopped && D.stopPropagation() : (S.hovered.set(te, D), X.onPointerOver == null || X.onPointerOver(D), X.onPointerEnter == null || X.onPointerEnter(D))
                        }
                        X.onPointerMove == null || X.onPointerMove(D)
                    } else {
                        const te = X[h];
                        te ? (!w || S.initialHits.includes(H)) && (f(v, S.interaction.filter(V => !S.initialHits.includes(V))), te(D)) : w && S.initialHits.includes(H) && f(v, S.interaction.filter(V => !S.initialHits.includes(V)))
                    }
            }
            c(I, v, C, T)
        }
    }
    return {
        handlePointer: g
    }
}
const yp = ["set", "get", "setSize", "setFrameloop", "setDpr", "events", "invalidate", "advance", "size", "viewport"],
    Bu = n => !!(n != null && n.render),
    El = P.createContext(null),
    Sp = (n, r) => {
        const l = Eu((g, h) => {
                const y = new Ne,
                    v = new Ne,
                    p = new Ne;

                function S(C = h().camera, T = v, D = h().size) {
                    const {
                        width: H,
                        height: b,
                        top: X,
                        left: te
                    } = D, V = H / b;
                    T instanceof Ne ? p.copy(T) : p.set(...T);
                    const q = C.getWorldPosition(y).distanceTo(p);
                    if (Pu(C)) return {
                        width: H / C.zoom,
                        height: b / C.zoom,
                        top: X,
                        left: te,
                        factor: 1,
                        distance: q,
                        aspect: V
                    }; {
                        const k = C.fov * Math.PI / 180,
                            A = 2 * Math.tan(k / 2) * q,
                            Y = A * (H / b);
                        return {
                            width: Y,
                            height: A,
                            top: X,
                            left: te,
                            factor: H / Y,
                            distance: q,
                            aspect: V
                        }
                    }
                }
                let x;
                const w = C => g(T => ({
                        performance: { ...T.performance,
                            current: C
                        }
                    })),
                    z = new Se;
                return {
                    set: g,
                    get: h,
                    gl: null,
                    camera: null,
                    raycaster: null,
                    events: {
                        priority: 1,
                        enabled: !0,
                        connected: !1
                    },
                    xr: null,
                    scene: null,
                    invalidate: (C = 1) => n(h(), C),
                    advance: (C, T) => r(C, T, h()),
                    legacy: !1,
                    linear: !1,
                    flat: !1,
                    controls: null,
                    clock: new id,
                    pointer: z,
                    mouse: z,
                    frameloop: "always",
                    onPointerMissed: void 0,
                    performance: {
                        current: 1,
                        min: .5,
                        max: 1,
                        debounce: 200,
                        regress: () => {
                            const C = h();
                            x && clearTimeout(x), C.performance.current !== C.performance.min && w(C.performance.min), x = setTimeout(() => w(h().performance.max), C.performance.debounce)
                        }
                    },
                    size: {
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0,
                        updateStyle: !1
                    },
                    viewport: {
                        initialDpr: 0,
                        dpr: 0,
                        width: 0,
                        height: 0,
                        top: 0,
                        left: 0,
                        aspect: 0,
                        distance: 0,
                        factor: 0,
                        getCurrentViewport: S
                    },
                    setEvents: C => g(T => ({ ...T,
                        events: { ...T.events,
                            ...C
                        }
                    })),
                    setSize: (C, T, D, H, b) => {
                        const X = h().camera,
                            te = {
                                width: C,
                                height: T,
                                top: H || 0,
                                left: b || 0,
                                updateStyle: D
                            };
                        g(V => ({
                            size: te,
                            viewport: { ...V.viewport,
                                ...S(X, v, te)
                            }
                        }))
                    },
                    setDpr: C => g(T => {
                        const D = Du(C);
                        return {
                            viewport: { ...T.viewport,
                                dpr: D,
                                initialDpr: T.viewport.initialDpr || D
                            }
                        }
                    }),
                    setFrameloop: (C = "always") => {
                        const T = h().clock;
                        T.stop(), T.elapsedTime = 0, C !== "never" && (T.start(), T.elapsedTime = 0), g(() => ({
                            frameloop: C
                        }))
                    },
                    previousRoot: void 0,
                    internal: {
                        active: !1,
                        priority: 0,
                        frames: 0,
                        lastEvent: P.createRef(),
                        interaction: [],
                        hovered: new Map,
                        subscribers: [],
                        initialClick: [0, 0],
                        initialHits: [],
                        capturedMap: new Map,
                        subscribe: (C, T, D) => {
                            const H = h().internal;
                            return H.priority = H.priority + (T > 0 ? 1 : 0), H.subscribers.push({
                                ref: C,
                                priority: T,
                                store: D
                            }), H.subscribers = H.subscribers.sort((b, X) => b.priority - X.priority), () => {
                                const b = h().internal;
                                b != null && b.subscribers && (b.priority = b.priority - (T > 0 ? 1 : 0), b.subscribers = b.subscribers.filter(X => X.ref !== C))
                            }
                        }
                    }
                }
            }),
            a = l.getState();
        let c = a.size,
            d = a.viewport.dpr,
            f = a.camera;
        return l.subscribe(() => {
            const {
                camera: g,
                size: h,
                viewport: y,
                gl: v,
                set: p
            } = l.getState();
            if (h.width !== c.width || h.height !== c.height || y.dpr !== d) {
                var S;
                c = h, d = y.dpr, zu(g, h), v.setPixelRatio(y.dpr);
                const x = (S = h.updateStyle) != null ? S : typeof HTMLCanvasElement < "u" && v.domElement instanceof HTMLCanvasElement;
                v.setSize(h.width, h.height, x)
            }
            g !== f && (f = g, p(x => ({
                viewport: { ...x.viewport,
                    ...x.viewport.getCurrentViewport(g)
                }
            })))
        }), l.subscribe(g => n(g)), l
    };
let Si, xp = new Set,
    Ep = new Set,
    _p = new Set;

function $s(n, r) {
    if (n.size)
        for (const {
                callback: l
            } of n.values()) l(r)
}

function hr(n, r) {
    switch (n) {
        case "before":
            return $s(xp, r);
        case "after":
            return $s(Ep, r);
        case "tail":
            return $s(_p, r)
    }
}
let el, tl;

function nl(n, r, l) {
    let a = r.clock.getDelta();
    for (r.frameloop === "never" && typeof n == "number" && (a = n - r.clock.elapsedTime, r.clock.oldTime = r.clock.elapsedTime, r.clock.elapsedTime = n), el = r.internal.subscribers, Si = 0; Si < el.length; Si++) tl = el[Si], tl.ref.current(tl.store.getState(), a, l);
    return !r.internal.priority && r.gl.render && r.gl.render(r.scene, r.camera), r.internal.frames = Math.max(0, r.internal.frames - 1), r.frameloop === "always" ? 1 : r.internal.frames
}

function wp(n) {
    let r = !1,
        l, a, c;

    function d(h) {
        a = requestAnimationFrame(d), r = !0, l = 0, hr("before", h);
        for (const v of n.values()) {
            var y;
            c = v.store.getState(), c.internal.active && (c.frameloop === "always" || c.internal.frames > 0) && !((y = c.gl.xr) != null && y.isPresenting) && (l += nl(h, c))
        }
        if (hr("after", h), l === 0) return hr("tail", h), r = !1, cancelAnimationFrame(a)
    }

    function f(h, y = 1) {
        var v;
        if (!h) return n.forEach(p => f(p.store.getState()), y);
        (v = h.gl.xr) != null && v.isPresenting || !h.internal.active || h.frameloop === "never" || (h.internal.frames = Math.min(60, h.internal.frames + y), r || (r = !0, requestAnimationFrame(d)))
    }

    function g(h, y = !0, v, p) {
        if (y && hr("before", h), v) nl(h, v, p);
        else
            for (const S of n.values()) nl(h, S.store.getState());
        y && hr("after", h)
    }
    return {
        loop: d,
        invalidate: f,
        advance: g
    }
}

function Tp(n) {
    const r = P.useRef(null);
    return kn(() => void(r.current = n.current.__r3f), [n]), r
}

function _l() {
    const n = P.useContext(El);
    if (!n) throw new Error("R3F: Hooks can only be used within the Canvas component!");
    return n
}

function dt(n = l => l, r) {
    return _l()(n, r)
}

function wl(n, r = 0) {
    const l = _l(),
        a = l.getState().internal.subscribe,
        c = Cu(n);
    return kn(() => a(c, r, l), [r, a, l]), null
}
const Nn = new Map,
    {
        invalidate: Fa,
        advance: Ha
    } = wp(Nn),
    {
        reconciler: mr,
        applyProps: Cn
    } = up(Nn, vp),
    Un = {
        objects: "shallow",
        strict: !1
    },
    Mp = (n, r) => {
        const l = typeof n == "function" ? n(r) : n;
        return Bu(l) ? l : new ed({
            powerPreference: "high-performance",
            canvas: r,
            antialias: !0,
            alpha: !0,
            ...n
        })
    };

function Rp(n, r) {
    const l = typeof HTMLCanvasElement < "u" && n instanceof HTMLCanvasElement;
    if (r) {
        const {
            width: a,
            height: c,
            top: d,
            left: f,
            updateStyle: g = l
        } = r;
        return {
            width: a,
            height: c,
            top: d,
            left: f,
            updateStyle: g
        }
    } else if (typeof HTMLCanvasElement < "u" && n instanceof HTMLCanvasElement && n.parentElement) {
        const {
            width: a,
            height: c,
            top: d,
            left: f
        } = n.parentElement.getBoundingClientRect();
        return {
            width: a,
            height: c,
            top: d,
            left: f,
            updateStyle: l
        }
    } else if (typeof OffscreenCanvas < "u" && n instanceof OffscreenCanvas) return {
        width: n.width,
        height: n.height,
        top: 0,
        left: 0,
        updateStyle: l
    };
    return {
        width: 0,
        height: 0,
        top: 0,
        left: 0
    }
}

function Pp(n) {
    const r = Nn.get(n),
        l = r == null ? void 0 : r.fiber,
        a = r == null ? void 0 : r.store;
    r && console.warn("R3F.createRoot should only be called once!");
    const c = typeof reportError == "function" ? reportError : console.error,
        d = a || Sp(Fa, Ha),
        f = l || mr.createContainer(d, zn.ConcurrentRoot, null, !1, null, "", c, null);
    r || Nn.set(n, {
        fiber: f,
        store: d
    });
    let g, h = !1,
        y;
    return {
        configure(v = {}) {
            let {
                gl: p,
                size: S,
                scene: x,
                events: w,
                onCreated: z,
                shadows: I = !1,
                linear: C = !1,
                flat: T = !1,
                legacy: D = !1,
                orthographic: H = !1,
                frameloop: b = "always",
                dpr: X = [1, 2],
                performance: te,
                raycaster: V,
                camera: q,
                onPointerMissed: k
            } = v, A = d.getState(), Y = A.gl;
            A.gl || A.set({
                gl: Y = Mp(p, n)
            });
            let ae = A.raycaster;
            ae || A.set({
                raycaster: ae = new su
            });
            const {
                params: se,
                ...Ee
            } = V || {};
            if (we.equ(Ee, ae, Un) || Cn(ae, { ...Ee
                }), we.equ(se, ae.params, Un) || Cn(ae, {
                    params: { ...ae.params,
                        ...se
                    }
                }), !A.camera || A.camera === y && !we.equ(y, q, Un)) {
                y = q;
                const K = q instanceof vl,
                    ue = K ? q : H ? new qf(0, 0, 0, 0, .1, 1e3) : new ru(75, 0, .1, 1e3);
                K || (ue.position.z = 5, q && Cn(ue, q), !A.camera && !(q != null && q.rotation) && ue.lookAt(0, 0, 0)), A.set({
                    camera: ue
                }), ae.camera = ue
            }
            if (!A.scene) {
                let K;
                x instanceof pr ? K = x : (K = new pr, x && Cn(K, x)), A.set({
                    scene: Ln(K)
                })
            }
            if (!A.xr) {
                var ge;
                const K = (ee, pe) => {
                        const Re = d.getState();
                        Re.frameloop !== "never" && Ha(ee, !0, Re, pe)
                    },
                    ue = () => {
                        const ee = d.getState();
                        ee.gl.xr.enabled = ee.gl.xr.isPresenting, ee.gl.xr.setAnimationLoop(ee.gl.xr.isPresenting ? K : null), ee.gl.xr.isPresenting || Fa(ee)
                    },
                    ve = {
                        connect() {
                            const ee = d.getState().gl;
                            ee.xr.addEventListener("sessionstart", ue), ee.xr.addEventListener("sessionend", ue)
                        },
                        disconnect() {
                            const ee = d.getState().gl;
                            ee.xr.removeEventListener("sessionstart", ue), ee.xr.removeEventListener("sessionend", ue)
                        }
                    };
                typeof((ge = Y.xr) == null ? void 0 : ge.addEventListener) == "function" && ve.connect(), A.set({
                    xr: ve
                })
            }
            if (Y.shadowMap) {
                const K = Y.shadowMap.enabled,
                    ue = Y.shadowMap.type;
                if (Y.shadowMap.enabled = !!I, we.boo(I)) Y.shadowMap.type = Vs;
                else if (we.str(I)) {
                    var Ce;
                    const ve = {
                        basic: td,
                        percentage: nd,
                        soft: Vs,
                        variance: rd
                    };
                    Y.shadowMap.type = (Ce = ve[I]) != null ? Ce : Vs
                } else we.obj(I) && Object.assign(Y.shadowMap, I);
                (K !== Y.shadowMap.enabled || ue !== Y.shadowMap.type) && (Y.shadowMap.needsUpdate = !0)
            }
            const M = Ru();
            M && ("enabled" in M ? M.enabled = !D : "legacyMode" in M && (M.legacyMode = D)), Cn(Y, {
                outputEncoding: C ? 3e3 : 3001,
                toneMapping: T ? Jf : $f
            }), A.legacy !== D && A.set(() => ({
                legacy: D
            })), A.linear !== C && A.set(() => ({
                linear: C
            })), A.flat !== T && A.set(() => ({
                flat: T
            })), p && !we.fun(p) && !Bu(p) && !we.equ(p, Y, Un) && Cn(Y, p), w && !A.events.handlers && A.set({
                events: w(d)
            });
            const W = Rp(n, S);
            return we.equ(W, A.size, Un) || A.setSize(W.width, W.height, W.updateStyle, W.top, W.left), X && A.viewport.dpr !== Du(X) && A.setDpr(X), A.frameloop !== b && A.setFrameloop(b), A.onPointerMissed || A.set({
                onPointerMissed: k
            }), te && !we.equ(te, A.performance, Un) && A.set(K => ({
                performance: { ...K.performance,
                    ...te
                }
            })), g = z, h = !0, this
        },
        render(v) {
            return h || this.configure(), mr.updateContainer(P.createElement(Cp, {
                store: d,
                children: v,
                onCreated: g,
                rootElement: n
            }), f, null, () => {}), d
        },
        unmount() {
            Nu(n)
        }
    }
}

function Cp({
    store: n,
    children: r,
    onCreated: l,
    rootElement: a
}) {
    return kn(() => {
        const c = n.getState();
        c.set(d => ({
            internal: { ...d.internal,
                active: !0
            }
        })), l && l(c), n.getState().events.connected || c.events.connect == null || c.events.connect(a)
    }, []), P.createElement(El.Provider, {
        value: n
    }, r)
}

function Nu(n, r) {
    const l = Nn.get(n),
        a = l == null ? void 0 : l.fiber;
    if (a) {
        const c = l == null ? void 0 : l.store.getState();
        c && (c.internal.active = !1), mr.updateContainer(null, a, null, () => {
            c && setTimeout(() => {
                try {
                    var d, f, g, h;
                    c.events.disconnect == null || c.events.disconnect(), (d = c.gl) == null || (f = d.renderLists) == null || f.dispose == null || f.dispose(), (g = c.gl) == null || g.forceContextLoss == null || g.forceContextLoss(), (h = c.gl) != null && h.xr && c.xr.disconnect(), hp(c), Nn.delete(n), r && r(n)
                } catch {}
            }, 500)
        })
    }
}

function ng(n, r, l) {
    return P.createElement(Up, {
        key: r.uuid,
        children: n,
        container: r,
        state: l
    })
}

function Up({
    state: n = {},
    children: r,
    container: l
}) {
    const {
        events: a,
        size: c,
        ...d
    } = n, f = _l(), [g] = P.useState(() => new su), [h] = P.useState(() => new Se), y = P.useCallback((p, S) => {
        const x = { ...p
        };
        Object.keys(p).forEach(z => {
            (yp.includes(z) || p[z] !== S[z] && S[z]) && delete x[z]
        });
        let w;
        if (S && c) {
            const z = S.camera;
            w = p.viewport.getCurrentViewport(z, new Ne, c), z !== p.camera && zu(z, c)
        }
        return { ...x,
            scene: l,
            raycaster: g,
            pointer: h,
            mouse: h,
            previousRoot: f,
            events: { ...p.events,
                ...S == null ? void 0 : S.events,
                ...a
            },
            size: { ...p.size,
                ...c
            },
            viewport: { ...p.viewport,
                ...w
            },
            ...d
        }
    }, [n]), [v] = P.useState(() => {
        const p = f.getState();
        return Eu((x, w) => ({ ...p,
            scene: l,
            raycaster: g,
            pointer: h,
            mouse: h,
            previousRoot: f,
            events: { ...p.events,
                ...a
            },
            size: { ...p.size,
                ...c
            },
            ...d,
            set: x,
            get: w,
            setEvents: z => x(I => ({ ...I,
                events: { ...I.events,
                    ...z
                }
            }))
        }))
    });
    return P.useEffect(() => {
        const p = f.subscribe(S => v.setState(x => y(S, x)));
        return () => {
            p(), v.destroy()
        }
    }, []), P.useEffect(() => {
        v.setState(p => y(f.getState(), p))
    }, [y]), P.createElement(P.Fragment, null, mr.createPortal(P.createElement(El.Provider, {
        value: v
    }, r), v, null))
}
mr.injectIntoDevTools({
    bundleType: 0,
    rendererPackageName: "@react-three/fiber",
    version: P.version
});

function al(n, r, l) {
    var a, c, d, f, g;
    r == null && (r = 100);

    function h() {
        var v = Date.now() - f;
        v < r && v >= 0 ? a = setTimeout(h, r - v) : (a = null, l || (g = n.apply(d, c), d = c = null))
    }
    var y = function() {
        d = this, c = arguments, f = Date.now();
        var v = l && !a;
        return a || (a = setTimeout(h, r)), v && (g = n.apply(d, c), d = c = null), g
    };
    return y.clear = function() {
        a && (clearTimeout(a), a = null)
    }, y.flush = function() {
        a && (g = n.apply(d, c), d = c = null, clearTimeout(a), a = null)
    }, y
}
al.debounce = al;
var Lp = al;
const Ga = Mi(Lp);

function Dp(n) {
    let {
        debounce: r,
        scroll: l,
        polyfill: a,
        offsetSize: c
    } = n === void 0 ? {
        debounce: 0,
        scroll: !1,
        offsetSize: !1
    } : n;
    const d = a || (typeof window > "u" ? class {} : window.ResizeObserver);
    if (!d) throw new Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
    const [f, g] = P.useState({
        left: 0,
        top: 0,
        width: 0,
        height: 0,
        bottom: 0,
        right: 0,
        x: 0,
        y: 0
    }), h = P.useRef({
        element: null,
        scrollContainers: null,
        resizeObserver: null,
        lastBounds: f
    }), y = r ? typeof r == "number" ? r : r.scroll : null, v = r ? typeof r == "number" ? r : r.resize : null, p = P.useRef(!1);
    P.useEffect(() => (p.current = !0, () => void(p.current = !1)));
    const [S, x, w] = P.useMemo(() => {
        const T = () => {
            if (!h.current.element) return;
            const {
                left: D,
                top: H,
                width: b,
                height: X,
                bottom: te,
                right: V,
                x: q,
                y: k
            } = h.current.element.getBoundingClientRect(), A = {
                left: D,
                top: H,
                width: b,
                height: X,
                bottom: te,
                right: V,
                x: q,
                y: k
            };
            h.current.element instanceof HTMLElement && c && (A.height = h.current.element.offsetHeight, A.width = h.current.element.offsetWidth), Object.freeze(A), p.current && !Bp(h.current.lastBounds, A) && g(h.current.lastBounds = A)
        };
        return [T, v ? Ga(T, v) : T, y ? Ga(T, y) : T]
    }, [g, c, y, v]);

    function z() {
        h.current.scrollContainers && (h.current.scrollContainers.forEach(T => T.removeEventListener("scroll", w, !0)), h.current.scrollContainers = null), h.current.resizeObserver && (h.current.resizeObserver.disconnect(), h.current.resizeObserver = null)
    }

    function I() {
        h.current.element && (h.current.resizeObserver = new d(w), h.current.resizeObserver.observe(h.current.element), l && h.current.scrollContainers && h.current.scrollContainers.forEach(T => T.addEventListener("scroll", w, {
            capture: !0,
            passive: !0
        })))
    }
    const C = T => {
        !T || T === h.current.element || (z(), h.current.element = T, h.current.scrollContainers = Ou(T), I())
    };
    return zp(w, !!l), Ip(x), P.useEffect(() => {
        z(), I()
    }, [l, w, x]), P.useEffect(() => z, []), [C, f, S]
}

function Ip(n) {
    P.useEffect(() => {
        const r = n;
        return window.addEventListener("resize", r), () => void window.removeEventListener("resize", r)
    }, [n])
}

function zp(n, r) {
    P.useEffect(() => {
        if (r) {
            const l = n;
            return window.addEventListener("scroll", l, {
                capture: !0,
                passive: !0
            }), () => void window.removeEventListener("scroll", l, !0)
        }
    }, [n, r])
}

function Ou(n) {
    const r = [];
    if (!n || n === document.body) return r;
    const {
        overflow: l,
        overflowX: a,
        overflowY: c
    } = window.getComputedStyle(n);
    return [l, a, c].some(d => d === "auto" || d === "scroll") && r.push(n), [...r, ...Ou(n.parentElement)]
}
const Ap = ["x", "y", "top", "bottom", "left", "right", "width", "height"],
    Bp = (n, r) => Ap.every(l => n[l] === r[l]);
var Np = Object.defineProperty,
    Op = Object.defineProperties,
    kp = Object.getOwnPropertyDescriptors,
    ja = Object.getOwnPropertySymbols,
    Fp = Object.prototype.hasOwnProperty,
    Hp = Object.prototype.propertyIsEnumerable,
    ba = (n, r, l) => r in n ? Np(n, r, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: l
    }) : n[r] = l,
    Va = (n, r) => {
        for (var l in r || (r = {})) Fp.call(r, l) && ba(n, l, r[l]);
        if (ja)
            for (var l of ja(r)) Hp.call(r, l) && ba(n, l, r[l]);
        return n
    },
    Gp = (n, r) => Op(n, kp(r));

function ku(n, r, l) {
    if (!n) return;
    if (l(n) === !0) return n;
    let a = r ? n.return : n.child;
    for (; a;) {
        const c = ku(a, r, l);
        if (c) return c;
        a = r ? null : a.sibling
    }
}

function Fu(n) {
    try {
        return Object.defineProperties(n, {
            _currentRenderer: {
                get() {
                    return null
                },
                set() {}
            },
            _currentRenderer2: {
                get() {
                    return null
                },
                set() {}
            }
        })
    } catch {
        return n
    }
}
const Tl = Fu(P.createContext(null));
class Hu extends P.Component {
    render() {
        return P.createElement(Tl.Provider, {
            value: this._reactInternals
        }, this.props.children)
    }
}
const {
    ReactCurrentOwner: Wa,
    ReactCurrentDispatcher: Qa
} = P.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;

function jp() {
    const n = P.useContext(Tl);
    if (n === null) throw new Error("its-fine: useFiber must be called within a <FiberProvider />!");
    const r = P.useId();
    return P.useMemo(() => {
        for (const a of [Wa == null ? void 0 : Wa.current, n, n == null ? void 0 : n.alternate]) {
            if (!a) continue;
            const c = ku(a, !1, d => {
                let f = d.memoizedState;
                for (; f;) {
                    if (f.memoizedState === r) return !0;
                    f = f.next
                }
            });
            if (c) return c
        }
    }, [n, r])
}

function bp() {
    var n, r;
    const l = jp(),
        [a] = P.useState(() => new Map);
    a.clear();
    let c = l;
    for (; c;) {
        const d = (n = c.type) == null ? void 0 : n._context;
        d && d !== Tl && !a.has(d) && a.set(d, (r = Qa == null ? void 0 : Qa.current) == null ? void 0 : r.readContext(Fu(d))), c = c.return
    }
    return a
}

function Vp() {
    const n = bp();
    return P.useMemo(() => Array.from(n.keys()).reduce((r, l) => a => P.createElement(r, null, P.createElement(l.Provider, Gp(Va({}, a), {
        value: n.get(l)
    }))), r => P.createElement(Hu, Va({}, r))), [n])
}
const rl = {
    onClick: ["click", !1],
    onContextMenu: ["contextmenu", !1],
    onDoubleClick: ["dblclick", !1],
    onWheel: ["wheel", !0],
    onPointerDown: ["pointerdown", !0],
    onPointerUp: ["pointerup", !0],
    onPointerLeave: ["pointerleave", !0],
    onPointerMove: ["pointermove", !0],
    onPointerCancel: ["pointercancel", !0],
    onLostPointerCapture: ["lostpointercapture", !0]
};

function Wp(n) {
    const {
        handlePointer: r
    } = gp(n);
    return {
        priority: 1,
        enabled: !0,
        compute(l, a, c) {
            a.pointer.set(l.offsetX / a.size.width * 2 - 1, -(l.offsetY / a.size.height) * 2 + 1), a.raycaster.setFromCamera(a.pointer, a.camera)
        },
        connected: void 0,
        handlers: Object.keys(rl).reduce((l, a) => ({ ...l,
            [a]: r(a)
        }), {}),
        update: () => {
            var l;
            const {
                events: a,
                internal: c
            } = n.getState();
            (l = c.lastEvent) != null && l.current && a.handlers && a.handlers.onPointerMove(c.lastEvent.current)
        },
        connect: l => {
            var a;
            const {
                set: c,
                events: d
            } = n.getState();
            d.disconnect == null || d.disconnect(), c(f => ({
                events: { ...f.events,
                    connected: l
                }
            })), Object.entries((a = d.handlers) != null ? a : []).forEach(([f, g]) => {
                const [h, y] = rl[f];
                l.addEventListener(h, g, {
                    passive: y
                })
            })
        },
        disconnect: () => {
            const {
                set: l,
                events: a
            } = n.getState();
            if (a.connected) {
                var c;
                Object.entries((c = a.handlers) != null ? c : []).forEach(([d, f]) => {
                    if (a && a.connected instanceof HTMLElement) {
                        const [g] = rl[d];
                        a.connected.removeEventListener(g, f)
                    }
                }), l(d => ({
                    events: { ...d.events,
                        connected: void 0
                    }
                }))
            }
        }
    }
}
const Qp = P.forwardRef(function({
        children: r,
        fallback: l,
        resize: a,
        style: c,
        gl: d,
        events: f = Wp,
        eventSource: g,
        eventPrefix: h,
        shadows: y,
        linear: v,
        flat: p,
        legacy: S,
        orthographic: x,
        frameloop: w,
        dpr: z,
        performance: I,
        raycaster: C,
        camera: T,
        scene: D,
        onPointerMissed: H,
        onCreated: b,
        ...X
    }, te) {
        P.useMemo(() => Mu(sd), []);
        const V = Vp(),
            [q, k] = Dp({
                scroll: !0,
                debounce: {
                    scroll: 50,
                    resize: 0
                },
                ...a
            }),
            A = P.useRef(null),
            Y = P.useRef(null);
        P.useImperativeHandle(te, () => A.current);
        const ae = Cu(H),
            [se, Ee] = P.useState(!1),
            [ge, Ce] = P.useState(!1);
        if (se) throw se;
        if (ge) throw ge;
        const M = P.useRef(null);
        kn(() => {
            const N = A.current;
            k.width > 0 && k.height > 0 && N && (M.current || (M.current = Pp(N)), M.current.configure({
                gl: d,
                events: f,
                shadows: y,
                linear: v,
                flat: p,
                legacy: S,
                orthographic: x,
                frameloop: w,
                dpr: z,
                performance: I,
                raycaster: C,
                camera: T,
                scene: D,
                size: k,
                onPointerMissed: (...W) => ae.current == null ? void 0 : ae.current(...W),
                onCreated: W => {
                    W.events.connect == null || W.events.connect(g ? cp(g) ? g.current : g : Y.current), h && W.setEvents({
                        compute: (K, ue) => {
                            const ve = K[h + "X"],
                                ee = K[h + "Y"];
                            ue.pointer.set(ve / ue.size.width * 2 - 1, -(ee / ue.size.height) * 2 + 1), ue.raycaster.setFromCamera(ue.pointer, ue.camera)
                        }
                    }), b == null || b(W)
                }
            }), M.current.render(P.createElement(V, null, P.createElement(Uu, {
                set: Ce
            }, P.createElement(P.Suspense, {
                fallback: P.createElement(fp, {
                    set: Ee
                })
            }, r)))))
        }), P.useEffect(() => {
            const N = A.current;
            if (N) return () => Nu(N)
        }, []);
        const B = g ? "none" : "auto";
        return P.createElement("div", qt({
            ref: Y,
            style: {
                position: "relative",
                width: "100%",
                height: "100%",
                overflow: "hidden",
                pointerEvents: B,
                ...c
            }
        }, X), P.createElement("div", {
            ref: q,
            style: {
                width: "100%",
                height: "100%"
            }
        }, P.createElement("canvas", {
            ref: A,
            style: {
                display: "block"
            }
        }, l)))
    }),
    ig = P.forwardRef(function(r, l) {
        return P.createElement(Hu, null, P.createElement(Qp, qt({}, r, {
            ref: l
        })))
    });

function Gu(n) {
    return function(r) {
        n.forEach(function(l) {
            typeof l == "function" ? l(r) : l != null && (l.current = r)
        })
    }
}

function Xp(n, r) {
    if (Object.is(n, r)) return !0;
    if (typeof n != "object" || n === null || typeof r != "object" || r === null) return !1;
    const l = Object.keys(n);
    if (l.length !== Object.keys(r).length) return !1;
    for (let a = 0; a < l.length; a++)
        if (!Object.prototype.hasOwnProperty.call(r, l[a]) || !Object.is(n[l[a]], r[l[a]])) return !1;
    return !0
}
const Kp = P.createContext([]);

function sg({
    box: n,
    multiple: r,
    children: l,
    onChange: a,
    onChangePointerUp: c,
    border: d = "1px solid #55aaff",
    backgroundColor: f = "rgba(75, 160, 255, 0.1)",
    filter: g = y => y,
    ...h
}) {
    const [y, v] = P.useState(!1), {
        setEvents: p,
        camera: S,
        raycaster: x,
        gl: w,
        controls: z,
        size: I,
        get: C
    } = dt(), [T, D] = P.useState(!1), [H, b] = P.useReducer((q, {
        object: k,
        shift: A
    }) => k === void 0 ? [] : Array.isArray(k) ? k : A ? q.includes(k) ? q.filter(Y => Y !== k) : [k, ...q] : q[0] === k ? [] : [k], []);
    P.useEffect(() => {
        y ? a == null || a(H) : c == null || c(H)
    }, [H, y]);
    const X = P.useCallback(q => {
            q.stopPropagation(), b({
                object: g([q.object])[0],
                shift: r && q.shiftKey
            })
        }, []),
        te = P.useCallback(q => !T && b({}), [T]),
        V = P.useRef(null);
    return P.useEffect(() => {
        if (!n || !r) return;
        const q = new cd(S, V.current),
            k = document.createElement("div");
        k.style.pointerEvents = "none", k.style.border = d, k.style.backgroundColor = f, k.style.position = "fixed";
        const A = new Se,
            Y = new Se,
            ae = new Se,
            se = C().events.enabled,
            Ee = z == null ? void 0 : z.enabled;
        let ge = !1;

        function Ce(ee, pe) {
            const {
                offsetX: Re,
                offsetY: Ii
            } = ee, {
                width: jn,
                height: hn
            } = I;
            pe.set(Re / jn * 2 - 1, -(Ii / hn) * 2 + 1)
        }

        function M(ee) {
            var pe;
            z && (z.enabled = !1), p({
                enabled: !1
            }), v(ge = !0), (pe = w.domElement.parentElement) == null || pe.appendChild(k), k.style.left = `${ee.clientX}px`, k.style.top = `${ee.clientY}px`, k.style.width = "0px", k.style.height = "0px", A.x = ee.clientX, A.y = ee.clientY
        }

        function B(ee) {
            ae.x = Math.max(A.x, ee.clientX), ae.y = Math.max(A.y, ee.clientY), Y.x = Math.min(A.x, ee.clientX), Y.y = Math.min(A.y, ee.clientY), k.style.left = `${Y.x}px`, k.style.top = `${Y.y}px`, k.style.width = `${ae.x-Y.x}px`, k.style.height = `${ae.y-Y.y}px`
        }

        function N() {
            if (ge) {
                var ee;
                z && (z.enabled = Ee), p({
                    enabled: se
                }), v(ge = !1), (ee = k.parentElement) == null || ee.removeChild(k)
            }
        }

        function W(ee) {
            ee.shiftKey && (M(ee), Ce(ee, q.startPoint))
        }
        let K = [];

        function ue(ee) {
            if (ge) {
                B(ee), Ce(ee, q.endPoint);
                const pe = q.select().sort(Re => Re.uuid).filter(Re => Re.isMesh);
                Xp(pe, K) || (K = pe, b({
                    object: g(pe)
                }))
            }
        }

        function ve(ee) {
            ge && N()
        }
        return document.addEventListener("pointerdown", W, {
            passive: !0
        }), document.addEventListener("pointermove", ue, {
            passive: !0,
            capture: !0
        }), document.addEventListener("pointerup", ve, {
            passive: !0
        }), () => {
            document.removeEventListener("pointerdown", W), document.removeEventListener("pointermove", ue), document.removeEventListener("pointerup", ve)
        }
    }, [I.width, I.height, x, S, z, w]), P.createElement("group", qt({
        ref: V,
        onClick: X,
        onPointerOver: () => D(!0),
        onPointerOut: () => D(!1),
        onPointerMissed: te
    }, h), P.createElement(Kp.Provider, {
        value: H
    }, l))
}
const Yp = P.forwardRef(function({
        points: r,
        color: l = "black",
        vertexColors: a,
        linewidth: c,
        lineWidth: d,
        segments: f,
        dashed: g,
        ...h
    }, y) {
        const v = dt(w => w.size),
            p = P.useMemo(() => f ? new fd : new dd, [f]),
            [S] = P.useState(() => new hd),
            x = P.useMemo(() => {
                const w = f ? new pd : new vd,
                    z = r.map(I => {
                        const C = Array.isArray(I);
                        return I instanceof Ne ? [I.x, I.y, I.z] : I instanceof Se ? [I.x, I.y, 0] : C && I.length === 3 ? [I[0], I[1], I[2]] : C && I.length === 2 ? [I[0], I[1], 0] : I
                    });
                if (w.setPositions(z.flat()), a) {
                    const I = a.map(C => C instanceof yr ? C.toArray() : C);
                    w.setColors(I.flat())
                }
                return w
            }, [r, f, a]);
        return P.useLayoutEffect(() => {
            p.computeLineDistances()
        }, [r, p]), P.useLayoutEffect(() => {
            g ? S.defines.USE_DASH = "" : delete S.defines.USE_DASH, S.needsUpdate = !0
        }, [g, S]), P.useEffect(() => () => x.dispose(), [x]), P.createElement("primitive", qt({
            object: p,
            ref: y
        }, h), P.createElement("primitive", {
            object: x,
            attach: "geometry"
        }), P.createElement("primitive", qt({
            object: S,
            attach: "material",
            color: l,
            vertexColors: !!a,
            resolution: [v.width, v.height],
            linewidth: c ? ? d,
            dashed: g
        }, h)))
    }),
    Zp = new Ne,
    lg = P.forwardRef(function({
        start: r = [0, 0, 0],
        end: l = [0, 0, 0],
        mid: a,
        segments: c = 20,
        ...d
    }, f) {
        const g = P.useRef(null),
            [h] = P.useState(() => new ld(void 0, void 0, void 0)),
            y = P.useCallback((p, S, x, w = 20) => (p instanceof Ne ? h.v0.copy(p) : h.v0.set(...p), S instanceof Ne ? h.v2.copy(S) : h.v2.set(...S), x instanceof Ne ? h.v1.copy(x) : Array.isArray(x) ? h.v1.set(...x) : h.v1.copy(h.v0.clone().add(h.v2.clone().sub(h.v0)).add(Zp.set(0, h.v0.y - h.v2.y, 0))), h.getPoints(w)), []);
        P.useLayoutEffect(() => {
            g.current.setPoints = (p, S, x) => {
                const w = y(p, S, x);
                g.current.geometry && g.current.geometry.setPositions(w.map(z => z.toArray()).flat())
            }
        }, []);
        const v = P.useMemo(() => y(r, l, a, c), [r, l, a, c]);
        return P.createElement(Yp, qt({
            ref: Gu([g, f]),
            points: v
        }, d))
    });

function ag(n, r, l, a) {
    const c = class extends St {
        constructor(f = {}) {
            const g = Object.entries(n);
            super({
                uniforms: g.reduce((h, [y, v]) => {
                    const p = od.clone({
                        [y]: {
                            value: v
                        }
                    });
                    return { ...h,
                        ...p
                    }
                }, {}),
                vertexShader: r,
                fragmentShader: l
            }), this.key = "", g.forEach(([h]) => Object.defineProperty(this, h, {
                get: () => this.uniforms[h].value,
                set: y => this.uniforms[h].value = y
            })), Object.assign(this, f), a && a(this)
        }
    };
    return c.key = lu.generateUUID(), c
}
const qp = () => parseInt(Ri.replace(/\D+/g, "")),
    Jp = qp();
var $p = 1 / 0,
    ev = 9007199254740991,
    tv = "[object Arguments]",
    nv = "[object Function]",
    rv = "[object GeneratorFunction]",
    iv = "[object Symbol]",
    sv = typeof Zt == "object" && Zt && Zt.Object === Object && Zt,
    lv = typeof self == "object" && self && self.Object === Object && self,
    ov = sv || lv || Function("return this")();

function av(n, r, l) {
    switch (l.length) {
        case 0:
            return n.call(r);
        case 1:
            return n.call(r, l[0]);
        case 2:
            return n.call(r, l[0], l[1]);
        case 3:
            return n.call(r, l[0], l[1], l[2])
    }
    return n.apply(r, l)
}

function uv(n, r) {
    for (var l = -1, a = n ? n.length : 0, c = Array(a); ++l < a;) c[l] = r(n[l], l, n);
    return c
}

function cv(n, r) {
    for (var l = -1, a = r.length, c = n.length; ++l < a;) n[c + l] = r[l];
    return n
}
var Ml = Object.prototype,
    fv = Ml.hasOwnProperty,
    Rl = Ml.toString,
    Xa = ov.Symbol,
    dv = Ml.propertyIsEnumerable,
    Ka = Xa ? Xa.isConcatSpreadable : void 0,
    Ya = Math.max;

function ju(n, r, l, a, c) {
    var d = -1,
        f = n.length;
    for (l || (l = mv), c || (c = []); ++d < f;) {
        var g = n[d];
        r > 0 && l(g) ? r > 1 ? ju(g, r - 1, l, a, c) : cv(c, g) : a || (c[c.length] = g)
    }
    return c
}

function hv(n, r) {
    return n = Object(n), pv(n, r, function(l, a) {
        return a in n
    })
}

function pv(n, r, l) {
    for (var a = -1, c = r.length, d = {}; ++a < c;) {
        var f = r[a],
            g = n[f];
        l(g, f) && (d[f] = g)
    }
    return d
}

function vv(n, r) {
    return r = Ya(r === void 0 ? n.length - 1 : r, 0),
        function() {
            for (var l = arguments, a = -1, c = Ya(l.length - r, 0), d = Array(c); ++a < c;) d[a] = l[r + a];
            a = -1;
            for (var f = Array(r + 1); ++a < r;) f[a] = l[a];
            return f[r] = d, av(n, this, f)
        }
}

function mv(n) {
    return Sv(n) || yv(n) || !!(Ka && n && n[Ka])
}

function gv(n) {
    if (typeof n == "string" || Mv(n)) return n;
    var r = n + "";
    return r == "0" && 1 / n == -$p ? "-0" : r
}

function yv(n) {
    return Ev(n) && fv.call(n, "callee") && (!dv.call(n, "callee") || Rl.call(n) == tv)
}
var Sv = Array.isArray;

function xv(n) {
    return n != null && wv(n.length) && !_v(n)
}

function Ev(n) {
    return bu(n) && xv(n)
}

function _v(n) {
    var r = Tv(n) ? Rl.call(n) : "";
    return r == nv || r == rv
}

function wv(n) {
    return typeof n == "number" && n > -1 && n % 1 == 0 && n <= ev
}

function Tv(n) {
    var r = typeof n;
    return !!n && (r == "object" || r == "function")
}

function bu(n) {
    return !!n && typeof n == "object"
}

function Mv(n) {
    return typeof n == "symbol" || bu(n) && Rl.call(n) == iv
}
var Rv = vv(function(n, r) {
        return n == null ? {} : hv(n, uv(ju(r, 1), gv))
    }),
    Pv = Rv;
const Cv = Mi(Pv);
var Uv = 200,
    Pl = "__lodash_hash_undefined__",
    Lv = 1 / 0,
    Vu = 9007199254740991,
    Dv = "[object Arguments]",
    Iv = "[object Function]",
    zv = "[object GeneratorFunction]",
    Av = "[object Symbol]",
    Bv = /[\\^$.*+?()[\]{}|]/g,
    Nv = /^\[object .+?Constructor\]$/,
    Ov = /^(?:0|[1-9]\d*)$/,
    kv = typeof Zt == "object" && Zt && Zt.Object === Object && Zt,
    Fv = typeof self == "object" && self && self.Object === Object && self,
    Cl = kv || Fv || Function("return this")();

function Hv(n, r, l) {
    switch (l.length) {
        case 0:
            return n.call(r);
        case 1:
            return n.call(r, l[0]);
        case 2:
            return n.call(r, l[0], l[1]);
        case 3:
            return n.call(r, l[0], l[1], l[2])
    }
    return n.apply(r, l)
}

function Gv(n, r) {
    var l = n ? n.length : 0;
    return !!l && Vv(n, r, 0) > -1
}

function jv(n, r, l) {
    for (var a = -1, c = n ? n.length : 0; ++a < c;)
        if (l(r, n[a])) return !0;
    return !1
}

function Wu(n, r) {
    for (var l = -1, a = n ? n.length : 0, c = Array(a); ++l < a;) c[l] = r(n[l], l, n);
    return c
}

function Ul(n, r) {
    for (var l = -1, a = r.length, c = n.length; ++l < a;) n[c + l] = r[l];
    return n
}

function bv(n, r, l, a) {
    for (var c = n.length, d = l + (a ? 1 : -1); a ? d-- : ++d < c;)
        if (r(n[d], d, n)) return d;
    return -1
}

function Vv(n, r, l) {
    if (r !== r) return bv(n, Wv, l);
    for (var a = l - 1, c = n.length; ++a < c;)
        if (n[a] === r) return a;
    return -1
}

function Wv(n) {
    return n !== n
}

function Qv(n, r) {
    for (var l = -1, a = Array(n); ++l < n;) a[l] = r(l);
    return a
}

function Xv(n) {
    return function(r) {
        return n(r)
    }
}

function Kv(n, r) {
    return n.has(r)
}

function Yv(n, r) {
    return n == null ? void 0 : n[r]
}

function Zv(n) {
    var r = !1;
    if (n != null && typeof n.toString != "function") try {
        r = !!(n + "")
    } catch {}
    return r
}

function Qu(n, r) {
    return function(l) {
        return n(r(l))
    }
}
var qv = Array.prototype,
    Jv = Function.prototype,
    Ci = Object.prototype,
    il = Cl["__core-js_shared__"],
    Za = function() {
        var n = /[^.]+$/.exec(il && il.keys && il.keys.IE_PROTO || "");
        return n ? "Symbol(src)_1." + n : ""
    }(),
    Xu = Jv.toString,
    Fn = Ci.hasOwnProperty,
    Ll = Ci.toString,
    $v = RegExp("^" + Xu.call(Fn).replace(Bv, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
    qa = Cl.Symbol,
    em = Qu(Object.getPrototypeOf, Object),
    tm = Ci.propertyIsEnumerable,
    nm = qv.splice,
    Ja = qa ? qa.isConcatSpreadable : void 0,
    ul = Object.getOwnPropertySymbols,
    $a = Math.max,
    rm = Yu(Cl, "Map"),
    gr = Yu(Object, "create");

function fn(n) {
    var r = -1,
        l = n ? n.length : 0;
    for (this.clear(); ++r < l;) {
        var a = n[r];
        this.set(a[0], a[1])
    }
}

function im() {
    this.__data__ = gr ? gr(null) : {}
}

function sm(n) {
    return this.has(n) && delete this.__data__[n]
}

function lm(n) {
    var r = this.__data__;
    if (gr) {
        var l = r[n];
        return l === Pl ? void 0 : l
    }
    return Fn.call(r, n) ? r[n] : void 0
}

function om(n) {
    var r = this.__data__;
    return gr ? r[n] !== void 0 : Fn.call(r, n)
}

function am(n, r) {
    var l = this.__data__;
    return l[n] = gr && r === void 0 ? Pl : r, this
}
fn.prototype.clear = im;
fn.prototype.delete = sm;
fn.prototype.get = lm;
fn.prototype.has = om;
fn.prototype.set = am;

function Hn(n) {
    var r = -1,
        l = n ? n.length : 0;
    for (this.clear(); ++r < l;) {
        var a = n[r];
        this.set(a[0], a[1])
    }
}

function um() {
    this.__data__ = []
}

function cm(n) {
    var r = this.__data__,
        l = Ui(r, n);
    if (l < 0) return !1;
    var a = r.length - 1;
    return l == a ? r.pop() : nm.call(r, l, 1), !0
}

function fm(n) {
    var r = this.__data__,
        l = Ui(r, n);
    return l < 0 ? void 0 : r[l][1]
}

function dm(n) {
    return Ui(this.__data__, n) > -1
}

function hm(n, r) {
    var l = this.__data__,
        a = Ui(l, n);
    return a < 0 ? l.push([n, r]) : l[a][1] = r, this
}
Hn.prototype.clear = um;
Hn.prototype.delete = cm;
Hn.prototype.get = fm;
Hn.prototype.has = dm;
Hn.prototype.set = hm;

function Gn(n) {
    var r = -1,
        l = n ? n.length : 0;
    for (this.clear(); ++r < l;) {
        var a = n[r];
        this.set(a[0], a[1])
    }
}

function pm() {
    this.__data__ = {
        hash: new fn,
        map: new(rm || Hn),
        string: new fn
    }
}

function vm(n) {
    return Li(this, n).delete(n)
}

function mm(n) {
    return Li(this, n).get(n)
}

function gm(n) {
    return Li(this, n).has(n)
}

function ym(n, r) {
    return Li(this, n).set(n, r), this
}
Gn.prototype.clear = pm;
Gn.prototype.delete = vm;
Gn.prototype.get = mm;
Gn.prototype.has = gm;
Gn.prototype.set = ym;

function Ti(n) {
    var r = -1,
        l = n ? n.length : 0;
    for (this.__data__ = new Gn; ++r < l;) this.add(n[r])
}

function Sm(n) {
    return this.__data__.set(n, Pl), this
}

function xm(n) {
    return this.__data__.has(n)
}
Ti.prototype.add = Ti.prototype.push = Sm;
Ti.prototype.has = xm;

function Em(n, r) {
    var l = Dl(n) || Zu(n) ? Qv(n.length, String) : [],
        a = l.length,
        c = !!a;
    for (var d in n)(r || Fn.call(n, d)) && !(c && (d == "length" || zm(d, a))) && l.push(d);
    return l
}

function Ui(n, r) {
    for (var l = n.length; l--;)
        if (Hm(n[l][0], r)) return l;
    return -1
}

function _m(n, r, l, a) {
    var c = -1,
        d = Gv,
        f = !0,
        g = n.length,
        h = [],
        y = r.length;
    if (!g) return h;
    l && (r = Wu(r, Xv(l))), a ? (d = jv, f = !1) : r.length >= Uv && (d = Kv, f = !1, r = new Ti(r));
    e: for (; ++c < g;) {
        var v = n[c],
            p = l ? l(v) : v;
        if (v = a || v !== 0 ? v : 0, f && p === p) {
            for (var S = y; S--;)
                if (r[S] === p) continue e;
            h.push(v)
        } else d(r, p, a) || h.push(v)
    }
    return h
}

function Ku(n, r, l, a, c) {
    var d = -1,
        f = n.length;
    for (l || (l = Im), c || (c = []); ++d < f;) {
        var g = n[d];
        r > 0 && l(g) ? r > 1 ? Ku(g, r - 1, l, a, c) : Ul(c, g) : a || (c[c.length] = g)
    }
    return c
}

function wm(n, r, l) {
    var a = r(n);
    return Dl(n) ? a : Ul(a, l(n))
}

function Tm(n) {
    if (!Il(n) || Bm(n)) return !1;
    var r = Ju(n) || Zv(n) ? $v : Nv;
    return r.test(Fm(n))
}

function Mm(n) {
    if (!Il(n)) return Om(n);
    var r = Nm(n),
        l = [];
    for (var a in n) a == "constructor" && (r || !Fn.call(n, a)) || l.push(a);
    return l
}

function Rm(n, r) {
    return n = Object(n), Pm(n, r, function(l, a) {
        return a in n
    })
}

function Pm(n, r, l) {
    for (var a = -1, c = r.length, d = {}; ++a < c;) {
        var f = r[a],
            g = n[f];
        l(g, f) && (d[f] = g)
    }
    return d
}

function Cm(n, r) {
    return r = $a(r === void 0 ? n.length - 1 : r, 0),
        function() {
            for (var l = arguments, a = -1, c = $a(l.length - r, 0), d = Array(c); ++a < c;) d[a] = l[r + a];
            a = -1;
            for (var f = Array(r + 1); ++a < r;) f[a] = l[a];
            return f[r] = d, Hv(n, this, f)
        }
}

function Um(n) {
    return wm(n, Vm, Dm)
}

function Li(n, r) {
    var l = n.__data__;
    return Am(r) ? l[typeof r == "string" ? "string" : "hash"] : l.map
}

function Yu(n, r) {
    var l = Yv(n, r);
    return Tm(l) ? l : void 0
}
var Lm = ul ? Qu(ul, Object) : ec,
    Dm = ul ? function(n) {
        for (var r = []; n;) Ul(r, Lm(n)), n = em(n);
        return r
    } : ec;

function Im(n) {
    return Dl(n) || Zu(n) || !!(Ja && n && n[Ja])
}

function zm(n, r) {
    return r = r ? ? Vu, !!r && (typeof n == "number" || Ov.test(n)) && n > -1 && n % 1 == 0 && n < r
}

function Am(n) {
    var r = typeof n;
    return r == "string" || r == "number" || r == "symbol" || r == "boolean" ? n !== "__proto__" : n === null
}

function Bm(n) {
    return !!Za && Za in n
}

function Nm(n) {
    var r = n && n.constructor,
        l = typeof r == "function" && r.prototype || Ci;
    return n === l
}

function Om(n) {
    var r = [];
    if (n != null)
        for (var l in Object(n)) r.push(l);
    return r
}

function km(n) {
    if (typeof n == "string" || bm(n)) return n;
    var r = n + "";
    return r == "0" && 1 / n == -Lv ? "-0" : r
}

function Fm(n) {
    if (n != null) {
        try {
            return Xu.call(n)
        } catch {}
        try {
            return n + ""
        } catch {}
    }
    return ""
}

function Hm(n, r) {
    return n === r || n !== n && r !== r
}

function Zu(n) {
    return Gm(n) && Fn.call(n, "callee") && (!tm.call(n, "callee") || Ll.call(n) == Dv)
}
var Dl = Array.isArray;

function qu(n) {
    return n != null && jm(n.length) && !Ju(n)
}

function Gm(n) {
    return $u(n) && qu(n)
}

function Ju(n) {
    var r = Il(n) ? Ll.call(n) : "";
    return r == Iv || r == zv
}

function jm(n) {
    return typeof n == "number" && n > -1 && n % 1 == 0 && n <= Vu
}

function Il(n) {
    var r = typeof n;
    return !!n && (r == "object" || r == "function")
}

function $u(n) {
    return !!n && typeof n == "object"
}

function bm(n) {
    return typeof n == "symbol" || $u(n) && Ll.call(n) == Av
}

function Vm(n) {
    return qu(n) ? Em(n, !0) : Mm(n)
}
var Wm = Cm(function(n, r) {
    return n == null ? {} : (r = Wu(Ku(r, 1), km), Rm(n, _m(Um(n), r)))
});

function ec() {
    return []
}
var Qm = Wm;
const Xm = Mi(Qm),
    ug = P.forwardRef(({
        children: n,
        domElement: r,
        onChange: l,
        onMouseDown: a,
        onMouseUp: c,
        onObjectChange: d,
        object: f,
        makeDefault: g,
        ...h
    }, y) => {
        const v = ["enabled", "axis", "mode", "translationSnap", "rotationSnap", "scaleSnap", "space", "size", "showX", "showY", "showZ"],
            {
                camera: p,
                ...S
            } = h,
            x = Cv(S, v),
            w = Xm(S, v),
            z = dt(se => se.controls),
            I = dt(se => se.gl),
            C = dt(se => se.events),
            T = dt(se => se.camera),
            D = dt(se => se.invalidate),
            H = dt(se => se.get),
            b = dt(se => se.set),
            X = p || T,
            te = r || C.connected || I.domElement,
            V = P.useMemo(() => new md(X, te), [X, te]),
            q = P.useRef();
        P.useLayoutEffect(() => (f ? V.attach(f instanceof wi ? f : f.current) : q.current instanceof wi && V.attach(q.current), () => void V.detach()), [f, n, V]), P.useEffect(() => {
            if (z) {
                const se = Ee => z.enabled = !Ee.value;
                return V.addEventListener("dragging-changed", se), () => V.removeEventListener("dragging-changed", se)
            }
        }, [V, z]);
        const k = P.useRef(),
            A = P.useRef(),
            Y = P.useRef(),
            ae = P.useRef();
        return P.useLayoutEffect(() => void(k.current = l), [l]), P.useLayoutEffect(() => void(A.current = a), [a]), P.useLayoutEffect(() => void(Y.current = c), [c]), P.useLayoutEffect(() => void(ae.current = d), [d]), P.useEffect(() => {
            const se = M => {
                    D(), k.current == null || k.current(M)
                },
                Ee = M => A.current == null ? void 0 : A.current(M),
                ge = M => Y.current == null ? void 0 : Y.current(M),
                Ce = M => ae.current == null ? void 0 : ae.current(M);
            return V.addEventListener("change", se), V.addEventListener("mouseDown", Ee), V.addEventListener("mouseUp", ge), V.addEventListener("objectChange", Ce), () => {
                V.removeEventListener("change", se), V.removeEventListener("mouseDown", Ee), V.removeEventListener("mouseUp", ge), V.removeEventListener("objectChange", Ce)
            }
        }, [D, V]), P.useEffect(() => {
            if (g) {
                const se = H().controls;
                return b({
                    controls: V
                }), () => b({
                    controls: se
                })
            }
        }, [g, V]), V ? P.createElement(P.Fragment, null, P.createElement("primitive", qt({
            ref: y,
            object: V
        }, x)), P.createElement("group", qt({
            ref: q
        }, w), n)) : null
    });

function cg(n, r) {
    const l = P.useRef(),
        [a] = P.useState(() => r ? r instanceof wi ? {
            current: r
        } : r : l),
        [c] = P.useState(() => new ad(void 0));
    P.useLayoutEffect(() => {
        r && (a.current = r instanceof wi ? r : r.current), c._root = a.current
    });
    const d = P.useRef({}),
        f = P.useMemo(() => {
            const g = {};
            return n.forEach(h => Object.defineProperty(g, h.name, {
                enumerable: !0,
                get() {
                    if (a.current) return d.current[h.name] || (d.current[h.name] = c.clipAction(h, a.current))
                },
                configurable: !0
            })), {
                ref: a,
                clips: n,
                actions: g,
                names: n.map(h => h.name),
                mixer: c
            }
        }, [n]);
    return wl((g, h) => c.update(h)), P.useEffect(() => {
        const g = a.current;
        return () => {
            d.current = {}, c.stopAllAction(), Object.values(f.actions).forEach(h => {
                g && c.uncacheAction(h, g)
            })
        }
    }, [n]), f
}
class Km extends St {
    constructor(r = new Se) {
        super({
            uniforms: {
                inputBuffer: new Q(null),
                depthBuffer: new Q(null),
                resolution: new Q(new Se),
                texelSize: new Q(new Se),
                halfTexelSize: new Q(new Se),
                kernel: new Q(0),
                scale: new Q(1),
                cameraNear: new Q(0),
                cameraFar: new Q(1),
                minDepthThreshold: new Q(0),
                maxDepthThreshold: new Q(1),
                depthScale: new Q(0),
                depthToBlurRatioBias: new Q(.25)
            },
            fragmentShader: `#include <common>
        #include <dithering_pars_fragment>      
        uniform sampler2D inputBuffer;
        uniform sampler2D depthBuffer;
        uniform float cameraNear;
        uniform float cameraFar;
        uniform float minDepthThreshold;
        uniform float maxDepthThreshold;
        uniform float depthScale;
        uniform float depthToBlurRatioBias;
        varying vec2 vUv;
        varying vec2 vUv0;
        varying vec2 vUv1;
        varying vec2 vUv2;
        varying vec2 vUv3;

        void main() {
          float depthFactor = 0.0;
          
          #ifdef USE_DEPTH
            vec4 depth = texture2D(depthBuffer, vUv);
            depthFactor = smoothstep(minDepthThreshold, maxDepthThreshold, 1.0-(depth.r * depth.a));
            depthFactor *= depthScale;
            depthFactor = max(0.0, min(1.0, depthFactor + 0.25));
          #endif
          
          vec4 sum = texture2D(inputBuffer, mix(vUv0, vUv, depthFactor));
          sum += texture2D(inputBuffer, mix(vUv1, vUv, depthFactor));
          sum += texture2D(inputBuffer, mix(vUv2, vUv, depthFactor));
          sum += texture2D(inputBuffer, mix(vUv3, vUv, depthFactor));
          gl_FragColor = sum * 0.25 ;

          #include <dithering_fragment>
          #include <tonemapping_fragment>
          #include <${Jp>=154?"colorspace_fragment":"encodings_fragment"}>
        }`,
            vertexShader: `uniform vec2 texelSize;
        uniform vec2 halfTexelSize;
        uniform float kernel;
        uniform float scale;
        varying vec2 vUv;
        varying vec2 vUv0;
        varying vec2 vUv1;
        varying vec2 vUv2;
        varying vec2 vUv3;

        void main() {
          vec2 uv = position.xy * 0.5 + 0.5;
          vUv = uv;

          vec2 dUv = (texelSize * vec2(kernel) + halfTexelSize) * scale;
          vUv0 = vec2(uv.x - dUv.x, uv.y + dUv.y);
          vUv1 = vec2(uv.x + dUv.x, uv.y + dUv.y);
          vUv2 = vec2(uv.x + dUv.x, uv.y - dUv.y);
          vUv3 = vec2(uv.x - dUv.x, uv.y - dUv.y);

          gl_Position = vec4(position.xy, 1.0, 1.0);
        }`,
            blending: Ot,
            depthWrite: !1,
            depthTest: !1
        }), this.toneMapped = !1, this.setTexelSize(r.x, r.y), this.kernel = new Float32Array([0, 1, 2, 2, 3])
    }
    setTexelSize(r, l) {
        this.uniforms.texelSize.value.set(r, l), this.uniforms.halfTexelSize.value.set(r, l).multiplyScalar(.5)
    }
    setResolution(r) {
        this.uniforms.resolution.value.copy(r)
    }
}
class fg {
    constructor({
        gl: r,
        resolution: l,
        width: a = 500,
        height: c = 500,
        minDepthThreshold: d = 0,
        maxDepthThreshold: f = 1,
        depthScale: g = 0,
        depthToBlurRatioBias: h = .25
    }) {
        this.renderToScreen = !1, this.renderTargetA = new rt(l, l, {
            minFilter: ht,
            magFilter: ht,
            stencilBuffer: !1,
            depthBuffer: !1,
            type: pl
        }), this.renderTargetB = this.renderTargetA.clone(), this.convolutionMaterial = new Km, this.convolutionMaterial.setTexelSize(1 / a, 1 / c), this.convolutionMaterial.setResolution(new Se(a, c)), this.scene = new pr, this.camera = new vl, this.convolutionMaterial.uniforms.minDepthThreshold.value = d, this.convolutionMaterial.uniforms.maxDepthThreshold.value = f, this.convolutionMaterial.uniforms.depthScale.value = g, this.convolutionMaterial.uniforms.depthToBlurRatioBias.value = h, this.convolutionMaterial.defines.USE_DEPTH = g > 0;
        const y = new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]),
            v = new Float32Array([0, 0, 2, 0, 0, 2]),
            p = new ml;
        p.setAttribute("position", new In(y, 3)), p.setAttribute("uv", new In(v, 2)), this.screen = new iu(p, this.convolutionMaterial), this.screen.frustumCulled = !1, this.scene.add(this.screen)
    }
    render(r, l, a) {
        const c = this.scene,
            d = this.camera,
            f = this.renderTargetA,
            g = this.renderTargetB;
        let h = this.convolutionMaterial,
            y = h.uniforms;
        y.depthBuffer.value = l.depthTexture;
        const v = h.kernel;
        let p = l,
            S, x, w;
        for (x = 0, w = v.length - 1; x < w; ++x) S = x & 1 ? g : f, y.kernel.value = v[x], y.inputBuffer.value = p.texture, r.setRenderTarget(S), r.render(c, d), p = S;
        y.kernel.value = v[x], y.inputBuffer.value = p.texture, r.setRenderTarget(this.renderToScreen ? null : a), r.render(c, d)
    }
}
class dg extends ud {
    constructor(r = {}) {
        super(r), this._tDepth = {
            value: null
        }, this._distortionMap = {
            value: null
        }, this._tDiffuse = {
            value: null
        }, this._tDiffuseBlur = {
            value: null
        }, this._textureMatrix = {
            value: null
        }, this._hasBlur = {
            value: !1
        }, this._mirror = {
            value: 0
        }, this._mixBlur = {
            value: 0
        }, this._blurStrength = {
            value: .5
        }, this._minDepthThreshold = {
            value: .9
        }, this._maxDepthThreshold = {
            value: 1
        }, this._depthScale = {
            value: 0
        }, this._depthToBlurRatioBias = {
            value: .25
        }, this._distortion = {
            value: 1
        }, this._mixContrast = {
            value: 1
        }, this.setValues(r)
    }
    onBeforeCompile(r) {
        var l;
        (l = r.defines) != null && l.USE_UV || (r.defines.USE_UV = ""), r.uniforms.hasBlur = this._hasBlur, r.uniforms.tDiffuse = this._tDiffuse, r.uniforms.tDepth = this._tDepth, r.uniforms.distortionMap = this._distortionMap, r.uniforms.tDiffuseBlur = this._tDiffuseBlur, r.uniforms.textureMatrix = this._textureMatrix, r.uniforms.mirror = this._mirror, r.uniforms.mixBlur = this._mixBlur, r.uniforms.mixStrength = this._blurStrength, r.uniforms.minDepthThreshold = this._minDepthThreshold, r.uniforms.maxDepthThreshold = this._maxDepthThreshold, r.uniforms.depthScale = this._depthScale, r.uniforms.depthToBlurRatioBias = this._depthToBlurRatioBias, r.uniforms.distortion = this._distortion, r.uniforms.mixContrast = this._mixContrast, r.vertexShader = `
        uniform mat4 textureMatrix;
        varying vec4 my_vUv;
      ${r.vertexShader}`, r.vertexShader = r.vertexShader.replace("#include <project_vertex>", `#include <project_vertex>
        my_vUv = textureMatrix * vec4( position, 1.0 );
        gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );`), r.fragmentShader = `
        uniform sampler2D tDiffuse;
        uniform sampler2D tDiffuseBlur;
        uniform sampler2D tDepth;
        uniform sampler2D distortionMap;
        uniform float distortion;
        uniform float cameraNear;
			  uniform float cameraFar;
        uniform bool hasBlur;
        uniform float mixBlur;
        uniform float mirror;
        uniform float mixStrength;
        uniform float minDepthThreshold;
        uniform float maxDepthThreshold;
        uniform float mixContrast;
        uniform float depthScale;
        uniform float depthToBlurRatioBias;
        varying vec4 my_vUv;
        ${r.fragmentShader}`, r.fragmentShader = r.fragmentShader.replace("#include <emissivemap_fragment>", `#include <emissivemap_fragment>

      float distortionFactor = 0.0;
      #ifdef USE_DISTORTION
        distortionFactor = texture2D(distortionMap, vUv).r * distortion;
      #endif

      vec4 new_vUv = my_vUv;
      new_vUv.x += distortionFactor;
      new_vUv.y += distortionFactor;

      vec4 base = texture2DProj(tDiffuse, new_vUv);
      vec4 blur = texture2DProj(tDiffuseBlur, new_vUv);

      vec4 merge = base;

      #ifdef USE_NORMALMAP
        vec2 normal_uv = vec2(0.0);
        vec4 normalColor = texture2D(normalMap, vUv * normalScale);
        vec3 my_normal = normalize( vec3( normalColor.r * 2.0 - 1.0, normalColor.b,  normalColor.g * 2.0 - 1.0 ) );
        vec3 coord = new_vUv.xyz / new_vUv.w;
        normal_uv = coord.xy + coord.z * my_normal.xz * 0.05;
        vec4 base_normal = texture2D(tDiffuse, normal_uv);
        vec4 blur_normal = texture2D(tDiffuseBlur, normal_uv);
        merge = base_normal;
        blur = blur_normal;
      #endif

      float depthFactor = 0.0001;
      float blurFactor = 0.0;

      #ifdef USE_DEPTH
        vec4 depth = texture2DProj(tDepth, new_vUv);
        depthFactor = smoothstep(minDepthThreshold, maxDepthThreshold, 1.0-(depth.r * depth.a));
        depthFactor *= depthScale;
        depthFactor = max(0.0001, min(1.0, depthFactor));

        #ifdef USE_BLUR
          blur = blur * min(1.0, depthFactor + depthToBlurRatioBias);
          merge = merge * min(1.0, depthFactor + 0.5);
        #else
          merge = merge * depthFactor;
        #endif

      #endif

      float reflectorRoughnessFactor = roughness;
      #ifdef USE_ROUGHNESSMAP
        vec4 reflectorTexelRoughness = texture2D( roughnessMap, vUv );
        reflectorRoughnessFactor *= reflectorTexelRoughness.g;
      #endif

      #ifdef USE_BLUR
        blurFactor = min(1.0, mixBlur * reflectorRoughnessFactor);
        merge = mix(merge, blur, blurFactor);
      #endif

      vec4 newMerge = vec4(0.0, 0.0, 0.0, 1.0);
      newMerge.r = (merge.r - 0.5) * mixContrast + 0.5;
      newMerge.g = (merge.g - 0.5) * mixContrast + 0.5;
      newMerge.b = (merge.b - 0.5) * mixContrast + 0.5;

      diffuseColor.rgb = diffuseColor.rgb * ((1.0 - min(1.0, mirror)) + newMerge.rgb * mixStrength);
      `)
    }
    get tDiffuse() {
        return this._tDiffuse.value
    }
    set tDiffuse(r) {
        this._tDiffuse.value = r
    }
    get tDepth() {
        return this._tDepth.value
    }
    set tDepth(r) {
        this._tDepth.value = r
    }
    get distortionMap() {
        return this._distortionMap.value
    }
    set distortionMap(r) {
        this._distortionMap.value = r
    }
    get tDiffuseBlur() {
        return this._tDiffuseBlur.value
    }
    set tDiffuseBlur(r) {
        this._tDiffuseBlur.value = r
    }
    get textureMatrix() {
        return this._textureMatrix.value
    }
    set textureMatrix(r) {
        this._textureMatrix.value = r
    }
    get hasBlur() {
        return this._hasBlur.value
    }
    set hasBlur(r) {
        this._hasBlur.value = r
    }
    get mirror() {
        return this._mirror.value
    }
    set mirror(r) {
        this._mirror.value = r
    }
    get mixBlur() {
        return this._mixBlur.value
    }
    set mixBlur(r) {
        this._mixBlur.value = r
    }
    get mixStrength() {
        return this._blurStrength.value
    }
    set mixStrength(r) {
        this._blurStrength.value = r
    }
    get minDepthThreshold() {
        return this._minDepthThreshold.value
    }
    set minDepthThreshold(r) {
        this._minDepthThreshold.value = r
    }
    get maxDepthThreshold() {
        return this._maxDepthThreshold.value
    }
    set maxDepthThreshold(r) {
        this._maxDepthThreshold.value = r
    }
    get depthScale() {
        return this._depthScale.value
    }
    set depthScale(r) {
        this._depthScale.value = r
    }
    get depthToBlurRatioBias() {
        return this._depthToBlurRatioBias.value
    }
    set depthToBlurRatioBias(r) {
        this._depthToBlurRatioBias.value = r
    }
    get distortion() {
        return this._distortion.value
    }
    set distortion(r) {
        this._distortion.value = r
    }
    get mixContrast() {
        return this._mixContrast.value
    }
    set mixContrast(r) {
        this._mixContrast.value = r
    }
}
const hg = P.forwardRef(({
        children: n,
        enabled: r = !0,
        speed: l = 1,
        rotationIntensity: a = 1,
        floatIntensity: c = 1,
        floatingRange: d = [-.1, .1],
        ...f
    }, g) => {
        const h = P.useRef(null),
            y = P.useRef(Math.random() * 1e4);
        return wl(v => {
            var p, S;
            if (!r || l === 0) return;
            const x = y.current + v.clock.getElapsedTime();
            h.current.rotation.x = Math.cos(x / 4 * l) / 8 * a, h.current.rotation.y = Math.sin(x / 4 * l) / 8 * a, h.current.rotation.z = Math.sin(x / 4 * l) / 20 * a;
            let w = Math.sin(x / 4 * l) / 10;
            w = lu.mapLinear(w, -.1, .1, (p = d == null ? void 0 : d[0]) !== null && p !== void 0 ? p : -.1, (S = d == null ? void 0 : d[1]) !== null && S !== void 0 ? S : .1), h.current.position.y = w * c, h.current.updateMatrix()
        }), P.createElement("group", f, P.createElement("group", {
            ref: Gu([h, g]),
            matrixAutoUpdate: !1
        }, n))
    }),
    Ym = P.createContext(null),
    eu = n => (n.getAttributes() & Pt.CONVOLUTION) === Pt.CONVOLUTION,
    pg = sl.memo(P.forwardRef(({
        children: n,
        camera: r,
        scene: l,
        resolutionScale: a,
        enabled: c = !0,
        renderPriority: d = 1,
        autoClear: f = !0,
        depthBuffer: g,
        disableNormalPass: h,
        stencilBuffer: y,
        multisampling: v = 8,
        frameBufferType: p = pl
    }, S) => {
        const {
            gl: x,
            scene: w,
            camera: z,
            size: I
        } = dt(), C = l || w, T = r || z, [D, H, b] = P.useMemo(() => {
            const q = gd(),
                k = new lh(x, {
                    depthBuffer: g,
                    stencilBuffer: y,
                    multisampling: v > 0 && q ? v : 0,
                    frameBufferType: p
                });
            k.addPass(new mu(C, T));
            let A = null,
                Y = null;
            return h || (Y = new rh(C, T), Y.enabled = !1, k.addPass(Y), a !== void 0 && q && (A = new qd({
                normalBuffer: Y.texture,
                resolutionScale: a
            }), A.enabled = !1, k.addPass(A))), [k, Y, A]
        }, [T, x, g, y, v, p, C, h, a]);
        P.useEffect(() => D == null ? void 0 : D.setSize(I.width, I.height), [D, I]), wl((q, k) => {
            if (c) {
                const A = x.autoClear;
                x.autoClear = f, y && !f && x.clearStencil(), D.render(k), x.autoClear = A
            }
        }, c ? d : 0);
        const X = P.useRef(null),
            te = Tp(X);
        P.useLayoutEffect(() => {
            const q = [];
            if (X.current && te.current && D) {
                const k = te.current.objects;
                for (let A = 0; A < k.length; A++) {
                    const Y = k[A];
                    if (Y instanceof $t) {
                        const ae = [Y];
                        if (!eu(Y)) {
                            let Ee = null;
                            for (;
                                (Ee = k[A + 1]) instanceof $t && !eu(Ee);) ae.push(Ee), A++
                        }
                        const se = new $d(T, ...ae);
                        q.push(se)
                    } else Y instanceof qe && q.push(Y)
                }
                for (const A of q) D == null || D.addPass(A);
                H && (H.enabled = !0), b && (b.enabled = !0)
            }
            return () => {
                for (const k of q) D == null || D.removePass(k);
                H && (H.enabled = !1), b && (b.enabled = !1)
            }
        }, [D, n, T, H, b, te]);
        const V = P.useMemo(() => ({
            composer: D,
            normalPass: H,
            downSamplingPass: b,
            resolutionScale: a,
            camera: T,
            scene: C
        }), [D, H, b, a, T, C]);
        return P.useImperativeHandle(S, () => D, [D]), vr.jsx(Ym.Provider, {
            value: V,
            children: vr.jsx("group", {
                ref: X,
                children: n
            })
        })
    }));
let Zm = 0;
const tu = new WeakMap,
    Di = (n, r) => sl.forwardRef(function({
        blendFunction: a = r == null ? void 0 : r.blendFunction,
        opacity: c = r == null ? void 0 : r.opacity,
        ...d
    }, f) {
        let g = tu.get(n);
        if (!g) {
            const v = `@react-three/postprocessing/${n.name}-${Zm++}`;
            Mu({
                [v]: n
            }), tu.set(n, g = v)
        }
        const h = dt(v => v.camera),
            y = sl.useMemo(() => {
                var v, p;
                return [...(v = r == null ? void 0 : r.args) != null ? v : [], ...(p = d.args) != null ? p : [{ ...r,
                    ...d
                }]]
            }, [JSON.stringify(d)]);
        return vr.jsx(g, {
            camera: h,
            "blendMode-blendFunction": a,
            "blendMode-opacity-value": c,
            ...d,
            ref: f,
            args: y
        })
    }),
    vg = Di(bh, {
        blendFunction: ie.ADD
    }),
    mg = Di(Xh),
    gg = Di(qh, {
        blendFunction: ie.COLOR_DODGE
    }),
    yg = P.forwardRef(function({
        blendFunction: r,
        adaptive: l,
        mode: a,
        resolution: c,
        maxLuminance: d,
        whitePoint: f,
        middleGrey: g,
        minLuminance: h,
        averageLuminance: y,
        adaptationRate: v,
        ...p
    }, S) {
        const x = P.useMemo(() => new $h({
            blendFunction: r,
            adaptive: l,
            mode: a,
            resolution: c,
            maxLuminance: d,
            whitePoint: f,
            middleGrey: g,
            minLuminance: h,
            averageLuminance: y,
            adaptationRate: v
        }), [r, l, a, c, d, f, g, h, y, v]);
        return P.useEffect(() => {
            x.dispose()
        }, [x]), vr.jsx("primitive", { ...p,
            ref: S,
            object: x,
            attributes: Pt.CONVOLUTION
        })
    }),
    Sg = Di(tp),
    xg = P.forwardRef(function({
        lut: r,
        tetrahedralInterpolation: l,
        ...a
    }, c) {
        const d = P.useMemo(() => new Yh(r, a), [r, a]),
            f = dt(g => g.invalidate);
        return P.useLayoutEffect(() => {
            l && (d.tetrahedralInterpolation = l), r && (d.lut = r), f()
        }, [d, f, r, l]), vr.jsx("primitive", {
            ref: c,
            object: d,
            dispose: null
        })
    });
export {
    vg as B, ig as C, $t as E, hg as F, mg as H, yl as K, tg as L, dg as M, gg as N, lg as Q, be as R, sg as S, yg as T, Sg as V, wl as a, ie as b, xg as c, pg as d, Mu as e, fg as f, ug as g, cg as h, ng as i, vr as j, wa as k, Gu as m, ag as s, dt as u
};