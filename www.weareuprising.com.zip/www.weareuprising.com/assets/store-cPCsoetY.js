import {
    r as S,
    g as m,
    R as G
} from "./react-ZVDsBwBb.js";
var y = {
    VITE_META_TITLE: "Uprising™ | Digital creative production company",
    VITE_META_KEYWORDS: "uprising, digital, creative, production, company",
    VITE_META_DESCRIPTION: "Uprising™ is a digital creative production studio based in Milan, Italy. We are designers, we are developers, we are Uprising™",
    VITE_META_SITE: "https://uprsg-site-v2.vercel.app",
    VITE_META_TYPE: "website",
    VITE_META_CARD: "summary_large_image",
    VITE_META_IMAGE: "https://uprsg-site-v2.vercel.app/assets/images/uprising-share.png",
    VITE_META_IMAGE_WIDTH: "1200",
    VITE_META_IMAGE_HEIGHT: "630",
    VITE_META_IMAGE_TYPE: "image/png",
    VITE_META_THEME_COLOR: "#000000",
    VITE_BASE_URL: "/",
    VITE_VERCEL_GIT_REPO_ID: "57900005",
    VITE_VERCEL_ENV: "production",
    VITE_VERCEL_GIT_PULL_REQUEST_ID: "",
    VITE_VERCEL_BRANCH_URL: "uprsg-site-v2-git-develop-studiogustos-projects.vercel.app",
    VITE_VERCEL_GIT_COMMIT_SHA: "b71ea8372beb8c54c63fc7a4aa7e9ddfac0393dd",
    VITE_VERCEL_URL: "uprsg-site-v2-9g4415z49-studiogustos-projects.vercel.app",
    VITE_VERCEL_GIT_COMMIT_AUTHOR_NAME: "Mauro Piccin",
    VITE_VERCEL_GIT_PREVIOUS_SHA: "",
    VITE_VERCEL_PROJECT_PRODUCTION_URL: "www.weareuprising.com",
    VITE_VERCEL_GIT_REPO_OWNER: "gustoids-dev",
    VITE_VERCEL_GIT_COMMIT_AUTHOR_LOGIN: "mpcreativedev",
    VITE_VERCEL_GIT_PROVIDER: "gitlab",
    VITE_VERCEL_GIT_COMMIT_REF: "develop",
    VITE_VERCEL_GIT_REPO_SLUG: "uprsg-site-v2",
    VITE_VERCEL_GIT_COMMIT_MESSAGE: `Merge branch 'next' into develop
`,
    BASE_URL: "/",
    MODE: "production",
    DEV: !1,
    PROD: !0,
    SSR: !1
};
const v = e => {
        let t;
        const r = new Set,
            n = (i, p) => {
                const o = typeof i == "function" ? i(t) : i;
                if (!Object.is(o, t)) {
                    const a = t;
                    t = p ? ? typeof o != "object" ? o : Object.assign({}, t, o), r.forEach(d => d(t, a))
                }
            },
            E = () => t,
            c = {
                setState: n,
                getState: E,
                subscribe: i => (r.add(i), () => r.delete(i)),
                destroy: () => {
                    (y ? "production" : void 0) !== "production" && console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."), r.clear()
                }
            };
        return t = e(n, E, c), c
    },
    h = e => e ? v(e) : v;
var M = {
        exports: {}
    },
    C = {},
    A = {
        exports: {}
    },
    L = {};
/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var I = S;

function D(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var w = typeof Object.is == "function" ? Object.is : D,
    U = I.useState,
    b = I.useEffect,
    P = I.useLayoutEffect,
    x = I.useDebugValue;

function H(e, t) {
    var r = t(),
        n = U({
            inst: {
                value: r,
                getSnapshot: t
            }
        }),
        E = n[0].inst,
        s = n[1];
    return P(function() {
        E.value = r, E.getSnapshot = t, V(E) && s({
            inst: E
        })
    }, [e, r, t]), b(function() {
        return V(E) && s({
            inst: E
        }), e(function() {
            V(E) && s({
                inst: E
            })
        })
    }, [e]), x(r), r
}

function V(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var r = t();
        return !w(e, r)
    } catch {
        return !0
    }
}

function N(e, t) {
    return t()
}
var j = typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u" ? N : H;
L.useSyncExternalStore = I.useSyncExternalStore !== void 0 ? I.useSyncExternalStore : j;
A.exports = L;
var W = A.exports;
/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l = S,
    $ = W;

function B(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var Y = typeof Object.is == "function" ? Object.is : B,
    z = $.useSyncExternalStore,
    F = l.useRef,
    q = l.useEffect,
    k = l.useMemo,
    J = l.useDebugValue;
C.useSyncExternalStoreWithSelector = function(e, t, r, n, E) {
    var s = F(null);
    if (s.current === null) {
        var u = {
            hasValue: !1,
            value: null
        };
        s.current = u
    } else u = s.current;
    s = k(function() {
        function i(_) {
            if (!p) {
                if (p = !0, o = _, _ = n(_), E !== void 0 && u.hasValue) {
                    var T = u.value;
                    if (E(T, _)) return a = T
                }
                return a = _
            }
            if (T = a, Y(o, _)) return T;
            var R = n(_);
            return E !== void 0 && E(T, R) ? T : (o = _, a = R)
        }
        var p = !1,
            o, a, d = r === void 0 ? null : r;
        return [function() {
            return i(t())
        }, d === null ? void 0 : function() {
            return i(d())
        }]
    }, [t, r, n, E]);
    var c = z(e, s[0], s[1]);
    return q(function() {
        u.hasValue = !0, u.value = c
    }, [c]), J(c), c
};
M.exports = C;
var K = M.exports;
const Q = m(K);
var O = {
    VITE_META_TITLE: "Uprising™ | Digital creative production company",
    VITE_META_KEYWORDS: "uprising, digital, creative, production, company",
    VITE_META_DESCRIPTION: "Uprising™ is a digital creative production studio based in Milan, Italy. We are designers, we are developers, we are Uprising™",
    VITE_META_SITE: "https://uprsg-site-v2.vercel.app",
    VITE_META_TYPE: "website",
    VITE_META_CARD: "summary_large_image",
    VITE_META_IMAGE: "https://uprsg-site-v2.vercel.app/assets/images/uprising-share.png",
    VITE_META_IMAGE_WIDTH: "1200",
    VITE_META_IMAGE_HEIGHT: "630",
    VITE_META_IMAGE_TYPE: "image/png",
    VITE_META_THEME_COLOR: "#000000",
    VITE_BASE_URL: "/",
    VITE_VERCEL_GIT_REPO_ID: "57900005",
    VITE_VERCEL_ENV: "production",
    VITE_VERCEL_GIT_PULL_REQUEST_ID: "",
    VITE_VERCEL_BRANCH_URL: "uprsg-site-v2-git-develop-studiogustos-projects.vercel.app",
    VITE_VERCEL_GIT_COMMIT_SHA: "b71ea8372beb8c54c63fc7a4aa7e9ddfac0393dd",
    VITE_VERCEL_URL: "uprsg-site-v2-9g4415z49-studiogustos-projects.vercel.app",
    VITE_VERCEL_GIT_COMMIT_AUTHOR_NAME: "Mauro Piccin",
    VITE_VERCEL_GIT_PREVIOUS_SHA: "",
    VITE_VERCEL_PROJECT_PRODUCTION_URL: "www.weareuprising.com",
    VITE_VERCEL_GIT_REPO_OWNER: "gustoids-dev",
    VITE_VERCEL_GIT_COMMIT_AUTHOR_LOGIN: "mpcreativedev",
    VITE_VERCEL_GIT_PROVIDER: "gitlab",
    VITE_VERCEL_GIT_COMMIT_REF: "develop",
    VITE_VERCEL_GIT_REPO_SLUG: "uprsg-site-v2",
    VITE_VERCEL_GIT_COMMIT_MESSAGE: `Merge branch 'next' into develop
`,
    BASE_URL: "/",
    MODE: "production",
    DEV: !1,
    PROD: !0,
    SSR: !1
};
const {
    useDebugValue: X
} = G, {
    useSyncExternalStoreWithSelector: Z
} = Q;
let g = !1;

function ee(e, t = e.getState, r) {
    (O ? "production" : void 0) !== "production" && r && !g && (console.warn("[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"), g = !0);
    const n = Z(e.subscribe, e.getState, e.getServerState || e.getState, t, r);
    return X(n), n
}
const f = e => {
        (O ? "production" : void 0) !== "production" && typeof e != "function" && console.warn("[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`.");
        const t = typeof e == "function" ? h(e) : e,
            r = (n, E) => ee(t, n, E);
        return Object.assign(r, t), r
    },
    re = e => e ? f(e) : f;
export {
    re as c
};